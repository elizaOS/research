"""Generate or verify the frozen scale-robust pair-feature evidence artifact.

Generation intentionally exposes no seed, configuration, or threshold tuning
flags.  The only executable schedule is the promoted evidence set 30--59::

    python -m alberta_framework.evaluation.scale_robust_feature_cli \
        --output outputs/scale_robust_feature/evidence.json

Verification never executes the scientific protocol::

    python -m alberta_framework.evaluation.scale_robust_feature_cli \
        --verify outputs/scale_robust_feature/evidence.json
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from pathlib import Path

from alberta_framework.evaluation.scale_robust_feature import (
    EVIDENCE_SEEDS,
    ScaleRobustFeatureReport,
    run_scale_robust_feature_evaluation,
)
from alberta_framework.evaluation.scale_robust_feature_artifact import (
    artifact_json,
    build_evidence_artifact,
    load_evidence_artifact,
    validate_evidence_artifact,
)

DEFAULT_OUTPUT = Path("outputs/scale_robust_feature/evidence.json")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Generate or verify the frozen exhaustive-pair scale-robustness evidence artifact."
        )
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--verify",
        type=Path,
        help="validate an existing artifact without running the protocol",
    )
    return parser


def _emit(payload: dict[str, object]) -> None:
    sys.stdout.write(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n"
    )


def _verify(path: Path) -> int:
    try:
        artifact = load_evidence_artifact(path)
        validation = validate_evidence_artifact(artifact)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        _emit(
            {
                "accepted": False,
                "artifact": str(path),
                "errors": [str(error)],
                "valid": False,
            }
        )
        return 2
    _emit(
        {
            "accepted": validation.accepted,
            "artifact": str(path),
            "errors": list(validation.errors),
            "valid": validation.valid,
        }
    )
    return 0 if validation.accepted else 1


def main(
    argv: Sequence[str] | None = None,
    *,
    report: ScaleRobustFeatureReport | None = None,
) -> int:
    """Generate the canonical evidence artifact or verify an existing one.

    ``report`` is an injection seam for synthetic tests.  Production CLI use
    cannot alter the evidence seed schedule, learner configurations, windows,
    bootstrap policy, or frozen thresholds.
    """

    args = _parser().parse_args(argv)
    if args.verify is not None:
        return _verify(args.verify)

    evidence_report = run_scale_robust_feature_evaluation() if report is None else report
    if evidence_report.seeds != EVIDENCE_SEEDS:
        _emit(
            {
                "accepted": False,
                "errors": ["report seed schedule must be the frozen evidence seeds 30-59"],
                "valid": False,
            }
        )
        return 2

    try:
        artifact = build_evidence_artifact(evidence_report)
        validation = validate_evidence_artifact(artifact)
        serialized = artifact_json(artifact)
    except (OSError, RuntimeError, ValueError) as error:
        _emit(
            {
                "accepted": False,
                "errors": [str(error)],
                "valid": False,
            }
        )
        return 2

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(serialized, encoding="utf-8")
    digest_record = artifact["content_digest"]
    digest = digest_record.get("sha256") if isinstance(digest_record, dict) else None
    _emit(
        {
            "accepted": validation.accepted,
            "artifact": str(args.output),
            "content_sha256": digest,
            "errors": list(validation.errors),
            "schema_version": artifact["schema_version"],
            "seed_count": len(evidence_report.seeds),
            "valid": validation.valid,
        }
    )
    return 0 if validation.accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
