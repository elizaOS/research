"""Machine-readable status index for promoted continual-learning evidence.

This module does not reinterpret scientific results and does not trust file
presence.  It invokes each versioned artifact's strict loader and validator,
then records one of four statuses:

``accepted``
    The artifact is internally valid and passed its frozen scientific gate.
``valid-rejection``
    The artifact is internally valid but failed at least one frozen gate.
``not-run``
    The expected artifact is absent.
``invalid``
    The file cannot be parsed or its validator rejects its integrity/schema.

The index is operational metadata, not a new scientific artifact or signature.
Its SHA-256 fields identify the exact artifact bytes that were inspected.
An overall accepted status means only that every *listed narrow gate* passed;
it is explicitly not an Alberta Plan completion certificate.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from alberta_framework.evaluation.continual_ia_artifact import (
    SCHEMA_VERSION as IA_SCHEMA_VERSION,
)
from alberta_framework.evaluation.continual_ia_artifact import (
    load_ia_evidence_artifact,
    validate_ia_evidence_artifact,
)
from alberta_framework.evaluation.continual_multiagent_artifact import (
    SCHEMA_VERSION as MULTIAGENT_SCHEMA_VERSION,
)
from alberta_framework.evaluation.continual_multiagent_artifact import (
    load_evidence_artifact as load_multiagent_artifact,
)
from alberta_framework.evaluation.continual_multiagent_artifact import (
    validate_evidence_artifact as validate_multiagent_artifact,
)
from alberta_framework.evaluation.ftl_decision_artifact import (
    SCHEMA_VERSION as FTL_SCHEMA_VERSION,
)
from alberta_framework.evaluation.ftl_decision_artifact import (
    load_ftl_decision_artifact,
    validate_ftl_decision_artifact,
)
from alberta_framework.evaluation.recurring_feature_artifact import (
    SCHEMA_VERSION as RECURRING_FEATURE_SCHEMA_VERSION,
)
from alberta_framework.evaluation.recurring_feature_artifact import (
    load_recurring_feature_artifact,
    validate_recurring_feature_artifact,
)
from alberta_framework.evaluation.scale_robust_feature_artifact import (
    SCHEMA_VERSION as SCALE_ROBUST_SCHEMA_VERSION,
)
from alberta_framework.evaluation.scale_robust_feature_artifact import (
    load_evidence_artifact as load_scale_robust_artifact,
)
from alberta_framework.evaluation.scale_robust_feature_artifact import (
    validate_evidence_artifact as validate_scale_robust_artifact,
)

MANIFEST_SCHEMA_VERSION = "alberta.evidence_index.v1"
REPO_ROOT = Path(__file__).resolve().parents[2]


class ValidationResult(Protocol):
    """Common result surface implemented by all promoted validators."""

    @property
    def valid(self) -> bool:
        """Whether parsing, schema, provenance, and reconstruction passed."""

    @property
    def accepted(self) -> bool:
        """Whether the valid artifact also passed its frozen scientific gate."""

    @property
    def errors(self) -> tuple[str, ...]:
        """Fail-closed validation errors."""


@dataclass(frozen=True)
class EvidenceSpec:
    """One immutable promoted-artifact lane."""

    name: str
    relative_path: Path
    expected_schema: str
    evidence_level: str
    narrow_claim: str
    generate_command: str
    loader: Callable[[Path], Mapping[str, object]]
    validator: Callable[[Mapping[str, object]], ValidationResult]


EVIDENCE_SPECS: tuple[EvidenceSpec, ...] = (
    EvidenceSpec(
        name="recurring_pair_features",
        relative_path=Path("outputs/recurring_feature/evidence.v1.json"),
        expected_schema=RECURRING_FEATURE_SCHEMA_VERSION,
        evidence_level="L2 narrow comparison",
        narrow_claim=(
            "fixed-budget active pair-bank retention and obsolete-bank eviction "
            "on the frozen supplied-head recurring-feature protocol"
        ),
        generate_command=(
            "python -m alberta_framework.evaluation.recurring_feature_cli "
            "--output outputs/recurring_feature/evidence.v1.json"
        ),
        loader=load_recurring_feature_artifact,
        validator=validate_recurring_feature_artifact,
    ),
    EvidenceSpec(
        name="scale_robust_pair_features",
        relative_path=Path("outputs/scale_robust_feature/evidence.v1.json"),
        expected_schema=SCALE_ROBUST_SCHEMA_VERSION,
        evidence_level="L2 narrow comparison",
        narrow_claim=(
            "scale-robust exhaustive pair-feature selection on the frozen "
            "gauntlet with matched legacy and retention ablations"
        ),
        generate_command=(
            "python -m alberta_framework.evaluation.scale_robust_feature_cli "
            "--output outputs/scale_robust_feature/evidence.v1.json"
        ),
        loader=load_scale_robust_artifact,
        validator=validate_scale_robust_artifact,
    ),
    EvidenceSpec(
        name="ftl_world_model_decision_fidelity",
        relative_path=Path("outputs/ftl_decision/evidence.v1.json"),
        expected_schema=FTL_SCHEMA_VERSION,
        evidence_level="L2 narrow comparison",
        narrow_claim=(
            "known-reward open-loop menu decision fidelity for the frozen "
            "deterministic sparse lifetime-statistics world-model protocol"
        ),
        generate_command=(
            "python -m alberta_framework.evaluation.ftl_decision_cli "
            "--output outputs/ftl_decision/evidence.v1.json"
        ),
        loader=load_ftl_decision_artifact,
        validator=validate_ftl_decision_artifact,
    ),
    EvidenceSpec(
        name="recurring_multiagent_coadaptation",
        relative_path=Path("outputs/continual_multiagent/evidence.json"),
        expected_schema=MULTIAGENT_SCHEMA_VERSION,
        evidence_level="L2 narrow comparison",
        narrow_claim=(
            "visibly cued fixed-memory two-agent coadaptation and recurrence "
            "on the frozen A-B-A micro-benchmark"
        ),
        generate_command=(
            "python -m alberta_framework.evaluation.continual_multiagent_cli "
            "--output outputs/continual_multiagent/evidence.json"
        ),
        loader=load_multiagent_artifact,
        validator=validate_multiagent_artifact,
    ),
    EvidenceSpec(
        name="continual_intelligence_amplification",
        relative_path=Path("outputs/continual_ia/evidence.json"),
        expected_schema=IA_SCHEMA_VERSION,
        evidence_level="L2 promoted negative result",
        narrow_claim=(
            "causal recommendation and prediction-augmentation effects on the "
            "frozen hidden-phase partner micro-benchmark"
        ),
        generate_command=(
            "python -m alberta_framework.evaluation.continual_ia_cli "
            "--output outputs/continual_ia/evidence.json"
        ),
        loader=load_ia_evidence_artifact,
        validator=validate_ia_evidence_artifact,
    ),
)


def _artifact_digest(artifact: Mapping[str, object]) -> str | None:
    """Extract a validator-bound scientific/content digest when present."""

    for key in ("scientific_digest", "content_digest"):
        record = artifact.get(key)
        if not isinstance(record, Mapping):
            continue
        value = record.get("sha256")
        if (
            isinstance(value, str)
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value)
        ):
            return value
    return None


def _inspect_spec(root: Path, spec: EvidenceSpec) -> dict[str, object]:
    path = root / spec.relative_path
    common: dict[str, object] = {
        "name": spec.name,
        "path": spec.relative_path.as_posix(),
        "expected_schema_version": spec.expected_schema,
        "evidence_level": spec.evidence_level,
        "narrow_claim": spec.narrow_claim,
        "generate_command": spec.generate_command,
    }
    if not path.is_file():
        return {
            **common,
            "status": "not-run",
            "present": False,
            "valid": False,
            "accepted": False,
            "errors": ["artifact is absent"],
            "artifact_bytes_sha256": None,
            "scientific_or_content_sha256": None,
        }

    raw_bytes: bytes | None = None
    try:
        raw_bytes = path.read_bytes()
        artifact = spec.loader(path)
        validation = spec.validator(artifact)
    except (
        KeyError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
        json.JSONDecodeError,
    ) as error:
        return {
            **common,
            "status": "invalid",
            "present": True,
            "valid": False,
            "accepted": False,
            "errors": [str(error)],
            "artifact_bytes_sha256": (
                hashlib.sha256(raw_bytes).hexdigest()
                if raw_bytes is not None
                else None
            ),
            "scientific_or_content_sha256": None,
        }

    schema = artifact.get("schema_version")
    schema_matches = schema == spec.expected_schema
    errors = list(validation.errors)
    if not schema_matches:
        errors.append(
            "manifest registry expected schema "
            f"{spec.expected_schema!r}, observed {schema!r}"
        )
    valid = validation.valid and schema_matches
    accepted = valid and validation.accepted
    return {
        **common,
        "status": "accepted" if accepted else ("valid-rejection" if valid else "invalid"),
        "present": True,
        "valid": valid,
        "accepted": accepted,
        "errors": errors,
        "observed_schema_version": schema,
        "artifact_bytes_sha256": hashlib.sha256(raw_bytes).hexdigest(),
        "scientific_or_content_sha256": _artifact_digest(artifact),
    }


def build_evidence_manifest(
    root: Path = REPO_ROOT,
    *,
    specs: Sequence[EvidenceSpec] = EVIDENCE_SPECS,
) -> dict[str, object]:
    """Validate every registered artifact and return the operational index."""

    if not specs:
        raise ValueError("at least one evidence specification is required")
    names = tuple(spec.name for spec in specs)
    paths = tuple(spec.relative_path for spec in specs)
    if len(set(names)) != len(names):
        raise ValueError("evidence specification names must be unique")
    if len(set(paths)) != len(paths):
        raise ValueError("evidence specification paths must be unique")
    for path in paths:
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("evidence specification paths must remain under root")

    resolved_root = root.resolve()
    records = [_inspect_spec(resolved_root, spec) for spec in specs]
    statuses = [str(record["status"]) for record in records]
    all_present = all(bool(record["present"]) for record in records)
    all_valid = all(bool(record["valid"]) for record in records)
    all_accepted = all(bool(record["accepted"]) for record in records)
    if "invalid" in statuses:
        overall_status = "invalid"
    elif "not-run" in statuses:
        overall_status = "not-run"
    elif all_accepted:
        overall_status = "accepted"
    else:
        overall_status = "valid-rejection"

    return {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "root": str(resolved_root),
        "interpretation": (
            "operational index of strict narrow-artifact validators; not a "
            "scientific artifact, signature, or Alberta Plan completion certificate"
        ),
        "overall_status": overall_status,
        "all_required_present": all_present,
        "all_required_valid": all_valid,
        "all_required_accepted": all_accepted,
        "artifact_count": len(records),
        "artifacts": records,
    }


def evidence_manifest_exit_code(manifest: Mapping[str, object]) -> int:
    """Return 0 accepted, 1 not-run/valid rejection, or 2 invalid."""

    status = manifest.get("overall_status")
    if status == "accepted":
        return 0
    if status in {"not-run", "valid-rejection"}:
        return 1
    return 2


def evidence_manifest_json(manifest: Mapping[str, object]) -> str:
    """Serialize the status index as strict, stable JSON."""

    return (
        json.dumps(
            manifest,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    )


__all__ = [
    "EVIDENCE_SPECS",
    "MANIFEST_SCHEMA_VERSION",
    "REPO_ROOT",
    "EvidenceSpec",
    "ValidationResult",
    "build_evidence_manifest",
    "evidence_manifest_exit_code",
    "evidence_manifest_json",
]
