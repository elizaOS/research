"""CLI for the frozen recurring pair-feature evidence artifact.

Run promoted evidence with::

    python -m alberta_framework.evaluation.recurring_feature_cli \
        --output outputs/recurring_feature/evidence.v1.json

Generation intentionally exposes no seed, protocol, or threshold tuning
options.  The only promoted run is the preregistered 30--59 seed schedule.
Verification never reruns or retunes the experiment.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path
from time import perf_counter

from alberta_framework.evaluation.recurring_feature_artifact import (
    load_recurring_feature_artifact,
    validate_recurring_feature_artifact,
    write_recurring_feature_artifact,
)
from alberta_framework.recurring_feature_gate import (
    RecurringFeatureGateResult,
    run_recurring_feature_gate,
)

DEFAULT_OUTPUT = Path("outputs/recurring_feature/evidence.v1.json")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=("Run or verify the frozen Gaussian/L2 recurring pair-feature gate.")
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--verify",
        type=Path,
        help="strictly validate an existing artifact without rerunning the gate",
    )
    return parser


def _emit(payload: dict[str, object]) -> None:
    sys.stdout.write(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n"
    )


def _verify(path: Path) -> int:
    try:
        artifact = load_recurring_feature_artifact(path)
        validation = validate_recurring_feature_artifact(artifact)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        _emit(
            {
                "accepted": False,
                "artifact": str(path),
                "errors": [str(error)],
                "valid": False,
            }
        )
        return 2
    _emit(
        {
            "accepted": validation.accepted,
            "artifact": str(path),
            "errors": list(validation.errors),
            "valid": validation.valid,
        }
    )
    return 0 if validation.accepted else (1 if validation.valid else 2)


def main(
    argv: Sequence[str] | None = None,
    *,
    result: RecurringFeatureGateResult | None = None,
    gate_wall_seconds: float | None = None,
    generated_at: datetime | None = None,
) -> int:
    """Generate frozen evidence or verify a file; injection keeps tests cheap."""

    args = _parser().parse_args(argv)
    if args.verify is not None:
        return _verify(args.verify)

    try:
        if result is None:
            started = perf_counter()
            evidence_result = run_recurring_feature_gate()
            elapsed = perf_counter() - started
        else:
            evidence_result = result
            elapsed = 0.0 if gate_wall_seconds is None else gate_wall_seconds
        artifact = write_recurring_feature_artifact(
            args.output,
            evidence_result,
            gate_wall_seconds=elapsed,
            generated_at=generated_at,
        )
        validation = validate_recurring_feature_artifact(artifact)
    except (OSError, RuntimeError, ValueError) as error:
        _emit(
            {
                "accepted": False,
                "artifact": str(args.output),
                "errors": [str(error)],
                "valid": False,
            }
        )
        return 2

    digest = artifact["scientific_digest"]
    digest_value = digest.get("sha256") if isinstance(digest, dict) else None
    scientific = artifact["scientific_payload"]
    aggregate = scientific.get("aggregate") if isinstance(scientific, dict) else None
    seed_count = aggregate.get("seed_count") if isinstance(aggregate, dict) else None
    _emit(
        {
            "accepted": validation.accepted,
            "artifact": str(args.output),
            "errors": list(validation.errors),
            "schema_version": artifact["schema_version"],
            "scientific_sha256": digest_value,
            "seed_count": seed_count,
            "valid": validation.valid,
        }
    )
    return 0 if validation.accepted else (1 if validation.valid else 2)


if __name__ == "__main__":
    raise SystemExit(main())
