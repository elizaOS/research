"""Frozen scale-robust exhaustive-pair feature evaluation.

This module contains the executable protocol behind the v1 evidence artifact.
The protocol is deliberately narrow: it evaluates an exhaustive degree-two
pair archive on the nine-segment Alberta gauntlet with a visible, supplied
two-coordinate task cue.  It does not evaluate open-ended or general feature
discovery.

Development used integer seed identifiers 8--15.  The promoted evidence
schedule is the disjoint, frozen set 30--59.  Each identifier maps directly to
``jax.random.key(seed_id)``; every arm and seed independently initializes the
learner with ``jax.random.key(123)``.
"""

from __future__ import annotations

import dataclasses
import math
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import jax
import jax.numpy as jnp
import jax.random as jr
import numpy as np
from jax import Array
from numpy.typing import NDArray

from alberta_framework.core.interaction_features import (
    FixedBudgetInteractionLearner,
)
from alberta_framework.streams.gauntlet import (
    SEGMENT_NAMES,
    GauntletConfig,
    GauntletStream,
)

DEVELOPMENT_SEEDS = tuple(range(8, 16))
EVIDENCE_SEEDS = tuple(range(30, 60))
LEARNER_INIT_SEED = 123

CONDITION_PRIMARY = "scale_robust_retained"
CONDITION_LEGACY = "legacy_retained"
CONDITION_NO_RETENTION = "scale_robust_no_retention"
CONDITION_NAMES = (
    CONDITION_PRIMARY,
    CONDITION_LEGACY,
    CONDITION_NO_RETENTION,
)

EARLY_WINDOW_STEPS = 200
TAIL_WINDOW_STEPS = 500
ASYMPTOTIC_WINDOW_STEPS = 1_500

FROZEN_STREAM_CONFIGURATION: dict[str, int | float] = {
    "relevant_dim": 8,
    "irrelevant_dim": 4,
    "segment_length": 3_000,
    "noise_std": 0.1,
    "feature_std": 1.0,
    "scale_factor": 10.0,
    "drift_rate": 0.01,
    "context_noise_std": 0.05,
}

_COMMON_LEARNER_CONFIGURATION: dict[str, object] = {
    "n_features": 24,
    "n_tasks": 1,
    "step_size_output": 0.03,
    "utility_decay": 0.995,
    "replacement_interval": 100,
    "min_feature_age": 50,
    "candidate_count": 91,
    "candidate_min_age": 25,
    "promotion_margin": 1.05,
    "promotion_blend": 1.0,
    "generator_mix": [1.0, 0.0, 0.0],
    "candidate_strategy": "all_pairs",
    "utility_aggregation": "mean",
    "utility_top_k": 1,
    "utility_task_balancing": "none",
    "task_activity_decay": 0.995,
    "future_utility_mix": 0.0,
    "candidate_utility_retention_decay": None,
    "refresh_candidates": False,
    "refresh_promoted_candidate": False,
    "include_squares": False,
    "obgd_kappa": 2.0,
    "scale_normalizer_decay": 0.99,
    "scale_normalizer_epsilon": 1e-6,
}


def _condition_configuration(
    *,
    retention: float | None,
    scale_robust: bool,
    use_obgd: bool,
) -> dict[str, object]:
    configuration = dict(_COMMON_LEARNER_CONFIGURATION)
    configuration.update(
        {
            "utility_retention_decay": retention,
            "use_obgd": use_obgd,
            "scale_robust": scale_robust,
        }
    )
    return configuration


FROZEN_CONDITION_CONFIGURATIONS: dict[str, dict[str, object]] = {
    CONDITION_PRIMARY: _condition_configuration(
        retention=0.9999,
        scale_robust=True,
        use_obgd=False,
    ),
    CONDITION_LEGACY: _condition_configuration(
        retention=0.9999,
        scale_robust=False,
        use_obgd=True,
    ),
    CONDITION_NO_RETENTION: _condition_configuration(
        retention=None,
        scale_robust=True,
        use_obgd=False,
    ),
}

EXPECTED_MEMORY: dict[str, dict[str, int | bool]] = {
    CONDITION_PRIMARY: {
        "active_pair_slots": 24,
        "candidate_archive_slots": 91,
        "candidate_archive_is_counted": True,
        "active_pair_descriptor_scalars": 48,
        "candidate_pair_descriptor_scalars": 182,
        "active_output_weight_scalars": 24,
        "candidate_output_weight_scalars": 91,
        "normalizer_scalars": 116,
        "normalizer_bytes": 464,
        "persistent_array_bytes": 4_164,
    },
    CONDITION_LEGACY: {
        "active_pair_slots": 24,
        "candidate_archive_slots": 91,
        "candidate_archive_is_counted": True,
        "active_pair_descriptor_scalars": 48,
        "candidate_pair_descriptor_scalars": 182,
        "active_output_weight_scalars": 24,
        "candidate_output_weight_scalars": 91,
        "normalizer_scalars": 0,
        "normalizer_bytes": 0,
        "persistent_array_bytes": 3_700,
    },
    CONDITION_NO_RETENTION: {
        "active_pair_slots": 24,
        "candidate_archive_slots": 91,
        "candidate_archive_is_counted": True,
        "active_pair_descriptor_scalars": 48,
        "candidate_pair_descriptor_scalars": 182,
        "active_output_weight_scalars": 24,
        "candidate_output_weight_scalars": 91,
        "normalizer_scalars": 116,
        "normalizer_bytes": 464,
        "persistent_array_bytes": 4_164,
    },
}


@dataclass(frozen=True)
class PhaseWindowRecord:
    """Sufficient prequential-error statistics for one 3,000-step phase."""

    phase_index: int
    phase_name: str
    step_count: int
    nonfinite_steps: int
    early_squared_error_sum: float | None
    early_count: int
    tail_squared_error_sum: float | None
    tail_count: int
    asymptotic_squared_error_sum: float | None
    asymptotic_count: int


@dataclass(frozen=True)
class ConditionSeedRecord:
    """Primitive record for one paired seed and one learner condition."""

    seed: int
    condition: str
    phases: tuple[PhaseWindowRecord, ...]
    end_segment_5_active_pairs: tuple[tuple[int, int], ...]
    final_active_pairs: tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class ScaleRobustFeatureReport:
    """Complete deterministic results plus host-dependent run timing."""

    seeds: tuple[int, ...]
    records: tuple[ConditionSeedRecord, ...]
    memory_by_condition: Mapping[str, Mapping[str, int | bool]]
    wall_time_seconds_by_condition: Mapping[str, float]


def frozen_stream_config() -> GauntletConfig:
    """Construct the explicit v1 stream and detect upstream default drift."""

    defaults = dataclasses.asdict(GauntletConfig())
    if defaults != FROZEN_STREAM_CONFIGURATION:
        raise RuntimeError("GauntletConfig defaults no longer match the frozen v1 protocol")
    return GauntletConfig(
        relevant_dim=8,
        irrelevant_dim=4,
        segment_length=3_000,
        noise_std=0.1,
        feature_std=1.0,
        scale_factor=10.0,
        drift_rate=0.01,
        context_noise_std=0.05,
    )


def make_condition_learner(condition: str) -> FixedBudgetInteractionLearner:
    """Construct one exact frozen learner arm."""

    if condition not in FROZEN_CONDITION_CONFIGURATIONS:
        raise ValueError(f"unknown condition: {condition!r}")
    retention = None if condition == CONDITION_NO_RETENTION else 0.9999
    scale_robust = condition != CONDITION_LEGACY
    use_obgd = condition == CONDITION_LEGACY
    learner = FixedBudgetInteractionLearner(
        n_features=24,
        n_tasks=1,
        step_size_output=0.03,
        utility_decay=0.995,
        replacement_interval=100,
        min_feature_age=50,
        candidate_count=91,
        candidate_min_age=25,
        promotion_margin=1.05,
        promotion_blend=1.0,
        generator_mix=(1.0, 0.0, 0.0),
        candidate_strategy="all_pairs",
        utility_aggregation="mean",
        utility_top_k=1,
        utility_task_balancing="none",
        task_activity_decay=0.995,
        future_utility_mix=0.0,
        utility_retention_decay=retention,
        candidate_utility_retention_decay=None,
        refresh_candidates=False,
        refresh_promoted_candidate=False,
        include_squares=False,
        use_obgd=use_obgd,
        obgd_kappa=2.0,
        scale_robust=scale_robust,
        scale_normalizer_decay=0.99,
        scale_normalizer_epsilon=1e-6,
    )
    observed = learner.to_config()
    expected = {
        "type": "FixedBudgetInteractionLearner",
        **FROZEN_CONDITION_CONFIGURATIONS[condition],
    }
    if observed != expected:
        raise RuntimeError(f"{condition} constructor no longer matches its frozen v1 configuration")
    return learner


def count_relevant_context_pairs(
    pairs: Sequence[tuple[int, int]],
    *,
    relevant_dim: int = 8,
    input_dim: int = 12,
) -> int:
    """Count active products joining a context coordinate to relevant input."""

    return sum(
        1
        for left, right in pairs
        if ((left >= input_dim) ^ (right >= input_dim)) and min(left, right) < relevant_dim
    )


def _finite_window_sum(values: NDArray[np.floating[Any]]) -> float | None:
    if not bool(np.all(np.isfinite(values))):
        return None
    total = float(np.sum(values, dtype=np.float64))
    return total if math.isfinite(total) else None


def phase_window_records(
    squared_errors: NDArray[np.floating[Any]],
    config: GauntletConfig,
) -> tuple[PhaseWindowRecord, ...]:
    """Reduce one per-step trace to the exact windows used by the v1 gate."""

    errors = np.asarray(squared_errors)
    if config.segment_length < ASYMPTOTIC_WINDOW_STEPS:
        raise ValueError("segment_length must cover the frozen 1,500-step asymptotic window")
    if errors.shape != (config.num_steps,):
        raise ValueError(
            f"squared_errors must have shape {(config.num_steps,)}, got {errors.shape}"
        )
    records: list[PhaseWindowRecord] = []
    for phase_index, phase_name in enumerate(SEGMENT_NAMES):
        start = phase_index * config.segment_length
        phase = errors[start : start + config.segment_length]
        early = phase[:EARLY_WINDOW_STEPS]
        tail = phase[-TAIL_WINDOW_STEPS:]
        asymptotic = phase[-ASYMPTOTIC_WINDOW_STEPS:]
        records.append(
            PhaseWindowRecord(
                phase_index=phase_index,
                phase_name=phase_name,
                step_count=config.segment_length,
                nonfinite_steps=int(np.count_nonzero(~np.isfinite(phase))),
                early_squared_error_sum=_finite_window_sum(early),
                early_count=EARLY_WINDOW_STEPS,
                tail_squared_error_sum=_finite_window_sum(tail),
                tail_count=TAIL_WINDOW_STEPS,
                asymptotic_squared_error_sum=_finite_window_sum(asymptotic),
                asymptotic_count=ASYMPTOTIC_WINDOW_STEPS,
            )
        )
    return tuple(records)


def _canonical_pairs(
    left: NDArray[np.integer[Any]],
    right: NDArray[np.integer[Any]],
) -> tuple[tuple[int, int], ...]:
    pairs = tuple(
        (int(left_value), int(right_value))
        for left_value, right_value in zip(left.tolist(), right.tolist(), strict=True)
    )
    return pairs


def _run_condition(
    condition: str,
    seeds: tuple[int, ...],
    stream: GauntletStream,
) -> tuple[
    tuple[ConditionSeedRecord, ...],
    dict[str, int | bool],
    float,
]:
    learner = make_condition_learner(condition)
    initial_state = learner.init(stream.feature_dim, jr.key(LEARNER_INIT_SEED))
    memory = learner.memory_accounting(initial_state)
    keys = jnp.stack([jr.key(seed) for seed in seeds])
    snapshot_step = 6 * stream.config.segment_length - 1

    def one_seed(
        key: Array,
    ) -> tuple[Array, Array, Array, Array, Array]:
        learner_state = learner.init(
            stream.feature_dim,
            jr.key(LEARNER_INIT_SEED),
        )
        stream_state = stream.init(key)
        snapshot_left = jnp.zeros_like(learner_state.feature_left)
        snapshot_right = jnp.zeros_like(learner_state.feature_right)

        def step_fn(
            carry: tuple[Any, Any, Array, Array],
            index: Array,
        ) -> tuple[tuple[Any, Any, Array, Array], Array]:
            state, gauntlet_state, saved_left, saved_right = carry
            timestep, next_gauntlet_state = stream.step(gauntlet_state, index)
            result = learner.update(
                state,
                timestep.observation,
                timestep.target,
            )
            capture = index == snapshot_step
            saved_left = jnp.where(
                capture,
                result.state.feature_left,
                saved_left,
            )
            saved_right = jnp.where(
                capture,
                result.state.feature_right,
                saved_right,
            )
            squared_error = jnp.squeeze(result.errors) ** 2
            return (
                result.state,
                next_gauntlet_state,
                saved_left,
                saved_right,
            ), squared_error

        (final_state, _, saved_left, saved_right), squared_errors = jax.lax.scan(
            step_fn,
            (
                learner_state,
                stream_state,
                snapshot_left,
                snapshot_right,
            ),
            jnp.arange(stream.config.num_steps),
        )
        return (
            squared_errors,
            saved_left,
            saved_right,
            final_state.feature_left,
            final_state.feature_right,
        )

    started = time.perf_counter()
    squared_errors, end_left, end_right, final_left, final_right = jax.vmap(one_seed)(keys)
    (
        squared_errors,
        end_left,
        end_right,
        final_left,
        final_right,
    ) = jax.device_get(
        (
            squared_errors,
            end_left,
            end_right,
            final_left,
            final_right,
        )
    )
    elapsed = time.perf_counter() - started

    squared_errors_np = np.asarray(squared_errors)
    end_left_np = np.asarray(end_left)
    end_right_np = np.asarray(end_right)
    final_left_np = np.asarray(final_left)
    final_right_np = np.asarray(final_right)
    records: list[ConditionSeedRecord] = []
    for index, seed in enumerate(seeds):
        records.append(
            ConditionSeedRecord(
                seed=seed,
                condition=condition,
                phases=phase_window_records(
                    squared_errors_np[index],
                    stream.config,
                ),
                end_segment_5_active_pairs=_canonical_pairs(
                    end_left_np[index],
                    end_right_np[index],
                ),
                final_active_pairs=_canonical_pairs(
                    final_left_np[index],
                    final_right_np[index],
                ),
            )
        )
    return tuple(records), memory, elapsed


def run_scale_robust_feature_evaluation(
    *,
    seeds: Sequence[int] = EVIDENCE_SEEDS,
) -> ScaleRobustFeatureReport:
    """Run the three paired frozen arms in one uninterrupted life per seed.

    The public default is the promoted 30--59 schedule.  Alternate schedules
    are useful only for development diagnostics; the v1 evidence validator
    will not accept them.
    """

    seed_schedule = tuple(int(seed) for seed in seeds)
    if not seed_schedule:
        raise ValueError("seeds must be non-empty")
    if len(set(seed_schedule)) != len(seed_schedule):
        raise ValueError("seeds must be unique")
    if any(seed < 0 for seed in seed_schedule):
        raise ValueError("seeds must be non-negative")

    stream = GauntletStream(frozen_stream_config())
    records: list[ConditionSeedRecord] = []
    memory_by_condition: dict[str, Mapping[str, int | bool]] = {}
    wall_times: dict[str, float] = {}
    for condition in CONDITION_NAMES:
        condition_records, memory, elapsed = _run_condition(
            condition,
            seed_schedule,
            stream,
        )
        records.extend(condition_records)
        memory_by_condition[condition] = memory
        wall_times[condition] = elapsed
    return ScaleRobustFeatureReport(
        seeds=seed_schedule,
        records=tuple(records),
        memory_by_condition=memory_by_condition,
        wall_time_seconds_by_condition=wall_times,
    )


def frozen_configuration_payload() -> dict[str, object]:
    """Return a fresh JSON-compatible copy of the complete v1 configuration."""

    return {
        "stream": dict(FROZEN_STREAM_CONFIGURATION),
        "seed_key_derivation": "jax.random.key(seed_id)",
        "learner_init_seed": LEARNER_INIT_SEED,
        "windows": {
            "early_steps": EARLY_WINDOW_STEPS,
            "tail_steps": TAIL_WINDOW_STEPS,
            "asymptotic_steps": ASYMPTOTIC_WINDOW_STEPS,
        },
        "conditions": {
            name: dict(FROZEN_CONDITION_CONFIGURATIONS[name]) for name in CONDITION_NAMES
        },
    }


def validate_runtime_memory(
    memory_by_condition: Mapping[str, Mapping[str, int | bool]],
) -> bool:
    """Return whether runtime accounting matches the frozen counted budget."""

    return {
        condition: dict(memory_by_condition.get(condition, {})) for condition in CONDITION_NAMES
    } == EXPECTED_MEMORY


__all__ = [
    "ASYMPTOTIC_WINDOW_STEPS",
    "CONDITION_LEGACY",
    "CONDITION_NAMES",
    "CONDITION_NO_RETENTION",
    "CONDITION_PRIMARY",
    "ConditionSeedRecord",
    "DEVELOPMENT_SEEDS",
    "EARLY_WINDOW_STEPS",
    "EVIDENCE_SEEDS",
    "EXPECTED_MEMORY",
    "FROZEN_CONDITION_CONFIGURATIONS",
    "FROZEN_STREAM_CONFIGURATION",
    "LEARNER_INIT_SEED",
    "PhaseWindowRecord",
    "ScaleRobustFeatureReport",
    "TAIL_WINDOW_STEPS",
    "count_relevant_context_pairs",
    "frozen_configuration_payload",
    "make_condition_learner",
    "phase_window_records",
    "run_scale_robust_feature_evaluation",
    "validate_runtime_memory",
]
