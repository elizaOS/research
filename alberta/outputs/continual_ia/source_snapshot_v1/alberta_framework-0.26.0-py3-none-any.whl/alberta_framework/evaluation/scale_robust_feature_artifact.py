"""Fail-closed v1 artifacts for the scale-robust pair-feature protocol.

The SHA-256 digest covers the exact frozen protocol, configuration,
thresholds, counted memory, primitive paired-seed records, reconstructed
aggregates and bootstrap intervals, acceptance checks, and source hashes.
Generation time, host runtime details, worktree dirtiness, and wall time are
retained outside the digest.

The supported claim is intentionally narrow.  This is a finite nine-phase
regression stream with an exhaustive degree-two candidate archive and a
visible, supplied task cue.  It is not evidence of general or open-ended
feature discovery, autonomous task inference, an indefinite retention
guarantee, continual control, or completion of the Alberta Plan.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import math
import platform
import subprocess
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import NoReturn

import jax
import numpy as np

from alberta_framework.evaluation.scale_robust_feature import (
    ASYMPTOTIC_WINDOW_STEPS,
    CONDITION_LEGACY,
    CONDITION_NAMES,
    CONDITION_NO_RETENTION,
    CONDITION_PRIMARY,
    DEVELOPMENT_SEEDS,
    EARLY_WINDOW_STEPS,
    EVIDENCE_SEEDS,
    EXPECTED_MEMORY,
    FROZEN_STREAM_CONFIGURATION,
    TAIL_WINDOW_STEPS,
    ScaleRobustFeatureReport,
    count_relevant_context_pairs,
    frozen_configuration_payload,
)
from alberta_framework.streams.gauntlet import SEGMENT_NAMES

SCHEMA_VERSION = "alberta.scale_robust_pair_feature_evidence.v1"
PROTOCOL_VERSION = "gauntlet-exhaustive-pair-scale-robustness.v1"
DIGEST_ALGORITHM = "sha256"
DIGEST_SCOPE = "$.scientific_payload"
CANONICALIZATION = "utf8-json-sort-keys-compact-no-nan"

BOOTSTRAP_RESAMPLES = 5_000
BOOTSTRAP_CONFIDENCE_LEVEL = 0.95
BOOTSTRAP_SEED = 2_026_073_004
BOOTSTRAP_METHOD = "paired-percentile-bootstrap"

_REPO_ROOT = Path(__file__).resolve().parents[2]
_SOURCE_PATHS = (
    Path("alberta_framework/core/interaction_features.py"),
    Path("alberta_framework/streams/gauntlet.py"),
    Path("alberta_framework/evaluation/scale_robust_feature.py"),
    Path("alberta_framework/evaluation/scale_robust_feature_artifact.py"),
    Path("alberta_framework/evaluation/scale_robust_feature_cli.py"),
)

_PHASE_RECORD_KEYS = frozenset(
    {
        "phase_index",
        "phase_name",
        "step_count",
        "nonfinite_steps",
        "early_squared_error_sum",
        "early_count",
        "tail_squared_error_sum",
        "tail_count",
        "asymptotic_squared_error_sum",
        "asymptotic_count",
    }
)
_METRIC_KEYS = frozenset(
    {
        "total_nonfinite_steps",
        "savings_c",
        "savings_d",
        "savings_c_final",
        "first_c_early_mse",
        "first_c_tail_mse",
        "recurrent_c_early_mse",
        "recurrent_c_tail_mse",
        "scaled_tail_mse",
        "nonlinear_mse",
        "final_c_early_mse",
        "final_c_tail_mse",
        "end_segment_5_relevant_context_pairs",
        "final_relevant_context_pairs",
    }
)
_CONDITION_RECORD_KEYS = frozenset(
    {
        "phase_windows",
        "end_segment_5_active_pairs",
        "final_active_pairs",
        "metrics",
    }
)
_COMPARISON_NAMES = (
    "primary_minus_legacy_final_savings",
    "legacy_minus_primary_final_tail_mse",
    "primary_minus_legacy_final_relevant_context_pairs",
    "primary_minus_no_retention_final_relevant_context_pairs",
    "no_retention_minus_primary_final_tail_mse",
)


@dataclass(frozen=True)
class ArtifactValidation:
    """Integrity and frozen-gate decision for one parsed artifact."""

    valid: bool
    accepted: bool
    errors: tuple[str, ...]


def _threshold_payload() -> dict[str, object]:
    return {
        "minimum_seed_count": 30,
        "minimum_relevant_context_pairs_end_segment_5": 7,
        "minimum_relevant_context_pairs_final": 7,
        "minimum_median_savings_c": 8.0,
        "minimum_median_savings_d": 5.0,
        "minimum_median_savings_c_final": 5.0,
        "maximum_median_first_c_early_mse": 15.0,
        "maximum_median_first_c_tail_mse": 2.0,
        "maximum_median_recurrent_c_early_mse": 2.0,
        "maximum_median_recurrent_c_tail_mse": 2.0,
        "maximum_median_scaled_tail_mse": 10.0,
        "maximum_per_seed_scaled_tail_mse": 50.0,
        "maximum_median_final_c_early_mse": 3.0,
        "maximum_median_final_c_tail_mse": 0.1,
        "maximum_per_seed_final_c_tail_mse": 0.1,
        "maximum_median_nonlinear_mse": 0.1,
        "minimum_all_seed_primary_minus_legacy_final_context": 0.0,
        "minimum_all_seed_legacy_minus_primary_final_tail_mse": 0.0,
        "minimum_all_seed_primary_minus_legacy_final_savings": 0.0,
        "minimum_paired_mean_primary_minus_legacy_final_savings_ci_lower": 2.0,
        "minimum_paired_mean_legacy_minus_primary_final_tail_mse_ci_lower": 5.0,
        "minimum_paired_mean_primary_minus_legacy_final_context_ci_lower": 7.0,
        "minimum_paired_mean_primary_minus_no_retention_final_context_ci_lower": 3.0,
        "bootstrap": {
            "resamples": BOOTSTRAP_RESAMPLES,
            "confidence_level": BOOTSTRAP_CONFIDENCE_LEVEL,
            "seed": BOOTSTRAP_SEED,
            "method": BOOTSTRAP_METHOD,
            "quantile_method": "linear",
            "statistic": "paired mean of per-seed differences",
        },
    }


def _protocol_payload() -> dict[str, object]:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "supported_claim": (
            "online scale-robust selection and retention of useful pair "
            "products from a counted exhaustive degree-two archive in the "
            "frozen visibly-cued nine-phase regression gauntlet"
        ),
        "schedule": list(SEGMENT_NAMES),
        "seed_roles": {
            "development_and_threshold_calibration": list(DEVELOPMENT_SEEDS),
            "promoted_held_out_evidence": list(EVIDENCE_SEEDS),
            "rule": (
                "development used seeds 8-15; promoted evidence uses the "
                "disjoint schedule 30-59 exactly, with no post-evidence tuning"
            ),
        },
        "paired_design": (
            "all three conditions receive the same stream seed and independently "
            "start from the same learner key for each pairing unit"
        ),
        "prequential_semantics": (
            "each squared error is measured from the prediction before the "
            "same observation-target transition updates the learner"
        ),
        "feature_search_space": (
            "all 91 distinct non-square products over the 14 supplied "
            "observation coordinates; 24 products are deployed"
        ),
        "task_information": (
            "the stream supplies two noisy visible context coordinates; the "
            "learner is not required to infer latent task identity"
        ),
        "memory_semantics": (
            "the 91 pair descriptors and all 91 dormant output heads remain "
            "resident and are counted even when only 24 pairs are deployed"
        ),
        "excluded_claims": [
            "general or open-ended feature discovery",
            "features outside the exhaustive degree-two archive",
            "autonomous task or context inference",
            "erasure from the resident candidate archive",
            "an indefinite-lifetime retention theorem",
            "continual control or reinforcement learning",
            "completion of the Alberta Plan",
        ],
    }


def canonical_scientific_bytes(payload: Mapping[str, object]) -> bytes:
    """Return the canonical deterministic JSON representation."""

    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def scientific_payload_sha256(payload: Mapping[str, object]) -> str:
    """Hash canonical deterministic scientific content."""

    return hashlib.sha256(canonical_scientific_bytes(payload)).hexdigest()


def _git_head() -> str:
    try:
        result = subprocess.run(
            ("git", "rev-parse", "HEAD"),
            cwd=_REPO_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as error:
        raise RuntimeError("unable to resolve git HEAD for provenance") from error
    commit = result.stdout.strip()
    if len(commit) != 40 or any(character not in "0123456789abcdef" for character in commit):
        raise RuntimeError("git HEAD is not a canonical 40-character SHA-1")
    return commit


def _git_dirty() -> bool:
    try:
        result = subprocess.run(
            ("git", "status", "--porcelain", "--untracked-files=normal"),
            cwd=_REPO_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as error:
        raise RuntimeError("unable to inspect git worktree provenance") from error
    return bool(result.stdout)


def _source_provenance() -> dict[str, object]:
    hashes: dict[str, str] = {}
    for relative_path in _SOURCE_PATHS:
        try:
            source = (_REPO_ROOT / relative_path).read_bytes()
        except OSError as error:
            raise RuntimeError(f"unable to hash source {relative_path}") from error
        hashes[relative_path.as_posix()] = hashlib.sha256(source).hexdigest()
    return {
        "repository_subtree": "research/alberta",
        "git_head": _git_head(),
        "source_sha256": hashes,
        "interpretation": (
            "reproducibility and integrity identifiers only; hashes are not "
            "signatures and do not establish artifact authenticity"
        ),
    }


def _runtime_provenance() -> dict[str, object]:
    return {
        "python": {
            "implementation": platform.python_implementation(),
            "version": platform.python_version(),
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "packages": {
            "alberta-framework": importlib.metadata.version("alberta-framework"),
            "jax": jax.__version__,
            "jaxlib": importlib.metadata.version("jaxlib"),
            "numpy": np.__version__,
        },
        "jax": {
            "default_backend": jax.default_backend(),
            "devices": [
                {
                    "platform": device.platform,
                    "device_kind": device.device_kind,
                }
                for device in jax.devices()
            ],
        },
    }


def _phase_payload(phase: object) -> dict[str, object]:
    return {
        "phase_index": getattr(phase, "phase_index"),
        "phase_name": getattr(phase, "phase_name"),
        "step_count": getattr(phase, "step_count"),
        "nonfinite_steps": getattr(phase, "nonfinite_steps"),
        "early_squared_error_sum": getattr(phase, "early_squared_error_sum"),
        "early_count": getattr(phase, "early_count"),
        "tail_squared_error_sum": getattr(phase, "tail_squared_error_sum"),
        "tail_count": getattr(phase, "tail_count"),
        "asymptotic_squared_error_sum": getattr(
            phase,
            "asymptotic_squared_error_sum",
        ),
        "asymptotic_count": getattr(phase, "asymptotic_count"),
    }


def _pair_payload(pairs: Sequence[tuple[int, int]]) -> list[list[int]]:
    return [[int(left), int(right)] for left, right in pairs]


def _window_mean(
    phase: Mapping[str, object],
    sum_key: str,
    count_key: str,
) -> float | None:
    total = _finite_number(phase.get(sum_key))
    count = _strict_int(phase.get(count_key))
    if total is None or count is None or count <= 0:
        return None
    value = total / count
    return value if math.isfinite(value) else None


def _metrics_from_condition(
    condition: Mapping[str, object],
) -> dict[str, object]:
    phases_object = condition.get("phase_windows")
    if not isinstance(phases_object, list) or len(phases_object) != len(SEGMENT_NAMES):
        return {key: None for key in _METRIC_KEYS}
    phases: list[Mapping[str, object]] = []
    for phase in phases_object:
        if not isinstance(phase, Mapping):
            return {key: None for key in _METRIC_KEYS}
        phases.append(phase)

    early = [
        _window_mean(
            phase,
            "early_squared_error_sum",
            "early_count",
        )
        for phase in phases
    ]
    tail = [
        _window_mean(
            phase,
            "tail_squared_error_sum",
            "tail_count",
        )
        for phase in phases
    ]
    asymptotic = [
        _window_mean(
            phase,
            "asymptotic_squared_error_sum",
            "asymptotic_count",
        )
        for phase in phases
    ]
    nonfinite = [_strict_int(phase.get("nonfinite_steps")) for phase in phases]

    end_pairs = _parsed_pairs(condition.get("end_segment_5_active_pairs"))
    final_pairs = _parsed_pairs(condition.get("final_active_pairs"))
    if (
        any(value is None for value in (*early, *tail, *asymptotic))
        or any(value is None for value in nonfinite)
        or end_pairs is None
        or final_pairs is None
    ):
        return {key: None for key in _METRIC_KEYS}

    finite_early = [float(value) for value in early if value is not None]
    finite_tail = [float(value) for value in tail if value is not None]
    finite_asymptotic = [float(value) for value in asymptotic if value is not None]
    finite_nonfinite = [int(value) for value in nonfinite if value is not None]
    return {
        "total_nonfinite_steps": sum(finite_nonfinite),
        "savings_c": finite_early[2] / max(finite_early[4], 1e-8),
        "savings_d": finite_early[3] / max(finite_early[5], 1e-8),
        "savings_c_final": finite_early[2] / max(finite_early[8], 1e-8),
        "first_c_early_mse": finite_early[2],
        "first_c_tail_mse": finite_tail[2],
        "recurrent_c_early_mse": finite_early[4],
        "recurrent_c_tail_mse": finite_tail[4],
        "scaled_tail_mse": finite_tail[6],
        # gauntlet_scorecard()["nonlinear_mse"] uses the trailing half.
        "nonlinear_mse": finite_asymptotic[7],
        "final_c_early_mse": finite_early[8],
        "final_c_tail_mse": finite_tail[8],
        "end_segment_5_relevant_context_pairs": count_relevant_context_pairs(
            end_pairs,
        ),
        "final_relevant_context_pairs": count_relevant_context_pairs(
            final_pairs,
        ),
    }


def _seed_payloads(report: ScaleRobustFeatureReport) -> list[dict[str, object]]:
    grouped: dict[int, dict[str, dict[str, object]]] = {}
    for record in report.records:
        conditions = grouped.setdefault(record.seed, {})
        if record.condition in conditions:
            raise ValueError(f"duplicate {record.condition!r} record for seed {record.seed}")
        primitive: dict[str, object] = {
            "phase_windows": [_phase_payload(phase) for phase in record.phases],
            "end_segment_5_active_pairs": _pair_payload(record.end_segment_5_active_pairs),
            "final_active_pairs": _pair_payload(record.final_active_pairs),
        }
        primitive["metrics"] = _metrics_from_condition(primitive)
        conditions[record.condition] = primitive

    payloads: list[dict[str, object]] = []
    for seed in sorted(grouped):
        conditions = grouped[seed]
        if set(conditions) != set(CONDITION_NAMES):
            raise ValueError(f"seed {seed} must contain exactly {CONDITION_NAMES!r}")
        payloads.append(
            {
                "seed": seed,
                "conditions": {condition: conditions[condition] for condition in CONDITION_NAMES},
            }
        )
    return payloads


def _metric_vector(
    seed_records: Sequence[Mapping[str, object]],
    condition: str,
    metric: str,
) -> list[float] | None:
    values: list[float] = []
    for seed_record in seed_records:
        conditions = seed_record.get("conditions")
        if not isinstance(conditions, Mapping):
            return None
        condition_record = conditions.get(condition)
        if not isinstance(condition_record, Mapping):
            return None
        metrics = condition_record.get("metrics")
        if not isinstance(metrics, Mapping):
            return None
        value = _finite_number(metrics.get(metric))
        if value is None:
            return None
        values.append(value)
    return values


def _median(values: Sequence[float] | None) -> float | None:
    if values is None or not values:
        return None
    array = np.asarray(values, dtype=np.float64)
    if not bool(np.all(np.isfinite(array))):
        return None
    return float(np.median(array))


def _minimum(values: Sequence[float] | None) -> float | None:
    if values is None or not values:
        return None
    return float(min(values))


def _maximum(values: Sequence[float] | None) -> float | None:
    if values is None or not values:
        return None
    return float(max(values))


def _aggregate_payload(
    seed_records: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    metric_names = tuple(key for key in _METRIC_KEYS if key != "total_nonfinite_steps")
    conditions: dict[str, object] = {}
    for condition in CONDITION_NAMES:
        conditions[condition] = {
            "median_metrics": {
                metric: _median(_metric_vector(seed_records, condition, metric))
                for metric in metric_names
            },
            "total_nonfinite_steps": (
                None
                if (
                    nonfinite := _metric_vector(
                        seed_records,
                        condition,
                        "total_nonfinite_steps",
                    )
                )
                is None
                else int(sum(nonfinite))
            ),
        }
    primary_scaled = _metric_vector(
        seed_records,
        CONDITION_PRIMARY,
        "scaled_tail_mse",
    )
    primary_final_tail = _metric_vector(
        seed_records,
        CONDITION_PRIMARY,
        "final_c_tail_mse",
    )
    primary_end_context = _metric_vector(
        seed_records,
        CONDITION_PRIMARY,
        "end_segment_5_relevant_context_pairs",
    )
    primary_final_context = _metric_vector(
        seed_records,
        CONDITION_PRIMARY,
        "final_relevant_context_pairs",
    )
    return {
        "seed_count": len(seed_records),
        "seeds": [seed_record.get("seed") for seed_record in seed_records],
        "conditions": conditions,
        "primary_extrema": {
            "minimum_relevant_context_pairs_end_segment_5": _minimum(primary_end_context),
            "minimum_relevant_context_pairs_final": _minimum(primary_final_context),
            "maximum_scaled_tail_mse": _maximum(primary_scaled),
            "maximum_final_c_tail_mse": _maximum(primary_final_tail),
        },
    }


def paired_bootstrap_mean_interval(
    differences: Sequence[float],
) -> dict[str, object]:
    """Deterministic paired percentile interval for a mean difference."""

    values = np.asarray(tuple(differences), dtype=np.float64)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("paired bootstrap requires a non-empty vector")
    if not bool(np.all(np.isfinite(values))):
        raise ValueError("paired bootstrap values must all be finite")
    generator = np.random.default_rng(BOOTSTRAP_SEED)
    indices = generator.integers(
        0,
        values.size,
        size=(BOOTSTRAP_RESAMPLES, values.size),
    )
    sampled_means = values[indices].mean(axis=1)
    tail = (1.0 - BOOTSTRAP_CONFIDENCE_LEVEL) / 2.0
    lower, upper = np.quantile(
        sampled_means,
        (tail, 1.0 - tail),
        method="linear",
    )
    return {
        "estimate": float(values.mean()),
        "lower": float(lower),
        "upper": float(upper),
        "confidence_level": BOOTSTRAP_CONFIDENCE_LEVEL,
        "resamples": BOOTSTRAP_RESAMPLES,
        "sample_size": int(values.size),
        "seed": BOOTSTRAP_SEED,
        "method": BOOTSTRAP_METHOD,
        "quantile_method": "linear",
        "pairing_unit": "seed",
        "statistic": "mean of paired per-seed differences",
    }


def _comparison(
    seed_records: Sequence[Mapping[str, object]],
    *,
    left_condition: str,
    left_metric: str,
    right_condition: str,
    right_metric: str,
    interpretation: str,
) -> dict[str, object]:
    left = _metric_vector(
        seed_records,
        left_condition,
        left_metric,
    )
    right = _metric_vector(
        seed_records,
        right_condition,
        right_metric,
    )
    if left is None or right is None or len(left) != len(right):
        differences: list[float] = []
    else:
        differences = [
            left_value - right_value for left_value, right_value in zip(left, right, strict=True)
        ]
    per_seed = (
        [
            {
                "seed": seed_record.get("seed"),
                "difference": difference,
            }
            for seed_record, difference in zip(
                seed_records,
                differences,
                strict=True,
            )
        ]
        if len(differences) == len(seed_records)
        else []
    )
    interval: dict[str, object] | None
    if differences:
        interval = paired_bootstrap_mean_interval(differences)
    else:
        interval = None
    return {
        "definition": {
            "left_condition": left_condition,
            "left_metric": left_metric,
            "right_condition": right_condition,
            "right_metric": right_metric,
            "operation": "left minus right",
            "interpretation": interpretation,
        },
        "per_seed": per_seed,
        "minimum_difference": _minimum(differences),
        "median_difference": _median(differences),
        "paired_mean_interval": interval,
    }


def _comparisons_payload(
    seed_records: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    return {
        "primary_minus_legacy_final_savings": _comparison(
            seed_records,
            left_condition=CONDITION_PRIMARY,
            left_metric="savings_c_final",
            right_condition=CONDITION_LEGACY,
            right_metric="savings_c_final",
            interpretation="positive favors the scale-robust primary arm",
        ),
        "legacy_minus_primary_final_tail_mse": _comparison(
            seed_records,
            left_condition=CONDITION_LEGACY,
            left_metric="final_c_tail_mse",
            right_condition=CONDITION_PRIMARY,
            right_metric="final_c_tail_mse",
            interpretation="positive is an error reduction for the primary arm",
        ),
        "primary_minus_legacy_final_relevant_context_pairs": _comparison(
            seed_records,
            left_condition=CONDITION_PRIMARY,
            left_metric="final_relevant_context_pairs",
            right_condition=CONDITION_LEGACY,
            right_metric="final_relevant_context_pairs",
            interpretation="positive favors the scale-robust primary arm",
        ),
        "primary_minus_no_retention_final_relevant_context_pairs": _comparison(
            seed_records,
            left_condition=CONDITION_PRIMARY,
            left_metric="final_relevant_context_pairs",
            right_condition=CONDITION_NO_RETENTION,
            right_metric="final_relevant_context_pairs",
            interpretation=(
                "secondary retention ablation; positive means the retention "
                "floor preserves more relevant context products"
            ),
        ),
        "no_retention_minus_primary_final_tail_mse": _comparison(
            seed_records,
            left_condition=CONDITION_NO_RETENTION,
            left_metric="final_c_tail_mse",
            right_condition=CONDITION_PRIMARY,
            right_metric="final_c_tail_mse",
            interpretation=(
                "descriptive retention ablation; positive is an error "
                "reduction for the retained primary arm and is not an "
                "acceptance-bound claim"
            ),
        ),
    }


def _comparison_value(
    comparisons: Mapping[str, object],
    comparison: str,
    field: str,
) -> float | None:
    record = comparisons.get(comparison)
    if not isinstance(record, Mapping):
        return None
    if field == "paired_mean_interval.lower":
        interval = record.get("paired_mean_interval")
        if not isinstance(interval, Mapping):
            return None
        return _finite_number(interval.get("lower"))
    return _finite_number(record.get(field))


def _aggregate_value(
    aggregate: Mapping[str, object],
    condition: str,
    metric: str,
) -> float | None:
    conditions = aggregate.get("conditions")
    if not isinstance(conditions, Mapping):
        return None
    condition_record = conditions.get(condition)
    if not isinstance(condition_record, Mapping):
        return None
    medians = condition_record.get("median_metrics")
    if not isinstance(medians, Mapping):
        return None
    return _finite_number(medians.get(metric))


def _extreme_value(
    aggregate: Mapping[str, object],
    name: str,
) -> float | None:
    extrema = aggregate.get("primary_extrema")
    if not isinstance(extrema, Mapping):
        return None
    return _finite_number(extrema.get(name))


def _check(
    name: str,
    *,
    actual: object,
    comparator: str,
    threshold: object,
    passed: bool,
) -> dict[str, object]:
    return {
        "name": name,
        "actual": actual,
        "comparator": comparator,
        "threshold": threshold,
        "passed": bool(passed),
    }


def _at_least(value: float | None, threshold: float) -> bool:
    return value is not None and value >= threshold


def _at_most(value: float | None, threshold: float) -> bool:
    return value is not None and value <= threshold


def _greater(value: float | None, threshold: float) -> bool:
    return value is not None and value > threshold


def _threshold_float(
    thresholds: Mapping[str, object],
    name: str,
) -> float:
    value = _finite_number(thresholds.get(name))
    if value is None:
        raise RuntimeError(f"frozen threshold {name!r} must be numeric")
    return value


def _threshold_int(
    thresholds: Mapping[str, object],
    name: str,
) -> int:
    value = _strict_int(thresholds.get(name))
    if value is None:
        raise RuntimeError(f"frozen threshold {name!r} must be integer")
    return value


def _acceptance_payload(
    *,
    seed_records: Sequence[Mapping[str, object]],
    memory: Mapping[str, object],
    aggregate: Mapping[str, object],
    comparisons: Mapping[str, object],
) -> dict[str, object]:
    thresholds = _threshold_payload()
    seeds = [seed_record.get("seed") for seed_record in seed_records]
    total_nonfinite = 0.0
    nonfinite_complete = True
    for condition in CONDITION_NAMES:
        conditions = aggregate.get("conditions")
        condition_record = conditions.get(condition) if isinstance(conditions, Mapping) else None
        value = (
            _finite_number(condition_record.get("total_nonfinite_steps"))
            if isinstance(condition_record, Mapping)
            else None
        )
        if value is None:
            nonfinite_complete = False
        else:
            total_nonfinite += value

    primary = CONDITION_PRIMARY
    checks = [
        _check(
            "canonical_evidence_seed_schedule",
            actual=seeds,
            comparator="==",
            threshold=list(EVIDENCE_SEEDS),
            passed=seeds == list(EVIDENCE_SEEDS),
        ),
        _check(
            "minimum_seed_count",
            actual=len(seed_records),
            comparator=">=",
            threshold=thresholds["minimum_seed_count"],
            passed=len(seed_records) >= _threshold_int(thresholds, "minimum_seed_count"),
        ),
        _check(
            "all_prequential_errors_finite",
            actual=total_nonfinite if nonfinite_complete else None,
            comparator="==",
            threshold=0,
            passed=nonfinite_complete and total_nonfinite == 0.0,
        ),
        _check(
            "counted_memory_matches_frozen_budget",
            actual=memory,
            comparator="==",
            threshold=EXPECTED_MEMORY,
            passed=memory == EXPECTED_MEMORY,
        ),
    ]

    minimum_checks = (
        (
            "primary_relevant_context_pairs_end_segment_5",
            _extreme_value(
                aggregate,
                "minimum_relevant_context_pairs_end_segment_5",
            ),
            "minimum_relevant_context_pairs_end_segment_5",
        ),
        (
            "primary_relevant_context_pairs_final",
            _extreme_value(
                aggregate,
                "minimum_relevant_context_pairs_final",
            ),
            "minimum_relevant_context_pairs_final",
        ),
        (
            "primary_median_savings_c",
            _aggregate_value(aggregate, primary, "savings_c"),
            "minimum_median_savings_c",
        ),
        (
            "primary_median_savings_d",
            _aggregate_value(aggregate, primary, "savings_d"),
            "minimum_median_savings_d",
        ),
        (
            "primary_median_savings_c_final",
            _aggregate_value(aggregate, primary, "savings_c_final"),
            "minimum_median_savings_c_final",
        ),
    )
    for name, actual, threshold_name in minimum_checks:
        threshold = _threshold_float(thresholds, threshold_name)
        checks.append(
            _check(
                name,
                actual=actual,
                comparator=">=",
                threshold=threshold,
                passed=_at_least(actual, threshold),
            )
        )

    maximum_checks = (
        (
            "primary_median_first_c_early_mse",
            _aggregate_value(aggregate, primary, "first_c_early_mse"),
            "maximum_median_first_c_early_mse",
        ),
        (
            "primary_median_first_c_tail_mse",
            _aggregate_value(aggregate, primary, "first_c_tail_mse"),
            "maximum_median_first_c_tail_mse",
        ),
        (
            "primary_median_recurrent_c_early_mse",
            _aggregate_value(aggregate, primary, "recurrent_c_early_mse"),
            "maximum_median_recurrent_c_early_mse",
        ),
        (
            "primary_median_recurrent_c_tail_mse",
            _aggregate_value(aggregate, primary, "recurrent_c_tail_mse"),
            "maximum_median_recurrent_c_tail_mse",
        ),
        (
            "primary_median_scaled_tail_mse",
            _aggregate_value(aggregate, primary, "scaled_tail_mse"),
            "maximum_median_scaled_tail_mse",
        ),
        (
            "primary_maximum_scaled_tail_mse",
            _extreme_value(aggregate, "maximum_scaled_tail_mse"),
            "maximum_per_seed_scaled_tail_mse",
        ),
        (
            "primary_median_final_c_early_mse",
            _aggregate_value(aggregate, primary, "final_c_early_mse"),
            "maximum_median_final_c_early_mse",
        ),
        (
            "primary_median_final_c_tail_mse",
            _aggregate_value(aggregate, primary, "final_c_tail_mse"),
            "maximum_median_final_c_tail_mse",
        ),
        (
            "primary_maximum_final_c_tail_mse",
            _extreme_value(aggregate, "maximum_final_c_tail_mse"),
            "maximum_per_seed_final_c_tail_mse",
        ),
        (
            "primary_median_nonlinear_mse",
            _aggregate_value(aggregate, primary, "nonlinear_mse"),
            "maximum_median_nonlinear_mse",
        ),
    )
    for name, actual, threshold_name in maximum_checks:
        threshold = _threshold_float(thresholds, threshold_name)
        checks.append(
            _check(
                name,
                actual=actual,
                comparator="<=",
                threshold=threshold,
                passed=_at_most(actual, threshold),
            )
        )

    all_seed_checks = (
        (
            "all_seed_primary_final_context_improvement_over_legacy",
            "primary_minus_legacy_final_relevant_context_pairs",
            "minimum_all_seed_primary_minus_legacy_final_context",
        ),
        (
            "all_seed_primary_final_tail_reduction_over_legacy",
            "legacy_minus_primary_final_tail_mse",
            "minimum_all_seed_legacy_minus_primary_final_tail_mse",
        ),
        (
            "all_seed_primary_final_savings_improvement_over_legacy",
            "primary_minus_legacy_final_savings",
            "minimum_all_seed_primary_minus_legacy_final_savings",
        ),
    )
    for name, comparison, threshold_name in all_seed_checks:
        actual = _comparison_value(
            comparisons,
            comparison,
            "minimum_difference",
        )
        threshold = _threshold_float(thresholds, threshold_name)
        checks.append(
            _check(
                name,
                actual=actual,
                comparator=">",
                threshold=threshold,
                passed=_greater(actual, threshold),
            )
        )

    interval_checks = (
        (
            "paired_mean_primary_minus_legacy_final_savings_ci_lower",
            "primary_minus_legacy_final_savings",
            "minimum_paired_mean_primary_minus_legacy_final_savings_ci_lower",
        ),
        (
            "paired_mean_legacy_minus_primary_final_tail_mse_ci_lower",
            "legacy_minus_primary_final_tail_mse",
            "minimum_paired_mean_legacy_minus_primary_final_tail_mse_ci_lower",
        ),
        (
            "paired_mean_primary_minus_legacy_final_context_ci_lower",
            "primary_minus_legacy_final_relevant_context_pairs",
            "minimum_paired_mean_primary_minus_legacy_final_context_ci_lower",
        ),
        (
            "paired_mean_primary_minus_no_retention_final_context_ci_lower",
            "primary_minus_no_retention_final_relevant_context_pairs",
            ("minimum_paired_mean_primary_minus_no_retention_final_context_ci_lower"),
        ),
    )
    for name, comparison, threshold_name in interval_checks:
        actual = _comparison_value(
            comparisons,
            comparison,
            "paired_mean_interval.lower",
        )
        threshold = _threshold_float(thresholds, threshold_name)
        checks.append(
            _check(
                name,
                actual=actual,
                comparator=">=",
                threshold=threshold,
                passed=_at_least(actual, threshold),
            )
        )

    return {
        "passed": all(bool(check["passed"]) for check in checks),
        "checks": checks,
        "retention_ablation_interpretation": (
            "only the paired lower bound for final relevant-context count is "
            "acceptance-bound; the no-retention final-tail comparison is "
            "descriptive and no retention-savings claim is made"
        ),
    }


def build_evidence_artifact(
    report: ScaleRobustFeatureReport,
) -> dict[str, object]:
    """Build a versioned artifact without upgrading failed evidence."""

    seed_records = _seed_payloads(report)
    if [record["seed"] for record in seed_records] != list(report.seeds):
        raise ValueError("report.seeds must be sorted and exactly match its primitive records")
    memory = {
        condition: dict(report.memory_by_condition.get(condition, {}))
        for condition in CONDITION_NAMES
    }
    aggregate = _aggregate_payload(seed_records)
    comparisons = _comparisons_payload(seed_records)
    acceptance = _acceptance_payload(
        seed_records=seed_records,
        memory=memory,
        aggregate=aggregate,
        comparisons=comparisons,
    )
    scientific_payload: dict[str, object] = {
        "protocol": _protocol_payload(),
        "configuration": frozen_configuration_payload(),
        "thresholds": _threshold_payload(),
        "memory_by_condition": memory,
        "seed_records": seed_records,
        "aggregate": aggregate,
        "comparisons": comparisons,
        "acceptance": acceptance,
        "source_provenance": _source_provenance(),
    }
    digest = scientific_payload_sha256(scientific_payload)
    wall_times = {
        condition: float(report.wall_time_seconds_by_condition.get(condition, math.nan))
        for condition in CONDITION_NAMES
    }
    return {
        "schema_version": SCHEMA_VERSION,
        "scientific_payload": scientific_payload,
        "content_digest": {
            "algorithm": DIGEST_ALGORITHM,
            "scope": DIGEST_SCOPE,
            "canonicalization": CANONICALIZATION,
            "sha256": digest,
        },
        "operational_metadata": {
            "generated_at_utc": datetime.now(UTC).isoformat(),
            "wall_time_seconds_by_condition": wall_times,
            "worktree_dirty": _git_dirty(),
            "runtime_provenance": _runtime_provenance(),
            "interpretation": (
                "host-dependent diagnostics outside the scientific digest and outside acceptance"
            ),
        },
    }


def artifact_json(artifact: Mapping[str, object]) -> str:
    """Serialize an artifact as strict, human-readable JSON."""

    return (
        json.dumps(
            artifact,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    )


def _reject_json_constant(value: str) -> NoReturn:
    raise ValueError(f"non-standard JSON constant is forbidden: {value}")


def _object_without_duplicates(
    pairs: list[tuple[str, object]],
) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key: {key!r}")
        result[key] = value
    return result


def load_evidence_artifact(path: Path) -> dict[str, object]:
    """Load strict JSON, rejecting duplicate keys and NaN/Infinity."""

    loaded = json.loads(
        path.read_text(encoding="utf-8"),
        parse_constant=_reject_json_constant,
        object_pairs_hook=_object_without_duplicates,
    )
    if not isinstance(loaded, dict):
        raise ValueError("artifact root must be an object")
    return loaded


def _finite_number(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    numeric = float(value)
    return numeric if math.isfinite(numeric) else None


def _strict_int(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _exact_keys(
    value: Mapping[str, object],
    expected: set[str] | frozenset[str],
    location: str,
    errors: list[str],
) -> None:
    actual = set(value)
    missing = sorted(set(expected) - actual)
    unknown = sorted(actual - set(expected))
    if missing:
        errors.append(f"{location} is missing keys: {', '.join(missing)}")
    if unknown:
        errors.append(f"{location} has unknown keys: {', '.join(unknown)}")


def _mapping(
    value: object,
    location: str,
    errors: list[str],
) -> Mapping[str, object] | None:
    if not isinstance(value, Mapping):
        errors.append(f"{location} must be an object")
        return None
    return value


def _parsed_pairs(value: object) -> tuple[tuple[int, int], ...] | None:
    if not isinstance(value, list):
        return None
    pairs: list[tuple[int, int]] = []
    for pair in value:
        if (
            not isinstance(pair, list)
            or len(pair) != 2
            or _strict_int(pair[0]) is None
            or _strict_int(pair[1]) is None
        ):
            return None
        pairs.append((int(pair[0]), int(pair[1])))
    return tuple(pairs)


def _validate_pair_bank(
    value: object,
    location: str,
    errors: list[str],
) -> None:
    pairs = _parsed_pairs(value)
    if pairs is None:
        errors.append(f"{location} must be a list of integer pairs")
        return
    if len(pairs) != 24:
        errors.append(f"{location} must contain exactly 24 active pairs")
    for index, (left, right) in enumerate(pairs):
        if not 0 <= left < right < 14:
            errors.append(f"{location}[{index}] must be canonical with 0 <= left < right < 14")


def _validate_phase(
    value: object,
    *,
    phase_index: int,
    location: str,
    errors: list[str],
) -> None:
    phase = _mapping(value, location, errors)
    if phase is None:
        return
    _exact_keys(phase, _PHASE_RECORD_KEYS, location, errors)
    if phase.get("phase_index") != phase_index:
        errors.append(f"{location}.phase_index is inconsistent")
    if phase.get("phase_name") != SEGMENT_NAMES[phase_index]:
        errors.append(f"{location}.phase_name is inconsistent")
    if phase.get("step_count") != FROZEN_STREAM_CONFIGURATION["segment_length"]:
        errors.append(f"{location}.step_count is inconsistent")
    nonfinite = _strict_int(phase.get("nonfinite_steps"))
    if nonfinite is None or not 0 <= nonfinite <= 3_000:
        errors.append(f"{location}.nonfinite_steps must be in [0, 3000]")
    expected_counts = {
        "early_count": EARLY_WINDOW_STEPS,
        "tail_count": TAIL_WINDOW_STEPS,
        "asymptotic_count": ASYMPTOTIC_WINDOW_STEPS,
    }
    for key, expected in expected_counts.items():
        if phase.get(key) != expected:
            errors.append(f"{location}.{key} must equal {expected}")
    for key in (
        "early_squared_error_sum",
        "tail_squared_error_sum",
        "asymptotic_squared_error_sum",
    ):
        value_number = _finite_number(phase.get(key))
        if value_number is None or value_number < 0.0:
            errors.append(f"{location}.{key} must be finite and non-negative")


def _validate_metrics(
    condition: Mapping[str, object],
    location: str,
    errors: list[str],
) -> None:
    metrics = _mapping(condition.get("metrics"), f"{location}.metrics", errors)
    if metrics is None:
        return
    _exact_keys(metrics, _METRIC_KEYS, f"{location}.metrics", errors)
    recomputed = _metrics_from_condition(condition)
    if metrics != recomputed:
        errors.append(f"{location}.metrics do not match primitive phase/pair records")
    nonfinite = _strict_int(metrics.get("total_nonfinite_steps"))
    if nonfinite is None or nonfinite < 0:
        errors.append(f"{location}.metrics.total_nonfinite_steps must be non-negative integer")
    for key in _METRIC_KEYS - {"total_nonfinite_steps"}:
        if _finite_number(metrics.get(key)) is None:
            errors.append(f"{location}.metrics.{key} must be finite")


def _validate_condition_record(
    value: object,
    location: str,
    errors: list[str],
) -> None:
    condition = _mapping(value, location, errors)
    if condition is None:
        return
    _exact_keys(condition, _CONDITION_RECORD_KEYS, location, errors)
    phases = condition.get("phase_windows")
    if not isinstance(phases, list) or len(phases) != len(SEGMENT_NAMES):
        errors.append(f"{location}.phase_windows must contain all nine phases")
    else:
        for phase_index, phase in enumerate(phases):
            _validate_phase(
                phase,
                phase_index=phase_index,
                location=f"{location}.phase_windows[{phase_index}]",
                errors=errors,
            )
    _validate_pair_bank(
        condition.get("end_segment_5_active_pairs"),
        f"{location}.end_segment_5_active_pairs",
        errors,
    )
    _validate_pair_bank(
        condition.get("final_active_pairs"),
        f"{location}.final_active_pairs",
        errors,
    )
    _validate_metrics(condition, location, errors)


def _validated_seed_records(
    value: object,
    errors: list[str],
) -> list[Mapping[str, object]]:
    if not isinstance(value, list):
        errors.append("scientific_payload.seed_records must be a list")
        return []
    records: list[Mapping[str, object]] = []
    observed_seeds: list[int] = []
    for index, item in enumerate(value):
        location = f"scientific_payload.seed_records[{index}]"
        record = _mapping(item, location, errors)
        if record is None:
            continue
        _exact_keys(record, {"seed", "conditions"}, location, errors)
        seed = _strict_int(record.get("seed"))
        if seed is None or seed < 0:
            errors.append(f"{location}.seed must be a non-negative integer")
        else:
            observed_seeds.append(seed)
        conditions = _mapping(
            record.get("conditions"),
            f"{location}.conditions",
            errors,
        )
        if conditions is not None:
            _exact_keys(
                conditions,
                set(CONDITION_NAMES),
                f"{location}.conditions",
                errors,
            )
            for condition in CONDITION_NAMES:
                _validate_condition_record(
                    conditions.get(condition),
                    f"{location}.conditions.{condition}",
                    errors,
                )
        records.append(record)
    if observed_seeds != sorted(observed_seeds):
        errors.append("scientific_payload.seed_records must be sorted by seed")
    if len(set(observed_seeds)) != len(observed_seeds):
        errors.append("scientific_payload.seed_records contain duplicate seeds")
    return records


def _validate_source_provenance(
    value: object,
    errors: list[str],
) -> None:
    source = _mapping(
        value,
        "scientific_payload.source_provenance",
        errors,
    )
    if source is None:
        return
    _exact_keys(
        source,
        {"repository_subtree", "git_head", "source_sha256", "interpretation"},
        "scientific_payload.source_provenance",
        errors,
    )
    if source.get("repository_subtree") != "research/alberta":
        errors.append("source_provenance.repository_subtree is inconsistent")
    git_head = source.get("git_head")
    if (
        not isinstance(git_head, str)
        or len(git_head) != 40
        or any(character not in "0123456789abcdef" for character in git_head)
    ):
        errors.append("source_provenance.git_head must be a canonical SHA-1")
    hashes = _mapping(
        source.get("source_sha256"),
        "scientific_payload.source_provenance.source_sha256",
        errors,
    )
    if hashes is not None:
        expected_paths = {path.as_posix() for path in _SOURCE_PATHS}
        _exact_keys(
            hashes,
            expected_paths,
            "scientific_payload.source_provenance.source_sha256",
            errors,
        )
        for path, digest in hashes.items():
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                errors.append(f"source SHA-256 for {path} is malformed")
    if not isinstance(source.get("interpretation"), str):
        errors.append("source_provenance.interpretation must be a string")
    try:
        current_source = _source_provenance()
    except RuntimeError as error:
        errors.append(f"unable to bind current source provenance: {error}")
    else:
        if source != current_source:
            errors.append(
                "scientific_payload.source_provenance does not match current "
                "git HEAD and source hashes"
            )


def _validate_memory(value: object, errors: list[str]) -> Mapping[str, object]:
    memory = _mapping(value, "scientific_payload.memory_by_condition", errors)
    if memory is None:
        return {}
    _exact_keys(
        memory,
        set(CONDITION_NAMES),
        "scientific_payload.memory_by_condition",
        errors,
    )
    expected_fields = set(next(iter(EXPECTED_MEMORY.values())))
    for condition in CONDITION_NAMES:
        condition_memory = _mapping(
            memory.get(condition),
            f"scientific_payload.memory_by_condition.{condition}",
            errors,
        )
        if condition_memory is None:
            continue
        _exact_keys(
            condition_memory,
            expected_fields,
            f"scientific_payload.memory_by_condition.{condition}",
            errors,
        )
        for key in expected_fields:
            value_field = condition_memory.get(key)
            if key == "candidate_archive_is_counted":
                if not isinstance(value_field, bool):
                    errors.append(f"memory_by_condition.{condition}.{key} must be boolean")
            else:
                integer_value = _strict_int(value_field)
                if integer_value is None or integer_value < 0:
                    errors.append(
                        f"memory_by_condition.{condition}.{key} must be a non-negative integer"
                    )
    return memory


def _validate_comparison_shape(
    value: object,
    *,
    sample_size: int,
    location: str,
    errors: list[str],
) -> None:
    comparison = _mapping(value, location, errors)
    if comparison is None:
        return
    _exact_keys(
        comparison,
        {
            "definition",
            "per_seed",
            "minimum_difference",
            "median_difference",
            "paired_mean_interval",
        },
        location,
        errors,
    )
    definition = _mapping(
        comparison.get("definition"),
        f"{location}.definition",
        errors,
    )
    if definition is not None:
        _exact_keys(
            definition,
            {
                "left_condition",
                "left_metric",
                "right_condition",
                "right_metric",
                "operation",
                "interpretation",
            },
            f"{location}.definition",
            errors,
        )
    per_seed = comparison.get("per_seed")
    if not isinstance(per_seed, list) or len(per_seed) != sample_size:
        errors.append(f"{location}.per_seed has wrong sample size")
    else:
        for index, item in enumerate(per_seed):
            record = _mapping(
                item,
                f"{location}.per_seed[{index}]",
                errors,
            )
            if record is not None:
                _exact_keys(
                    record,
                    {"seed", "difference"},
                    f"{location}.per_seed[{index}]",
                    errors,
                )
                if _strict_int(record.get("seed")) is None:
                    errors.append(f"{location}.per_seed[{index}].seed must be integer")
                if _finite_number(record.get("difference")) is None:
                    errors.append(f"{location}.per_seed[{index}].difference must be finite")
    for key in ("minimum_difference", "median_difference"):
        if _finite_number(comparison.get(key)) is None:
            errors.append(f"{location}.{key} must be finite")
    interval = _mapping(
        comparison.get("paired_mean_interval"),
        f"{location}.paired_mean_interval",
        errors,
    )
    if interval is not None:
        _exact_keys(
            interval,
            {
                "estimate",
                "lower",
                "upper",
                "confidence_level",
                "resamples",
                "sample_size",
                "seed",
                "method",
                "quantile_method",
                "pairing_unit",
                "statistic",
            },
            f"{location}.paired_mean_interval",
            errors,
        )
        for key in ("estimate", "lower", "upper", "confidence_level"):
            if _finite_number(interval.get(key)) is None:
                errors.append(f"{location}.paired_mean_interval.{key} must be finite")
        expected = {
            "confidence_level": BOOTSTRAP_CONFIDENCE_LEVEL,
            "resamples": BOOTSTRAP_RESAMPLES,
            "sample_size": sample_size,
            "seed": BOOTSTRAP_SEED,
            "method": BOOTSTRAP_METHOD,
            "quantile_method": "linear",
            "pairing_unit": "seed",
            "statistic": "mean of paired per-seed differences",
        }
        for key, expected_value in expected.items():
            if interval.get(key) != expected_value:
                errors.append(f"{location}.paired_mean_interval.{key} is inconsistent")


def _validate_acceptance_shape(
    value: object,
    errors: list[str],
) -> None:
    acceptance = _mapping(value, "scientific_payload.acceptance", errors)
    if acceptance is None:
        return
    _exact_keys(
        acceptance,
        {"passed", "checks", "retention_ablation_interpretation"},
        "scientific_payload.acceptance",
        errors,
    )
    if not isinstance(acceptance.get("passed"), bool):
        errors.append("scientific_payload.acceptance.passed must be boolean")
    if not isinstance(acceptance.get("retention_ablation_interpretation"), str):
        errors.append("acceptance.retention_ablation_interpretation must be a string")
    checks = acceptance.get("checks")
    if not isinstance(checks, list) or not checks:
        errors.append("scientific_payload.acceptance.checks must be non-empty list")
        return
    names: list[str] = []
    for index, item in enumerate(checks):
        location = f"scientific_payload.acceptance.checks[{index}]"
        check = _mapping(item, location, errors)
        if check is None:
            continue
        _exact_keys(
            check,
            {"name", "actual", "comparator", "threshold", "passed"},
            location,
            errors,
        )
        name = check.get("name")
        if not isinstance(name, str):
            errors.append(f"{location}.name must be string")
        else:
            names.append(name)
        if check.get("comparator") not in {"==", ">=", "<=", ">"}:
            errors.append(f"{location}.comparator is unsupported")
        if not isinstance(check.get("passed"), bool):
            errors.append(f"{location}.passed must be boolean")
    if len(names) != len(set(names)):
        errors.append("scientific_payload.acceptance checks contain duplicate names")


def _validate_operational_metadata(
    value: object,
    errors: list[str],
) -> None:
    operational = _mapping(value, "operational_metadata", errors)
    if operational is None:
        return
    _exact_keys(
        operational,
        {
            "generated_at_utc",
            "wall_time_seconds_by_condition",
            "worktree_dirty",
            "runtime_provenance",
            "interpretation",
        },
        "operational_metadata",
        errors,
    )
    generated = operational.get("generated_at_utc")
    if not isinstance(generated, str):
        errors.append("operational_metadata.generated_at_utc must be string")
    else:
        try:
            parsed = datetime.fromisoformat(generated)
        except ValueError:
            errors.append("operational_metadata.generated_at_utc is invalid ISO-8601")
        else:
            if parsed.tzinfo is None:
                errors.append("operational_metadata.generated_at_utc must include timezone")
    timings = _mapping(
        operational.get("wall_time_seconds_by_condition"),
        "operational_metadata.wall_time_seconds_by_condition",
        errors,
    )
    if timings is not None:
        _exact_keys(
            timings,
            set(CONDITION_NAMES),
            "operational_metadata.wall_time_seconds_by_condition",
            errors,
        )
        for condition in CONDITION_NAMES:
            timing = _finite_number(timings.get(condition))
            if timing is None or timing < 0.0:
                errors.append(
                    f"operational wall time for {condition} must be finite and non-negative"
                )
    if not isinstance(operational.get("worktree_dirty"), bool):
        errors.append("operational_metadata.worktree_dirty must be boolean")
    if not isinstance(operational.get("interpretation"), str):
        errors.append("operational_metadata.interpretation must be string")

    runtime = _mapping(
        operational.get("runtime_provenance"),
        "operational_metadata.runtime_provenance",
        errors,
    )
    if runtime is None:
        return
    _exact_keys(
        runtime,
        {"python", "platform", "packages", "jax"},
        "operational_metadata.runtime_provenance",
        errors,
    )
    nested_schemas = {
        "python": {"implementation", "version"},
        "platform": {"system", "release", "machine"},
        "packages": {"alberta-framework", "jax", "jaxlib", "numpy"},
        "jax": {"default_backend", "devices"},
    }
    for name, keys in nested_schemas.items():
        nested = _mapping(
            runtime.get(name),
            f"operational_metadata.runtime_provenance.{name}",
            errors,
        )
        if nested is not None:
            _exact_keys(
                nested,
                keys,
                f"operational_metadata.runtime_provenance.{name}",
                errors,
            )
    jax_payload = runtime.get("jax")
    if isinstance(jax_payload, Mapping):
        devices = jax_payload.get("devices")
        if not isinstance(devices, list):
            errors.append("runtime_provenance.jax.devices must be list")
        else:
            for index, device in enumerate(devices):
                device_mapping = _mapping(
                    device,
                    f"runtime_provenance.jax.devices[{index}]",
                    errors,
                )
                if device_mapping is not None:
                    _exact_keys(
                        device_mapping,
                        {"platform", "device_kind"},
                        f"runtime_provenance.jax.devices[{index}]",
                        errors,
                    )


def validate_evidence_artifact(
    artifact: Mapping[str, object],
) -> ArtifactValidation:
    """Strictly validate structure, digest, internal bindings, and gate."""

    errors: list[str] = []
    _exact_keys(
        artifact,
        {
            "schema_version",
            "scientific_payload",
            "content_digest",
            "operational_metadata",
        },
        "$",
        errors,
    )
    if artifact.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version must be {SCHEMA_VERSION!r}")

    scientific = _mapping(
        artifact.get("scientific_payload"),
        "scientific_payload",
        errors,
    )
    accepted_by_payload = False
    if scientific is not None:
        _exact_keys(
            scientific,
            {
                "protocol",
                "configuration",
                "thresholds",
                "memory_by_condition",
                "seed_records",
                "aggregate",
                "comparisons",
                "acceptance",
                "source_provenance",
            },
            "scientific_payload",
            errors,
        )
        if scientific.get("protocol") != _protocol_payload():
            errors.append("scientific_payload.protocol is not the frozen v1 protocol")
        if scientific.get("configuration") != frozen_configuration_payload():
            errors.append("scientific_payload.configuration is not the frozen v1 configuration")
        if scientific.get("thresholds") != _threshold_payload():
            errors.append("scientific_payload.thresholds are not the frozen v1 thresholds")
        memory = _validate_memory(
            scientific.get("memory_by_condition"),
            errors,
        )
        records = _validated_seed_records(
            scientific.get("seed_records"),
            errors,
        )
        recomputed_aggregate = _aggregate_payload(records)
        if scientific.get("aggregate") != recomputed_aggregate:
            errors.append("scientific_payload.aggregate does not match primitive records")
        comparisons = scientific.get("comparisons")
        comparisons_mapping = _mapping(
            comparisons,
            "scientific_payload.comparisons",
            errors,
        )
        if comparisons_mapping is not None:
            _exact_keys(
                comparisons_mapping,
                set(_COMPARISON_NAMES),
                "scientific_payload.comparisons",
                errors,
            )
            for name in _COMPARISON_NAMES:
                _validate_comparison_shape(
                    comparisons_mapping.get(name),
                    sample_size=len(records),
                    location=f"scientific_payload.comparisons.{name}",
                    errors=errors,
                )
        recomputed_comparisons = _comparisons_payload(records)
        if comparisons != recomputed_comparisons:
            errors.append("scientific_payload.comparisons do not match primitive records")
        recomputed_acceptance = _acceptance_payload(
            seed_records=records,
            memory=memory,
            aggregate=recomputed_aggregate,
            comparisons=recomputed_comparisons,
        )
        _validate_acceptance_shape(scientific.get("acceptance"), errors)
        if scientific.get("acceptance") != recomputed_acceptance:
            errors.append("scientific_payload.acceptance does not match recomputed gate")
        accepted_by_payload = bool(recomputed_acceptance["passed"])
        _validate_source_provenance(
            scientific.get("source_provenance"),
            errors,
        )

    digest = _mapping(
        artifact.get("content_digest"),
        "content_digest",
        errors,
    )
    if digest is not None:
        _exact_keys(
            digest,
            {"algorithm", "scope", "canonicalization", "sha256"},
            "content_digest",
            errors,
        )
        if digest.get("algorithm") != DIGEST_ALGORITHM:
            errors.append(f"content_digest.algorithm must be {DIGEST_ALGORITHM!r}")
        if digest.get("scope") != DIGEST_SCOPE:
            errors.append(f"content_digest.scope must be {DIGEST_SCOPE!r}")
        if digest.get("canonicalization") != CANONICALIZATION:
            errors.append("content_digest.canonicalization is unsupported")
        recorded = digest.get("sha256")
        if (
            not isinstance(recorded, str)
            or len(recorded) != 64
            or any(character not in "0123456789abcdef" for character in recorded)
        ):
            errors.append("content_digest.sha256 must be canonical SHA-256")
        elif scientific is not None:
            try:
                expected_digest = scientific_payload_sha256(scientific)
            except (TypeError, ValueError) as error:
                errors.append(f"scientific_payload is not canonical finite JSON: {error}")
            else:
                if recorded != expected_digest:
                    errors.append("content_digest.sha256 does not match scientific_payload")

    _validate_operational_metadata(
        artifact.get("operational_metadata"),
        errors,
    )
    valid = not errors
    return ArtifactValidation(
        valid=valid,
        accepted=valid and accepted_by_payload,
        errors=tuple(errors),
    )


__all__ = [
    "ArtifactValidation",
    "BOOTSTRAP_CONFIDENCE_LEVEL",
    "BOOTSTRAP_METHOD",
    "BOOTSTRAP_RESAMPLES",
    "BOOTSTRAP_SEED",
    "CANONICALIZATION",
    "DIGEST_ALGORITHM",
    "DIGEST_SCOPE",
    "PROTOCOL_VERSION",
    "SCHEMA_VERSION",
    "artifact_json",
    "build_evidence_artifact",
    "canonical_scientific_bytes",
    "load_evidence_artifact",
    "paired_bootstrap_mean_interval",
    "scientific_payload_sha256",
    "validate_evidence_artifact",
]
