"""Import and compare seed-level results from the official Foragax agents.

The official agents write one compressed NumPy archive per seed.  Importing
those archives keeps Alberta's comparison tied to the authors' implementations
without copying their code or silently substituting a different DQN/PPO/RTU
implementation.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import numpy as np

from alberta_framework.benchmarks.forager import (
    FORAGAX_AGENTS_URL,
    FORAGAX_PAPER_CONFIG_COMMIT,
    FORAGER_FOV_AGENTS_URL,
    FORAGER_FOV_CONFIG_COMMIT,
    ForagerBenchmarkSummary,
    ForagerEnvConfig,
    ForagerRunResult,
    bootstrap_mean_interval,
    forager_metric_contract,
    summarize_forager_runs,
)

FORAGAX_AGENTS_AUDIT_COMMIT = "9710f60fa30da5badc451ad7ce3ff296d5070830"
FORAGAX_CAMERA_READY_CONFIG_COMMIT = "20617616b27b7cd85a2acbed52a73ff9fa6eb480"
FORAGER_RESULT_SCHEMA_VERSION = "1.0"

ForagerMetric = Literal[
    "mean_reward",
    "final_window_mean_reward",
    "final_ewm_reward",
    "mean_ewm_reward",
]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record_steps(steps: int, record_every: int) -> list[int]:
    targets = [1]
    targets.extend(range(record_every, steps + 1, record_every))
    if targets[-1] != steps:
        targets.append(steps)
    return sorted(set(targets))


def _reward_metrics(
    rewards: np.ndarray,
    *,
    ewm_decay: float,
    record_every: int,
    final_window: int,
    chunk_size: int = 1_000_000,
) -> tuple[
    float,
    float,
    float,
    float,
    tuple[int, ...],
    tuple[float, ...],
    tuple[float, ...],
]:
    """Compute paper-aligned reward summaries with bounded working memory."""
    try:
        from scipy.signal import lfilter
    except ImportError as exc:  # pragma: no cover - scipy is a core dependency
        raise ImportError("scipy is required to import official Foragax results") from exc

    steps = int(rewards.size)
    targets = _record_steps(steps, record_every)
    target_index = 0
    curve_steps: list[int] = []
    curve_ewm: list[float] = []
    curve_window: list[float] = []
    reward_tail = np.zeros((0,), dtype=np.float64)
    filter_state = np.zeros((1,), dtype=np.float64)
    completed = 0
    total_reward = 0.0
    ewm_total = 0.0
    last_filtered = 0.0

    for start in range(0, steps, chunk_size):
        stop = min(steps, start + chunk_size)
        chunk = np.asarray(rewards[start:stop], dtype=np.float64)
        filtered, filter_state = lfilter(
            np.asarray([1.0], dtype=np.float64),
            np.asarray([1.0, -ewm_decay], dtype=np.float64),
            chunk,
            zi=filter_state,
        )
        last_filtered = float(filtered[-1])
        total_reward += float(np.sum(chunk, dtype=np.float64))
        step_numbers = np.arange(
            completed + 1,
            completed + chunk.size + 1,
            dtype=np.float64,
        )
        denominators = (
            np.ones_like(step_numbers)
            if ewm_decay == 0.0
            else (1.0 - np.power(ewm_decay, step_numbers)) / (1.0 - ewm_decay)
        )
        ewm_values = filtered / denominators
        ewm_total += float(np.sum(ewm_values, dtype=np.float64))

        combined = np.concatenate((reward_tail, chunk))
        prefix = np.concatenate(
            (np.zeros((1,), dtype=np.float64), np.cumsum(combined, dtype=np.float64))
        )
        active = stop - start
        while target_index < len(targets) and targets[target_index] <= completed + active:
            step_number = targets[target_index]
            local_count = step_number - completed
            combined_end = reward_tail.size + local_count
            combined_start = max(0, combined_end - final_window)
            window_sum = prefix[combined_end] - prefix[combined_start]
            window_count = combined_end - combined_start
            curve_steps.append(step_number)
            curve_ewm.append(float(ewm_values[local_count - 1]))
            curve_window.append(float(window_sum / window_count))
            target_index += 1
        reward_tail = combined[-min(final_window, combined.size) :]
        completed += active

    final_denominator = 1.0 if ewm_decay == 0.0 else (1.0 - ewm_decay**steps) / (1.0 - ewm_decay)
    return (
        total_reward,
        float(np.mean(reward_tail)),
        last_filtered / final_denominator,
        ewm_total / steps,
        tuple(curve_steps),
        tuple(curve_ewm),
        tuple(curve_window),
    )


@dataclass(frozen=True)
class OfficialForagaxRunSpec:
    """Provenance required to import one official-agent result archive."""

    agent: str
    seed: int
    path: Path
    environment: ForagerEnvConfig = dataclasses.field(
        default_factory=ForagerEnvConfig.paper_relearning
    )
    privileged: bool = False
    source_repository: str | None = None
    source_commit: str | None = None
    config_path: str | None = None
    expected_steps: int | None = None
    protocol_attested: bool = False

    def __post_init__(self) -> None:
        if self.protocol_attested and (
            self.source_repository is None or self.source_commit is None
        ):
            raise ValueError(
                "protocol-attested imports require explicit source_repository and source_commit"
            )
        source_repository = self.source_repository or (
            FORAGER_FOV_AGENTS_URL
            if self.environment.preset == "field_of_view"
            else FORAGAX_AGENTS_URL
        )
        source_commit = self.source_commit or (
            FORAGER_FOV_CONFIG_COMMIT
            if self.environment.preset == "field_of_view"
            else FORAGAX_PAPER_CONFIG_COMMIT
        )
        object.__setattr__(self, "source_repository", source_repository)
        object.__setattr__(self, "source_commit", source_commit)
        if not self.agent.strip():
            raise ValueError("agent must be non-empty")
        if source_repository not in {
            FORAGAX_AGENTS_URL,
            FORAGER_FOV_AGENTS_URL,
        }:
            raise ValueError("source_repository must be a recognized official agent repository")
        if self.expected_steps is not None and self.expected_steps < 1:
            raise ValueError("expected_steps must be positive")
        if self.protocol_attested and not self.config_path:
            raise ValueError("protocol-attested imports require config_path")
        if self.protocol_attested and (
            len(source_commit) != 40
            or any(character not in "0123456789abcdef" for character in source_commit)
        ):
            raise ValueError("protocol-attested imports require a full lowercase commit SHA")


def import_official_foragax_npz(
    spec: OfficialForagaxRunSpec,
    *,
    ewm_decay: float = 0.999,
    record_every: int = 1_000,
    final_window: int = 100_000,
) -> ForagerRunResult:
    """Convert one official ``data/<seed>.npz`` archive to Alberta's schema."""
    path = spec.path.expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    if spec.protocol_attested and path.name != f"{spec.seed}.npz":
        raise ValueError(
            "protocol-attested official archives must retain the authors' "
            f"<seed>.npz filename; expected {spec.seed}.npz, found {path.name!r}"
        )
    with np.load(path, allow_pickle=False) as archive:
        if "rewards" not in archive:
            raise ValueError(f"{path} does not contain a 'rewards' array")
        rewards = np.asarray(archive["rewards"])
        biome_regret = (
            np.asarray(archive["biome_regret"], dtype=np.float64)
            if "biome_regret" in archive
            else np.zeros((0,), dtype=np.float64)
        )
    rewards = np.squeeze(rewards)
    if rewards.ndim != 1 or rewards.size == 0:
        raise ValueError(
            f"{path} rewards must be a non-empty one-dimensional array, got shape {rewards.shape}"
        )
    if not np.all(np.isfinite(rewards)):
        raise FloatingPointError(f"{path} contains non-finite rewards")
    steps = int(rewards.size)
    if spec.expected_steps is not None and steps != spec.expected_steps:
        raise ValueError(f"{path} contains {steps} rewards; expected {spec.expected_steps}")
    (
        total_reward,
        final_window_mean,
        final_ewm,
        mean_ewm,
        curve_steps,
        curve_ewm,
        curve_window,
    ) = _reward_metrics(
        rewards,
        ewm_decay=ewm_decay,
        record_every=record_every,
        final_window=final_window,
    )

    finite_regret = biome_regret[np.isfinite(biome_regret)]
    mean_regret = float(np.mean(finite_regret)) if finite_regret.size else math.nan
    final_regret = float(np.ravel(biome_regret)[-1]) if biome_regret.size else math.nan
    metadata: dict[str, Any] = {
        "name": spec.agent,
        "privileged": spec.privileged,
        "seed": spec.seed,
        "result_source": "official_foragax_agents_npz",
        "source_repository": spec.source_repository,
        "source_commit": spec.source_commit,
        "config_path": spec.config_path,
        "archive_path": str(path),
        "archive_sha256": _sha256(path),
        "protocol_attested": spec.protocol_attested,
        "timing_available": False,
        "comparison_note": (
            "Imported seed-level output from the official agent repository. "
            "A paper-faithful claim additionally requires protocol_attested=true."
        ),
    }
    return ForagerRunResult(
        agent=spec.agent,
        privileged=spec.privileged,
        seed=spec.seed,
        steps=steps,
        total_reward=total_reward,
        mean_reward=total_reward / steps,
        final_window_mean_reward=final_window_mean,
        final_ewm_reward=final_ewm,
        mean_ewm_reward=mean_ewm,
        mean_biome_regret=mean_regret,
        final_biome_regret=final_regret,
        curve_steps=curve_steps,
        curve_ewm_reward=curve_ewm,
        curve_window_reward=curve_window,
        duration_s=math.nan,
        frames_per_second=math.nan,
        environment=spec.environment.to_dict(),
        metric_contract=forager_metric_contract(
            ewm_decay=ewm_decay,
            final_window=final_window,
            record_every=record_every,
            steps=steps,
        ),
        agent_metadata=metadata,
    )


def _environment_signature(run: ForagerRunResult) -> tuple[Any, ...]:
    return (
        json.dumps(run.environment, sort_keys=True, default=str),
        json.dumps(run.metric_contract, sort_keys=True, default=str),
        run.steps,
    )


@dataclass(frozen=True)
class ForagerPairedComparison:
    """Paired-seed bootstrap difference between two methods."""

    candidate: str
    baseline: str
    candidate_privileged: bool
    baseline_privileged: bool
    metric: ForagerMetric
    seeds: tuple[int, ...]
    mean_difference: float
    ci_low: float
    ci_high: float
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        data = dataclasses.asdict(self)
        data["seeds"] = list(self.seeds)
        return data


def paired_forager_comparison(
    candidate_runs: Sequence[ForagerRunResult],
    baseline_runs: Sequence[ForagerRunResult],
    *,
    metric: ForagerMetric = "mean_reward",
    confidence: float = 0.95,
    bootstrap_resamples: int = 10_000,
    bootstrap_seed: int = 0,
) -> ForagerPairedComparison:
    """Compare methods using identical seeds and environment contracts."""
    if not candidate_runs or not baseline_runs:
        raise ValueError("both candidate_runs and baseline_runs are required")
    for label, method_runs in (
        ("candidate", candidate_runs),
        ("baseline", baseline_runs),
    ):
        if any(
            run.agent_metadata.get("result_source") == "official_foragax_agents_npz"
            and run.agent_metadata.get("protocol_attested") is not True
            for run in method_runs
        ):
            raise ValueError(f"{label} contains an official archive without protocol attestation")
    summarize_forager_runs(
        candidate_runs,
        metric=metric,
        confidence=confidence,
        bootstrap_resamples=1,
        bootstrap_seed=bootstrap_seed,
    )
    summarize_forager_runs(
        baseline_runs,
        metric=metric,
        confidence=confidence,
        bootstrap_resamples=1,
        bootstrap_seed=bootstrap_seed,
    )
    candidate_by_seed = {run.seed: run for run in candidate_runs}
    baseline_by_seed = {run.seed: run for run in baseline_runs}
    if len(candidate_by_seed) != len(candidate_runs) or len(baseline_by_seed) != len(baseline_runs):
        raise ValueError("each method must contain at most one run per seed")
    if candidate_by_seed.keys() != baseline_by_seed.keys():
        raise ValueError("paired comparison requires identical seed sets")
    seeds = tuple(sorted(candidate_by_seed))
    for seed in seeds:
        candidate = candidate_by_seed[seed]
        baseline = baseline_by_seed[seed]
        if _environment_signature(candidate) != _environment_signature(baseline):
            raise ValueError(
                f"seed {seed} uses different environment, interaction budget, or metric contract"
            )
    differences = [
        float(getattr(candidate_by_seed[seed], metric))
        - float(getattr(baseline_by_seed[seed], metric))
        for seed in seeds
    ]
    mean, low, high = bootstrap_mean_interval(
        differences,
        confidence=confidence,
        resamples=bootstrap_resamples,
        seed=bootstrap_seed,
    )
    return ForagerPairedComparison(
        candidate=candidate_runs[0].agent,
        baseline=baseline_runs[0].agent,
        candidate_privileged=candidate_runs[0].privileged,
        baseline_privileged=baseline_runs[0].privileged,
        metric=metric,
        seeds=seeds,
        mean_difference=mean,
        ci_low=low,
        ci_high=high,
        confidence=confidence,
    )


@dataclass(frozen=True)
class ForagerComparisonReport:
    """Summaries and valid paired comparisons for one candidate."""

    candidate: str
    metric: ForagerMetric
    summaries: Mapping[str, ForagerBenchmarkSummary]
    paired_comparisons: tuple[ForagerPairedComparison, ...]
    unpaired_methods: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": FORAGER_RESULT_SCHEMA_VERSION,
            "candidate": self.candidate,
            "metric": self.metric,
            "summaries": {name: summary.to_dict() for name, summary in self.summaries.items()},
            "paired_comparisons": [comparison.to_dict() for comparison in self.paired_comparisons],
            "unpaired_methods": list(self.unpaired_methods),
        }


def build_forager_comparison_report(
    runs: Sequence[ForagerRunResult],
    *,
    candidate: str = "alberta_horde_ac",
    metric: ForagerMetric = "mean_reward",
    confidence: float = 0.95,
    bootstrap_resamples: int = 10_000,
    bootstrap_seed: int = 0,
) -> ForagerComparisonReport:
    """Group seed runs and compare every exactly paired method to Alberta."""
    grouped: dict[str, list[ForagerRunResult]] = {}
    for run in runs:
        grouped.setdefault(run.agent, []).append(run)
    if candidate not in grouped:
        raise ValueError(f"candidate {candidate!r} is absent from runs")
    summaries = {
        name: summarize_forager_runs(
            method_runs,
            metric=metric,
            confidence=confidence,
            bootstrap_resamples=bootstrap_resamples,
            bootstrap_seed=bootstrap_seed,
        )
        for name, method_runs in grouped.items()
    }
    candidate_seeds = {run.seed for run in grouped[candidate]}
    comparisons: list[ForagerPairedComparison] = []
    unpaired: list[str] = []
    for name, method_runs in grouped.items():
        if name == candidate:
            continue
        if {run.seed for run in method_runs} != candidate_seeds:
            unpaired.append(name)
            continue
        try:
            comparisons.append(
                paired_forager_comparison(
                    grouped[candidate],
                    method_runs,
                    metric=metric,
                    confidence=confidence,
                    bootstrap_resamples=bootstrap_resamples,
                    bootstrap_seed=bootstrap_seed,
                )
            )
        except ValueError:
            unpaired.append(name)
    return ForagerComparisonReport(
        candidate=candidate,
        metric=metric,
        summaries=summaries,
        paired_comparisons=tuple(comparisons),
        unpaired_methods=tuple(sorted(unpaired)),
    )
