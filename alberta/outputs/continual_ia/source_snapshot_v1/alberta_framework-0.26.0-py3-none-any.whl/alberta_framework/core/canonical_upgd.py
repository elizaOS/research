"""Canonical first-order Utility-based Perturbed Gradient Descent.

This module implements the weight-wise UPGD update from Elsayed and Mahmood,
ICLR 2024, as a small JAX PyTree transform.  It is intentionally separate from
``core.upgd.UPGDLearner``: that historical Alberta learner uses absolute
``|w g|`` utility and a power gate, and changing it in place would invalidate
existing checkpoints and results.

The protecting update is

``w <- (1 - alpha * weight_decay) * w
       - alpha * (gradient + noise) * (1 - scaled_utility)``.

The non-protecting ablation gates only the perturbation.  Utility is the signed
first-order Taylor approximation ``-gradient * weight``, accumulated with an
EMA and bias correction.  Global scaling divides by the maximum corrected
utility across eligible parameters; local scaling uses an L2 norm along each
leaf's final axis, matching the paper's row-local weight normalization.

Reference:
    Elsayed, M. & Mahmood, A. R. (2024). Addressing Loss of Plasticity and
    Catastrophic Forgetting in Continual Learning. ICLR 2024.
    https://openreview.net/forum?id=sKPzAXoylB

    Released MIT implementation audited at commit
    ``b75e90ad4b09c28971ac9dbb902a8fd86709b28c``:
    https://github.com/mohmdelsayed/upgd
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Literal

import chex
import jax
import jax.numpy as jnp
import jax.random as jr
from jax import Array
from jaxtyping import Int

UPGDMode = Literal["protecting", "non_protecting"]
UPGDNormalization = Literal["global", "local", "official_code_global"]


@dataclass(frozen=True)
class CanonicalUPGDConfig:
    """Configuration for canonical first-order UPGD.

    Args:
        step_size: Base gradient step size ``alpha``.
        utility_decay: EMA decay ``beta`` for signed utility.
        noise_std: Standard deviation ``sigma`` of Gaussian perturbations.
        weight_decay: Decoupled UPGD-W decay coefficient.
        mode: ``"protecting"`` gates gradient and noise;
            ``"non_protecting"`` gates noise only.
        normalization: Paper-canonical global maximum, leaf-local L2 scaling,
            or ``"official_code_global"`` compatibility with the authors'
            released PyTorch implementation.  The released global code divides
            bias-corrected utilities by the maximum *uncorrected* EMA, unlike
            Algorithm 1 in the paper.
        epsilon: Positive numerical floor for normalization and bias correction.
    """

    step_size: float = 1e-3
    utility_decay: float = 0.999
    noise_std: float = 1e-3
    weight_decay: float = 0.0
    mode: UPGDMode = "protecting"
    normalization: UPGDNormalization = "global"
    epsilon: float = 1e-8

    def __post_init__(self) -> None:
        if not math.isfinite(self.step_size) or self.step_size <= 0.0:
            raise ValueError("step_size must be finite and positive")
        if (
            not math.isfinite(self.utility_decay)
            or not 0.0 <= self.utility_decay < 1.0
        ):
            raise ValueError("utility_decay must be finite and in [0, 1)")
        if not math.isfinite(self.noise_std) or self.noise_std < 0.0:
            raise ValueError("noise_std must be finite and non-negative")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0.0:
            raise ValueError("weight_decay must be finite and non-negative")
        if self.mode not in {"protecting", "non_protecting"}:
            raise ValueError("mode must be 'protecting' or 'non_protecting'")
        if self.normalization not in {
            "global",
            "local",
            "official_code_global",
        }:
            raise ValueError(
                "normalization must be 'global', 'local', or "
                "'official_code_global'"
            )
        if not math.isfinite(self.epsilon) or self.epsilon <= 0.0:
            raise ValueError("epsilon must be finite and positive")

    def to_config(self) -> dict[str, object]:
        """Return a JSON-serializable configuration."""

        return {
            "type": "CanonicalUPGD",
            "step_size": self.step_size,
            "utility_decay": self.utility_decay,
            "noise_std": self.noise_std,
            "weight_decay": self.weight_decay,
            "mode": self.mode,
            "normalization": self.normalization,
            "epsilon": self.epsilon,
        }

    @classmethod
    def from_config(cls, config: dict[str, object]) -> CanonicalUPGDConfig:
        """Reconstruct a configuration and reject a mismatched type tag."""

        payload = dict(config)
        type_name = payload.pop("type", "CanonicalUPGD")
        if type_name != "CanonicalUPGD":
            raise ValueError(f"expected CanonicalUPGD config, got {type_name!r}")
        return cls(**payload)  # type: ignore[arg-type]


@chex.dataclass(frozen=True)
class CanonicalUPGDState:
    """Optimizer state for an arbitrary parameter PyTree."""

    utility_ema: Any
    utility_age: Any
    step: Int[Array, ""]


@chex.dataclass(frozen=True)
class CanonicalUPGDUpdate:
    """Result of one functional UPGD update."""

    params: Any
    state: CanonicalUPGDState
    next_key: Array
    scaled_utility: Any
    corrected_utility: Any
    perturbation: Any
    metrics: dict[str, Array]


def _flatten_with_none(tree: Any) -> tuple[list[Any], jax.tree_util.PyTreeDef]:
    """Flatten a PyTree while treating a missing gradient as a leaf."""

    leaves, structure = jax.tree_util.tree_flatten(
        tree,
        is_leaf=lambda value: value is None,
    )
    return list(leaves), structure


def _local_normalize(utility: Array, epsilon: float) -> Array:
    """Apply Algorithm 2's row-local L2 normalization to one parameter leaf."""

    if utility.ndim == 0:
        denominator = jnp.maximum(jnp.abs(utility), epsilon)
    else:
        denominator = jnp.maximum(
            jnp.linalg.norm(utility, axis=-1, keepdims=True),
            epsilon,
        )
    return utility / denominator


def _safe_signed_denominator(value: Array, epsilon: float) -> Array:
    """Floor a scalar magnitude without changing its sign."""

    signed_floor = jnp.where(value < 0.0, -epsilon, epsilon)
    return jnp.where(jnp.abs(value) >= epsilon, value, signed_floor)


class CanonicalUPGD:
    """Functional, JIT-compatible first-order UPGD PyTree transform."""

    def __init__(self, config: CanonicalUPGDConfig | None = None):
        self._config = CanonicalUPGDConfig() if config is None else config

    @property
    def config(self) -> CanonicalUPGDConfig:
        """Return the immutable optimizer configuration."""

        return self._config

    def to_config(self) -> dict[str, object]:
        """Serialize the optimizer configuration."""

        return self._config.to_config()

    @classmethod
    def from_config(cls, config: dict[str, object]) -> CanonicalUPGD:
        """Reconstruct an optimizer from serialized configuration."""

        return cls(CanonicalUPGDConfig.from_config(config))

    def init(self, params: Any) -> CanonicalUPGDState:
        """Initialize signed-utility traces matching ``params``."""

        return CanonicalUPGDState(
            utility_ema=jax.tree.map(jnp.zeros_like, params),
            utility_age=jax.tree.map(
                lambda value: jnp.zeros(value.shape, dtype=jnp.int32),
                params,
            ),
            step=jnp.array(0, dtype=jnp.int32),
        )

    def update(
        self,
        state: CanonicalUPGDState,
        params: Any,
        gradients: Any,
        key: Array,
        *,
        mask: Any | None = None,
        noise: Any | None = None,
    ) -> CanonicalUPGDUpdate:
        """Apply one canonical UPGD-W step.

        ``mask`` controls where UPGD utility/noise gating applies.  Masked-out
        parameters still receive ordinary gradient and decoupled weight-decay
        updates, allowing callers to protect a trunk while training heads and
        biases with plain SGDW.  A ``None`` gradient or a non-finite gradient
        skips that parameter element entirely and is reported in metrics.

        ``noise`` may supply the already-scaled perturbation PyTree ``xi`` for
        equation-level parity tests.  Normal operation omits it and samples
        ``N(0, noise_std**2)`` from ``key``.
        """

        param_leaves, structure = _flatten_with_none(params)
        grad_leaves, grad_structure = _flatten_with_none(gradients)
        utility_leaves, utility_structure = _flatten_with_none(state.utility_ema)
        age_leaves, age_structure = _flatten_with_none(state.utility_age)
        if not (
            structure == grad_structure == utility_structure == age_structure
        ):
            raise ValueError("params, gradients, and UPGD state must share a PyTree structure")

        if mask is None:
            mask_leaves = [jnp.ones_like(value, dtype=jnp.bool_) for value in param_leaves]
        else:
            mask_leaves, mask_structure = _flatten_with_none(mask)
            if mask_structure != structure:
                raise ValueError("mask must share the parameter PyTree structure")

        if noise is None:
            supplied_noise_leaves: list[Any] = [None] * len(param_leaves)
        else:
            supplied_noise_leaves, noise_structure = _flatten_with_none(noise)
            if noise_structure != structure:
                raise ValueError("noise must share the parameter PyTree structure")

        split_keys = jr.split(key, len(param_leaves) + 1)
        next_key = split_keys[0]
        noise_keys = split_keys[1:]
        beta = self._config.utility_decay

        corrected_leaves: list[Array] = []
        new_utility_leaves: list[Array] = []
        new_age_leaves: list[Array] = []
        finite_masks: list[Array] = []
        eligible_masks: list[Array] = []
        clean_gradients: list[Array] = []

        for param, gradient, utility, age, mask_leaf in zip(
            param_leaves,
            grad_leaves,
            utility_leaves,
            age_leaves,
            mask_leaves,
            strict=True,
        ):
            eligible = jnp.broadcast_to(jnp.asarray(mask_leaf, dtype=jnp.bool_), param.shape)
            if gradient is None:
                finite = jnp.zeros(param.shape, dtype=jnp.bool_)
                clean_gradient = jnp.zeros_like(param)
            else:
                gradient_array = jnp.asarray(gradient, dtype=param.dtype)
                if gradient_array.shape != param.shape:
                    raise ValueError("every gradient leaf must match its parameter shape")
                finite = jnp.isfinite(param) & jnp.isfinite(gradient_array)
                clean_gradient = jnp.where(finite, gradient_array, 0.0)

            utility_active = eligible & finite
            instantaneous = -clean_gradient * param
            next_utility = jnp.where(
                utility_active,
                beta * utility + (1.0 - beta) * instantaneous,
                utility,
            )
            next_age = age + utility_active.astype(jnp.int32)
            bias_correction = 1.0 - jnp.power(beta, next_age.astype(param.dtype))
            corrected = jnp.where(
                next_age > 0,
                next_utility / jnp.maximum(bias_correction, self._config.epsilon),
                0.0,
            )

            clean_gradients.append(clean_gradient)
            finite_masks.append(finite)
            eligible_masks.append(eligible)
            new_utility_leaves.append(next_utility)
            new_age_leaves.append(next_age)
            corrected_leaves.append(corrected)

        if self._config.normalization in {"global", "official_code_global"}:
            maximum = jnp.array(-jnp.inf, dtype=jnp.float32)
            has_eligible = jnp.array(False)
            reference_leaves = (
                corrected_leaves
                if self._config.normalization == "global"
                else new_utility_leaves
            )
            for reference, eligible, age in zip(
                reference_leaves,
                eligible_masks,
                new_age_leaves,
                strict=True,
            ):
                valid = eligible & (age > 0) & jnp.isfinite(reference)
                leaf_maximum = jnp.max(
                    jnp.where(valid, reference, -jnp.inf),
                    initial=-jnp.inf,
                )
                maximum = jnp.maximum(maximum, leaf_maximum.astype(jnp.float32))
                has_eligible = has_eligible | jnp.any(valid)
            global_maximum = jnp.where(has_eligible, maximum, 0.0)
            denominator = _safe_signed_denominator(
                global_maximum,
                self._config.epsilon,
            )
            normalized_leaves = [
                corrected / denominator.astype(corrected.dtype)
                for corrected in corrected_leaves
            ]
        else:
            global_maximum = jnp.array(jnp.nan, dtype=jnp.float32)
            normalized_leaves = [
                _local_normalize(corrected, self._config.epsilon)
                for corrected in corrected_leaves
            ]

        new_param_leaves: list[Array] = []
        gate_leaves: list[Array] = []
        perturbation_leaves: list[Array] = []
        gate_sum = jnp.array(0.0, dtype=jnp.float32)
        utility_sum = jnp.array(0.0, dtype=jnp.float32)
        eligible_count = jnp.array(0.0, dtype=jnp.float32)
        nonfinite_count = jnp.array(0.0, dtype=jnp.float32)

        for (
            param,
            gradient,
            normalized,
            corrected,
            finite,
            eligible,
            noise_key,
            supplied_noise,
        ) in zip(
            param_leaves,
            clean_gradients,
            normalized_leaves,
            corrected_leaves,
            finite_masks,
            eligible_masks,
            noise_keys,
            supplied_noise_leaves,
            strict=True,
        ):
            gate = jnp.where(eligible, jax.nn.sigmoid(normalized), 0.0)
            if supplied_noise is None:
                sampled_noise = (
                    jr.normal(noise_key, param.shape, dtype=param.dtype)
                    * self._config.noise_std
                )
            else:
                sampled_noise = jnp.asarray(supplied_noise, dtype=param.dtype)
                if sampled_noise.shape != param.shape:
                    raise ValueError("every noise leaf must match its parameter shape")
            finite_noise = jnp.where(jnp.isfinite(sampled_noise), sampled_noise, 0.0)
            perturbation = jnp.where(eligible & finite, finite_noise, 0.0)

            if self._config.mode == "protecting":
                direction = (gradient + perturbation) * (1.0 - gate)
            else:
                direction = gradient + perturbation * (1.0 - gate)

            decayed = param * (
                1.0 - self._config.step_size * self._config.weight_decay
            )
            candidate = decayed - self._config.step_size * direction
            updated = jnp.where(finite, candidate, param)

            count = jnp.sum(eligible.astype(jnp.float32))
            gate_sum = gate_sum + jnp.sum(gate.astype(jnp.float32))
            utility_sum = utility_sum + jnp.sum(
                jnp.where(eligible, jnp.abs(corrected), 0.0).astype(jnp.float32)
            )
            eligible_count = eligible_count + count
            nonfinite_count = nonfinite_count + jnp.sum((~finite).astype(jnp.float32))

            new_param_leaves.append(updated)
            gate_leaves.append(gate)
            perturbation_leaves.append(perturbation)

        count_floor = jnp.maximum(eligible_count, 1.0)
        next_state = CanonicalUPGDState(
            utility_ema=jax.tree_util.tree_unflatten(structure, new_utility_leaves),
            utility_age=jax.tree_util.tree_unflatten(structure, new_age_leaves),
            step=state.step + jnp.array(1, dtype=jnp.int32),
        )
        return CanonicalUPGDUpdate(
            params=jax.tree_util.tree_unflatten(structure, new_param_leaves),
            state=next_state,
            next_key=next_key,
            scaled_utility=jax.tree_util.tree_unflatten(structure, gate_leaves),
            corrected_utility=jax.tree_util.tree_unflatten(
                structure,
                corrected_leaves,
            ),
            perturbation=jax.tree_util.tree_unflatten(
                structure,
                perturbation_leaves,
            ),
            metrics={
                "mean_scaled_utility": gate_sum / count_floor,
                "mean_absolute_utility": utility_sum / count_floor,
                "global_maximum_utility": global_maximum,
                "eligible_parameter_count": eligible_count,
                "nonfinite_or_missing_count": nonfinite_count,
            },
        )
