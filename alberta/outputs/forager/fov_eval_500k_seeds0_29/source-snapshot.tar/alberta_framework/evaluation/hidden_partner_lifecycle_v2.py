"""Development-only v2 lifecycle metrics and evidence-lease tuning grid.

This module closes the endpoint loopholes in the original hidden-partner
diagnostic.  Feature presence is indexed by the representation available for
decision ``t``.  A lifecycle event produced while processing transition ``t``
therefore first changes presence at decision ``t + 1``.

The exhaustive 66-pair archive is reported separately from the scarce
deployed bank.  Retirement means release of deployed capacity and reset of the
candidate's learned head; it does not erase the enumerated descriptor.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import math
from collections.abc import Sequence
from typing import cast

import numpy as np

from alberta_framework.core.integrated_hidden_partner import (
    IntegratedHiddenPartnerConfig,
)
from alberta_framework.evaluation.hidden_partner_development import (
    HiddenPartnerCondition,
    HiddenPartnerDevelopmentProtocol,
    HiddenPartnerDevelopmentRunner,
    HiddenPartnerRunResult,
    HiddenPartnerSeedPair,
    derive_hidden_partner_seed_pairs,
)

HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA = "alberta.hidden-partner-development.lifecycle.v2"
LEASE_TUNING_NAMESPACE = "hidden-partner-v0-dev-v2-evidence-lease-grid-c-v1"
LEASE_TUNING_SEED_COUNT = 8
TUNING_SELECTION_RULE: dict[str, object] = {
    "feasibility": (
        "all finite/contracts; mean reward >=0.85; minimum reward "
        ">=0.80; and at least 75% per-life joint C-retain/D-retire success"
    ),
    "lexicographic_maximum": [
        "joint_success_count",
        "minimum_seed_reward",
        "mean_reward",
        "negative_total_d_repromotions",
        "negative_median_d_retirement_latency_steps",
        "negative_cell_index",
    ],
    "no_feasible_cell_result": None,
}

FEATURE_LEARNING_WINDOW = 128
RETIREMENT_CONFIRMATION_WINDOW = 128
FINAL_ABSENCE_WINDOW = 256
RECURRENT_ENTRY_WINDOW = 128
CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD = 0.80
CRITICAL_MASKED_NLL_INCREASE_THRESHOLD = 0.005
CRITICAL_MASKED_NLL_POSITIVE_FRACTION_THRESHOLD = 0.55
RECURRENT_EARLY_REWARD_THRESHOLD = 0.75
INITIAL_LATE_REWARD_THRESHOLD = 0.75
RETENTION_RATIO_THRESHOLD = 0.80
MINIMUM_JOINT_SUCCESS_FRACTION = 0.75
CHANCE_REWARD = 0.50

LEASE_TUNING_SCOPE_LIMITS = (
    "scripted nonlearning partner",
    "hard-coded C and D identities",
    "fixed schedule with unequal recurrence gaps",
    "exhaustive enumerated pair archive",
    "interaction-task utility only",
    "feature masking is a same-state diagnostic, not an executed intervention",
    "retirement releases deployed capacity but preserves the descriptor archive",
    "development tuning seeds cannot promote evidence",
)

_C_PAIR = (0, 2)
_D_PAIR = (4, 5)


@dataclasses.dataclass(frozen=True)
class EvidenceLeaseTuningCell:
    """One immutable cell in the consumed v2 lease grid."""

    index: int
    grace_steps: int
    evidence_threshold: float
    candidate_promotion_floor: float = 0.01

    def agent_config(self) -> IntegratedHiddenPartnerConfig:
        return IntegratedHiddenPartnerConfig(
            active_utility_retention_grace_steps=self.grace_steps,
            active_utility_evidence_threshold=self.evidence_threshold,
            retire_stale_features=True,
            candidate_promotion_floor=self.candidate_promotion_floor,
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "index": self.index,
            "grace_steps": self.grace_steps,
            "evidence_threshold": self.evidence_threshold,
            "candidate_promotion_floor": self.candidate_promotion_floor,
            "agent_config": self.agent_config().to_config(),
        }


LEASE_TUNING_GRID: tuple[EvidenceLeaseTuningCell, ...] = tuple(
    EvidenceLeaseTuningCell(index=index, grace_steps=grace, evidence_threshold=threshold)
    for index, (grace, threshold) in enumerate(
        (
            (2_048, 0.075),
            (2_048, 0.10),
            (3_072, 0.10),
            (3_072, 0.15),
            (3_072, 0.20),
            (4_096, 0.10),
            (4_096, 0.20),
            (4_096, 0.40),
        )
    )
)


@dataclasses.dataclass(frozen=True)
class CriticalPairLifecycleInterval:
    """Canonical half-open run of critical-pair bank locations."""

    start: int
    end_exclusive: int
    deployed_slot: int
    shadow_slot: int
    candidate_slot: int

    def to_dict(self) -> dict[str, int]:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class CriticalLifecycleV2Summary:
    """Continuous C retention and per-life D learned-then-retired metrics."""

    cycle_steps: int
    decision_state_count: int
    representation_link_contract_valid: bool
    c_shadow_deployed_mismatch_steps: int
    d_shadow_deployed_mismatch_steps: int
    c_promotion_event_steps: tuple[int, ...]
    c_acquisition_step: int | None
    c_first_late_reward: float
    c_first_late_intended_accuracy: float
    c_first_late_masked_nll_increase: float
    c_first_late_masked_nll_positive_fraction: float
    c_task_learned: bool
    c_survival_end_exclusive: int
    c_survival_gap_steps: int | None
    c_first_survival_gap_step: int | None
    c_evictions_after_acquisition: int
    c_repromotions_after_acquisition: int
    c_continuously_survived: bool
    c_recurrent_early_reward: float
    c_recurrent_early_excess_reward_retention: float
    c_recurrent_early_intended_accuracy: float
    c_recurrent_early_masked_nll_increase: float
    c_recurrent_early_masked_nll_positive_fraction: float
    c_retained_and_used: bool
    d_promotion_event_steps: tuple[int, ...]
    d_acquisition_step: int | None
    d_deployed_through_exit: bool
    d_late_reward: float
    d_late_intended_accuracy: float
    d_late_masked_nll_increase: float
    d_late_masked_nll_positive_fraction: float
    d_task_learned: bool
    d_retirement_event_step: int | None
    d_retirement_step: int | None
    d_retirement_event_latency_steps: int | None
    d_retirement_latency_steps: int | None
    d_post_exit_live_slot_steps: int
    d_post_exit_live_fraction: float
    d_post_exit_promotion_count: int
    d_repromotions_after_retirement: int
    d_absent_entire_final_window: bool
    d_retirement_event_steps: tuple[int, ...]
    d_retirement_event_reset_counts: tuple[int, ...]
    d_retirement_event_candidate_utility_post: tuple[float, ...]
    d_retirement_event_candidate_head_linf_post: tuple[float, ...]
    d_retirement_event_candidate_age_post: tuple[int, ...]
    d_retirement_event_count: int
    d_matching_candidate_reset_count: int
    d_linked_matching_candidate_reset_count: int | None
    d_linked_candidate_utility_post: float | None
    d_linked_candidate_head_linf_post: float | None
    d_linked_candidate_age_post: int | None
    d_retirement_event_aligned: bool
    d_learned_then_stably_retired: bool
    joint_memory_management_success: bool
    candidate_archive_contract_valid: bool
    c_candidate_utility_at_life_end: float
    d_candidate_utility_at_life_end: float
    c_lifecycle_rle: tuple[CriticalPairLifecycleInterval, ...]
    d_lifecycle_rle: tuple[CriticalPairLifecycleInterval, ...]

    def to_dict(self) -> dict[str, object]:
        payload = dataclasses.asdict(self)
        for field in (
            "c_promotion_event_steps",
            "d_promotion_event_steps",
            "d_retirement_event_steps",
            "d_retirement_event_reset_counts",
            "d_retirement_event_candidate_utility_post",
            "d_retirement_event_candidate_head_linf_post",
            "d_retirement_event_candidate_age_post",
        ):
            payload[field] = list(payload[field])
        payload["c_lifecycle_rle"] = [interval.to_dict() for interval in self.c_lifecycle_rle]
        payload["d_lifecycle_rle"] = [interval.to_dict() for interval in self.d_lifecycle_rle]
        return payload


def _descriptor_slots(
    descriptors: np.ndarray,
    pair: tuple[int, int],
    *,
    require_exactly_one: bool,
) -> np.ndarray:
    target = np.asarray(pair, dtype=np.int32)
    matches = np.all(descriptors == target, axis=-1)
    counts = np.sum(matches, axis=1)
    if np.any(counts > 1):
        raise ValueError(f"descriptor {pair!r} appears in multiple slots")
    if require_exactly_one and np.any(counts != 1):
        raise ValueError(f"candidate archive does not contain exactly one {pair!r}")
    return np.where(counts == 1, np.argmax(matches, axis=1), -1).astype(np.int32)


def _canonical_lifecycle_rle(
    deployed_slots: np.ndarray,
    shadow_slots: np.ndarray,
    candidate_slots: np.ndarray,
) -> tuple[CriticalPairLifecycleInterval, ...]:
    if not (
        deployed_slots.shape == shadow_slots.shape == candidate_slots.shape
        and deployed_slots.ndim == 1
        and deployed_slots.size > 0
    ):
        raise ValueError("lifecycle slot arrays must be equal non-empty vectors")
    rows = np.stack((deployed_slots, shadow_slots, candidate_slots), axis=1)
    starts = np.concatenate(
        (
            np.asarray([0], dtype=np.int64),
            np.flatnonzero(np.any(rows[1:] != rows[:-1], axis=1)) + 1,
        )
    )
    ends = np.concatenate((starts[1:], np.asarray([rows.shape[0]], dtype=np.int64)))
    return tuple(
        CriticalPairLifecycleInterval(
            start=int(start),
            end_exclusive=int(end),
            deployed_slot=int(rows[start, 0]),
            shadow_slot=int(rows[start, 1]),
            candidate_slot=int(rows[start, 2]),
        )
        for start, end in zip(starts, ends, strict=True)
    )


def _first_sustained(
    values: np.ndarray,
    start: int,
    end_exclusive: int,
    window: int,
) -> int | None:
    selected = np.asarray(values[start:end_exclusive], dtype=np.int8)
    if selected.size < window:
        return None
    totals = np.convolve(
        selected,
        np.ones(window, dtype=np.int32),
        mode="valid",
    )
    hits = np.flatnonzero(totals == window)
    return None if hits.size == 0 else int(start + hits[0])


def _transition_count(values: np.ndarray, *, rising: bool) -> int:
    previous = np.asarray(values[:-1], dtype=np.bool_)
    current = np.asarray(values[1:], dtype=np.bool_)
    selected = (~previous & current) if rising else (previous & ~current)
    return int(np.sum(selected))


def summarize_critical_lifecycle_v2(
    result: HiddenPartnerRunResult,
) -> CriticalLifecycleV2Summary:
    """Reconstruct continuous lifecycle facts from one primitive decision trace."""
    summary = result.summary
    trace = result.trace
    cycle_steps = summary.cycle_steps
    deployed = np.asarray(trace.active_descriptors, dtype=np.int32)[:cycle_steps]
    shadow = np.asarray(trace.shadow_descriptors_pre, dtype=np.int32)[:cycle_steps]
    candidates = np.asarray(trace.candidate_descriptors, dtype=np.int32)[:cycle_steps]
    candidate_utilities_post = np.asarray(
        trace.candidate_utilities_post,
        dtype=np.float64,
    )[:cycle_steps]
    rewards = np.asarray(trace.reward, dtype=np.float64)[:cycle_steps]
    intended_correct = np.asarray(
        trace.behavior_intended_correct,
        dtype=np.bool_,
    )[:cycle_steps]

    c_deployed_slots = _descriptor_slots(
        deployed,
        _C_PAIR,
        require_exactly_one=False,
    )
    d_deployed_slots = _descriptor_slots(
        deployed,
        _D_PAIR,
        require_exactly_one=False,
    )
    c_shadow_slots = _descriptor_slots(
        shadow,
        _C_PAIR,
        require_exactly_one=False,
    )
    d_shadow_slots = _descriptor_slots(
        shadow,
        _D_PAIR,
        require_exactly_one=False,
    )
    c_candidate_slots = _descriptor_slots(
        candidates,
        _C_PAIR,
        require_exactly_one=True,
    )
    d_candidate_slots = _descriptor_slots(
        candidates,
        _D_PAIR,
        require_exactly_one=True,
    )
    c_present = c_deployed_slots >= 0
    d_present = d_deployed_slots >= 0

    ends = np.cumsum((0, *summary.segment_lengths), dtype=np.int64)
    d_start, d_end = int(ends[3]), int(ends[4])
    first_c_start, first_c_end = int(ends[5]), int(ends[6])
    recurrent_c_start = int(ends[8])
    c_acquisition = _first_sustained(
        c_present,
        first_c_start,
        first_c_end,
        FEATURE_LEARNING_WINDOW,
    )
    c_survival_end = min(
        cycle_steps,
        recurrent_c_start + RECURRENT_ENTRY_WINDOW,
    )
    if c_acquisition is None:
        c_gap_steps = None
        c_first_gap = None
        c_evictions = 0
        c_repromotions = 0
        c_continuous = False
    else:
        c_interval = c_present[c_acquisition:c_survival_end]
        missing = np.flatnonzero(~c_interval)
        c_gap_steps = int(missing.size)
        c_first_gap = None if missing.size == 0 else int(c_acquisition + missing[0])
        c_evictions = _transition_count(c_interval, rising=False)
        c_repromotions = _transition_count(c_interval, rising=True)
        c_continuous = c_gap_steps == 0

    recurrent_window = slice(
        recurrent_c_start,
        min(cycle_steps, recurrent_c_start + RECURRENT_ENTRY_WINDOW),
    )
    c_early_reward = float(np.mean(rewards[recurrent_window]))
    prior_c_late_reward = summary.segments[5].late_reward
    c_retention_ratio = c_early_reward / max(prior_c_late_reward, 1e-7)
    c_early_accuracy = float(np.mean(intended_correct[recurrent_window]))
    c_retained_and_used = (
        c_continuous
        and c_early_reward >= RECURRENT_EARLY_REWARD_THRESHOLD
        and c_retention_ratio >= RETENTION_RATIO_THRESHOLD
    )

    d_acquisition = _first_sustained(
        d_present,
        d_start,
        d_end,
        FEATURE_LEARNING_WINDOW,
    )
    d_through_exit = bool(np.all(d_present[d_end - FEATURE_LEARNING_WINDOW : d_end]))
    d_late_accuracy = float(np.mean(intended_correct[d_end - FEATURE_LEARNING_WINDOW : d_end]))
    d_task_learned = (
        d_acquisition is not None
        and d_through_exit
        and d_late_accuracy >= CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD
    )
    d_retirement = _first_sustained(
        ~d_present,
        d_end,
        cycle_steps,
        RETIREMENT_CONFIRMATION_WINDOW,
    )
    d_latency = None if d_retirement is None else d_retirement - d_end
    d_post_exit = d_present[d_end:]
    d_post_exit_steps = int(np.sum(d_post_exit))
    d_post_exit_promotions = _transition_count(d_post_exit, rising=True)
    if d_retirement is None:
        d_repromotions = 0
    else:
        d_repromotions = _transition_count(
            d_present[d_retirement:],
            rising=True,
        )
    d_final_absent = bool(np.all(~d_present[-FINAL_ABSENCE_WINDOW:]))

    retired_left = np.asarray(trace.interaction_retired_left, dtype=np.int32)[:cycle_steps]
    retired_right = np.asarray(trace.interaction_retired_right, dtype=np.int32)[:cycle_steps]
    reset_counts = np.asarray(
        trace.interaction_matching_candidate_reset_count,
        dtype=np.int64,
    )[:cycle_steps]
    d_retired_events = (retired_left == _D_PAIR[0]) & (retired_right == _D_PAIR[1])
    d_retirement_event_count = int(np.sum(d_retired_events))
    d_candidate_reset_count = int(np.sum(reset_counts[d_retired_events]))
    d_stably_retired = (
        d_task_learned
        and d_retirement is not None
        and d_final_absent
        and d_repromotions == 0
        and d_retirement_event_count >= 1
        and d_candidate_reset_count >= 1
    )

    c_candidate_index = int(c_candidate_slots[-1])
    d_candidate_index = int(d_candidate_slots[-1])
    return CriticalLifecycleV2Summary(
        cycle_steps=cycle_steps,
        c_acquisition_step=c_acquisition,
        c_survival_end_exclusive=c_survival_end,
        c_survival_gap_steps=c_gap_steps,
        c_first_survival_gap_step=c_first_gap,
        c_evictions_after_acquisition=c_evictions,
        c_repromotions_after_acquisition=c_repromotions,
        c_continuously_survived=c_continuous,
        c_recurrent_early_reward=c_early_reward,
        c_recurrent_early_to_prior_late_ratio=c_retention_ratio,
        c_recurrent_early_intended_accuracy=c_early_accuracy,
        c_retained_and_used=c_retained_and_used,
        d_acquisition_step=d_acquisition,
        d_deployed_through_exit=d_through_exit,
        d_late_intended_accuracy=d_late_accuracy,
        d_task_learned=d_task_learned,
        d_retirement_step=d_retirement,
        d_retirement_latency_steps=d_latency,
        d_post_exit_live_slot_steps=d_post_exit_steps,
        d_post_exit_live_fraction=d_post_exit_steps / max(cycle_steps - d_end, 1),
        d_post_exit_promotion_count=d_post_exit_promotions,
        d_repromotions_after_retirement=d_repromotions,
        d_absent_entire_final_window=d_final_absent,
        d_retirement_event_count=d_retirement_event_count,
        d_matching_candidate_reset_count=d_candidate_reset_count,
        d_learned_then_stably_retired=d_stably_retired,
        joint_memory_management_success=(c_retained_and_used and d_stably_retired),
        c_candidate_archive_present_all_steps=bool(np.all(c_candidate_slots >= 0)),
        d_candidate_archive_present_all_steps=bool(np.all(d_candidate_slots >= 0)),
        c_candidate_utility_at_life_end=float(candidate_utilities_post[-1, c_candidate_index]),
        d_candidate_utility_at_life_end=float(candidate_utilities_post[-1, d_candidate_index]),
        c_lifecycle_rle=_canonical_lifecycle_rle(
            c_deployed_slots,
            c_shadow_slots,
            c_candidate_slots,
        ),
        d_lifecycle_rle=_canonical_lifecycle_rle(
            d_deployed_slots,
            d_shadow_slots,
            d_candidate_slots,
        ),
    )


def _cell_digest(cell: EvidenceLeaseTuningCell) -> str:
    serialized = json.dumps(
        cell.to_dict(),
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(serialized).hexdigest()


def run_evidence_lease_tuning_grid(
    *,
    seed_pairs: Sequence[HiddenPartnerSeedPair] | None = None,
    protocol: HiddenPartnerDevelopmentProtocol | None = None,
) -> dict[str, object]:
    """Execute the immutable consumed grid and select only among feasible cells."""
    resolved_seeds = (
        derive_hidden_partner_seed_pairs(
            LEASE_TUNING_NAMESPACE,
            LEASE_TUNING_SEED_COUNT,
        )
        if seed_pairs is None
        else tuple(seed_pairs)
    )
    if len(resolved_seeds) != LEASE_TUNING_SEED_COUNT or any(
        pair.namespace != LEASE_TUNING_NAMESPACE for pair in resolved_seeds
    ):
        raise ValueError("tuning seeds must be the exact eight-pair v2 grid namespace")
    resolved_protocol = HiddenPartnerDevelopmentProtocol() if protocol is None else protocol
    run_records: list[dict[str, object]] = []
    aggregates: list[dict[str, object]] = []
    required_successes = math.ceil(MINIMUM_JOINT_SUCCESS_FRACTION * len(resolved_seeds))
    for cell in LEASE_TUNING_GRID:
        condition = HiddenPartnerCondition(
            name="full",
            config=cell.agent_config(),
            isolated_question=f"evidence-lease tuning cell {cell.index}",
        )
        runner = HiddenPartnerDevelopmentRunner(condition, resolved_protocol)
        cell_records: list[tuple[HiddenPartnerRunResult, CriticalLifecycleV2Summary]] = []
        for seed_pair in resolved_seeds:
            result = runner.run(seed_pair)
            lifecycle = summarize_critical_lifecycle_v2(result)
            cell_records.append((result, lifecycle))
            run_records.append(
                {
                    "cell_index": cell.index,
                    "seed_pair": seed_pair.to_dict(),
                    "run_summary": result.summary.to_dict(),
                    "critical_lifecycle": lifecycle.to_dict(),
                }
            )
        summaries = [item[0].summary for item in cell_records]
        lifecycles = [item[1] for item in cell_records]
        rewards = np.asarray(
            [summary.mean_reward for summary in summaries],
            dtype=np.float64,
        )
        joint_count = sum(lifecycle.joint_memory_management_success for lifecycle in lifecycles)
        c_count = sum(lifecycle.c_retained_and_used for lifecycle in lifecycles)
        d_count = sum(lifecycle.d_learned_then_stably_retired for lifecycle in lifecycles)
        latencies = [
            cast(int, lifecycle.d_retirement_latency_steps)
            for lifecycle in lifecycles
            if lifecycle.d_retirement_latency_steps is not None
        ]
        contracts_valid = all(
            summary.all_finite
            and summary.counter_contract_valid
            and summary.causal_contract_valid
            and summary.resource_shape_matched
            for summary in summaries
        )
        feasible = (
            contracts_valid
            and float(np.mean(rewards)) >= 0.85
            and float(np.min(rewards)) >= 0.80
            and joint_count >= required_successes
            and c_count >= required_successes
            and d_count >= required_successes
        )
        aggregates.append(
            {
                "cell_index": cell.index,
                "cell_digest": _cell_digest(cell),
                "seed_count": len(resolved_seeds),
                "required_success_count": required_successes,
                "finite_contract_valid": contracts_valid,
                "mean_reward": float(np.mean(rewards)),
                "minimum_seed_reward": float(np.min(rewards)),
                "joint_success_count": joint_count,
                "c_retained_and_used_count": c_count,
                "d_learned_then_stably_retired_count": d_count,
                "total_d_repromotions": int(
                    sum(lifecycle.d_repromotions_after_retirement for lifecycle in lifecycles)
                ),
                "median_d_retirement_latency_steps": (
                    None if not latencies else float(np.median(latencies))
                ),
                "feasible": feasible,
            }
        )

    feasible_cells = [record for record in aggregates if record["feasible"]]
    selected: dict[str, object] | None = None
    if feasible_cells:
        selected = max(
            feasible_cells,
            key=lambda record: (
                cast(int, record["joint_success_count"]),
                cast(float, record["minimum_seed_reward"]),
                cast(float, record["mean_reward"]),
                -cast(int, record["total_d_repromotions"]),
                -cast(
                    float,
                    record["median_d_retirement_latency_steps"],
                ),
                -cast(int, record["cell_index"]),
            ),
        )
    return {
        "schema_version": HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA,
        "development_only": True,
        "scientific_promotion_allowed": False,
        "seed_namespace": LEASE_TUNING_NAMESPACE,
        "seed_pairs": [pair.to_dict() for pair in resolved_seeds],
        "grid": [cell.to_dict() for cell in LEASE_TUNING_GRID],
        "selection_rule": TUNING_SELECTION_RULE,
        "aggregates": aggregates,
        "selected_cell": selected,
        "runs": run_records,
        "scope_limits": [
            "scripted nonlearning partner",
            "hard-coded C and D identities",
            "fixed schedule with unequal recurrence gaps",
            "exhaustive enumerated pair archive",
            "interaction-task utility only",
            "development tuning seeds cannot promote evidence",
        ],
    }


__all__ = [
    "CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD",
    "CriticalLifecycleV2Summary",
    "CriticalPairLifecycleInterval",
    "EvidenceLeaseTuningCell",
    "FEATURE_LEARNING_WINDOW",
    "FINAL_ABSENCE_WINDOW",
    "HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA",
    "LEASE_TUNING_GRID",
    "LEASE_TUNING_NAMESPACE",
    "LEASE_TUNING_SEED_COUNT",
    "MINIMUM_JOINT_SUCCESS_FRACTION",
    "RECURRENT_EARLY_REWARD_THRESHOLD",
    "RECURRENT_ENTRY_WINDOW",
    "RETENTION_RATIO_THRESHOLD",
    "RETIREMENT_CONFIRMATION_WINDOW",
    "TUNING_SELECTION_RULE",
    "run_evidence_lease_tuning_grid",
    "summarize_critical_lifecycle_v2",
]
