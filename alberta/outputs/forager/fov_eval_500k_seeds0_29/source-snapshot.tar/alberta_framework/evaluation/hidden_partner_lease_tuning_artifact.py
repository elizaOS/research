"""Fail-closed artifact for the consumed hidden-partner lease tuning grid."""

from __future__ import annotations

import dataclasses
import hashlib
import json
import math
from collections.abc import Mapping
from dataclasses import dataclass
from numbers import Real
from pathlib import Path
from typing import cast

import numpy as np

from alberta_framework.evaluation.hidden_partner_development import (
    derive_hidden_partner_seed_pairs,
    hidden_partner_run_summary_from_dict,
)
from alberta_framework.evaluation.hidden_partner_lifecycle_v2 import (
    HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA,
    LEASE_TUNING_GRID,
    LEASE_TUNING_NAMESPACE,
    LEASE_TUNING_SEED_COUNT,
    MINIMUM_JOINT_SUCCESS_FRACTION,
    TUNING_SELECTION_RULE,
    CriticalLifecycleV2Summary,
)

LEASE_TUNING_ARTIFACT_SCHEMA = (
    "alberta.hidden-partner-lease-tuning-artifact.v1"
)
REPO_ROOT = Path(__file__).resolve().parents[2]
SOURCE_PATHS = (
    Path("alberta_framework/core/average_reward.py"),
    Path("alberta_framework/core/behavior_model.py"),
    Path("alberta_framework/core/feature_bank_router.py"),
    Path("alberta_framework/core/integrated_hidden_partner.py"),
    Path("alberta_framework/core/interaction_features.py"),
    Path("alberta_framework/core/joint_partner_world.py"),
    Path("alberta_framework/core/state_builder.py"),
    Path("alberta_framework/evaluation/hidden_partner_development.py"),
    Path("alberta_framework/evaluation/hidden_partner_lifecycle_v2.py"),
    Path(
        "alberta_framework/evaluation/"
        "hidden_partner_lease_tuning_artifact.py"
    ),
    Path("alberta_framework/evaluation/hidden_partner_lease_tuning_cli.py"),
    Path("alberta_framework/streams/hidden_partner_mapping.py"),
)


@dataclass(frozen=True)
class LeaseTuningArtifactValidation:
    """Structural validity and separately reported grid feasibility."""

    valid: bool
    feasible_cell_selected: bool
    errors: tuple[str, ...]


def _canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()


def _canonical_sha256(value: object) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest()


def source_snapshot(root: Path = REPO_ROOT) -> dict[str, str]:
    """Hash every source capable of changing the stored tuning record."""
    return {
        relative.as_posix(): hashlib.sha256(
            (root / relative).read_bytes()
        ).hexdigest()
        for relative in SOURCE_PATHS
    }


def build_lease_tuning_artifact(
    record: Mapping[str, object],
    *,
    operational_metadata: Mapping[str, object],
    root: Path = REPO_ROOT,
) -> dict[str, object]:
    """Wrap one exact tuning record in source hashes and a scientific digest."""
    payload = {**dict(record), "source_sha256": source_snapshot(root)}
    return {
        "schema_version": LEASE_TUNING_ARTIFACT_SCHEMA,
        "development_only": True,
        "scientific_promotion_allowed": False,
        "scientific_payload": payload,
        "scientific_digest": {
            "algorithm": "sha256",
            "scope": "$.scientific_payload",
            "sha256": _canonical_sha256(payload),
        },
        "operational_metadata": dict(operational_metadata),
    }


def lease_tuning_artifact_json(artifact: Mapping[str, object]) -> str:
    """Serialize strict pretty JSON."""
    return (
        json.dumps(
            artifact,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )


def load_lease_tuning_artifact(path: Path) -> dict[str, object]:
    """Load strict JSON while rejecting duplicate fields and constants."""

    def pairs_hook(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key!r}")
            result[key] = value
        return result

    def reject_constant(value: str) -> object:
        raise ValueError(f"non-finite JSON constant is forbidden: {value}")

    parsed = json.loads(
        path.read_text(encoding="utf-8"),
        object_pairs_hook=pairs_hook,
        parse_constant=reject_constant,
    )
    if not isinstance(parsed, dict):
        raise ValueError("lease tuning artifact must be one JSON object")
    return parsed


def _validate_operational_metadata(
    operational: object,
    errors: list[str],
) -> None:
    expected = {
        "argv",
        "generated_at_utc",
        "jax_backend",
        "jax_device_count",
        "jax_version",
        "platform",
        "python_version",
        "wall_seconds",
    }
    if not isinstance(operational, Mapping) or set(operational) != expected:
        errors.append("operational_metadata fields do not match the schema")
        return
    if not isinstance(operational.get("argv"), list) or any(
        not isinstance(item, str) for item in cast(list[object], operational["argv"])
    ):
        errors.append("operational argv must be an array of strings")
    for field in ("generated_at_utc", "jax_backend", "jax_version", "platform", "python_version"):
        value = operational.get(field)
        if not isinstance(value, str) or not value:
            errors.append(f"operational {field} must be a non-empty string")
    count = operational.get("jax_device_count")
    if type(count) is not int or count <= 0:
        errors.append("operational jax_device_count must be positive")
    wall = operational.get("wall_seconds")
    if (
        isinstance(wall, bool)
        or not isinstance(wall, Real)
        or not math.isfinite(float(wall))
        or float(wall) < 0.0
    ):
        errors.append("operational wall_seconds must be finite and non-negative")


def _validate_rle(
    raw: object,
    cycle_steps: int,
    field: str,
    errors: list[str],
) -> None:
    if not isinstance(raw, list) or not raw:
        errors.append(f"{field} must be a non-empty RLE array")
        return
    expected_fields = {
        "start",
        "end_exclusive",
        "deployed_slot",
        "shadow_slot",
        "candidate_slot",
    }
    previous_end = 0
    previous_state: tuple[int, int, int] | None = None
    for index, interval in enumerate(raw):
        if not isinstance(interval, Mapping) or set(interval) != expected_fields:
            errors.append(f"{field}[{index}] fields are invalid")
            continue
        values = [interval.get(name) for name in expected_fields]
        if any(type(value) is not int for value in values):
            errors.append(f"{field}[{index}] values must be integers")
            continue
        start = cast(int, interval["start"])
        end = cast(int, interval["end_exclusive"])
        deployed = cast(int, interval["deployed_slot"])
        shadow = cast(int, interval["shadow_slot"])
        candidate = cast(int, interval["candidate_slot"])
        if start != previous_end or not start < end <= cycle_steps:
            errors.append(f"{field}[{index}] is noncontiguous or empty")
        if not -1 <= deployed < 12 or not -1 <= shadow < 12:
            errors.append(f"{field}[{index}] active slot is out of bounds")
        if not 0 <= candidate < 66:
            errors.append(f"{field}[{index}] candidate slot is out of bounds")
        state = (deployed, shadow, candidate)
        if previous_state == state:
            errors.append(f"{field}[{index}] is a noncanonical split")
        previous_state = state
        previous_end = end
    if previous_end != cycle_steps:
        errors.append(f"{field} does not cover the complete life")


def _reconstruct_aggregates(
    runs: list[Mapping[str, object]],
) -> list[dict[str, object]]:
    required = math.ceil(
        MINIMUM_JOINT_SUCCESS_FRACTION * LEASE_TUNING_SEED_COUNT
    )
    aggregates: list[dict[str, object]] = []
    for cell in LEASE_TUNING_GRID:
        cell_runs = [
            run for run in runs if run.get("cell_index") == cell.index
        ]
        rewards = np.asarray(
            [
                cast(Mapping[str, object], run["run_summary"])["mean_reward"]
                for run in cell_runs
            ],
            dtype=np.float64,
        )
        lifecycles = [
            cast(Mapping[str, object], run["critical_lifecycle"])
            for run in cell_runs
        ]
        summaries = [
            cast(Mapping[str, object], run["run_summary"])
            for run in cell_runs
        ]
        valid = all(
            summary.get("all_finite") is True
            and summary.get("counter_contract_valid") is True
            and summary.get("causal_contract_valid") is True
            and summary.get("resource_shape_matched") is True
            for summary in summaries
        )
        joint_count = sum(
            lifecycle.get("joint_memory_management_success") is True
            for lifecycle in lifecycles
        )
        c_count = sum(
            lifecycle.get("c_retained_and_used") is True
            for lifecycle in lifecycles
        )
        d_count = sum(
            lifecycle.get("d_learned_then_stably_retired") is True
            for lifecycle in lifecycles
        )
        latencies = [
            cast(int, lifecycle["d_retirement_latency_steps"])
            for lifecycle in lifecycles
            if lifecycle.get("d_retirement_latency_steps") is not None
        ]
        feasible = (
            valid
            and float(np.mean(rewards)) >= 0.85
            and float(np.min(rewards)) >= 0.80
            and joint_count >= required
            and c_count >= required
            and d_count >= required
        )
        aggregates.append(
            {
                "cell_index": cell.index,
                "cell_digest": _canonical_sha256(cell.to_dict()),
                "seed_count": LEASE_TUNING_SEED_COUNT,
                "required_success_count": required,
                "finite_contract_valid": valid,
                "mean_reward": float(np.mean(rewards)),
                "minimum_seed_reward": float(np.min(rewards)),
                "joint_success_count": joint_count,
                "c_retained_and_used_count": c_count,
                "d_learned_then_stably_retired_count": d_count,
                "total_d_repromotions": int(
                    sum(
                        cast(
                            int,
                            lifecycle["d_repromotions_after_retirement"],
                        )
                        for lifecycle in lifecycles
                    )
                ),
                "median_d_retirement_latency_steps": (
                    None if not latencies else float(np.median(latencies))
                ),
                "feasible": feasible,
            }
        )
    return aggregates


def _select_cell(
    aggregates: list[dict[str, object]],
) -> dict[str, object] | None:
    feasible = [record for record in aggregates if record["feasible"]]
    if not feasible:
        return None
    return max(
        feasible,
        key=lambda record: (
            cast(int, record["joint_success_count"]),
            cast(float, record["minimum_seed_reward"]),
            cast(float, record["mean_reward"]),
            -cast(int, record["total_d_repromotions"]),
            -cast(float, record["median_d_retirement_latency_steps"]),
            -cast(int, record["cell_index"]),
        ),
    )


def validate_lease_tuning_artifact(
    artifact: Mapping[str, object],
    *,
    root: Path = REPO_ROOT,
) -> LeaseTuningArtifactValidation:
    """Fail closed on source, digest, seed, grid, run, RLE, or aggregate drift."""
    errors: list[str] = []
    expected_top = {
        "schema_version",
        "development_only",
        "scientific_promotion_allowed",
        "scientific_payload",
        "scientific_digest",
        "operational_metadata",
    }
    if set(artifact) != expected_top:
        errors.append("top-level artifact fields do not match the schema")
    if artifact.get("schema_version") != LEASE_TUNING_ARTIFACT_SCHEMA:
        errors.append("artifact schema version is unsupported")
    if artifact.get("development_only") is not True:
        errors.append("artifact must remain development-only")
    if artifact.get("scientific_promotion_allowed") is not False:
        errors.append("artifact must forbid promotion")
    _validate_operational_metadata(
        artifact.get("operational_metadata"),
        errors,
    )

    payload = artifact.get("scientific_payload")
    if not isinstance(payload, Mapping):
        errors.append("scientific_payload must be an object")
        payload = {}
    expected_payload = {
        "schema_version",
        "development_only",
        "scientific_promotion_allowed",
        "seed_namespace",
        "seed_pairs",
        "grid",
        "selection_rule",
        "aggregates",
        "selected_cell",
        "runs",
        "scope_limits",
        "source_sha256",
    }
    if set(payload) != expected_payload:
        errors.append("scientific_payload fields do not match the schema")
    if payload.get("schema_version") != HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA:
        errors.append("lifecycle record schema is unsupported")
    if payload.get("development_only") is not True:
        errors.append("scientific payload must remain development-only")
    if payload.get("scientific_promotion_allowed") is not False:
        errors.append("scientific payload must forbid promotion")
    if payload.get("seed_namespace") != LEASE_TUNING_NAMESPACE:
        errors.append("tuning seed namespace is invalid")
    if payload.get("selection_rule") != TUNING_SELECTION_RULE:
        errors.append("tuning selection rule changed")
    if payload.get("grid") != [cell.to_dict() for cell in LEASE_TUNING_GRID]:
        errors.append("tuning grid changed")
    expected_seeds = [
        pair.to_dict()
        for pair in derive_hidden_partner_seed_pairs(
            LEASE_TUNING_NAMESPACE,
            LEASE_TUNING_SEED_COUNT,
        )
    ]
    if payload.get("seed_pairs") != expected_seeds:
        errors.append("tuning seed pairs changed")

    digest = artifact.get("scientific_digest")
    if not isinstance(digest, Mapping) or set(digest) != {
        "algorithm",
        "scope",
        "sha256",
    }:
        errors.append("scientific_digest fields are invalid")
    else:
        try:
            expected_digest = _canonical_sha256(payload)
        except (TypeError, ValueError) as error:
            errors.append(f"scientific payload is not strict JSON: {error}")
        else:
            if digest.get("algorithm") != "sha256":
                errors.append("scientific digest algorithm must be sha256")
            if digest.get("scope") != "$.scientific_payload":
                errors.append("scientific digest scope is invalid")
            if digest.get("sha256") != expected_digest:
                errors.append("scientific payload digest mismatch")

    try:
        expected_sources = source_snapshot(root)
    except OSError as error:
        errors.append(f"cannot hash current tuning sources: {error}")
    else:
        if payload.get("source_sha256") != expected_sources:
            errors.append("source hashes do not match pinned tuning sources")

    runs_payload = payload.get("runs")
    reconstructed_runs: list[Mapping[str, object]] = []
    expected_run_count = len(LEASE_TUNING_GRID) * LEASE_TUNING_SEED_COUNT
    if not isinstance(runs_payload, list) or len(runs_payload) != expected_run_count:
        errors.append(f"runs must contain exactly {expected_run_count} records")
    else:
        lifecycle_fields = {
            field.name for field in dataclasses.fields(CriticalLifecycleV2Summary)
        }
        for index, run in enumerate(runs_payload):
            if not isinstance(run, Mapping) or set(run) != {
                "cell_index",
                "seed_pair",
                "run_summary",
                "critical_lifecycle",
            }:
                errors.append(f"runs[{index}] fields are invalid")
                continue
            expected_cell = index // LEASE_TUNING_SEED_COUNT
            expected_seed = index % LEASE_TUNING_SEED_COUNT
            if run.get("cell_index") != expected_cell:
                errors.append(f"runs[{index}] cell ordering is invalid")
            if run.get("seed_pair") != expected_seeds[expected_seed]:
                errors.append(f"runs[{index}] seed pairing is invalid")
            summary_payload = run.get("run_summary")
            if not isinstance(summary_payload, Mapping):
                errors.append(f"runs[{index}].run_summary must be an object")
                continue
            try:
                summary = hidden_partner_run_summary_from_dict(summary_payload)
            except (TypeError, ValueError) as error:
                errors.append(f"runs[{index}].run_summary is invalid: {error}")
                continue
            if summary.seed_pair.to_dict() != expected_seeds[expected_seed]:
                errors.append(f"runs[{index}] summary seed pairing is invalid")
            lifecycle = run.get("critical_lifecycle")
            if not isinstance(lifecycle, Mapping) or set(lifecycle) != lifecycle_fields:
                errors.append(f"runs[{index}].critical_lifecycle fields are invalid")
                continue
            if lifecycle.get("cycle_steps") != summary.cycle_steps:
                errors.append(f"runs[{index}] lifecycle length is inconsistent")
            for field in (
                "c_continuously_survived",
                "c_retained_and_used",
                "d_task_learned",
                "d_absent_entire_final_window",
                "d_learned_then_stably_retired",
                "joint_memory_management_success",
                "c_candidate_archive_present_all_steps",
                "d_candidate_archive_present_all_steps",
            ):
                if type(lifecycle.get(field)) is not bool:
                    errors.append(f"runs[{index}] lifecycle {field} must be boolean")
            if lifecycle.get("joint_memory_management_success") != (
                lifecycle.get("c_retained_and_used") is True
                and lifecycle.get("d_learned_then_stably_retired") is True
            ):
                errors.append(f"runs[{index}] joint lifecycle flag is inconsistent")
            _validate_rle(
                lifecycle.get("c_lifecycle_rle"),
                summary.cycle_steps,
                f"runs[{index}].c_lifecycle_rle",
                errors,
            )
            _validate_rle(
                lifecycle.get("d_lifecycle_rle"),
                summary.cycle_steps,
                f"runs[{index}].d_lifecycle_rle",
                errors,
            )
            reconstructed_runs.append(run)

    if len(reconstructed_runs) == expected_run_count:
        expected_aggregates = _reconstruct_aggregates(reconstructed_runs)
        if payload.get("aggregates") != expected_aggregates:
            errors.append("aggregates do not reconstruct exactly from runs")
        if payload.get("selected_cell") != _select_cell(expected_aggregates):
            errors.append("selected cell does not follow the frozen rule")

    selected = payload.get("selected_cell")
    return LeaseTuningArtifactValidation(
        valid=not errors,
        feasible_cell_selected=isinstance(selected, Mapping),
        errors=tuple(errors),
    )


__all__ = [
    "LEASE_TUNING_ARTIFACT_SCHEMA",
    "LeaseTuningArtifactValidation",
    "REPO_ROOT",
    "SOURCE_PATHS",
    "build_lease_tuning_artifact",
    "lease_tuning_artifact_json",
    "load_lease_tuning_artifact",
    "source_snapshot",
    "validate_lease_tuning_artifact",
]
