"""Strict, resumable Alberta-only Forager variant-matrix execution.

The matrix runner is deliberately narrower than :mod:`alberta_framework.forager_cli`.
It accepts only Alberta configurations, records a normalized scientific
configuration before doing any benchmark work, and writes immutable,
self-hashing batch artifacts.  A later invocation resumes only when every
existing byte belongs to the same configuration and execution environment.

Input manifest schema (``schema_version == "2.0"``)::

    {
      "schema_version": "2.0",
      "preset": "field_of_view",
      "stage": "tuning",
      "steps": 10000,
      "seeds": [1000000, 1000001],
      "jax_chunk_size": 1000,
      "seed_batch_size": 2,
      "mode": "strict",
      "selection_rule": {
        "metric": "fov_last_10pct_ema_auc",
        "direction": "maximize",
        "statistic": "conservative_ci_endpoint",
        "confidence": 0.95,
        "bootstrap_resamples": 10000,
        "bootstrap_seed": 0,
        "tie_break": "variant_id_ascending"
      },
      "variants": {
        "default": {
          "kind": "alberta_horde_ac",
          "selection_group": "policy",
          "config": {}
        },
        "small": {
          "kind": "alberta_horde_ac",
          "selection_group": "policy",
          "config": {
            "actor_hidden_sizes": [32, 32],
            "features": {"reward_trace_decays": [0.9, 0.99]}
          }
        }
      }
    }

``tuning_seeds`` and ``evaluation_seeds`` may additionally be declared to
attest the two disjoint sets.  An evaluation can cryptographically link a
completed tuning report with ``tuning_selection``; see
:class:`ForagerTuningSelection`.

Schema 1.0 is intentionally rejected because it did not declare algorithm
kinds, selection groups, or a deterministic winner rule.  Every execution
stores a canonical USTAR source snapshot and inventory.  The current
``source_execution_mode`` runs the live tree while repeatedly proving it still
matches that immutable snapshot; an extracted-snapshot launcher can use the
same execution identity without weakening the artifact contract.
"""

from __future__ import annotations

import argparse
import contextlib
import dataclasses
import fcntl
import hashlib
import importlib.metadata
import io
import json
import logging
import math
import os
import platform
import re
import stat
import subprocess
import sys
import tarfile
import time
import types
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import Any, Literal, cast, get_args, get_origin, get_type_hints

import jax

from alberta_framework.benchmarks.causal_map_forager import (
    CAUSAL_MAP_VARIANT_KIND,
    CausalMapForagerConfig,
    run_causal_map_forager_seeds,
)
from alberta_framework.benchmarks.forager import (
    AlbertaForagerConfig,
    ForagerBatchMode,
    ForagerBenchmarkConfig,
    ForagerFeatureConfig,
    ForagerPreset,
    ForagerRunResult,
    foragax_install_tree_sha256,
    forager_metric_contract,
    paper_protocol,
    run_alberta_forager_seeds,
    summarize_forager_runs,
)

FORAGER_MATRIX_SCHEMA_VERSION = "2.0"
FORAGER_MATRIX_EXECUTION_MANIFEST = "alberta_forager_matrix_execution_manifest"
FORAGER_MATRIX_BATCH_ARTIFACT = "alberta_forager_matrix_batch"
FORAGER_MATRIX_REPORT = "alberta_forager_matrix_report"

EXECUTION_MANIFEST_FILENAME = "matrix-manifest.json"
FINAL_REPORT_FILENAME = "report.json"
LOCK_FILENAME = ".forager-matrix.lock"
SOURCE_SNAPSHOT_FILENAME = "source-snapshot.tar"
SOURCE_INVENTORY_MEMBER = "SOURCE_INVENTORY.json"
SOURCE_TREE_HASH_SCHEME = "canonical-source-inventory-v1"
SOURCE_ARCHIVE_FORMAT = "ustar-v1"
SOURCE_EXECUTION_MODE = "live_tree_verified_against_immutable_snapshot"

LOGGER = logging.getLogger("alberta.forager_matrix")
REPO_ROOT = Path(__file__).resolve().parents[2]

_VARIANT_ID = re.compile(r"[a-z0-9](?:[a-z0-9_-]{0,62}[a-z0-9])?")
_SHA256 = re.compile(r"[0-9a-f]{64}")
_MAX_JAX_SEED = 2**31 - 1
_RUN_FIELDS = frozenset(item.name for item in dataclasses.fields(ForagerRunResult))
_FORAGER_METRICS = frozenset(
    {
        "mean_reward",
        "final_window_mean_reward",
        "final_ewm_reward",
        "mean_ewm_reward",
        "fov_last_10pct_ema_auc",
    }
)

ForagerVariantKind = Literal["alberta_horde_ac", "alberta_causal_map"]
ForagerVariantConfig = AlbertaForagerConfig | CausalMapForagerConfig
SelectionDirection = Literal["maximize", "minimize"]
SelectionStatistic = Literal["mean", "conservative_ci_endpoint"]


class ForagerMatrixError(RuntimeError):
    """Base class for matrix execution failures."""


class ForagerMatrixManifestError(ValueError):
    """The strict input manifest is malformed or internally inconsistent."""


class ForagerMatrixStateError(ForagerMatrixError):
    """Existing output cannot be authenticated as resumable matrix state."""


class ForagerMatrixLockedError(ForagerMatrixError):
    """Another process currently owns the output-directory lock."""


@dataclass(frozen=True)
class ForagerTuningRule:
    """Deterministic within-group tuning selection contract."""

    metric: str
    direction: SelectionDirection
    statistic: SelectionStatistic
    confidence: float
    bootstrap_resamples: int
    bootstrap_seed: int
    tie_break: Literal["variant_id_ascending"] = "variant_id_ascending"

    def to_dict(self) -> dict[str, Any]:
        """Return the canonical JSON representation."""
        return {
            "metric": self.metric,
            "direction": self.direction,
            "statistic": self.statistic,
            "confidence": self.confidence,
            "bootstrap_resamples": self.bootstrap_resamples,
            "bootstrap_seed": self.bootstrap_seed,
            "tie_break": self.tie_break,
        }


@dataclass(frozen=True)
class ForagerMatrixVariant:
    """One exact algorithm/configuration in a named selection group."""

    kind: ForagerVariantKind
    selection_group: str
    config: ForagerVariantConfig

    def to_dict(self) -> dict[str, Any]:
        """Return the normalized full variant descriptor."""
        return {
            "kind": self.kind,
            "selection_group": self.selection_group,
            "config": self.config.to_dict(),
        }

    @property
    def config_sha256(self) -> str:
        """Hash the normalized algorithm configuration only."""
        return _json_sha256(self.config.to_dict())

    @property
    def descriptor_sha256(self) -> str:
        """Hash kind, selection group, and normalized configuration."""
        return _json_sha256(self.to_dict())


@dataclass(frozen=True)
class ForagerTuningSelection:
    """Cryptographic link from evaluation variants to a completed tuning report.

    ``report_path`` is a safe POSIX-relative path resolved beneath the input
    manifest's directory. ``file_sha256`` hashes the exact canonical report
    file, including its trailing newline. ``selected_variants`` maps each
    evaluation variant ID to the selected variant ID in that tuning report.
    """

    report_path: str
    file_sha256: str
    selected_variants: Mapping[str, str]

    def to_dict(self) -> dict[str, Any]:
        """Return the canonical JSON representation."""
        return {
            "report_path": self.report_path,
            "file_sha256": self.file_sha256,
            "selected_variants": dict(sorted(self.selected_variants.items())),
        }


@dataclass(frozen=True)
class ForagerMatrixManifest:
    """Validated, normalized Alberta Forager matrix configuration."""

    schema_version: str
    preset: ForagerPreset
    stage: Literal["tuning", "evaluation"]
    steps: int
    seeds: tuple[int, ...]
    jax_chunk_size: int
    seed_batch_size: int
    mode: ForagerBatchMode
    selection_rule: ForagerTuningRule
    variants: Mapping[str, ForagerMatrixVariant]
    tuning_seeds: tuple[int, ...] | None = None
    evaluation_seeds: tuple[int, ...] | None = None
    tuning_selection: ForagerTuningSelection | None = None
    source_path: Path | None = field(default=None, compare=False, repr=False)

    def to_dict(self) -> dict[str, Any]:
        """Return the normalized scientific configuration.

        Partial and complete input variants normalize to the same fully
        resolved configuration and therefore receive the same configuration
        hash.
        """
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "preset": self.preset,
            "stage": self.stage,
            "steps": self.steps,
            "seeds": list(self.seeds),
            "jax_chunk_size": self.jax_chunk_size,
            "seed_batch_size": self.seed_batch_size,
            "mode": self.mode,
            "selection_rule": self.selection_rule.to_dict(),
            "variants": {
                variant_id: variant.to_dict()
                for variant_id, variant in sorted(self.variants.items())
            },
        }
        if self.tuning_seeds is not None:
            payload["tuning_seeds"] = list(self.tuning_seeds)
        if self.evaluation_seeds is not None:
            payload["evaluation_seeds"] = list(self.evaluation_seeds)
        if self.tuning_selection is not None:
            payload["tuning_selection"] = self.tuning_selection.to_dict()
        return payload

    @property
    def config_sha256(self) -> str:
        """Hash the canonical normalized scientific configuration."""
        return _json_sha256(self.to_dict())


@dataclass(frozen=True)
class _BatchPlan:
    variant_id: str
    batch_index: int
    seeds: tuple[int, ...]

    @property
    def relative_path(self) -> str:
        return f"batches/{self.variant_id}/batch-{self.batch_index:05d}.json"

    def to_dict(self) -> dict[str, Any]:
        return {
            "variant_id": self.variant_id,
            "batch_index": self.batch_index,
            "seeds": list(self.seeds),
            "path": self.relative_path,
        }


@dataclass(frozen=True)
class _SourceSnapshot:
    archive_bytes: bytes = field(repr=False)
    archive_sha256: str
    tree_sha256: str
    inventory_sha256: str
    inventory: Mapping[str, Any]

    def metadata(self) -> dict[str, Any]:
        return {
            "path": SOURCE_SNAPSHOT_FILENAME,
            "archive_format": SOURCE_ARCHIVE_FORMAT,
            "archive_sha256": self.archive_sha256,
            "tree_sha256": self.tree_sha256,
            "inventory_sha256": self.inventory_sha256,
            "inventory": dict(self.inventory),
            "source_execution_mode": SOURCE_EXECUTION_MODE,
        }


def _reject_duplicate_object_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ForagerMatrixManifestError(f"duplicate JSON object key {key!r}")
        result[key] = value
    return result


def _reject_nonfinite_json(token: str) -> Any:
    raise ForagerMatrixManifestError(f"non-finite JSON number {token!r} is not allowed")


def _decode_strict_json(data: str, *, description: str) -> Any:
    try:
        return json.loads(
            data,
            object_pairs_hook=_reject_duplicate_object_keys,
            parse_constant=_reject_nonfinite_json,
        )
    except ForagerMatrixManifestError:
        raise
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise ForagerMatrixManifestError(f"{description} is not valid strict JSON: {exc}") from exc


def _require_object(value: Any, path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ForagerMatrixManifestError(f"{path} must be a JSON object")
    if any(not isinstance(key, str) for key in value):
        raise ForagerMatrixManifestError(f"{path} object keys must be strings")
    return cast(Mapping[str, Any], value)


def _require_exact_keys(
    value: Mapping[str, Any],
    *,
    path: str,
    required: set[str],
    optional: set[str] | None = None,
) -> None:
    allowed = required | (optional or set())
    unknown = sorted(value.keys() - allowed)
    missing = sorted(required - value.keys())
    if unknown:
        raise ForagerMatrixManifestError(f"{path} contains unknown keys: {', '.join(unknown)}")
    if missing:
        raise ForagerMatrixManifestError(f"{path} is missing required keys: {', '.join(missing)}")


def _require_string(value: Any, path: str) -> str:
    if not isinstance(value, str):
        raise ForagerMatrixManifestError(f"{path} must be a string")
    return value


def _require_positive_int(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ForagerMatrixManifestError(f"{path} must be an integer")
    if value < 1:
        raise ForagerMatrixManifestError(f"{path} must be positive")
    return value


def _require_nonnegative_int(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ForagerMatrixManifestError(f"{path} must be an integer")
    if value < 0:
        raise ForagerMatrixManifestError(f"{path} must be non-negative")
    return value


def _require_seed_list(value: Any, path: str) -> tuple[int, ...]:
    if not isinstance(value, list):
        raise ForagerMatrixManifestError(f"{path} must be a JSON array")
    if not value:
        raise ForagerMatrixManifestError(f"{path} must not be empty")
    result: list[int] = []
    for index, seed in enumerate(value):
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ForagerMatrixManifestError(f"{path}[{index}] must be an integer")
        if not 0 <= seed <= _MAX_JAX_SEED:
            raise ForagerMatrixManifestError(f"{path}[{index}] must lie in [0, {_MAX_JAX_SEED}]")
        result.append(seed)
    if len(set(result)) != len(result):
        raise ForagerMatrixManifestError(f"{path} contains duplicate seed IDs")
    return tuple(result)


def _validate_variant_id(value: str, path: str) -> str:
    if _VARIANT_ID.fullmatch(value) is None:
        raise ForagerMatrixManifestError(
            f"{path} must be a lowercase path-safe slug of 1 to 64 "
            "letters, digits, underscores, or hyphens"
        )
    return value


def _coerce_typed_value(value: Any, annotation: Any, path: str) -> Any:
    origin = get_origin(annotation)
    arguments = get_args(annotation)

    if origin in (types.UnionType, getattr(sys.modules.get("typing"), "Union", object)):
        non_none = tuple(item for item in arguments if item is not type(None))
        if len(non_none) != len(arguments) and value is None:
            return None
        if len(non_none) == 1:
            return _coerce_typed_value(value, non_none[0], path)

    if origin is tuple:
        if not isinstance(value, list):
            raise ForagerMatrixManifestError(f"{path} must be a JSON array")
        element_type = arguments[0] if arguments else Any
        return tuple(
            _coerce_typed_value(item, element_type, f"{path}[{index}]")
            for index, item in enumerate(value)
        )

    if annotation is bool:
        if type(value) is not bool:
            raise ForagerMatrixManifestError(f"{path} must be a boolean")
        return value
    if annotation is int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ForagerMatrixManifestError(f"{path} must be an integer")
        return value
    if annotation is float:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ForagerMatrixManifestError(f"{path} must be a number")
        converted = float(value)
        if not math.isfinite(converted):
            raise ForagerMatrixManifestError(f"{path} must be finite")
        return converted
    if annotation is str:
        return _require_string(value, path)
    if annotation is Any:
        return value

    raise ForagerMatrixManifestError(f"{path} has an unsupported configuration type")


def _parse_dataclass_overrides[T](
    cls: type[T],
    value: Any,
    *,
    path: str,
) -> T:
    payload = _require_object(value, path)
    class_fields = {item.name: item for item in dataclasses.fields(cast(Any, cls))}
    unknown = sorted(payload.keys() - class_fields.keys())
    if unknown:
        raise ForagerMatrixManifestError(f"{path} contains unknown keys: {', '.join(unknown)}")
    annotations = get_type_hints(cls)
    arguments: dict[str, Any] = {}
    for name, item in payload.items():
        item_path = f"{path}.{name}"
        if name == "features" and cls is AlbertaForagerConfig:
            arguments[name] = _parse_dataclass_overrides(
                ForagerFeatureConfig,
                item,
                path=item_path,
            )
        else:
            arguments[name] = _coerce_typed_value(item, annotations[name], item_path)
    try:
        return cls(**arguments)
    except (TypeError, ValueError) as exc:
        raise ForagerMatrixManifestError(f"{path} is invalid: {exc}") from exc


def _safe_relative_path(value: Any, path: str) -> str:
    text = _require_string(value, path)
    if not text or "\\" in text or "\x00" in text:
        raise ForagerMatrixManifestError(f"{path} must be a safe non-empty POSIX path")
    candidate = PurePosixPath(text)
    if candidate.is_absolute() or any(part in ("", ".", "..") for part in candidate.parts):
        raise ForagerMatrixManifestError(f"{path} must be relative and may not contain '.' or '..'")
    component = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")
    if any(component.fullmatch(part) is None for part in candidate.parts):
        raise ForagerMatrixManifestError(f"{path} contains an unsafe path component")
    return candidate.as_posix()


def _parse_tuning_rule(value: Any) -> ForagerTuningRule:
    payload = _require_object(value, "manifest.selection_rule")
    _require_exact_keys(
        payload,
        path="manifest.selection_rule",
        required={
            "metric",
            "direction",
            "statistic",
            "confidence",
            "bootstrap_resamples",
            "bootstrap_seed",
            "tie_break",
        },
    )
    metric = _require_string(payload["metric"], "manifest.selection_rule.metric")
    if metric not in _FORAGER_METRICS:
        raise ForagerMatrixManifestError(
            "manifest.selection_rule.metric must be a supported Forager metric"
        )
    direction_value = _require_string(
        payload["direction"],
        "manifest.selection_rule.direction",
    )
    if direction_value not in ("maximize", "minimize"):
        raise ForagerMatrixManifestError(
            "manifest.selection_rule.direction must be 'maximize' or 'minimize'"
        )
    statistic_value = _require_string(
        payload["statistic"],
        "manifest.selection_rule.statistic",
    )
    if statistic_value not in ("mean", "conservative_ci_endpoint"):
        raise ForagerMatrixManifestError(
            "manifest.selection_rule.statistic must be 'mean' or 'conservative_ci_endpoint'"
        )
    confidence_value = payload["confidence"]
    if (
        isinstance(confidence_value, bool)
        or not isinstance(confidence_value, (int, float))
        or not math.isfinite(float(confidence_value))
        or not 0.0 < float(confidence_value) < 1.0
    ):
        raise ForagerMatrixManifestError(
            "manifest.selection_rule.confidence must be finite and lie in (0, 1)"
        )
    bootstrap_resamples = _require_positive_int(
        payload["bootstrap_resamples"],
        "manifest.selection_rule.bootstrap_resamples",
    )
    bootstrap_seed = _require_nonnegative_int(
        payload["bootstrap_seed"],
        "manifest.selection_rule.bootstrap_seed",
    )
    if bootstrap_seed > _MAX_JAX_SEED:
        raise ForagerMatrixManifestError(
            f"manifest.selection_rule.bootstrap_seed must not exceed {_MAX_JAX_SEED}"
        )
    tie_break = _require_string(
        payload["tie_break"],
        "manifest.selection_rule.tie_break",
    )
    if tie_break != "variant_id_ascending":
        raise ForagerMatrixManifestError(
            "manifest.selection_rule.tie_break must be 'variant_id_ascending'"
        )
    return ForagerTuningRule(
        metric=metric,
        direction=cast(SelectionDirection, direction_value),
        statistic=cast(SelectionStatistic, statistic_value),
        confidence=float(confidence_value),
        bootstrap_resamples=bootstrap_resamples,
        bootstrap_seed=bootstrap_seed,
        tie_break="variant_id_ascending",
    )


def _parse_variant(value: Any, *, path: str) -> ForagerMatrixVariant:
    payload = _require_object(value, path)
    _require_exact_keys(
        payload,
        path=path,
        required={"kind", "selection_group", "config"},
    )
    kind_value = _require_string(payload["kind"], f"{path}.kind")
    if kind_value not in ("alberta_horde_ac", CAUSAL_MAP_VARIANT_KIND):
        raise ForagerMatrixManifestError(f"{path}.kind is unknown: {kind_value!r}")
    selection_group = _validate_variant_id(
        _require_string(payload["selection_group"], f"{path}.selection_group"),
        f"{path}.selection_group",
    )
    if kind_value == "alberta_horde_ac":
        config: ForagerVariantConfig = _parse_dataclass_overrides(
            AlbertaForagerConfig,
            payload["config"],
            path=f"{path}.config",
        )
    else:
        config_payload = dict(_require_object(payload["config"], f"{path}.config"))
        declared_quantile = config_payload.pop("respawn_quantile_z", None)
        try:
            parsed_causal = _parse_dataclass_overrides(
                CausalMapForagerConfig,
                config_payload,
                path=f"{path}.config",
            )
            config = (
                CausalMapForagerConfig.from_dict(
                    {
                        **parsed_causal.to_dict(),
                        "respawn_quantile_z": declared_quantile,
                    }
                )
                if declared_quantile is not None
                else parsed_causal
            )
        except (TypeError, ValueError) as exc:
            raise ForagerMatrixManifestError(f"{path}.config is invalid: {exc}") from exc
    return ForagerMatrixVariant(
        kind=cast(ForagerVariantKind, kind_value),
        selection_group=selection_group,
        config=config,
    )


def _parse_tuning_selection(
    value: Any,
    *,
    variant_ids: set[str],
) -> ForagerTuningSelection:
    payload = _require_object(value, "manifest.tuning_selection")
    _require_exact_keys(
        payload,
        path="manifest.tuning_selection",
        required={"report_path", "file_sha256", "selected_variants"},
    )
    report_path = _safe_relative_path(
        payload["report_path"],
        "manifest.tuning_selection.report_path",
    )
    file_sha256 = _require_string(
        payload["file_sha256"],
        "manifest.tuning_selection.file_sha256",
    )
    if _SHA256.fullmatch(file_sha256) is None:
        raise ForagerMatrixManifestError(
            "manifest.tuning_selection.file_sha256 must be a lowercase SHA-256 digest"
        )
    selected_payload = _require_object(
        payload["selected_variants"],
        "manifest.tuning_selection.selected_variants",
    )
    if set(selected_payload) != variant_ids:
        missing = sorted(variant_ids - selected_payload.keys())
        extra = sorted(selected_payload.keys() - variant_ids)
        details = []
        if missing:
            details.append(f"missing {', '.join(missing)}")
        if extra:
            details.append(f"unknown {', '.join(extra)}")
        raise ForagerMatrixManifestError(
            "manifest.tuning_selection.selected_variants must map every "
            f"evaluation variant exactly ({'; '.join(details)})"
        )
    selected: dict[str, str] = {}
    for evaluation_id, tuning_id_value in selected_payload.items():
        _validate_variant_id(
            evaluation_id,
            f"manifest.tuning_selection.selected_variants.{evaluation_id}",
        )
        tuning_id = _require_string(
            tuning_id_value,
            f"manifest.tuning_selection.selected_variants.{evaluation_id}",
        )
        selected[evaluation_id] = _validate_variant_id(
            tuning_id,
            f"manifest.tuning_selection.selected_variants.{evaluation_id}",
        )
    return ForagerTuningSelection(
        report_path=report_path,
        file_sha256=file_sha256,
        selected_variants=MappingProxyType(dict(sorted(selected.items()))),
    )


def parse_forager_matrix_manifest(
    value: Any,
    *,
    source_path: Path | None = None,
) -> ForagerMatrixManifest:
    """Validate and normalize an already-decoded strict manifest payload."""
    payload = _require_object(value, "manifest")
    schema_version = _require_string(
        payload.get("schema_version"),
        "manifest.schema_version",
    )
    if schema_version == "1.0":
        raise ForagerMatrixManifestError(
            "manifest schema '1.0' is unsupported: migrate every variant to "
            "{kind, selection_group, config} and declare selection_rule"
        )
    if schema_version != FORAGER_MATRIX_SCHEMA_VERSION:
        raise ForagerMatrixManifestError(
            f"manifest.schema_version must be {FORAGER_MATRIX_SCHEMA_VERSION!r}"
        )
    _require_exact_keys(
        payload,
        path="manifest",
        required={
            "schema_version",
            "preset",
            "stage",
            "steps",
            "seeds",
            "jax_chunk_size",
            "seed_batch_size",
            "mode",
            "selection_rule",
            "variants",
        },
        optional={"tuning_seeds", "evaluation_seeds", "tuning_selection"},
    )

    preset_value = _require_string(payload["preset"], "manifest.preset")
    if preset_value not in ("relearning", "field_of_view", "unending"):
        raise ForagerMatrixManifestError(f"unknown Forager preset {preset_value!r}")
    preset = cast(ForagerPreset, preset_value)

    stage_value = _require_string(payload["stage"], "manifest.stage")
    if stage_value not in ("tuning", "evaluation"):
        raise ForagerMatrixManifestError("manifest.stage must be 'tuning' or 'evaluation'")
    stage = cast(Literal["tuning", "evaluation"], stage_value)

    steps = _require_positive_int(payload["steps"], "manifest.steps")
    seeds = _require_seed_list(payload["seeds"], "manifest.seeds")
    jax_chunk_size = _require_positive_int(
        payload["jax_chunk_size"],
        "manifest.jax_chunk_size",
    )
    seed_batch_size = _require_positive_int(
        payload["seed_batch_size"],
        "manifest.seed_batch_size",
    )

    mode_value = _require_string(payload["mode"], "manifest.mode")
    if mode_value not in ("vmap", "strict"):
        raise ForagerMatrixManifestError("manifest.mode must be 'vmap' or 'strict'")
    mode = cast(ForagerBatchMode, mode_value)

    selection_rule = _parse_tuning_rule(payload["selection_rule"])
    variants_payload = _require_object(payload["variants"], "manifest.variants")
    if not variants_payload:
        raise ForagerMatrixManifestError("manifest.variants must not be empty")
    variants: dict[str, ForagerMatrixVariant] = {}
    for raw_variant_id, config_payload in variants_payload.items():
        variant_id = _validate_variant_id(raw_variant_id, f"manifest.variants.{raw_variant_id}")
        variants[variant_id] = _parse_variant(
            config_payload,
            path=f"manifest.variants.{variant_id}",
        )

    tuning_seeds = (
        _require_seed_list(payload["tuning_seeds"], "manifest.tuning_seeds")
        if "tuning_seeds" in payload
        else None
    )
    evaluation_seeds = (
        _require_seed_list(payload["evaluation_seeds"], "manifest.evaluation_seeds")
        if "evaluation_seeds" in payload
        else None
    )
    if tuning_seeds is not None and evaluation_seeds is not None:
        overlap = sorted(set(tuning_seeds) & set(evaluation_seeds))
        if overlap:
            raise ForagerMatrixManifestError(
                "manifest tuning and evaluation seed sets overlap: "
                + ", ".join(str(seed) for seed in overlap)
            )
    if stage == "tuning" and tuning_seeds is not None and seeds != tuning_seeds:
        raise ForagerMatrixManifestError(
            "manifest.seeds must exactly match manifest.tuning_seeds for the tuning stage"
        )
    if stage == "evaluation" and evaluation_seeds is not None and seeds != evaluation_seeds:
        raise ForagerMatrixManifestError(
            "manifest.seeds must exactly match manifest.evaluation_seeds for the evaluation stage"
        )

    tuning_selection = (
        _parse_tuning_selection(
            payload["tuning_selection"],
            variant_ids=set(variants),
        )
        if "tuning_selection" in payload
        else None
    )
    if tuning_selection is not None and stage != "evaluation":
        raise ForagerMatrixManifestError(
            "manifest.tuning_selection is valid only for the evaluation stage"
        )

    return ForagerMatrixManifest(
        schema_version=schema_version,
        preset=preset,
        stage=stage,
        steps=steps,
        seeds=seeds,
        jax_chunk_size=jax_chunk_size,
        seed_batch_size=seed_batch_size,
        mode=mode,
        selection_rule=selection_rule,
        variants=MappingProxyType(dict(sorted(variants.items()))),
        tuning_seeds=tuning_seeds,
        evaluation_seeds=evaluation_seeds,
        tuning_selection=tuning_selection,
        source_path=source_path,
    )


def load_forager_matrix_manifest(path: str | Path) -> ForagerMatrixManifest:
    """Load a UTF-8 strict JSON matrix manifest, rejecting duplicate keys."""
    source = Path(path).expanduser()
    try:
        text = _read_regular_file_bytes(source).decode("utf-8")
    except (ForagerMatrixStateError, UnicodeError) as exc:
        raise ForagerMatrixManifestError(f"could not read manifest {source}: {exc}") from exc
    payload = _decode_strict_json(text, description=f"manifest {source}")
    return parse_forager_matrix_manifest(payload, source_path=source.resolve())


def _json_safe(value: Any) -> Any:
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return _json_safe(dataclasses.asdict(value))
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return value.as_posix()
    return value


def _canonical_json_bytes(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ForagerMatrixError(f"value is not canonical JSON data: {exc}") from exc


def _json_sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest()


def _hashed_payload(value: Mapping[str, Any]) -> dict[str, Any]:
    if "payload_sha256" in value:
        raise ForagerMatrixError("payload_sha256 must not be supplied before hashing")
    result = dict(value)
    result["payload_sha256"] = _json_sha256(result)
    return result


def _verify_hashed_payload(value: Any, *, description: str) -> Mapping[str, Any]:
    payload = _require_object(value, description)
    supplied = payload.get("payload_sha256")
    if not isinstance(supplied, str) or _SHA256.fullmatch(supplied) is None:
        raise ForagerMatrixStateError(f"{description} has no valid payload_sha256")
    unhashed = {key: item for key, item in payload.items() if key != "payload_sha256"}
    actual = _json_sha256(unhashed)
    if supplied != actual:
        raise ForagerMatrixStateError(
            f"{description} payload_sha256 mismatch: expected {actual}, found {supplied}"
        )
    return payload


def _decode_canonical_artifact(
    raw: bytes,
    *,
    description: str,
) -> Mapping[str, Any]:
    try:
        text = raw.decode("utf-8")
    except UnicodeError as exc:
        raise ForagerMatrixStateError(f"could not decode {description}: {exc}") from exc
    try:
        decoded = _decode_strict_json(text, description=description)
    except ForagerMatrixManifestError as exc:
        raise ForagerMatrixStateError(str(exc)) from exc
    payload = _verify_hashed_payload(decoded, description=description)
    expected_bytes = _canonical_json_bytes(payload) + b"\n"
    if raw != expected_bytes:
        raise ForagerMatrixStateError(f"{description} is not canonical JSON")
    return payload


def _load_canonical_artifact(path: Path, *, description: str) -> Mapping[str, Any]:
    try:
        raw = _read_regular_file_bytes(path)
    except ForagerMatrixStateError as exc:
        raise ForagerMatrixStateError(f"could not read {description}: {exc}") from exc
    return _decode_canonical_artifact(raw, description=description)


def _atomic_create_bytes(path: Path, encoded: bytes) -> None:
    """Atomically create bytes through a no-follow directory descriptor."""
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_RDONLY | os.O_DIRECTORY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        directory_descriptor = os.open(path.parent, flags)
    except OSError as exc:
        raise ForagerMatrixStateError(
            f"could not open artifact directory without following links: {path.parent}"
        ) from exc
    temporary_name: str | None = None
    descriptor: int | None = None
    try:
        try:
            os.stat(path.name, dir_fd=directory_descriptor, follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise ForagerMatrixStateError(f"refusing to overwrite existing artifact {path}")

        create_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            create_flags |= os.O_NOFOLLOW
        for attempt in range(100):
            candidate = f".{path.name}.{os.getpid()}.{time.time_ns()}.{attempt}.tmp"
            try:
                descriptor = os.open(
                    candidate,
                    create_flags,
                    0o600,
                    dir_fd=directory_descriptor,
                )
            except FileExistsError:
                continue
            temporary_name = candidate
            break
        if descriptor is None or temporary_name is None:  # pragma: no cover
            raise ForagerMatrixStateError(f"could not allocate a temporary artifact for {path}")
        try:
            view = memoryview(encoded)
            while view:
                written = os.write(descriptor, view)
                if written <= 0:  # pragma: no cover - defensive OS contract check
                    raise ForagerMatrixStateError(f"short write while creating artifact {path}")
                view = view[written:]
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
            descriptor = None
        try:
            os.link(
                temporary_name,
                path.name,
                src_dir_fd=directory_descriptor,
                dst_dir_fd=directory_descriptor,
                follow_symlinks=False,
            )
        except FileExistsError as exc:
            raise ForagerMatrixStateError(
                f"refusing to overwrite concurrently created artifact {path}"
            ) from exc
        try:
            os.fsync(directory_descriptor)
        except OSError as exc:  # pragma: no cover - filesystem-specific
            raise ForagerMatrixStateError(
                f"could not synchronize artifact directory {path.parent}"
            ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if temporary_name is not None:
            with contextlib.suppress(FileNotFoundError):
                os.unlink(temporary_name, dir_fd=directory_descriptor)
        os.close(directory_descriptor)


def _atomic_create_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Atomically create a canonical artifact without replacing any file."""
    _atomic_create_bytes(path, _canonical_json_bytes(payload) + b"\n")


def _read_regular_file_bytes(path: Path) -> bytes:
    """Read one stable regular file without following its final symlink."""
    try:
        before_path = os.lstat(path)
    except OSError as exc:
        raise ForagerMatrixStateError(f"could not stat regular file {path}") from exc
    if not stat.S_ISREG(before_path.st_mode):
        raise ForagerMatrixStateError(f"path is not a regular file: {path}")
    flags = os.O_RDONLY
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise ForagerMatrixStateError(
            f"could not open regular file without following links: {path}"
        ) from exc
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or (before.st_dev, before.st_ino) != (
            before_path.st_dev,
            before_path.st_ino,
        ):
            raise ForagerMatrixStateError(f"regular file changed before read: {path}")
        chunks: list[bytes] = []
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
        after = os.fstat(descriptor)
        stable_fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
        if any(getattr(before, name) != getattr(after, name) for name in stable_fields):
            raise ForagerMatrixStateError(f"regular file changed during read: {path}")
        data = b"".join(chunks)
        if len(data) != after.st_size:
            raise ForagerMatrixStateError(f"regular file changed during read: {path}")
        return data
    finally:
        os.close(descriptor)


def _source_file_paths() -> tuple[Path, ...]:
    """Return the exact archive source set, rejecting links and special files."""
    required = (
        REPO_ROOT / "pyproject.toml",
        REPO_ROOT / "uv.lock",
        REPO_ROOT / "FORAGER_BENCHMARK.md",
    )
    framework = REPO_ROOT / "alberta_framework"
    try:
        framework_stat = os.lstat(framework)
    except OSError as exc:
        raise ForagerMatrixStateError("alberta_framework source directory is missing") from exc
    if not stat.S_ISDIR(framework_stat.st_mode):
        raise ForagerMatrixStateError("alberta_framework source path must be a real directory")
    paths: list[Path] = list(required)

    def walk_error(error: OSError) -> None:
        raise ForagerMatrixStateError(f"could not enumerate source tree: {error}") from error

    for directory, directory_names, file_names in os.walk(
        framework,
        topdown=True,
        onerror=walk_error,
        followlinks=False,
    ):
        base = Path(directory)
        retained_directories: list[str] = []
        for name in sorted(directory_names):
            child = base / name
            child_stat = os.lstat(child)
            if stat.S_ISLNK(child_stat.st_mode):
                raise ForagerMatrixStateError(
                    f"source tree contains symlink {child.relative_to(REPO_ROOT)}"
                )
            if not stat.S_ISDIR(child_stat.st_mode):
                raise ForagerMatrixStateError(
                    f"source tree contains special entry {child.relative_to(REPO_ROOT)}"
                )
            if name != "__pycache__":
                retained_directories.append(name)
        directory_names[:] = retained_directories
        for name in sorted(file_names):
            child = base / name
            child_stat = os.lstat(child)
            if stat.S_ISLNK(child_stat.st_mode):
                raise ForagerMatrixStateError(
                    f"source tree contains symlink {child.relative_to(REPO_ROOT)}"
                )
            if not stat.S_ISREG(child_stat.st_mode):
                raise ForagerMatrixStateError(
                    f"source tree contains special entry {child.relative_to(REPO_ROOT)}"
                )
            if child.suffix not in {".pyc", ".pyo"}:
                paths.append(child)
    unique = sorted(set(paths), key=lambda item: item.relative_to(REPO_ROOT).as_posix())
    return tuple(unique)


def _tar_regular_file(name: str, data: bytes) -> tuple[tarfile.TarInfo, io.BytesIO]:
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mtime = 0
    info.type = tarfile.REGTYPE
    return info, io.BytesIO(data)


def _build_source_snapshot() -> _SourceSnapshot:
    """Capture a deterministic, path-independent source archive."""
    source_files: list[tuple[str, bytes]] = []
    inventory_files: list[dict[str, Any]] = []
    for path in _source_file_paths():
        relative = path.relative_to(REPO_ROOT).as_posix()
        if (
            PurePosixPath(relative).is_absolute()
            or ".." in PurePosixPath(relative).parts
            or "\\" in relative
        ):  # pragma: no cover - relative_to plus POSIX conversion guards this
            raise ForagerMatrixStateError("source inventory contains an unsafe path")
        contents = _read_regular_file_bytes(path)
        source_files.append((relative, contents))
        inventory_files.append(
            {
                "path": relative,
                "size": len(contents),
                "sha256": hashlib.sha256(contents).hexdigest(),
            }
        )
    tree_payload = {
        "tree_hash_scheme": SOURCE_TREE_HASH_SCHEME,
        "files": inventory_files,
    }
    tree_sha256 = _json_sha256(tree_payload)
    inventory = {
        "schema_version": "1.0",
        **tree_payload,
        "tree_sha256": tree_sha256,
    }
    inventory_bytes = _canonical_json_bytes(inventory) + b"\n"
    inventory_sha256 = hashlib.sha256(inventory_bytes).hexdigest()
    archive_buffer = io.BytesIO()
    with tarfile.open(
        fileobj=archive_buffer,
        mode="w",
        format=tarfile.USTAR_FORMAT,
    ) as archive:
        info, stream = _tar_regular_file(SOURCE_INVENTORY_MEMBER, inventory_bytes)
        archive.addfile(info, stream)
        for relative, contents in source_files:
            info, stream = _tar_regular_file(relative, contents)
            archive.addfile(info, stream)
    archive_bytes = archive_buffer.getvalue()
    return _SourceSnapshot(
        archive_bytes=archive_bytes,
        archive_sha256=hashlib.sha256(archive_bytes).hexdigest(),
        tree_sha256=tree_sha256,
        inventory_sha256=inventory_sha256,
        inventory=MappingProxyType(inventory),
    )


def _source_tree_sha256() -> str:
    """Hash the exact reconstructible source inventory."""
    return _build_source_snapshot().tree_sha256


def _verify_source_snapshot_file(path: Path, expected: _SourceSnapshot) -> None:
    actual = _read_regular_file_bytes(path)
    actual_sha256 = hashlib.sha256(actual).hexdigest()
    if actual_sha256 != expected.archive_sha256 or actual != expected.archive_bytes:
        raise ForagerMatrixStateError(
            "immutable source snapshot does not match the current source tree"
        )


def _git_provenance() -> dict[str, Any]:
    def git(*arguments: str) -> str | None:
        try:
            result = subprocess.run(
                ("git", *arguments),
                cwd=REPO_ROOT,
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError:
            return None
        return result.stdout.strip() if result.returncode == 0 else None

    status = git("status", "--porcelain=v1")
    diff = git("diff", "HEAD", "--no-ext-diff", "--binary")
    return {
        "commit": git("rev-parse", "HEAD"),
        "dirty": bool(status),
        "status": status.splitlines() if status else [],
        "diff_sha256": hashlib.sha256(diff.encode()).hexdigest() if diff is not None else None,
    }


def _distribution_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _environment_spec(config: ForagerBenchmarkConfig) -> dict[str, Any]:
    environment = config.environment
    return {
        "preset": environment.preset,
        "env_id": environment.resolved_env_id,
        "aperture_size": environment.aperture_size,
        "observation_type": environment.resolved_observation_type,
        "reward_delay": environment.reward_delay,
        "random_shift_max_steps": environment.random_shift_max_steps,
        "extra_kwargs": _json_safe(environment.extra_kwargs),
        "require_exact_version": environment.require_exact_version,
    }


def _benchmark_spec(config: ForagerBenchmarkConfig) -> dict[str, Any]:
    return {
        "environment": _environment_spec(config),
        "result_environment": _json_safe(config.environment.to_dict()),
        "steps": config.steps,
        "seed": config.seed,
        "ewm_decay": config.ewm_decay,
        "record_every": config.record_every,
        "final_window": config.final_window,
        "jax_chunk_size": config.jax_chunk_size,
        "metric_contract": forager_metric_contract(
            ewm_decay=config.ewm_decay,
            final_window=config.final_window,
            record_every=config.record_every,
            steps=config.steps,
        ),
    }


def _execution_context(
    config: ForagerBenchmarkConfig,
    source_snapshot: _SourceSnapshot | None = None,
) -> dict[str, Any]:
    snapshot = source_snapshot or _build_source_snapshot()
    packages = {
        name: _distribution_version(name)
        for name in (
            "alberta-framework",
            "jax",
            "jaxlib",
            "numpy",
            "flax",
            "continual-foragax",
            "gymnax",
        )
    }
    packages["continual-foragax-install-tree-sha256"] = foragax_install_tree_sha256()
    runtime = {
        "python_implementation": platform.python_implementation(),
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "jax_backend": jax.default_backend(),
        "jax_devices": [str(device) for device in jax.devices()],
    }
    environment = _environment_spec(config)
    identity = {
        "source_tree_sha256": snapshot.tree_sha256,
        "source_archive_sha256": snapshot.archive_sha256,
        "source_inventory_sha256": snapshot.inventory_sha256,
        "source_execution_mode": SOURCE_EXECUTION_MODE,
        "environment_sha256": _json_sha256(environment),
        "package_sha256": _json_sha256(packages),
        "runtime_sha256": _json_sha256(runtime),
    }
    return {
        "execution_identity": identity,
        "source": {
            "tree_hash_scheme": SOURCE_TREE_HASH_SCHEME,
            "tree_sha256": identity["source_tree_sha256"],
            "snapshot": snapshot.metadata(),
            "git": _git_provenance(),
        },
        "environment": environment,
        "packages": packages,
        "runtime": runtime,
    }


def _assert_source_tree_unchanged(execution_identity: Mapping[str, Any]) -> None:
    """Refuse to emit an artifact if sources changed after identity capture."""
    expected = execution_identity.get("source_tree_sha256")
    current = _source_tree_sha256()
    if current != expected:
        raise ForagerMatrixStateError(
            "source tree changed during matrix execution; refusing artifact emission "
            f"(captured {expected}, current {current})"
        )


def _build_benchmark_config(manifest: ForagerMatrixManifest) -> ForagerBenchmarkConfig:
    protocol = paper_protocol(manifest.preset)
    return ForagerBenchmarkConfig(
        environment=protocol.environment,
        steps=manifest.steps,
        seed=0,
        ewm_decay=protocol.ewm_decay,
        record_every=1_000,
        final_window=protocol.final_window_steps,
        jax_chunk_size=manifest.jax_chunk_size,
    )


def _batch_plan(manifest: ForagerMatrixManifest) -> tuple[_BatchPlan, ...]:
    result: list[_BatchPlan] = []
    for variant_id in sorted(manifest.variants):
        for index, offset in enumerate(range(0, len(manifest.seeds), manifest.seed_batch_size)):
            result.append(
                _BatchPlan(
                    variant_id=variant_id,
                    batch_index=index,
                    seeds=manifest.seeds[offset : offset + manifest.seed_batch_size],
                )
            )
    return tuple(result)


def _resolve_tuning_report_path(manifest: ForagerMatrixManifest) -> Path:
    selection = manifest.tuning_selection
    if selection is None:
        raise ForagerMatrixError("no tuning selection was declared")
    if manifest.source_path is None:
        raise ForagerMatrixManifestError(
            "tuning_selection requires a filesystem-backed input manifest"
        )
    base = manifest.source_path.parent.resolve()
    candidate = base.joinpath(*PurePosixPath(selection.report_path).parts)
    current = base
    for component in PurePosixPath(selection.report_path).parts:
        current = current / component
        if current.exists() and current.is_symlink():
            raise ForagerMatrixManifestError(
                "manifest.tuning_selection.report_path may not traverse symlinks"
            )
    resolved = candidate.resolve(strict=False)
    try:
        resolved.relative_to(base)
    except ValueError as exc:  # pragma: no cover - guarded lexically as well
        raise ForagerMatrixManifestError(
            "manifest.tuning_selection.report_path escapes the manifest directory"
        ) from exc
    if not resolved.is_file() or resolved.is_symlink():
        raise ForagerMatrixManifestError(
            f"tuning selection report is not a regular file: {selection.report_path}"
        )
    return resolved


def _validate_report_variants_for_selection(
    manifest: ForagerMatrixManifest,
    value: Any,
) -> Mapping[str, Mapping[str, Any]]:
    payload = _require_object(value, "referenced variants")
    if set(payload) != set(manifest.variants):
        raise ForagerMatrixManifestError(
            "referenced report variants do not match its matrix configuration"
        )
    validated: dict[str, Mapping[str, Any]] = {}
    expected_entry_keys = {
        "kind",
        "selection_group",
        "config",
        "config_sha256",
        "variant_sha256",
        "seeds",
        "seed_batches",
        "summary",
    }
    expected_summary_keys = {
        "agent",
        "privileged",
        "seeds",
        "metric",
        "mean",
        "ci_low",
        "ci_high",
        "confidence",
        "bootstrap_resamples",
        "bootstrap_seed",
    }
    for variant_id, variant in manifest.variants.items():
        entry = _require_object(
            payload[variant_id],
            f"referenced variants.{variant_id}",
        )
        if set(entry) != expected_entry_keys:
            raise ForagerMatrixManifestError(
                f"referenced variant {variant_id!r} has unknown or missing fields"
            )
        if (
            entry["kind"] != variant.kind
            or entry["selection_group"] != variant.selection_group
            or entry["config"] != variant.config.to_dict()
            or entry["config_sha256"] != variant.config_sha256
            or entry["variant_sha256"] != variant.descriptor_sha256
            or entry["seeds"] != list(manifest.seeds)
        ):
            raise ForagerMatrixManifestError(
                f"referenced variant {variant_id!r} does not match matrix_config"
            )
        summary = _require_object(
            entry["summary"],
            f"referenced variants.{variant_id}.summary",
        )
        if set(summary) != expected_summary_keys:
            raise ForagerMatrixManifestError(
                f"referenced variant {variant_id!r} summary is malformed"
            )
        rule = manifest.selection_rule
        if (
            summary["agent"] != variant.kind
            or summary["privileged"] is not False
            or summary["seeds"] != list(manifest.seeds)
            or summary["metric"] != rule.metric
            or summary["confidence"] != rule.confidence
            or summary["bootstrap_resamples"] != rule.bootstrap_resamples
            or summary["bootstrap_seed"] != rule.bootstrap_seed
        ):
            raise ForagerMatrixManifestError(
                f"referenced variant {variant_id!r} summary is not bound to its rule"
            )
        for name in ("mean", "ci_low", "ci_high"):
            try:
                _finite_number(
                    summary[name],
                    f"referenced variants.{variant_id}.summary.{name}",
                )
            except ForagerMatrixStateError as exc:
                raise ForagerMatrixManifestError(str(exc)) from exc
        validated[variant_id] = entry
    return MappingProxyType(validated)


def _validate_tuning_reference(manifest: ForagerMatrixManifest) -> dict[str, Any] | None:
    selection = manifest.tuning_selection
    if selection is None:
        return None
    report_path = _resolve_tuning_report_path(manifest)
    try:
        report_bytes = _read_regular_file_bytes(report_path)
    except ForagerMatrixStateError as exc:
        raise ForagerMatrixManifestError(f"could not read tuning selection report: {exc}") from exc
    actual_file_sha256 = hashlib.sha256(report_bytes).hexdigest()
    if actual_file_sha256 != selection.file_sha256:
        raise ForagerMatrixManifestError(
            "tuning selection report file SHA-256 mismatch: "
            f"expected {selection.file_sha256}, found {actual_file_sha256}"
        )
    try:
        report = _decode_canonical_artifact(
            report_bytes,
            description="referenced tuning report",
        )
    except ForagerMatrixStateError as exc:
        raise ForagerMatrixManifestError(str(exc)) from exc
    required = {
        "schema_version",
        "artifact_type",
        "status",
        "matrix_config",
        "matrix_config_sha256",
        "benchmark_config",
        "benchmark_config_sha256",
        "execution_manifest_sha256",
        "execution_identity",
        "source_snapshot",
        "protocol_conformance",
        "variants",
        "selection_results",
        "batch_artifacts",
        "provenance",
        "started_at_utc",
        "completed_at_utc",
        "benchmark_wall_time_s",
        "payload_sha256",
    }
    if set(report) != required:
        raise ForagerMatrixManifestError(
            "referenced tuning report does not match the matrix report schema"
        )
    if (
        report["schema_version"] != FORAGER_MATRIX_SCHEMA_VERSION
        or report["artifact_type"] != FORAGER_MATRIX_REPORT
        or report["status"] != "complete"
    ):
        raise ForagerMatrixManifestError("referenced tuning report is not a completed matrix")
    matrix_config = _require_object(report["matrix_config"], "referenced matrix_config")
    if report["matrix_config_sha256"] != _json_sha256(matrix_config):
        raise ForagerMatrixManifestError("referenced tuning report matrix_config SHA-256 mismatch")
    try:
        tuning_manifest = parse_forager_matrix_manifest(matrix_config)
    except ForagerMatrixManifestError as exc:
        raise ForagerMatrixManifestError(
            f"referenced tuning report matrix_config is invalid: {exc}"
        ) from exc
    if matrix_config.get("stage") != "tuning":
        raise ForagerMatrixManifestError("referenced report is not a tuning-stage report")
    if matrix_config.get("preset") != manifest.preset:
        raise ForagerMatrixManifestError("referenced tuning report uses a different preset")
    protocol = _require_object(
        report["protocol_conformance"],
        "referenced protocol_conformance",
    )
    if not isinstance(protocol.get("stage_protocol_conformant"), bool):
        raise ForagerMatrixManifestError(
            "referenced tuning report lacks a valid stage conformance result"
        )
    if tuning_manifest.selection_rule != manifest.selection_rule:
        raise ForagerMatrixManifestError(
            "evaluation selection rule does not match the referenced tuning report"
        )
    tuning_variants = _validate_report_variants_for_selection(
        tuning_manifest,
        report["variants"],
    )
    expected_selection_results = _selection_results_payload(
        tuning_manifest,
        tuning_variants,
    )
    if report["selection_results"] != expected_selection_results:
        raise ForagerMatrixManifestError(
            "referenced tuning report ranking does not recompute from its summaries"
        )
    selection_results = _require_object(
        report["selection_results"],
        "referenced selection_results",
    )
    groups = _require_object(
        selection_results.get("groups"),
        "referenced selection_results.groups",
    )
    selected_details: dict[str, Any] = {}
    for evaluation_id, tuning_id in selection.selected_variants.items():
        if tuning_id not in tuning_variants:
            raise ForagerMatrixManifestError(
                f"selected tuning variant {tuning_id!r} is absent from the tuning report"
            )
        tuning_entry = _require_object(
            tuning_variants[tuning_id],
            f"referenced variants.{tuning_id}",
        )
        evaluation_variant = manifest.variants[evaluation_id]
        group_entry = _require_object(
            groups.get(evaluation_variant.selection_group),
            "referenced selection group",
        )
        if group_entry.get("selected_variant_id") != tuning_id:
            raise ForagerMatrixManifestError(
                f"selected tuning variant {tuning_id!r} is not the declared "
                f"top-ranked winner of group {evaluation_variant.selection_group!r}"
            )
        if tuning_entry.get("selection_group") != evaluation_variant.selection_group:
            raise ForagerMatrixManifestError(
                f"evaluation variant {evaluation_id!r} uses a different selection group"
            )
        if tuning_entry.get("kind") != evaluation_variant.kind:
            raise ForagerMatrixManifestError(
                f"evaluation variant {evaluation_id!r} changes the selected agent kind"
            )
        tuning_hash = tuning_entry.get("config_sha256")
        evaluation_hash = evaluation_variant.config_sha256
        if tuning_hash != evaluation_hash:
            raise ForagerMatrixManifestError(
                f"evaluation variant {evaluation_id!r} does not match selected "
                f"tuning variant {tuning_id!r}"
            )
        selected_details[evaluation_id] = {
            "tuning_variant_id": tuning_id,
            "selection_group": evaluation_variant.selection_group,
            "kind": evaluation_variant.kind,
            "config_sha256": evaluation_hash,
        }
    tuning_seed_values = matrix_config.get("seeds")
    tuning_seeds = _require_seed_list(tuning_seed_values, "referenced matrix_config.seeds")
    overlap = sorted(set(tuning_seeds) & set(manifest.seeds))
    if overlap:
        raise ForagerMatrixManifestError(
            "referenced tuning seeds overlap evaluation seeds: "
            + ", ".join(str(seed) for seed in overlap)
        )
    return {
        "report_path": selection.report_path,
        "file_sha256": actual_file_sha256,
        "report_payload_sha256": report["payload_sha256"],
        "matrix_config_sha256": report["matrix_config_sha256"],
        "tuning_seeds": list(tuning_seeds),
        "stage_protocol_conformant": protocol["stage_protocol_conformant"],
        "selected_variants": selected_details,
    }


def _protocol_conformance(
    manifest: ForagerMatrixManifest,
    tuning_reference: Mapping[str, Any] | None,
) -> dict[str, Any]:
    protocol = paper_protocol(manifest.preset)
    if manifest.stage == "tuning":
        expected_steps = protocol.tuning_steps
        expected_seeds = tuple(
            range(
                protocol.tuning_seed_offset,
                protocol.tuning_seed_offset + protocol.tuning_seeds,
            )
        )
    else:
        expected_steps = protocol.evaluation_steps
        expected_seeds = tuple(
            range(
                protocol.evaluation_seed_start,
                protocol.evaluation_seed_start + protocol.evaluation_seeds,
            )
        )
    horizon_conformant = manifest.steps == expected_steps
    seed_set_conformant = manifest.seeds == expected_seeds
    stage_conformant = horizon_conformant and seed_set_conformant
    declared_disjoint: bool | None = None
    if manifest.tuning_seeds is not None and manifest.evaluation_seeds is not None:
        declared_disjoint = not bool(set(manifest.tuning_seeds) & set(manifest.evaluation_seeds))
    tuning_reference_valid = tuning_reference is not None
    full_conformant = bool(
        manifest.stage == "evaluation"
        and stage_conformant
        and tuning_reference is not None
        and tuning_reference["stage_protocol_conformant"]
    )
    return {
        "preset": manifest.preset,
        "stage": manifest.stage,
        "expected_steps": expected_steps,
        "actual_steps": manifest.steps,
        "horizon_conformant": horizon_conformant,
        "expected_seeds": list(expected_seeds),
        "actual_seeds": list(manifest.seeds),
        "seed_set_conformant": seed_set_conformant,
        "declared_tuning_evaluation_seed_sets_disjoint": declared_disjoint,
        "stage_protocol_conformant": stage_conformant,
        "tuning_stage_executed": manifest.stage == "tuning" or tuning_reference_valid,
        "tuning_reference_validated": tuning_reference_valid,
        "tuning_reference": _json_safe(tuning_reference),
        "full_paper_protocol_conformant": full_conformant,
        "conformance_note": (
            "Full paper-protocol conformance requires a paper-conformant evaluation "
            "manifest that cryptographically references a completed, paper-conformant "
            "tuning/selection report with disjoint seeds."
        ),
    }


def _execution_manifest_payload(
    manifest: ForagerMatrixManifest,
    benchmark: ForagerBenchmarkConfig,
    plan: Sequence[_BatchPlan],
    context: Mapping[str, Any],
    protocol_conformance: Mapping[str, Any],
) -> dict[str, Any]:
    normalized = manifest.to_dict()
    benchmark_payload = _benchmark_spec(benchmark)
    return _hashed_payload(
        {
            "schema_version": FORAGER_MATRIX_SCHEMA_VERSION,
            "artifact_type": FORAGER_MATRIX_EXECUTION_MANIFEST,
            "matrix_config": normalized,
            "matrix_config_sha256": _json_sha256(normalized),
            "benchmark_config": benchmark_payload,
            "benchmark_config_sha256": _json_sha256(benchmark_payload),
            "execution_identity": context["execution_identity"],
            "source_snapshot": context["source"]["snapshot"],
            "batch_plan": [item.to_dict() for item in plan],
            "protocol_conformance": dict(protocol_conformance),
            "provenance": dict(context),
            "created_at_utc": datetime.now(UTC).isoformat(),
        }
    )


def _validate_execution_manifest(
    payload: Mapping[str, Any],
    expected: Mapping[str, Any],
) -> None:
    required = {
        "schema_version",
        "artifact_type",
        "matrix_config",
        "matrix_config_sha256",
        "benchmark_config",
        "benchmark_config_sha256",
        "execution_identity",
        "source_snapshot",
        "batch_plan",
        "protocol_conformance",
        "provenance",
        "created_at_utc",
        "payload_sha256",
    }
    if set(payload) != required:
        raise ForagerMatrixStateError("execution manifest contains unknown or missing keys")
    if (
        payload["schema_version"] != FORAGER_MATRIX_SCHEMA_VERSION
        or payload["artifact_type"] != FORAGER_MATRIX_EXECUTION_MANIFEST
    ):
        raise ForagerMatrixStateError("execution manifest schema or artifact type mismatch")
    for key in (
        "matrix_config",
        "matrix_config_sha256",
        "benchmark_config",
        "benchmark_config_sha256",
        "execution_identity",
        "source_snapshot",
        "batch_plan",
        "protocol_conformance",
    ):
        if payload[key] != expected[key]:
            if key == "execution_identity":
                current = _require_object(expected[key], "current execution identity")
                recorded = _require_object(payload[key], "recorded execution identity")
                changed = [
                    name
                    for name in (
                        "source_tree_sha256",
                        "source_archive_sha256",
                        "source_inventory_sha256",
                        "source_execution_mode",
                        "environment_sha256",
                        "package_sha256",
                        "runtime_sha256",
                    )
                    if current.get(name) != recorded.get(name)
                ]
                detail = ", ".join(changed) if changed else "execution identity"
                raise ForagerMatrixStateError(f"resume refused because {detail} changed")
            raise ForagerMatrixStateError(f"resume refused because {key} changed")
    provenance = _require_object(payload["provenance"], "execution manifest provenance")
    if provenance.get("execution_identity") != payload["execution_identity"]:
        raise ForagerMatrixStateError(
            "execution manifest provenance does not match its execution identity"
        )
    source = _require_object(
        provenance.get("source"),
        "execution manifest provenance.source",
    )
    if source.get("snapshot") != payload["source_snapshot"]:
        raise ForagerMatrixStateError(
            "execution manifest source snapshot does not match provenance"
        )
    identity = _require_object(
        payload["execution_identity"],
        "execution manifest execution_identity",
    )
    snapshot = _require_object(
        payload["source_snapshot"],
        "execution manifest source_snapshot",
    )
    for identity_key, snapshot_key in (
        ("source_tree_sha256", "tree_sha256"),
        ("source_archive_sha256", "archive_sha256"),
        ("source_inventory_sha256", "inventory_sha256"),
        ("source_execution_mode", "source_execution_mode"),
    ):
        if identity.get(identity_key) != snapshot.get(snapshot_key):
            raise ForagerMatrixStateError(
                "execution manifest source snapshot does not match execution identity"
            )


def _run_to_payload(run: ForagerRunResult) -> dict[str, Any]:
    return cast(dict[str, Any], _json_safe(run.to_dict()))


def _finite_number(value: Any, path: str, *, minimum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ForagerMatrixStateError(f"{path} must be a finite number")
    result = float(value)
    if not math.isfinite(result):
        raise ForagerMatrixStateError(f"{path} must be a finite number")
    if minimum is not None and result < minimum:
        raise ForagerMatrixStateError(f"{path} must be at least {minimum}")
    return result


def _optional_finite_number(value: Any, path: str) -> float:
    if value is None:
        return math.nan
    return _finite_number(value, path)


def _run_from_payload(
    value: Any,
    *,
    path: str,
    expected_seed: int,
    expected_steps: int,
    expected_kind: ForagerVariantKind,
    expected_config: Mapping[str, Any],
    expected_environment: Mapping[str, Any],
    expected_metric_contract: Mapping[str, Any],
    expected_mode: ForagerBatchMode,
    expected_batch_seeds: Sequence[int],
) -> ForagerRunResult:
    payload = _require_object(value, path)
    if set(payload) != _RUN_FIELDS:
        unknown = sorted(payload.keys() - _RUN_FIELDS)
        missing = sorted(_RUN_FIELDS - payload.keys())
        details = []
        if unknown:
            details.append(f"unknown {', '.join(unknown)}")
        if missing:
            details.append(f"missing {', '.join(missing)}")
        raise ForagerMatrixStateError(f"{path} fields are invalid ({'; '.join(details)})")
    if payload["agent"] != expected_kind or payload["privileged"] is not False:
        raise ForagerMatrixStateError(
            f"{path} agent kind or privilege label does not match its variant"
        )
    seed = payload["seed"]
    steps = payload["steps"]
    if isinstance(seed, bool) or not isinstance(seed, int) or seed != expected_seed:
        raise ForagerMatrixStateError(f"{path}.seed does not match its batch")
    if isinstance(steps, bool) or not isinstance(steps, int) or steps != expected_steps:
        raise ForagerMatrixStateError(f"{path}.steps does not match the matrix horizon")

    curve_steps_raw = payload["curve_steps"]
    if not isinstance(curve_steps_raw, list) or any(
        isinstance(item, bool) or not isinstance(item, int) or item < 1 or item > steps
        for item in curve_steps_raw
    ):
        raise ForagerMatrixStateError(f"{path}.curve_steps is invalid")
    curve_ewm_raw = payload["curve_ewm_reward"]
    curve_window_raw = payload["curve_window_reward"]
    if not isinstance(curve_ewm_raw, list) or not isinstance(curve_window_raw, list):
        raise ForagerMatrixStateError(f"{path} curves must be JSON arrays")
    if not (len(curve_steps_raw) == len(curve_ewm_raw) == len(curve_window_raw)):
        raise ForagerMatrixStateError(f"{path} curve lengths differ")
    if (
        not curve_steps_raw
        or curve_steps_raw[0] != 1
        or curve_steps_raw[-1] != steps
        or any(
            current >= following for current, following in zip(curve_steps_raw, curve_steps_raw[1:])
        )
    ):
        raise ForagerMatrixStateError(
            f"{path}.curve_steps must increase strictly from 1 through steps"
        )
    curve_ewm = tuple(
        _finite_number(item, f"{path}.curve_ewm_reward[{index}]")
        for index, item in enumerate(curve_ewm_raw)
    )
    curve_window = tuple(
        _finite_number(item, f"{path}.curve_window_reward[{index}]")
        for index, item in enumerate(curve_window_raw)
    )

    environment = _require_object(payload["environment"], f"{path}.environment")
    metric_contract = _require_object(payload["metric_contract"], f"{path}.metric_contract")
    agent_metadata = _require_object(payload["agent_metadata"], f"{path}.agent_metadata")
    if environment != expected_environment:
        raise ForagerMatrixStateError(f"{path} environment does not match the benchmark")
    if metric_contract != expected_metric_contract:
        raise ForagerMatrixStateError(f"{path} metric contract does not match the benchmark")
    metadata_config = agent_metadata.get("config")
    if metadata_config != expected_config:
        raise ForagerMatrixStateError(f"{path} Alberta configuration hash mismatch")
    metadata_seed = agent_metadata.get("seed")
    if metadata_seed != seed:
        raise ForagerMatrixStateError(f"{path} agent and environment seeds differ")
    if agent_metadata.get("name") != expected_kind or agent_metadata.get("privileged") is not False:
        raise ForagerMatrixStateError(
            f"{path} agent metadata kind or privilege label does not match"
        )
    runner = _require_object(agent_metadata.get("runner"), f"{path}.agent_metadata.runner")
    if runner.get("batch_mode") != expected_mode or runner.get("batch_seeds") != list(
        expected_batch_seeds
    ):
        raise ForagerMatrixStateError(
            f"{path} runner metadata does not match its batch mode and seeds"
        )

    total_reward = _finite_number(payload["total_reward"], f"{path}.total_reward")
    mean_reward = _finite_number(payload["mean_reward"], f"{path}.mean_reward")
    if not math.isclose(
        mean_reward,
        total_reward / steps,
        rel_tol=1e-12,
        abs_tol=1e-12,
    ):
        raise ForagerMatrixStateError(
            f"{path}.mean_reward is inconsistent with total_reward / steps"
        )

    return ForagerRunResult(
        agent=expected_kind,
        privileged=False,
        seed=seed,
        steps=steps,
        total_reward=total_reward,
        mean_reward=mean_reward,
        final_window_mean_reward=_finite_number(
            payload["final_window_mean_reward"],
            f"{path}.final_window_mean_reward",
        ),
        final_ewm_reward=_finite_number(
            payload["final_ewm_reward"],
            f"{path}.final_ewm_reward",
        ),
        mean_ewm_reward=_finite_number(
            payload["mean_ewm_reward"],
            f"{path}.mean_ewm_reward",
        ),
        fov_last_10pct_ema_auc=_finite_number(
            payload["fov_last_10pct_ema_auc"],
            f"{path}.fov_last_10pct_ema_auc",
        ),
        mean_biome_regret=_optional_finite_number(
            payload["mean_biome_regret"],
            f"{path}.mean_biome_regret",
        ),
        final_biome_regret=_optional_finite_number(
            payload["final_biome_regret"],
            f"{path}.final_biome_regret",
        ),
        curve_steps=tuple(curve_steps_raw),
        curve_ewm_reward=curve_ewm,
        curve_window_reward=curve_window,
        duration_s=_finite_number(
            payload["duration_s"],
            f"{path}.duration_s",
            minimum=0.0,
        ),
        frames_per_second=_finite_number(
            payload["frames_per_second"],
            f"{path}.frames_per_second",
            minimum=0.0,
        ),
        environment=dict(environment),
        metric_contract=dict(metric_contract),
        agent_metadata=dict(agent_metadata),
    )


def _batch_payload(
    *,
    manifest: ForagerMatrixManifest,
    execution_manifest: Mapping[str, Any],
    item: _BatchPlan,
    runs: Sequence[ForagerRunResult],
    wall_time_s: float,
) -> dict[str, Any]:
    variant = manifest.variants[item.variant_id]
    descriptor = variant.to_dict()
    return _hashed_payload(
        {
            "schema_version": FORAGER_MATRIX_SCHEMA_VERSION,
            "artifact_type": FORAGER_MATRIX_BATCH_ARTIFACT,
            "matrix_config_sha256": manifest.config_sha256,
            "execution_manifest_sha256": execution_manifest["payload_sha256"],
            "execution_identity": execution_manifest["execution_identity"],
            "variant_id": item.variant_id,
            "variant": descriptor,
            "variant_sha256": _json_sha256(descriptor),
            "batch_index": item.batch_index,
            "seeds": list(item.seeds),
            "mode": manifest.mode,
            "runs": [_run_to_payload(run) for run in runs],
            "wall_time_s": wall_time_s,
            "created_at_utc": datetime.now(UTC).isoformat(),
        }
    )


def _validate_batch_artifact(
    payload: Mapping[str, Any],
    *,
    manifest: ForagerMatrixManifest,
    execution_manifest: Mapping[str, Any],
    item: _BatchPlan,
) -> tuple[ForagerRunResult, ...]:
    required = {
        "schema_version",
        "artifact_type",
        "matrix_config_sha256",
        "execution_manifest_sha256",
        "execution_identity",
        "variant_id",
        "variant",
        "variant_sha256",
        "batch_index",
        "seeds",
        "mode",
        "runs",
        "wall_time_s",
        "created_at_utc",
        "payload_sha256",
    }
    if set(payload) != required:
        raise ForagerMatrixStateError(
            f"batch artifact {item.relative_path} contains unknown or missing keys"
        )
    variant = manifest.variants[item.variant_id]
    descriptor = variant.to_dict()
    config = variant.config.to_dict()
    expected_values = {
        "schema_version": FORAGER_MATRIX_SCHEMA_VERSION,
        "artifact_type": FORAGER_MATRIX_BATCH_ARTIFACT,
        "matrix_config_sha256": manifest.config_sha256,
        "execution_manifest_sha256": execution_manifest["payload_sha256"],
        "execution_identity": execution_manifest["execution_identity"],
        "variant_id": item.variant_id,
        "variant": descriptor,
        "variant_sha256": _json_sha256(descriptor),
        "batch_index": item.batch_index,
        "seeds": list(item.seeds),
        "mode": manifest.mode,
    }
    for key, expected in expected_values.items():
        if payload[key] != expected:
            raise ForagerMatrixStateError(
                f"batch artifact {item.relative_path} has mismatched {key}"
            )
    _finite_number(
        payload["wall_time_s"],
        f"batch artifact {item.relative_path}.wall_time_s",
        minimum=0.0,
    )
    raw_runs = payload["runs"]
    if not isinstance(raw_runs, list) or len(raw_runs) != len(item.seeds):
        raise ForagerMatrixStateError(
            f"batch artifact {item.relative_path} has the wrong result count"
        )
    benchmark_payload = _require_object(
        execution_manifest["benchmark_config"],
        "execution manifest benchmark_config",
    )
    expected_environment = _require_object(
        benchmark_payload.get("result_environment"),
        "execution manifest benchmark_config.result_environment",
    )
    expected_metric_contract = _require_object(
        benchmark_payload.get("metric_contract"),
        "execution manifest benchmark_config.metric_contract",
    )
    return tuple(
        _run_from_payload(
            raw,
            path=f"batch artifact {item.relative_path}.runs[{index}]",
            expected_seed=seed,
            expected_steps=manifest.steps,
            expected_kind=variant.kind,
            expected_config=config,
            expected_environment=expected_environment,
            expected_metric_contract=expected_metric_contract,
            expected_mode=manifest.mode,
            expected_batch_seeds=item.seeds,
        )
        for index, (raw, seed) in enumerate(zip(raw_runs, item.seeds))
    )


def _summary_payload(
    runs: Sequence[ForagerRunResult],
    *,
    rule: ForagerTuningRule,
) -> dict[str, Any]:
    summary = summarize_forager_runs(
        runs,
        metric=cast(Any, rule.metric),
        confidence=rule.confidence,
        bootstrap_resamples=rule.bootstrap_resamples,
        bootstrap_seed=rule.bootstrap_seed,
    )
    return {
        "agent": summary.agent,
        "privileged": summary.privileged,
        "seeds": list(summary.seeds),
        "metric": summary.metric,
        "mean": summary.mean,
        "ci_low": summary.ci_low,
        "ci_high": summary.ci_high,
        "confidence": summary.confidence,
        "bootstrap_resamples": rule.bootstrap_resamples,
        "bootstrap_seed": rule.bootstrap_seed,
    }


def _selection_score(
    summary: Mapping[str, Any],
    rule: ForagerTuningRule,
) -> float:
    if rule.statistic == "mean":
        value = summary.get("mean")
    elif rule.direction == "maximize":
        value = summary.get("ci_low")
    else:
        value = summary.get("ci_high")
    return _finite_number(value, "variant selection score")


def _selection_results_payload(
    manifest: ForagerMatrixManifest,
    variants: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any] | None:
    if manifest.stage != "tuning":
        return None
    grouped: dict[str, list[dict[str, Any]]] = {}
    for variant_id, variant in sorted(manifest.variants.items()):
        entry = variants[variant_id]
        summary = _require_object(
            entry["summary"],
            f"variants.{variant_id}.summary",
        )
        grouped.setdefault(variant.selection_group, []).append(
            {
                "variant_id": variant_id,
                "kind": variant.kind,
                "config_sha256": variant.config_sha256,
                "variant_sha256": variant.descriptor_sha256,
                "mean": _finite_number(summary.get("mean"), "summary.mean"),
                "ci_low": _finite_number(summary.get("ci_low"), "summary.ci_low"),
                "ci_high": _finite_number(summary.get("ci_high"), "summary.ci_high"),
                "selection_score": _selection_score(summary, manifest.selection_rule),
            }
        )
    groups: dict[str, Any] = {}
    for group_id, raw_rows in sorted(grouped.items()):
        if manifest.selection_rule.direction == "maximize":
            ordered = sorted(
                raw_rows,
                key=lambda row: (-float(row["selection_score"]), row["variant_id"]),
            )
        else:
            ordered = sorted(
                raw_rows,
                key=lambda row: (float(row["selection_score"]), row["variant_id"]),
            )
        ranked = [
            {
                "rank": index,
                **row,
            }
            for index, row in enumerate(ordered, start=1)
        ]
        groups[group_id] = {
            "selection_group": group_id,
            "ranked_variants": ranked,
            "selected_variant_id": ranked[0]["variant_id"],
        }
    return {
        "rule": manifest.selection_rule.to_dict(),
        "groups": groups,
    }


def _variant_report_payload(
    *,
    manifest: ForagerMatrixManifest,
    plan: Sequence[_BatchPlan],
    batch_payloads: Mapping[str, Mapping[str, Any]],
    runs_by_variant: Mapping[str, Sequence[ForagerRunResult]],
) -> dict[str, Any]:
    variants: dict[str, Any] = {}
    for variant_id, variant in sorted(manifest.variants.items()):
        variant_batches = [item for item in plan if item.variant_id == variant_id]
        variants[variant_id] = {
            "kind": variant.kind,
            "selection_group": variant.selection_group,
            "config": variant.config.to_dict(),
            "config_sha256": variant.config_sha256,
            "variant_sha256": variant.descriptor_sha256,
            "seeds": list(manifest.seeds),
            "seed_batches": [
                {
                    "batch_index": item.batch_index,
                    "seeds": list(item.seeds),
                    "path": item.relative_path,
                    "payload_sha256": batch_payloads[item.relative_path]["payload_sha256"],
                }
                for item in variant_batches
            ],
            "summary": _summary_payload(
                runs_by_variant[variant_id],
                rule=manifest.selection_rule,
            ),
        }
    return variants


def _report_payload(
    *,
    manifest: ForagerMatrixManifest,
    execution_manifest: Mapping[str, Any],
    plan: Sequence[_BatchPlan],
    batch_payloads: Mapping[str, Mapping[str, Any]],
    runs_by_variant: Mapping[str, Sequence[ForagerRunResult]],
) -> dict[str, Any]:
    batch_wall_time = sum(float(payload["wall_time_s"]) for payload in batch_payloads.values())
    variants = _variant_report_payload(
        manifest=manifest,
        plan=plan,
        batch_payloads=batch_payloads,
        runs_by_variant=runs_by_variant,
    )
    return _hashed_payload(
        {
            "schema_version": FORAGER_MATRIX_SCHEMA_VERSION,
            "artifact_type": FORAGER_MATRIX_REPORT,
            "status": "complete",
            "matrix_config": manifest.to_dict(),
            "matrix_config_sha256": manifest.config_sha256,
            "benchmark_config": execution_manifest["benchmark_config"],
            "benchmark_config_sha256": execution_manifest["benchmark_config_sha256"],
            "execution_manifest_sha256": execution_manifest["payload_sha256"],
            "execution_identity": execution_manifest["execution_identity"],
            "source_snapshot": execution_manifest["source_snapshot"],
            "protocol_conformance": execution_manifest["protocol_conformance"],
            "variants": variants,
            "selection_results": _selection_results_payload(manifest, variants),
            "batch_artifacts": [
                {
                    **item.to_dict(),
                    "payload_sha256": batch_payloads[item.relative_path]["payload_sha256"],
                }
                for item in plan
            ],
            "provenance": execution_manifest["provenance"],
            "started_at_utc": execution_manifest["created_at_utc"],
            "completed_at_utc": datetime.now(UTC).isoformat(),
            "benchmark_wall_time_s": batch_wall_time,
        }
    )


def _validate_report(
    payload: Mapping[str, Any],
    *,
    manifest: ForagerMatrixManifest,
    execution_manifest: Mapping[str, Any],
    plan: Sequence[_BatchPlan],
    batch_payloads: Mapping[str, Mapping[str, Any]],
    runs_by_variant: Mapping[str, Sequence[ForagerRunResult]],
) -> None:
    expected = _report_payload(
        manifest=manifest,
        execution_manifest=execution_manifest,
        plan=plan,
        batch_payloads=batch_payloads,
        runs_by_variant=runs_by_variant,
    )
    dynamic = {"completed_at_utc", "payload_sha256"}
    if set(payload) != set(expected):
        raise ForagerMatrixStateError("final report contains unknown or missing keys")
    for key in expected.keys() - dynamic:
        if payload[key] != expected[key]:
            raise ForagerMatrixStateError(f"final report has mismatched {key}")
    completed_at = payload["completed_at_utc"]
    if not isinstance(completed_at, str) or not completed_at:
        raise ForagerMatrixStateError("final report has an invalid completion timestamp")


def _allowed_output_entries(
    plan: Sequence[_BatchPlan],
) -> tuple[set[str], set[str]]:
    files = {
        LOCK_FILENAME,
        SOURCE_SNAPSHOT_FILENAME,
        EXECUTION_MANIFEST_FILENAME,
        FINAL_REPORT_FILENAME,
        *(item.relative_path for item in plan),
    }
    directories = {"batches", *(f"batches/{item.variant_id}" for item in plan)}
    return files, directories


def _validate_output_inventory(output_dir: Path, plan: Sequence[_BatchPlan]) -> None:
    allowed_files, allowed_directories = _allowed_output_entries(plan)
    for path in output_dir.rglob("*"):
        relative = path.relative_to(output_dir).as_posix()
        if path.is_symlink():
            raise ForagerMatrixStateError(f"output state contains symlink {relative}")
        if path.is_dir():
            if relative not in allowed_directories:
                raise ForagerMatrixStateError(
                    f"output state contains unexpected directory {relative}"
                )
        elif relative not in allowed_files:
            raise ForagerMatrixStateError(f"output state contains unexpected file {relative}")

    execution_path = output_dir / EXECUTION_MANIFEST_FILENAME
    committed_entries = [
        path
        for path in output_dir.iterdir()
        if path.name not in {LOCK_FILENAME, SOURCE_SNAPSHOT_FILENAME}
    ]
    if not execution_path.exists() and committed_entries:
        raise ForagerMatrixStateError(
            "non-empty output state has no valid execution manifest; refusing to overwrite it"
        )


@contextlib.contextmanager
def _output_lock(output_dir: Path) -> Iterator[None]:
    if output_dir.exists() and output_dir.is_symlink():
        raise ForagerMatrixStateError("output directory may not be a symlink")
    output_dir.mkdir(parents=True, exist_ok=True)
    if not output_dir.is_dir():
        raise ForagerMatrixStateError("output path is not a directory")
    flags = os.O_RDWR | os.O_CREAT
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(output_dir / LOCK_FILENAME, flags, 0o600)
    except OSError as exc:
        raise ForagerMatrixStateError(f"could not open output lock: {exc}") from exc
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ForagerMatrixLockedError(
                f"another matrix runner holds {output_dir / LOCK_FILENAME}"
            ) from exc
        yield
    finally:
        with contextlib.suppress(OSError):
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def _dry_run_payload(
    *,
    manifest: ForagerMatrixManifest,
    benchmark: ForagerBenchmarkConfig,
    plan: Sequence[_BatchPlan],
    context: Mapping[str, Any],
    protocol_conformance: Mapping[str, Any],
) -> dict[str, Any]:
    variants = {
        variant_id: {
            **variant.to_dict(),
            "config_sha256": variant.config_sha256,
            "variant_sha256": variant.descriptor_sha256,
        }
        for variant_id, variant in sorted(manifest.variants.items())
    }
    return _hashed_payload(
        {
            "schema_version": FORAGER_MATRIX_SCHEMA_VERSION,
            "artifact_type": "alberta_forager_matrix_dry_run",
            "dry_run": True,
            "matrix_config": manifest.to_dict(),
            "matrix_config_sha256": manifest.config_sha256,
            "benchmark_config": _benchmark_spec(benchmark),
            "benchmark_config_sha256": _json_sha256(_benchmark_spec(benchmark)),
            "execution_identity": context["execution_identity"],
            "source_snapshot": context["source"]["snapshot"],
            "protocol_conformance": dict(protocol_conformance),
            "variants": variants,
            "batch_plan": [item.to_dict() for item in plan],
            "provenance": dict(context),
        }
    )


def run_forager_matrix(
    manifest: ForagerMatrixManifest | str | Path,
    output_dir: str | Path,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Execute or resume a deterministic Alberta Forager variant matrix.

    Existing artifacts are never replaced.  Completed prefix batches are
    cryptographically and semantically validated, while a gap, unknown file,
    altered hash, or changed execution identity fails closed.
    """
    loaded = (
        load_forager_matrix_manifest(manifest) if isinstance(manifest, (str, Path)) else manifest
    )
    if not isinstance(loaded, ForagerMatrixManifest):
        raise TypeError("manifest must be a ForagerMatrixManifest or JSON path")

    benchmark = _build_benchmark_config(loaded)
    plan = _batch_plan(loaded)
    source_snapshot = _build_source_snapshot()
    context = _execution_context(benchmark, source_snapshot)
    tuning_reference = _validate_tuning_reference(loaded)
    conformance = _protocol_conformance(loaded, tuning_reference)

    if dry_run:
        _assert_source_tree_unchanged(context["execution_identity"])
        return _dry_run_payload(
            manifest=loaded,
            benchmark=benchmark,
            plan=plan,
            context=context,
            protocol_conformance=conformance,
        )

    destination = Path(output_dir).expanduser()
    if destination.exists() and destination.is_symlink():
        raise ForagerMatrixStateError("output directory may not be a symlink")
    destination = destination.resolve(strict=False)

    with _output_lock(destination):
        _validate_output_inventory(destination, plan)
        execution_path = destination / EXECUTION_MANIFEST_FILENAME
        snapshot_path = destination / SOURCE_SNAPSHOT_FILENAME
        if snapshot_path.exists() or snapshot_path.is_symlink():
            _verify_source_snapshot_file(snapshot_path, source_snapshot)
        elif execution_path.exists():
            raise ForagerMatrixStateError(
                "execution manifest exists without its immutable source snapshot"
            )
        else:
            _assert_source_tree_unchanged(context["execution_identity"])
            _atomic_create_bytes(snapshot_path, source_snapshot.archive_bytes)
            _verify_source_snapshot_file(snapshot_path, source_snapshot)
        expected_execution = _execution_manifest_payload(
            loaded,
            benchmark,
            plan,
            context,
            conformance,
        )
        if execution_path.exists():
            execution_manifest = _load_canonical_artifact(
                execution_path,
                description="execution manifest",
            )
            _validate_execution_manifest(execution_manifest, expected_execution)
            _verify_source_snapshot_file(snapshot_path, source_snapshot)
        else:
            _assert_source_tree_unchanged(context["execution_identity"])
            _atomic_create_json(execution_path, expected_execution)
            execution_manifest = expected_execution

        batch_payloads: dict[str, Mapping[str, Any]] = {}
        runs_by_variant: dict[str, list[ForagerRunResult]] = {
            variant_id: [] for variant_id in sorted(loaded.variants)
        }
        missing_seen = False
        for item in plan:
            artifact_path = destination / item.relative_path
            if artifact_path.exists():
                if missing_seen:
                    raise ForagerMatrixStateError(
                        "batch artifacts are not a completed deterministic prefix"
                    )
                batch = _load_canonical_artifact(
                    artifact_path,
                    description=f"batch artifact {item.relative_path}",
                )
                batch_runs = _validate_batch_artifact(
                    batch,
                    manifest=loaded,
                    execution_manifest=execution_manifest,
                    item=item,
                )
                batch_payloads[item.relative_path] = batch
                runs_by_variant[item.variant_id].extend(batch_runs)
            else:
                missing_seen = True

        report_path = destination / FINAL_REPORT_FILENAME
        if report_path.exists() and missing_seen:
            raise ForagerMatrixStateError("final report exists before all planned batches")

        for item in plan:
            if item.relative_path in batch_payloads:
                continue
            _assert_source_tree_unchanged(context["execution_identity"])
            started = time.perf_counter()
            variant = loaded.variants[item.variant_id]
            if variant.kind == "alberta_horde_ac":
                if not isinstance(variant.config, AlbertaForagerConfig):
                    raise ForagerMatrixError(f"variant {item.variant_id!r} kind/config mismatch")
                returned = run_alberta_forager_seeds(
                    variant.config,
                    benchmark,
                    item.seeds,
                    mode=loaded.mode,
                )
            elif variant.kind == CAUSAL_MAP_VARIANT_KIND:
                if not isinstance(variant.config, CausalMapForagerConfig):
                    raise ForagerMatrixError(f"variant {item.variant_id!r} kind/config mismatch")
                returned = run_causal_map_forager_seeds(
                    variant.config,
                    benchmark,
                    item.seeds,
                    mode=loaded.mode,
                )
            else:  # pragma: no cover - parser and frozen descriptor guard this
                raise ForagerMatrixError(
                    f"variant {item.variant_id!r} has unknown kind {variant.kind!r}"
                )
            wall_time_s = time.perf_counter() - started
            if len(returned) != len(item.seeds):
                raise ForagerMatrixError(
                    f"runner returned {len(returned)} results for {len(item.seeds)} seeds"
                )
            config = variant.config.to_dict()
            benchmark_payload = _require_object(
                execution_manifest["benchmark_config"],
                "execution manifest benchmark_config",
            )
            expected_environment = _require_object(
                benchmark_payload.get("result_environment"),
                "execution manifest benchmark_config.result_environment",
            )
            expected_metric_contract = _require_object(
                benchmark_payload.get("metric_contract"),
                "execution manifest benchmark_config.metric_contract",
            )
            checked_runs = tuple(
                _run_from_payload(
                    _run_to_payload(run),
                    path=f"new batch {item.relative_path}.runs[{index}]",
                    expected_seed=seed,
                    expected_steps=loaded.steps,
                    expected_kind=variant.kind,
                    expected_config=config,
                    expected_environment=expected_environment,
                    expected_metric_contract=expected_metric_contract,
                    expected_mode=loaded.mode,
                    expected_batch_seeds=item.seeds,
                )
                for index, (run, seed) in enumerate(zip(returned, item.seeds))
            )
            batch = _batch_payload(
                manifest=loaded,
                execution_manifest=execution_manifest,
                item=item,
                runs=checked_runs,
                wall_time_s=wall_time_s,
            )
            artifact_path = destination / item.relative_path
            _assert_source_tree_unchanged(context["execution_identity"])
            _atomic_create_json(artifact_path, batch)
            batch_payloads[item.relative_path] = batch
            runs_by_variant[item.variant_id].extend(checked_runs)

        _assert_source_tree_unchanged(context["execution_identity"])
        report = _report_payload(
            manifest=loaded,
            execution_manifest=execution_manifest,
            plan=plan,
            batch_payloads=batch_payloads,
            runs_by_variant=runs_by_variant,
        )
        if report_path.exists():
            existing_report = _load_canonical_artifact(
                report_path,
                description="final report",
            )
            _validate_report(
                existing_report,
                manifest=loaded,
                execution_manifest=execution_manifest,
                plan=plan,
                batch_payloads=batch_payloads,
                runs_by_variant=runs_by_variant,
            )
            _assert_source_tree_unchanged(context["execution_identity"])
            return dict(existing_report)
        _assert_source_tree_unchanged(context["execution_identity"])
        _atomic_create_json(report_path, report)
        return report


# Concise aliases for callers that already operate in the Forager matrix module.
load_matrix_manifest = load_forager_matrix_manifest
run_matrix = run_forager_matrix


def _configure_logging() -> None:
    if LOGGER.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    LOGGER.addHandler(handler)
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run or resume a strict Alberta-only Forager variant matrix."
    )
    parser.add_argument("manifest", type=Path, help="Strict JSON matrix manifest")
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="Immutable resumable artifact directory",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and print the canonical plan without creating output",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point; available as ``python -m ...forager_matrix``."""
    _configure_logging()
    args = _parser().parse_args(argv)
    try:
        report = run_forager_matrix(
            args.manifest,
            args.output_dir,
            dry_run=bool(args.dry_run),
        )
    except (ForagerMatrixError, ForagerMatrixManifestError) as exc:
        LOGGER.error(str(exc))
        return 2
    LOGGER.info(
        json.dumps(
            report,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
