"""Run and verify the official continual-Foragax agent implementations.

This module deliberately treats an official result as more than an ``.npz``
file.  A completed run is accompanied by an atomic manifest that binds the
artifact to a clean source checkout, an exact historical config blob, the
official lock file, the supplied Python interpreter, and the effective seed.

The official entry points use incompatible meanings for ``--max_steps``:
``continuing_main.py`` counts environment interactions, while ``rtu_ppo.py``
counts rollout updates.  The public request therefore uses environment steps
and only emits a PPO override when the requested horizon is exactly divisible
by the selected config's rollout length.
"""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import io
import json
import logging
import os
import re
import stat
import subprocess
import sys
import tempfile
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path, PureWindowsPath
from typing import Any, Literal, cast

import numpy as np

OFFICIAL_FORAGAX_REPOSITORY = (
    "https://github.com/steventango/continual-foragax-agents"
)
OFFICIAL_FORAGAX_PAPER_COMMIT = "6c3175729377e634460ed41621fed7de06432cf8"
OFFICIAL_FORAGAX_CAMERA_READY_COMMIT = "20617616b27b7cd85a2acbed52a73ff9fa6eb480"
OFFICIAL_FORAGAX_AUDIT_COMMIT = "9710f60fa30da5badc451ad7ce3ff296d5070830"
OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION = "1.3"
OFFICIAL_FORAGAX_AGENT_ACCESS_SCHEMA_VERSION = "1.0"
OFFICIAL_FORAGAX_OUTPUT_TREE_HASH_SCHEME = "relative-path+type+size+bytes-v2"
_ARCHIVAL_MANIFEST_SCHEMA_VERSIONS = frozenset({"1.1", "1.2"})

_COMMIT_PATTERN = re.compile(r"^[0-9a-f]{40}$")
_PROBE_PREFIX = "ALBERTA_OFFICIAL_FORAGAX_PROBE="
LOGGER = logging.getLogger("alberta.forager.official")


class OfficialForagaxValidationError(ValueError):
    """Raised when provenance or artifact verification fails closed."""


@dataclass(frozen=True)
class OfficialForagaxRunRequest:
    """Inputs for one official seed/index execution.

    ``config_commit`` may differ from ``execution_commit``.  This is useful
    when a corrected current runner executes an unchanged paper config.  The
    path must exist in the claimed config commit.  Execution uses an
    atomically materialized copy of that exact Git blob, so a later checkout
    may safely contain a repurposed config at the same path without obscuring
    which bytes were run.
    """

    repository: Path
    execution_commit: str
    config_path: Path
    interpreter: Path
    output_dir: Path
    index: int
    config_commit: str | None = None
    expected_seed: int | None = None
    max_env_steps: int | None = None
    gpu: bool = False
    expected_repository: str = OFFICIAL_FORAGAX_REPOSITORY

    def __post_init__(self) -> None:
        for name, value in (
            ("repository", self.repository),
            ("config_path", self.config_path),
            ("interpreter", self.interpreter),
            ("output_dir", self.output_dir),
        ):
            if not isinstance(value, Path):
                raise OfficialForagaxValidationError(
                    f"{name} must be a pathlib.Path"
                )
        if not self.config_path.parts:
            raise OfficialForagaxValidationError("config_path must not be empty")
        if not isinstance(self.gpu, bool):
            raise OfficialForagaxValidationError("gpu must be a boolean")
        if not isinstance(self.expected_repository, str):
            raise OfficialForagaxValidationError(
                "expected_repository must be a string"
            )
        if not _COMMIT_PATTERN.fullmatch(self.execution_commit):
            raise OfficialForagaxValidationError(
                "execution_commit must be a full lowercase 40-character Git SHA"
            )
        if self.config_commit is not None and not _COMMIT_PATTERN.fullmatch(
            self.config_commit
        ):
            raise OfficialForagaxValidationError(
                "config_commit must be a full lowercase 40-character Git SHA"
            )
        if (
            isinstance(self.index, bool)
            or not isinstance(self.index, int)
            or self.index < 0
        ):
            raise OfficialForagaxValidationError("index must be a non-negative integer")
        if self.expected_seed is not None and (
            isinstance(self.expected_seed, bool)
            or not isinstance(self.expected_seed, int)
            or self.expected_seed < 0
        ):
            raise OfficialForagaxValidationError(
                "expected_seed must be a non-negative integer"
            )
        if self.max_env_steps is not None and (
            isinstance(self.max_env_steps, bool)
            or not isinstance(self.max_env_steps, int)
            or self.max_env_steps < 1
        ):
            raise OfficialForagaxValidationError("max_env_steps must be positive")
        if (
            _canonical_repository_url(self.expected_repository)
            != OFFICIAL_FORAGAX_REPOSITORY
        ):
            raise OfficialForagaxValidationError(
                "expected_repository must name the official continual-Foragax repository"
            )


@dataclass(frozen=True)
class OfficialForagaxBatchRunRequest:
    """Inputs for one native, vectorized official index-range execution.

    The official entry points accept Python-style half-open slices.  A batch
    request is therefore deliberately restricted to one ordered contiguous
    range so it can be represented by exactly one ``-i START:STOP`` argument
    and one upstream process/JAX compilation.
    """

    repository: Path
    execution_commit: str
    config_path: Path
    interpreter: Path
    output_dir: Path
    indices: tuple[int, ...]
    config_commit: str | None = None
    expected_seeds: tuple[int, ...] | None = None
    max_env_steps: int | None = None
    gpu: bool = False
    expected_repository: str = OFFICIAL_FORAGAX_REPOSITORY

    def __post_init__(self) -> None:
        indices = tuple(self.indices)
        object.__setattr__(self, "indices", indices)
        if len(indices) < 2:
            raise OfficialForagaxValidationError(
                "a batch request must contain at least two indices"
            )
        if any(
            isinstance(index, bool)
            or not isinstance(index, int)
            or index < 0
            for index in indices
        ):
            raise OfficialForagaxValidationError(
                "batch indices must be non-negative integers"
            )
        if len(set(indices)) != len(indices):
            raise OfficialForagaxValidationError("batch indices must be unique")
        expected_indices = tuple(range(indices[0], indices[-1] + 1))
        if indices != expected_indices:
            raise OfficialForagaxValidationError(
                "batch indices must be ordered and contiguous so the official "
                "runner receives one START:STOP expression"
            )
        if self.expected_seeds is not None:
            expected_seeds = tuple(self.expected_seeds)
            object.__setattr__(self, "expected_seeds", expected_seeds)
            if len(expected_seeds) != len(indices):
                raise OfficialForagaxValidationError(
                    "expected_seeds must have one entry per requested index"
                )
            if any(
                isinstance(seed, bool)
                or not isinstance(seed, int)
                or seed < 0
                for seed in expected_seeds
            ):
                raise OfficialForagaxValidationError(
                    "expected_seeds must contain non-negative integers"
                )
            if len(set(expected_seeds)) != len(expected_seeds):
                raise OfficialForagaxValidationError(
                    "expected_seeds must be unique"
                )
        # Reuse the complete scalar validation contract for shared fields.
        OfficialForagaxRunRequest(
            repository=self.repository,
            execution_commit=self.execution_commit,
            config_path=self.config_path,
            config_commit=self.config_commit,
            interpreter=self.interpreter,
            output_dir=self.output_dir,
            index=indices[0],
            expected_seed=(
                None if self.expected_seeds is None else self.expected_seeds[0]
            ),
            max_env_steps=self.max_env_steps,
            gpu=self.gpu,
            expected_repository=self.expected_repository,
        )

    @property
    def index_expression(self) -> str:
        """Return the official CLI's half-open ``START:STOP`` expression."""
        return f"{self.indices[0]}:{self.indices[-1] + 1}"


@dataclass(frozen=True)
class OfficialForagaxRunPlan:
    """Validated, fully resolved command and provenance for one run."""

    request: OfficialForagaxRunRequest
    source: Mapping[str, Any]
    run: Mapping[str, Any]
    claim: Mapping[str, Any]
    command: tuple[str, ...]
    environment_overrides: Mapping[str, str]
    relevant_environment: Mapping[str, str]
    interpreter_sha256: str
    package_freeze: tuple[str, ...]
    package_freeze_sha256: str
    runtime: Mapping[str, Any]
    config_snapshot_bytes: bytes = dataclasses.field(repr=False)
    execution_config_bytes: bytes = dataclasses.field(repr=False)

    @property
    def output_dir(self) -> Path:
        return self.request.output_dir.expanduser().resolve()

    @property
    def manifest_path(self) -> Path:
        return self.output_dir / "manifest.json"

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dry-run description."""
        return {
            "schema_version": OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION,
            "manifest_kind": "official_foragax_single",
            "dry_run": True,
            "claim": dict(self.claim),
            "source": dict(self.source),
            "run": dict(self.run),
            "environment": _manifest_environment(self),
            "execution": {
                "command": _normalized_command(self),
                "command_sha256": _json_sha256(_normalized_command(self)),
                "cwd": "<OUTPUT_DIR>",
                "environment_overrides": dict(self.environment_overrides),
                "relevant_environment": dict(self.relevant_environment),
                "interpreter": "<OFFICIAL_PYTHON>",
                "interpreter_sha256": self.interpreter_sha256,
                "package_freeze_method": "importlib.metadata_with_pep610",
                "package_freeze": list(self.package_freeze),
                "package_inventory": list(_package_inventory(self.package_freeze)),
                "package_inventory_sha256": _text_sha256(
                    _package_inventory(self.package_freeze)
                ),
                "package_freeze_sha256": self.package_freeze_sha256,
                "runtime": dict(self.runtime),
                "runtime_sha256": _json_sha256(self.runtime),
            },
            "output_dir": "<OUTPUT_DIR>",
            "manifest_path": "manifest.json",
        }


@dataclass(frozen=True)
class OfficialForagaxBatchRunPlan:
    """Validated command and provenance for one official native batch."""

    request: OfficialForagaxBatchRunRequest
    source: Mapping[str, Any]
    run: Mapping[str, Any]
    claim: Mapping[str, Any]
    command: tuple[str, ...]
    environment_overrides: Mapping[str, str]
    relevant_environment: Mapping[str, str]
    interpreter_sha256: str
    package_freeze: tuple[str, ...]
    package_freeze_sha256: str
    runtime: Mapping[str, Any]
    config_snapshot_bytes: bytes = dataclasses.field(repr=False)
    execution_config_bytes: bytes = dataclasses.field(repr=False)

    @property
    def output_dir(self) -> Path:
        return self.request.output_dir.expanduser().resolve()

    @property
    def manifest_path(self) -> Path:
        return self.output_dir / "manifest.json"

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dry-run description."""
        return {
            "schema_version": OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION,
            "manifest_kind": "official_foragax_batch",
            "dry_run": True,
            "claim": dict(self.claim),
            "source": dict(self.source),
            "run": dict(self.run),
            "environment": _manifest_environment(self),
            "execution": {
                "command": _normalized_command(self),
                "command_sha256": _json_sha256(_normalized_command(self)),
                "cwd": "<OUTPUT_DIR>",
                "environment_overrides": dict(self.environment_overrides),
                "relevant_environment": dict(self.relevant_environment),
                "interpreter": "<OFFICIAL_PYTHON>",
                "interpreter_sha256": self.interpreter_sha256,
                "package_freeze_method": "importlib.metadata_with_pep610",
                "package_freeze": list(self.package_freeze),
                "package_inventory": list(_package_inventory(self.package_freeze)),
                "package_inventory_sha256": _text_sha256(
                    _package_inventory(self.package_freeze)
                ),
                "package_freeze_sha256": self.package_freeze_sha256,
                "runtime": dict(self.runtime),
                "runtime_sha256": _json_sha256(self.runtime),
            },
            "output_dir": "<OUTPUT_DIR>",
            "manifest_path": "manifest.json",
        }


@dataclass(frozen=True)
class VerifiedOfficialForagaxManifest:
    """A manifest whose source, environment, and result hashes were verified."""

    manifest_path: Path
    artifact_path: Path
    manifest: Mapping[str, Any]


@dataclass(frozen=True)
class OfficialForagaxRun:
    """Completed or hash-verified resumed official run."""

    manifest_path: Path
    artifact_path: Path
    manifest: Mapping[str, Any]
    resumed: bool


@dataclass(frozen=True)
class VerifiedOfficialForagaxBatchManifest:
    """A batch manifest whose complete ordered artifact set was verified."""

    manifest_path: Path
    artifact_paths: tuple[Path, ...]
    manifest: Mapping[str, Any]


@dataclass(frozen=True)
class OfficialForagaxBatchRun:
    """Completed or hash-verified resumed native official batch."""

    manifest_path: Path
    artifact_paths: tuple[Path, ...]
    manifest: Mapping[str, Any]
    resumed: bool


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_relative_path(value: str, *, label: str) -> Path:
    """Return one normalized POSIX-relative path or fail closed."""
    if not value or "\x00" in value:
        raise OfficialForagaxValidationError(
            f"official {label} must be a non-empty relative path"
        )
    relative = Path(value)
    windows_relative = PureWindowsPath(value)
    if (
        relative.is_absolute()
        or windows_relative.is_absolute()
        or bool(windows_relative.drive)
        or ".." in windows_relative.parts
        or "\\" in value
        or ".." in relative.parts
        or relative.as_posix() != value
        or relative == Path(".")
    ):
        raise OfficialForagaxValidationError(
            f"official {label} must be a canonical path inside its run directory"
        )
    return relative


def _stat_object_identity(metadata: os.stat_result) -> tuple[int, int, int]:
    return (
        int(metadata.st_dev),
        int(metadata.st_ino),
        stat.S_IFMT(metadata.st_mode),
    )


def _stat_file_identity(metadata: os.stat_result) -> tuple[int, ...]:
    return (
        *_stat_object_identity(metadata),
        int(metadata.st_size),
        int(metadata.st_mtime_ns),
        int(metadata.st_ctime_ns),
    )


def _directory_open_flags() -> int:
    return (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_DIRECTORY", 0)
        | getattr(os, "O_NOFOLLOW", 0)
    )


def _file_open_flags() -> int:
    return os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)


def _open_directory_path_nofollow(path: Path, *, label: str) -> tuple[int, os.stat_result]:
    absolute = _absolute_without_resolving_symlinks(path)
    anchor = Path(absolute.anchor)
    descriptor: int | None = None
    try:
        descriptor = os.open(anchor, _directory_open_flags())
        opened = os.fstat(descriptor)
        for position, part in enumerate(absolute.parts[1:], start=1):
            child_descriptor, child_metadata = _open_directory_at_nofollow(
                descriptor,
                part,
                label=(
                    f"{label} ancestor "
                    f"{Path(*absolute.parts[: position + 1])}"
                ),
            )
            os.close(descriptor)
            descriptor = child_descriptor
            opened = child_metadata
        result = descriptor
        descriptor = None
        return result, opened
    except OfficialForagaxValidationError:
        raise
    except OSError as exc:
        raise OfficialForagaxValidationError(
            f"official {label} cannot be opened safely: {absolute}: {exc}"
        ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _open_directory_at_nofollow(
    parent_descriptor: int,
    name: str,
    *,
    label: str,
) -> tuple[int, os.stat_result]:
    descriptor: int | None = None
    try:
        before = os.stat(name, dir_fd=parent_descriptor, follow_symlinks=False)
        if not stat.S_ISDIR(before.st_mode) or stat.S_ISLNK(before.st_mode):
            raise OfficialForagaxValidationError(
                f"official {label} is not a real directory"
            )
        descriptor = os.open(
            name,
            _directory_open_flags(),
            dir_fd=parent_descriptor,
        )
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISDIR(opened.st_mode)
            or _stat_object_identity(before) != _stat_object_identity(opened)
        ):
            raise OfficialForagaxValidationError(
                f"official {label} changed while it was opened"
            )
        result = descriptor
        descriptor = None
        return result, opened
    except OfficialForagaxValidationError:
        raise
    except OSError as exc:
        raise OfficialForagaxValidationError(
            f"official {label} cannot be traversed safely: {exc}"
        ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _read_regular_at_nofollow(
    parent_descriptor: int,
    name: str,
    *,
    label: str,
    capture_bytes: bool,
) -> tuple[dict[str, Any], bytes | None, os.stat_result]:
    """Hash exactly the regular file opened without following a final symlink."""
    descriptor: int | None = None
    try:
        path_before = os.stat(
            name,
            dir_fd=parent_descriptor,
            follow_symlinks=False,
        )
        if not stat.S_ISREG(path_before.st_mode) or stat.S_ISLNK(path_before.st_mode):
            raise OfficialForagaxValidationError(
                f"official {label} is not a regular file"
            )
        descriptor = os.open(
            name,
            _file_open_flags(),
            dir_fd=parent_descriptor,
        )
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISREG(opened.st_mode)
            or _stat_object_identity(path_before) != _stat_object_identity(opened)
        ):
            raise OfficialForagaxValidationError(
                f"official {label} changed while it was opened"
            )
        digest = hashlib.sha256()
        captured = bytearray() if capture_bytes else None
        byte_count = 0
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            digest.update(block)
            byte_count += len(block)
            if captured is not None:
                captured.extend(block)
        after_read = os.fstat(descriptor)
        path_after = os.stat(
            name,
            dir_fd=parent_descriptor,
            follow_symlinks=False,
        )
        expected_identity = _stat_file_identity(opened)
        if (
            _stat_file_identity(after_read) != expected_identity
            or _stat_file_identity(path_after) != expected_identity
            or byte_count != int(opened.st_size)
        ):
            raise OfficialForagaxValidationError(
                f"official {label} changed while it was hashed"
            )
        return (
            {
                "sha256": digest.hexdigest(),
                "byte_size": byte_count,
            },
            None if captured is None else bytes(captured),
            opened,
        )
    except OfficialForagaxValidationError:
        raise
    except OSError as exc:
        raise OfficialForagaxValidationError(
            f"official {label} cannot be read safely: {exc}"
        ) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _read_bound_regular_file(
    root: Path,
    relative_value: str,
    *,
    label: str,
    capture_bytes: bool = False,
) -> tuple[dict[str, Any], bytes | None]:
    """Read a run-relative file through retained no-follow ancestor descriptors."""
    root = _absolute_without_resolving_symlinks(root)
    relative = _canonical_relative_path(relative_value, label=label)
    root_descriptor, root_identity = _open_directory_path_nofollow(
        root,
        label="output root",
    )
    descriptors = [root_descriptor]
    links: list[tuple[int, str, os.stat_result]] = []
    try:
        parent_descriptor = root_descriptor
        for position, part in enumerate(relative.parts[:-1]):
            child_descriptor, child_identity = _open_directory_at_nofollow(
                parent_descriptor,
                part,
                label=f"{label} ancestor {'/'.join(relative.parts[: position + 1])}",
            )
            links.append((parent_descriptor, part, child_identity))
            descriptors.append(child_descriptor)
            parent_descriptor = child_descriptor
        metadata, contents, file_identity = _read_regular_at_nofollow(
            parent_descriptor,
            relative.name,
            label=label,
            capture_bytes=capture_bytes,
        )
        for ancestor_descriptor, name, expected in reversed(links):
            current = os.stat(
                name,
                dir_fd=ancestor_descriptor,
                follow_symlinks=False,
            )
            if _stat_object_identity(current) != _stat_object_identity(expected):
                raise OfficialForagaxValidationError(
                    f"official {label} ancestor changed while it was read"
                )
        root_after = root.lstat()
        if _stat_object_identity(root_after) != _stat_object_identity(root_identity):
            raise OfficialForagaxValidationError(
                f"official {label} output root changed while it was read"
            )
        final_file = os.stat(
            relative.name,
            dir_fd=parent_descriptor,
            follow_symlinks=False,
        )
        if _stat_file_identity(final_file) != _stat_file_identity(file_identity):
            raise OfficialForagaxValidationError(
                f"official {label} changed after it was read"
            )
        return metadata, contents
    except OfficialForagaxValidationError:
        raise
    except OSError as exc:
        raise OfficialForagaxValidationError(
            f"official {label} cannot be verified safely: {exc}"
        ) from exc
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)


def _harness_sha256() -> str:
    return _sha256(Path(__file__).resolve())


_HARNESS_SHA256_AT_IMPORT = _harness_sha256()


def _absolute_without_resolving_symlinks(path: Path) -> Path:
    return Path(os.path.abspath(os.path.expanduser(os.fspath(path))))


def _text_sha256(lines: Sequence[str]) -> str:
    encoded = ("\n".join(lines) + ("\n" if lines else "")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _canonical_json_sha256(payload: Mapping[str, Any]) -> str:
    unsigned = {key: value for key, value in payload.items() if key != "manifest_sha256"}
    encoded = json.dumps(
        unsigned,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def _json_sha256(payload: Any) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def _normalized_command(
    plan: OfficialForagaxRunPlan | OfficialForagaxBatchRunPlan,
) -> list[str]:
    """Remove host-specific paths while retaining the exact logical command."""
    output_dir = plan.output_dir
    interpreter = _absolute_without_resolving_symlinks(plan.request.interpreter)
    normalized: list[str] = []
    for argument in plan.command:
        if argument == str(interpreter):
            normalized.append("<OFFICIAL_PYTHON>")
            continue
        candidate = Path(argument)
        if candidate.is_absolute():
            try:
                source_relative = candidate.relative_to(plan.request.repository)
            except ValueError:
                pass
            else:
                normalized.append(
                    f"<OFFICIAL_CHECKOUT>/{source_relative.as_posix()}"
                )
                continue
            try:
                relative = candidate.relative_to(output_dir)
            except ValueError:
                normalized.append("<HOST_PATH>")
            else:
                normalized.append(
                    "<OUTPUT_DIR>"
                    if not relative.parts
                    else f"<OUTPUT_DIR>/{relative.as_posix()}"
                )
            continue
        normalized.append(argument)
    return normalized


def _manifest_environment(
    plan: OfficialForagaxRunPlan | OfficialForagaxBatchRunPlan,
) -> dict[str, Any]:
    semantic = plan.run.get("environment")
    implementation = plan.runtime.get("foragax_implementation")
    if not isinstance(semantic, Mapping) or not isinstance(implementation, Mapping):
        raise OfficialForagaxValidationError(
            "official environment provenance is incomplete"
        )
    return {
        "semantic": dict(semantic),
        "implementation": dict(implementation),
    }


def _run_process(
    command: Sequence[str],
    *,
    cwd: Path,
    environment: Mapping[str, str] | None = None,
) -> subprocess.CompletedProcess[bytes]:
    result = subprocess.run(
        tuple(command),
        cwd=cwd,
        env=None if environment is None else dict(environment),
        check=False,
        capture_output=True,
    )
    if result.returncode != 0:
        stderr = result.stderr.decode(errors="replace").strip()
        raise OfficialForagaxValidationError(
            f"command failed ({result.returncode}): {' '.join(command)}"
            + (f"\n{stderr}" if stderr else "")
        )
    return result


def _git_text(repository: Path, *arguments: str) -> str:
    result = _run_process(("git", *arguments), cwd=repository)
    return result.stdout.decode().strip()


def _git_bytes(repository: Path, *arguments: str) -> bytes:
    return _run_process(("git", *arguments), cwd=repository).stdout


def _canonical_repository_url(value: str) -> str:
    url = value.strip().rstrip("/")
    if url.startswith("git@github.com:"):
        url = f"https://github.com/{url.removeprefix('git@github.com:')}"
    elif url.startswith("ssh://git@github.com/"):
        url = f"https://github.com/{url.removeprefix('ssh://git@github.com/')}"
    return url.removesuffix(".git")


def _relative_path_in_repository(repository: Path, candidate: Path) -> tuple[Path, str]:
    path = (
        candidate.expanduser().resolve()
        if candidate.is_absolute()
        else (repository / candidate).resolve()
    )
    try:
        relative = path.relative_to(repository).as_posix()
    except ValueError as exc:
        raise OfficialForagaxValidationError(
            f"config_path must resolve inside the official repository: {path}"
        ) from exc
    return path, relative


def _tracked_tree_sha256(repository: Path, pathspec: str) -> str:
    raw_paths = _git_bytes(repository, "ls-files", "-z", "--", pathspec)
    relative_paths = sorted(
        item.decode()
        for item in raw_paths.split(b"\0")
        if item
    )
    if not relative_paths:
        raise OfficialForagaxValidationError(
            f"official repository has no tracked files under {pathspec!r}"
        )
    digest = hashlib.sha256()
    for relative in relative_paths:
        encoded_path = relative.encode()
        contents = (repository / relative).read_bytes()
        digest.update(len(encoded_path).to_bytes(4, "big"))
        digest.update(encoded_path)
        digest.update(len(contents).to_bytes(8, "big"))
        digest.update(contents)
    return digest.hexdigest()


def _command_environment(*, gpu: bool) -> dict[str, str]:
    inherited = (
        "CUDA_VISIBLE_DEVICES",
        "JAX_ENABLE_X64",
        "LD_LIBRARY_PATH",
        "MKL_NUM_THREADS",
        "NVIDIA_VISIBLE_DEVICES",
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "XLA_FLAGS",
        "XLA_PYTHON_CLIENT_MEM_FRACTION",
        "XLA_PYTHON_CLIENT_PREALLOCATE",
    )
    environment = {
        key: os.environ[key]
        for key in inherited
        if key in os.environ
    }
    environment.update(
        {
            "LANG": "C.UTF-8",
            "LC_ALL": "C.UTF-8",
            "PATH": os.defpath,
            "PYTHONHASHSEED": "0",
            "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUTF8": "1",
            "TZ": "UTC",
        }
    )
    if not gpu:
        environment["JAX_PLATFORM_NAME"] = "cpu"
        environment["JAX_PLATFORMS"] = "cpu"
    return environment


def _environment_overrides(*, gpu: bool) -> dict[str, str]:
    overrides = {
        "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    if not gpu:
        overrides.update(
            JAX_PLATFORM_NAME="cpu",
            JAX_PLATFORMS="cpu",
        )
    return overrides


def _relevant_environment(environment: Mapping[str, str]) -> dict[str, str]:
    path_like_keys = {"LD_LIBRARY_PATH", "PATH", "XLA_FLAGS"}
    return {
        key: (
            f"<REDACTED_PATH_VALUE sha256="
            f"{hashlib.sha256(environment[key].encode()).hexdigest()}>"
            if key in path_like_keys
            else environment[key]
        )
        for key in sorted(environment)
    }


def _sanitized_runtime(runtime: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(runtime)
    result["executable"] = "<OFFICIAL_PYTHON>"
    implementation = result.get("foragax_implementation")
    if isinstance(implementation, Mapping):
        normalized = dict(implementation)
        direct_url = normalized.get("direct_url")
        if isinstance(direct_url, Mapping):
            normalized_url = dict(direct_url)
            url = normalized_url.get("url")
            if isinstance(url, str) and url.startswith("file:"):
                normalized_url["url"] = "<LOCAL_PATH>"
            normalized["direct_url"] = normalized_url
        result["foragax_implementation"] = normalized
    return result


def _package_inventory(package_freeze: Sequence[str]) -> tuple[str, ...]:
    """Retain distributions/versions without persisting host-local URLs."""
    return tuple(sorted(line.split(" ; direct_url=", 1)[0] for line in package_freeze))


def _sanitize_package_freeze_line(line: str) -> str:
    prefix, separator, direct_url_text = line.partition(" ; direct_url=")
    if not separator:
        return line
    try:
        direct_url = json.loads(direct_url_text)
    except json.JSONDecodeError:
        return prefix + " ; direct_url=<REDACTED>"
    if isinstance(direct_url, dict):
        url = direct_url.get("url")
        if isinstance(url, str) and url.startswith("file:"):
            direct_url["url"] = "<LOCAL_PATH>"
    return (
        prefix
        + " ; direct_url="
        + json.dumps(direct_url, sort_keys=True, separators=(",", ":"))
    )


def _extract_probe_payload(stdout: bytes) -> Mapping[str, Any]:
    for line in reversed(stdout.decode(errors="replace").splitlines()):
        if line.startswith(_PROBE_PREFIX):
            payload = json.loads(line.removeprefix(_PROBE_PREFIX))
            if not isinstance(payload, dict):
                break
            return cast(Mapping[str, Any], payload)
    raise OfficialForagaxValidationError("supplied interpreter did not return probe metadata")


def _probe_experiment(
    *,
    repository: Path,
    interpreter: Path,
    config_path: Path,
    index: int,
    environment: Mapping[str, str],
) -> Mapping[str, Any]:
    script = f"""
import hashlib
import importlib
import inspect
import json
import sys
from pathlib import Path

repo = Path({str(repository)!r})
sys.path.insert(0, str(repo / "src"))
from experiment import ExperimentModel as Experiment

config_path = Path({str(config_path)!r})
config_data = json.loads(config_path.read_text(encoding="utf-8"))
agent_name = config_data["agent"]
exp = Experiment.load(config_path)
hypers = exp.get_hypers({index})
stored_seed = int(exp.getRun({index}))
top_level_seed_offset = int(hypers.get("seed_offset", 0))
nested = hypers.get("experiment", {{}})
nested_seed_offset = (
    int(nested["seed_offset"])
    if isinstance(nested, dict) and "seed_offset" in nested
    else 0
)
rollout_steps = hypers.get("rollout_steps")
num_updates = hypers.get("num_updates")
environment = hypers.get("environment", {{}})
if not isinstance(environment, dict):
    raise TypeError("resolved environment hyperparameters must be an object")
ppo_signature = (
    str(agent_name).startswith(("PPO", "RealTimeActorCritic", "ActorCritic"))
    or rollout_steps is not None
)
registry_module_name = (
    "algorithms.PPORegistry" if ppo_signature else "algorithms.registry"
)
registry_module = importlib.import_module(registry_module_name)
agent_class = registry_module.getAgent(agent_name)


def source_identity(value):
    source_path = Path(value).resolve()
    relative = source_path.relative_to(repo).as_posix()
    contents = source_path.read_bytes()
    return {{
        "path": relative,
        "sha256": hashlib.sha256(contents).hexdigest(),
    }}


registry_source = source_identity(inspect.getsourcefile(registry_module))
class_source = source_identity(inspect.getsourcefile(agent_class))
hypers_json = json.dumps(
    hypers,
    allow_nan=False,
    separators=(",", ":"),
    sort_keys=True,
)
payload = {{
    "num_permutations": int(exp.numPermutations()),
    "stored_seed": stored_seed,
    "declared_top_level_seed_offset": top_level_seed_offset,
    "declared_nested_seed_offset": nested_seed_offset,
    "rollout_steps": None if rollout_steps is None else int(rollout_steps),
    "num_updates": None if num_updates is None else int(num_updates),
    "environment": environment,
    "resolved_hyperparameters": hypers,
    "resolved_hyperparameters_sha256": hashlib.sha256(
        hypers_json.encode()
    ).hexdigest(),
    "registry": {{
        "module": registry_module_name,
        "class": f"{{agent_class.__module__}}.{{agent_class.__qualname__}}",
        "registry_source_path": registry_source["path"],
        "registry_source_sha256": registry_source["sha256"],
        "class_source_path": class_source["path"],
        "class_source_sha256": class_source["sha256"],
    }},
}}
sys.stdout.write({_PROBE_PREFIX!r} + json.dumps(payload, sort_keys=True) + "\\n")
"""
    result = _run_process(
        (str(interpreter), "-c", script),
        cwd=repository,
        environment=environment,
    )
    return _extract_probe_payload(result.stdout)


def _probe_runtime(
    *,
    repository: Path,
    interpreter: Path,
    environment: Mapping[str, str],
) -> Mapping[str, Any]:
    script = f"""
import hashlib
import importlib.metadata
import importlib.util
import json
import platform
import sys
from pathlib import Path

import jax
import numpy

distribution_name = "continual-foragax"
distribution = importlib.metadata.distribution(distribution_name)
direct_url_text = distribution.read_text("direct_url.json")
direct_url = None
if direct_url_text:
    try:
        direct_url = json.loads(direct_url_text)
    except json.JSONDecodeError:
        direct_url = {{"unparsed": direct_url_text.strip()}}

spec = importlib.util.find_spec("foragax")
locations = spec.submodule_search_locations if spec is not None else None
if not locations:
    raise RuntimeError("the supplied interpreter cannot locate the foragax package")
files = []
for location in locations:
    root = Path(location).resolve()
    if not root.is_dir():
        continue
    files.extend(
        (f"foragax/{{path.relative_to(root).as_posix()}}", path)
        for path in root.rglob("*")
        if path.is_file()
        and "__pycache__" not in path.parts
        and path.suffix not in {{".pyc", ".pyo"}}
    )
if not files:
    raise RuntimeError("the supplied interpreter has an empty foragax package tree")
tree_digest = hashlib.sha256()
for relative, path in sorted(files):
    encoded_path = relative.encode()
    contents = path.read_bytes()
    tree_digest.update(len(encoded_path).to_bytes(4, "big"))
    tree_digest.update(encoded_path)
    tree_digest.update(len(contents).to_bytes(8, "big"))
    tree_digest.update(contents)

devices = []
for device in jax.devices():
    devices.append({{
        "id": int(getattr(device, "id", -1)),
        "platform": str(getattr(device, "platform", "")),
        "device_kind": str(getattr(device, "device_kind", "")),
        "process_index": int(getattr(device, "process_index", 0)),
    }})
payload = {{
    "python": platform.python_version(),
    "implementation": platform.python_implementation(),
    "platform": platform.platform(),
    "executable": sys.executable,
    "jax": jax.__version__,
    "numpy": numpy.__version__,
    "jax_backend": jax.default_backend(),
    "jax_devices": devices,
    "foragax_implementation": {{
        "distribution": distribution_name,
        "package": "foragax",
        "version": distribution.version,
        "direct_url": direct_url,
        "install_tree_hash_scheme": "relative-path+size+bytes-v1",
        "install_tree_sha256": tree_digest.hexdigest(),
        "verified": True,
    }},
}}
sys.stdout.write({_PROBE_PREFIX!r} + json.dumps(payload, sort_keys=True) + "\\n")
"""
    result = _run_process(
        (str(interpreter), "-c", script),
        cwd=repository,
        environment=environment,
    )
    return _extract_probe_payload(result.stdout)


def _semantic_environment(probe: Mapping[str, Any]) -> dict[str, Any]:
    """Resolve official environment hyperparameters to Alberta's exact schema."""
    raw = probe.get("environment")
    if not isinstance(raw, dict):
        raise OfficialForagaxValidationError(
            "official ExperimentModel returned invalid environment hyperparameters"
        )
    env_id = raw.get("env_id")
    presets = {
        "ForagaxSquareWaveTwoBiome-v11": ("relearning", "color"),
        "ForagaxTwoBiomeLarge-v1": ("field_of_view", "color"),
        "ForagaxBig-v5": ("unending", "rgb"),
    }
    if env_id not in presets:
        raise OfficialForagaxValidationError(
            "official environment cannot be mapped to a benchmark preset: "
            f"{env_id!r}"
        )
    preset, default_observation_type = presets[cast(str, env_id)]
    aperture_size = raw.get("aperture_size", 9)
    observation_type = raw.get("observation_type", default_observation_type)
    reward_delay = raw.get("reward_delay", 0)
    random_shift_max_steps = raw.get("random_shift_max_steps", 0)
    if (
        isinstance(aperture_size, bool)
        or not isinstance(aperture_size, int)
        or (aperture_size != -1 and (aperture_size < 1 or aperture_size % 2 == 0))
    ):
        raise OfficialForagaxValidationError(
            "official environment aperture_size is invalid"
        )
    if observation_type not in {"color", "rgb", "object"}:
        raise OfficialForagaxValidationError(
            "official environment observation_type is invalid"
        )
    for name, value in (
        ("reward_delay", reward_delay),
        ("random_shift_max_steps", random_shift_max_steps),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise OfficialForagaxValidationError(
                f"official environment {name} is invalid"
            )
    consumed = {
        "env_id",
        "aperture_size",
        "observation_type",
        "reward_delay",
        "random_shift_max_steps",
    }
    return {
        "preset": preset,
        "env_id": env_id,
        "aperture_size": aperture_size,
        "observation_type": observation_type,
        "reward_delay": reward_delay,
        "random_shift_max_steps": random_shift_max_steps,
        "extra_kwargs": {
            key: value for key, value in raw.items() if key not in consumed
        },
    }


_LEARNING_REGISTRY_CLASSES = frozenset(
    {
        "algorithms.nn.AADRQN.AADRQN",
        "algorithms.nn.ACConv.ActorCriticConv",
        "algorithms.nn.ACMLP.ActorCriticMLP",
        "algorithms.nn.ATAADRQN.ATAADRQN",
        "algorithms.nn.DQN.DQN",
        "algorithms.nn.DQN_Hare_and_Tortoise.DQN_Hare_and_Tortoise",
        "algorithms.nn.DQN_L2.DQN_L2",
        "algorithms.nn.DQN_L2_Init.DQN_L2_Init",
        "algorithms.nn.DQN_ReDo.DQN_ReDo",
        "algorithms.nn.DQN_Reset.DQN_Reset",
        "algorithms.nn.DQN_Shrink_and_Perturb.DQN_Shrink_and_Perturb",
        "algorithms.nn.DQN_Spectral_Reg.DQN_Spectral_Reg",
        "algorithms.nn.DRQN.DRQN",
        "algorithms.nn.EQRC.EQRC",
        "algorithms.nn.ESMAC.ESMAC",
        "algorithms.nn.MADRQN.MADRQN",
        "algorithms.nn.PT_DQN.PT_DQN",
        "algorithms.nn.RealTimeACConv.RealTimeActorCriticConv",
        "algorithms.nn.RealTimeACConvHint.RealTimeActorCriticConvHint",
        "algorithms.nn.RealTimeACConvHintRTU.RealTimeActorCriticConvHintRTU",
        "algorithms.nn.RealTimeACConvPooling.RealTimeActorCriticConvPooling",
        "algorithms.nn.RealTimeACMLP.RealTimeActorCriticMLP",
        "algorithms.nn.RealTimeACMLPMulti.RealTimeActorCriticMLPMulti",
        "algorithms.tc.ESARSA.ESARSA",
        "algorithms.tc.SoftmaxAC.SoftmaxAC",
    }
)
_SEARCH_REGISTRY_CLASS = "algorithms.SearchAgent.SearchAgent"
_MCTS_REGISTRY_CLASS = "algorithms.MCTSAgent.MCTSAgent"
_RANDOM_REGISTRY_CLASS = "algorithms.RandomAgent.RandomAgent"


def _validated_registry_identity(value: Any) -> dict[str, str]:
    if not isinstance(value, dict) or set(value) != {
        "module",
        "class",
        "registry_source_path",
        "registry_source_sha256",
        "class_source_path",
        "class_source_sha256",
    }:
        raise OfficialForagaxValidationError(
            "official agent registry identity has an unexpected schema"
        )
    result: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(item, str) or not item:
            raise OfficialForagaxValidationError(
                f"official agent registry {key} is invalid"
            )
        result[key] = item
    if result["module"] not in {"algorithms.registry", "algorithms.PPORegistry"}:
        raise OfficialForagaxValidationError(
            "official agent registry module is not recognized"
        )
    for key in ("registry_source_path", "class_source_path"):
        relative = _canonical_relative_path(
            result[key],
            label=f"agent registry {key}",
        )
        if not relative.parts or relative.parts[0] != "src":
            raise OfficialForagaxValidationError(
                f"official agent registry {key} must identify execution source"
            )
    for key in ("registry_source_sha256", "class_source_sha256"):
        if not re.fullmatch(r"[0-9a-f]{64}", result[key]):
            raise OfficialForagaxValidationError(
                f"official agent registry {key} is not a SHA-256"
            )
    return result


def _validated_resolved_hyperparameters(
    probe: Mapping[str, Any],
    *,
    forbidden_host_paths: Sequence[Path] = (),
) -> dict[str, Any]:
    value = probe.get("resolved_hyperparameters")
    if not isinstance(value, dict):
        raise OfficialForagaxValidationError(
            "official ExperimentModel did not return resolved hyperparameters"
        )
    try:
        encoded = json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        normalized = json.loads(encoded)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise OfficialForagaxValidationError(
            "official resolved hyperparameters are not canonical JSON"
        ) from exc
    assert isinstance(normalized, dict)
    expected_hash = probe.get("resolved_hyperparameters_sha256")
    actual_hash = hashlib.sha256(encoded.encode()).hexdigest()
    if expected_hash != actual_hash:
        raise OfficialForagaxValidationError(
            "official resolved hyperparameter hash does not verify"
        )

    forbidden = tuple(
        str(path)
        for path in forbidden_host_paths
        if str(path) and str(path) not in {".", os.sep}
    )

    def validate_strings(item: Any) -> None:
        if isinstance(item, dict):
            for key, nested in item.items():
                if not isinstance(key, str):
                    raise OfficialForagaxValidationError(
                        "official resolved hyperparameter keys must be strings"
                    )
                validate_strings(nested)
        elif isinstance(item, list):
            for nested in item:
                validate_strings(nested)
        elif isinstance(item, str):
            if (
                Path(item).is_absolute()
                or PureWindowsPath(item).is_absolute()
                or any(path in item for path in forbidden)
            ):
                raise OfficialForagaxValidationError(
                    "official resolved hyperparameters contain a host-local path"
                )

    validate_strings(normalized)
    return cast(dict[str, Any], normalized)


def _classify_official_foragax_agent_access(
    *,
    agent: str,
    resolved_hyperparameters: Mapping[str, Any],
    semantic_environment: Mapping[str, Any],
    registry: Mapping[str, str],
) -> dict[str, Any]:
    """Classify scientific identity and information access, failing closed."""
    registry_class = registry["class"]
    if registry_class in _LEARNING_REGISTRY_CLASSES:
        method_family = "learning"
        recognized = True
    elif registry_class == _SEARCH_REGISTRY_CLASS:
        method_family = "search_control"
        recognized = True
    elif registry_class == _MCTS_REGISTRY_CLASS:
        method_family = "planning_control"
        recognized = True
    elif registry_class == _RANDOM_REGISTRY_CLASS:
        method_family = "random_control"
        recognized = True
    else:
        method_family = "unclassified"
        recognized = False

    mode = resolved_hyperparameters.get("mode")
    reward_prioritization = resolved_hyperparameters.get(
        "reward_prioritization",
        False,
    )
    temperature_prioritization = resolved_hyperparameters.get(
        "temperature_prioritization",
        False,
    )
    channel_priorities = resolved_hyperparameters.get("channel_priorities", {})
    access_values_valid = (
        (mode is None or mode in {"aperture", "world"})
        and isinstance(reward_prioritization, bool)
        and isinstance(temperature_prioritization, bool)
        and isinstance(channel_priorities, dict)
        and all(isinstance(key, str) for key in channel_priorities)
        and all(
            isinstance(priority, (int, float)) and not isinstance(priority, bool)
            for priority in channel_priorities.values()
        )
    )
    aperture_size = semantic_environment.get("aperture_size")
    observation_type = semantic_environment.get("observation_type")
    full_world_observation = (
        aperture_size == -1
        or mode == "world"
        or "_world" in agent.casefold()
        or "-world" in agent.casefold()
    )
    explicit_privileged_name = any(
        marker in agent.casefold() for marker in ("privileged", "oracle")
    )
    object_identity_observation = observation_type == "object"
    static_channel_prior = bool(channel_priorities)
    simulator_access = registry_class == _MCTS_REGISTRY_CLASS
    privileged = bool(
        full_world_observation
        or object_identity_observation
        or reward_prioritization is True
        or temperature_prioritization is True
        or static_channel_prior
        or simulator_access
        or explicit_privileged_name
    )
    classification_consistent = not (
        ("_world" in agent.casefold() or "-world" in agent.casefold())
        and aperture_size != -1
        and mode != "world"
    )
    classified = recognized and access_values_valid and classification_consistent
    if not classified:
        role = "unclassified"
    elif method_family == "learning":
        role = "privileged_learning_control" if privileged else "learning_baseline"
    elif method_family == "random_control":
        role = "privileged_control" if privileged else "lower_control"
    else:
        role = "privileged_control" if privileged else "nonlearning_control"
    return {
        "schema_version": OFFICIAL_FORAGAX_AGENT_ACCESS_SCHEMA_VERSION,
        "classification_rule": "official-foragax-agent-access-v1",
        "official_agent": agent,
        "registry_module": registry["module"],
        "registry_class": registry_class,
        "method_family": method_family,
        "role": role,
        "classified": classified,
        "privileged": privileged if classified else None,
        "information_access": {
            "observation_scope": (
                "full_world" if full_world_observation else "aperture"
            ),
            "aperture_size": aperture_size,
            "observation_type": observation_type,
            "search_mode": mode,
            "uses_object_identity_observation": object_identity_observation,
            "uses_reward_grid": reward_prioritization is True,
            "uses_temperature_info": temperature_prioritization is True,
            "uses_static_channel_priorities": static_channel_prior,
            "uses_simulator_state": simulator_access,
            "explicit_privileged_name": explicit_privileged_name,
        },
    }


def _agent_access_binding_sha256(
    *,
    source: Mapping[str, Any],
    resolved_hyperparameters_sha256: str,
    semantic_environment: Mapping[str, Any],
    registry: Mapping[str, str],
    agent_access_sha256: str,
) -> str:
    return _json_sha256(
        {
            "schema_version": OFFICIAL_FORAGAX_AGENT_ACCESS_SCHEMA_VERSION,
            "repository": source.get("repository"),
            "execution_commit": source.get("execution_commit"),
            "source_tree_sha256": source.get("source_tree_sha256"),
            "config_commit": source.get("config_commit"),
            "config_sha256": source.get("config_sha256"),
            "resolved_hyperparameters_sha256": resolved_hyperparameters_sha256,
            "semantic_environment_sha256": _json_sha256(semantic_environment),
            "registry_sha256": _json_sha256(registry),
            "agent_access_sha256": agent_access_sha256,
        }
    )


def _verified_agent_access_sections(
    *,
    source: Mapping[str, Any],
    run: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, str]]:
    raw_resolved = run.get("resolved_hyperparameters")
    if not isinstance(raw_resolved, dict):
        raise OfficialForagaxValidationError(
            "official manifest lacks exact resolved hyperparameters"
        )
    resolved = _validated_resolved_hyperparameters(
        {
            "resolved_hyperparameters": raw_resolved,
            "resolved_hyperparameters_sha256": run.get(
                "resolved_hyperparameters_sha256"
            ),
        }
    )
    resolved_hash = _json_sha256(resolved)
    semantic = run.get("environment")
    if not isinstance(semantic, dict):
        raise OfficialForagaxValidationError(
            "official manifest environment semantics are invalid"
        )
    expected_semantic = _semantic_environment(
        {"environment": resolved.get("environment")}
    )
    if semantic != expected_semantic:
        raise OfficialForagaxValidationError(
            "official manifest environment semantics do not match exact "
            "resolved hyperparameters"
        )
    registry = _validated_registry_identity(run.get("registry"))
    if run.get("registry_sha256") != _json_sha256(registry):
        raise OfficialForagaxValidationError(
            "official manifest agent registry hash does not verify"
        )
    agent = run.get("agent")
    if not isinstance(agent, str) or not agent:
        raise OfficialForagaxValidationError(
            "official manifest agent identity is invalid"
        )
    expected_access = _classify_official_foragax_agent_access(
        agent=agent,
        resolved_hyperparameters=resolved,
        semantic_environment=semantic,
        registry=registry,
    )
    access = run.get("agent_access")
    if access != expected_access:
        raise OfficialForagaxValidationError(
            "official manifest agent-access classification does not verify"
        )
    access_hash = _json_sha256(expected_access)
    if run.get("agent_access_sha256") != access_hash:
        raise OfficialForagaxValidationError(
            "official manifest agent-access hash does not verify"
        )
    binding = _agent_access_binding_sha256(
        source=source,
        resolved_hyperparameters_sha256=resolved_hash,
        semantic_environment=semantic,
        registry=registry,
        agent_access_sha256=access_hash,
    )
    if run.get("agent_access_binding_sha256") != binding:
        raise OfficialForagaxValidationError(
            "official manifest agent-access provenance binding does not verify"
        )
    return (
        resolved,
        expected_access,
        registry,
    )


def _package_freeze(
    *,
    repository: Path,
    interpreter: Path,
    environment: Mapping[str, str],
) -> tuple[str, ...]:
    script = f"""
import json
import sys
from importlib.metadata import distributions

packages = []
for distribution in distributions():
    name = distribution.metadata.get("Name") or "UNKNOWN"
    line = f"{{name}}=={{distribution.version}}"
    direct_url = distribution.read_text("direct_url.json")
    if direct_url:
        try:
            direct_url = json.dumps(
                json.loads(direct_url),
                sort_keys=True,
                separators=(",", ":"),
            )
        except json.JSONDecodeError:
            direct_url = direct_url.strip()
        line += f" ; direct_url={{direct_url}}"
    packages.append(line)
sys.stdout.write(
    {_PROBE_PREFIX!r}
    + json.dumps({{"packages": sorted(set(packages))}}, sort_keys=True)
    + "\\n"
)
"""
    result = _run_process(
        (str(interpreter), "-c", script),
        cwd=repository,
        environment=environment,
    )
    payload = _extract_probe_payload(result.stdout)
    packages = payload.get("packages")
    if not isinstance(packages, list) or not all(
        isinstance(item, str) and item for item in packages
    ):
        raise OfficialForagaxValidationError(
            "supplied interpreter returned an invalid package freeze"
        )
    return tuple(sorted(_sanitize_package_freeze_line(line) for line in packages))


def _claim(
    *,
    execution_commit: str,
    config_commit: str,
) -> dict[str, Any]:
    corrected_commits = {
        OFFICIAL_FORAGAX_CAMERA_READY_COMMIT,
        OFFICIAL_FORAGAX_AUDIT_COMMIT,
    }
    if execution_commit in corrected_commits:
        classification = "corrected_official_reproduction"
    elif execution_commit == OFFICIAL_FORAGAX_PAPER_COMMIT:
        classification = "paper_revision_execution"
    else:
        classification = "pinned_official_commit_reproduction"
    return {
        "classification": classification,
        "execution_commit": execution_commit,
        "config_commit": config_commit,
        "historical_config_snapshot": config_commit != execution_commit,
        "exact_paper_source": execution_commit == OFFICIAL_FORAGAX_PAPER_COMMIT,
        "exact_paper_config": config_commit == OFFICIAL_FORAGAX_PAPER_COMMIT,
        "exact_paper_runnable_attested": False,
        "note": (
            "The manifest proves the exact execution and config blobs. It does "
            "not claim that the paper-tag lock can execute later Foragax "
            "environment IDs; corrected-source executions remain corrected "
            "official reproductions."
        ),
    }


def prepare_official_foragax_run(
    request: OfficialForagaxRunRequest,
) -> OfficialForagaxRunPlan:
    """Validate source/config/environment and construct one exact command."""
    if _harness_sha256() != _HARNESS_SHA256_AT_IMPORT:
        raise OfficialForagaxValidationError(
            "official runner harness changed after this interpreter imported it"
        )
    repository = request.repository.expanduser().resolve()
    if not repository.is_dir():
        raise FileNotFoundError(repository)
    if not (repository / ".git").exists():
        raise OfficialForagaxValidationError(f"{repository} is not a Git checkout")

    actual_commit = _git_text(repository, "rev-parse", "--verify", "HEAD^{commit}")
    if actual_commit != request.execution_commit:
        raise OfficialForagaxValidationError(
            f"checkout HEAD is {actual_commit}; expected {request.execution_commit}"
        )
    status = _git_text(
        repository,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
    )
    if status:
        raise OfficialForagaxValidationError(
            "official checkout must be clean; status contains:\n" + status
        )

    origin = _canonical_repository_url(
        _git_text(repository, "remote", "get-url", "origin")
    )
    expected_repository = _canonical_repository_url(request.expected_repository)
    if origin != expected_repository:
        raise OfficialForagaxValidationError(
            f"origin is {origin!r}; expected official repository {expected_repository!r}"
        )

    checkout_config, config_relative = _relative_path_in_repository(
        repository,
        request.config_path,
    )
    config_commit = request.config_commit or request.execution_commit
    resolved_config_commit = _git_text(
        repository,
        "rev-parse",
        "--verify",
        f"{config_commit}^{{commit}}",
    )
    if resolved_config_commit != config_commit:
        raise OfficialForagaxValidationError(
            f"config_commit resolved to {resolved_config_commit}, expected {config_commit}"
        )
    historical_config = _git_bytes(
        repository,
        "show",
        f"{config_commit}:{config_relative}",
    )
    historical_lock = _git_bytes(repository, "show", f"{config_commit}:uv.lock")
    execution_config = _git_bytes(repository, "show", "HEAD:config.json")

    try:
        config_data = json.loads(historical_config)
    except json.JSONDecodeError as exc:
        raise OfficialForagaxValidationError(f"{config_relative} is not valid JSON") from exc
    if not isinstance(config_data, dict):
        raise OfficialForagaxValidationError("official config must be a JSON object")
    agent = config_data.get("agent")
    problem = config_data.get("problem")
    configured_env_steps = config_data.get("total_steps")
    meta_parameters = config_data.get("metaParameters")
    if not isinstance(agent, str) or not agent.strip():
        raise OfficialForagaxValidationError("official config has no non-empty agent")
    if not isinstance(problem, str) or not problem.strip():
        raise OfficialForagaxValidationError("official config has no non-empty problem")
    if (
        isinstance(configured_env_steps, bool)
        or not isinstance(configured_env_steps, int)
        or configured_env_steps < 1
    ):
        raise OfficialForagaxValidationError(
            "official config total_steps must be a positive integer"
        )
    if not isinstance(meta_parameters, dict):
        raise OfficialForagaxValidationError(
            "official config metaParameters must be an object"
        )

    interpreter = _absolute_without_resolving_symlinks(request.interpreter)
    if not interpreter.is_file() or not os.access(interpreter, os.X_OK):
        raise OfficialForagaxValidationError(
            f"supplied interpreter is not an executable file: {interpreter}"
        )
    environment = _command_environment(gpu=request.gpu)
    with tempfile.TemporaryDirectory(prefix="alberta-foragax-config-probe-") as directory:
        probe_config = Path(directory) / "config.snapshot.json"
        probe_config.write_bytes(historical_config)
        probe = _probe_experiment(
            repository=repository,
            interpreter=interpreter,
            config_path=probe_config,
            index=request.index,
            environment=environment,
        )
    rollout_steps = probe.get("rollout_steps")
    ppo_signature = (
        agent.startswith(("PPO", "RealTimeActorCritic", "ActorCritic"))
        or rollout_steps is not None
    )
    if ppo_signature:
        family: Literal["continuing", "ppo"] = "ppo"
        entrypoint = "src/rtu_ppo.py"
        if (
            isinstance(rollout_steps, bool)
            or not isinstance(rollout_steps, int)
            or rollout_steps < 1
        ):
            raise OfficialForagaxValidationError(
                "PPO/RTU-PPO config must resolve a positive rollout_steps"
            )
        configured_updates = probe.get("num_updates")
        if configured_updates is None:
            configured_updates = configured_env_steps // rollout_steps + 1
        if (
            isinstance(configured_updates, bool)
            or not isinstance(configured_updates, int)
            or configured_updates < 1
        ):
            raise OfficialForagaxValidationError(
                "PPO/RTU-PPO config must resolve a positive update count"
            )
        if request.max_env_steps is None:
            max_steps_argument = None
            expected_result_env_steps = configured_updates * rollout_steps
        else:
            quotient, remainder = divmod(request.max_env_steps, rollout_steps)
            if remainder:
                raise OfficialForagaxValidationError(
                    f"requested {request.max_env_steps} environment steps cannot be "
                    f"represented exactly by PPO rollout_steps={rollout_steps}"
                )
            max_steps_argument = quotient
            expected_result_env_steps = request.max_env_steps
        max_steps_semantics = (
            "rtu_ppo.py --max_steps counts rollout updates; the runner converts "
            "an exactly divisible environment-step horizon"
        )
    else:
        family = "continuing"
        entrypoint = "src/continuing_main.py"
        configured_updates = None
        max_steps_argument = request.max_env_steps
        expected_result_env_steps = request.max_env_steps or configured_env_steps
        max_steps_semantics = "continuing_main.py --max_steps counts environment steps"

    stored_seed = probe.get("stored_seed")
    if isinstance(stored_seed, bool) or not isinstance(stored_seed, int):
        raise OfficialForagaxValidationError(
            "official ExperimentModel returned a non-integer stored seed"
        )
    offset_key = (
        "declared_top_level_seed_offset"
        if family == "ppo"
        else "declared_nested_seed_offset"
    )
    applied_seed_offset = probe.get(offset_key)
    if isinstance(applied_seed_offset, bool) or not isinstance(
        applied_seed_offset, int
    ):
        raise OfficialForagaxValidationError(
            "official ExperimentModel returned a non-integer applied seed offset"
        )
    effective_seed = stored_seed + applied_seed_offset
    if request.expected_seed is not None and effective_seed != request.expected_seed:
        raise OfficialForagaxValidationError(
            f"index {request.index} has effective seed {effective_seed}; "
            f"expected {request.expected_seed}"
        )
    semantic_environment = _semantic_environment(probe)
    resolved_hyperparameters = _validated_resolved_hyperparameters(
        probe,
        forbidden_host_paths=(
            repository,
            interpreter,
            request.output_dir.expanduser().absolute(),
        ),
    )
    registry = _validated_registry_identity(probe.get("registry"))

    entrypoint_path = repository / entrypoint
    if not entrypoint_path.is_file():
        raise FileNotFoundError(entrypoint_path)
    _git_text(repository, "ls-files", "--error-unmatch", "--", entrypoint)
    lock_path = repository / "uv.lock"
    if not lock_path.is_file():
        raise FileNotFoundError(lock_path)
    _git_text(repository, "ls-files", "--error-unmatch", "--", "uv.lock")
    for path_key, hash_key in (
        ("registry_source_path", "registry_source_sha256"),
        ("class_source_path", "class_source_sha256"),
    ):
        registry_path = repository / registry[path_key]
        if not registry_path.is_file() or _sha256(registry_path) != registry[hash_key]:
            raise OfficialForagaxValidationError(
                f"official probed agent {path_key} does not verify"
            )
        _git_text(
            repository,
            "ls-files",
            "--error-unmatch",
            "--",
            registry[path_key],
        )

    output_dir = request.output_dir.expanduser().resolve()
    try:
        output_dir.relative_to(repository)
    except ValueError:
        pass
    else:
        raise OfficialForagaxValidationError(
            "output_dir must be outside the official source checkout so result "
            "files cannot alter or hide its worktree attestation"
        )
    command = [
        str(interpreter),
        str(entrypoint_path),
        "-e",
        "experiment/config.snapshot.json",
        "-i",
        str(request.index),
        "--save_path",
        "official-results",
        "--checkpoint_path",
        "official-checkpoints",
        "--silent",
    ]
    if request.gpu:
        command.append("--gpu")
    if max_steps_argument is not None:
        command.extend(("--max_steps", str(max_steps_argument)))

    freeze = _package_freeze(
        repository=repository,
        interpreter=interpreter,
        environment=environment,
    )
    runtime = _sanitized_runtime(
        _probe_runtime(
            repository=repository,
            interpreter=interpreter,
            environment=environment,
        )
    )
    checkout_config_bytes = (
        checkout_config.read_bytes() if checkout_config.is_file() else None
    )
    source = {
        "repository": expected_repository,
        "origin": origin,
        "execution_commit": request.execution_commit,
        "execution_tree_git_sha1": _git_text(repository, "rev-parse", "HEAD^{tree}"),
        "source_tree_sha256": _tracked_tree_sha256(repository, "src"),
        "config_path": config_relative,
        "config_snapshot_path": "experiment/config.snapshot.json",
        "execution_config_path": "config.json",
        "execution_config_git_blob_sha1": _git_text(
            repository,
            "rev-parse",
            "HEAD:config.json",
        ),
        "execution_config_sha256": hashlib.sha256(execution_config).hexdigest(),
        "config_commit": config_commit,
        "config_git_blob_sha1": _git_text(
            repository,
            "rev-parse",
            f"{config_commit}:{config_relative}",
        ),
        "config_sha256": hashlib.sha256(historical_config).hexdigest(),
        "config_commit_lock_git_blob_sha1": _git_text(
            repository,
            "rev-parse",
            f"{config_commit}:uv.lock",
        ),
        "config_commit_lock_sha256": hashlib.sha256(historical_lock).hexdigest(),
        "checkout_config_present": checkout_config_bytes is not None,
        "checkout_config_sha256": (
            None
            if checkout_config_bytes is None
            else hashlib.sha256(checkout_config_bytes).hexdigest()
        ),
        "checkout_config_matches_snapshot": checkout_config_bytes == historical_config,
        "lock_path": "uv.lock",
        "lock_git_blob_sha1": _git_text(repository, "rev-parse", "HEAD:uv.lock"),
        "lock_sha256": _sha256(lock_path),
        "entrypoint": entrypoint,
        "entrypoint_sha256": _sha256(entrypoint_path),
        "harness_module_path": "alberta_framework/benchmarks/official_foragax.py",
        "harness_module_sha256": _HARNESS_SHA256_AT_IMPORT,
        "worktree_clean": True,
    }
    agent_access = _classify_official_foragax_agent_access(
        agent=agent,
        resolved_hyperparameters=resolved_hyperparameters,
        semantic_environment=semantic_environment,
        registry=registry,
    )
    agent_access_sha256 = _json_sha256(agent_access)
    run = {
        "agent": agent,
        "problem": problem,
        "entrypoint_family": family,
        "index": request.index,
        "num_permutations": probe.get("num_permutations"),
        "stored_seed": stored_seed,
        "applied_seed_offset": applied_seed_offset,
        "declared_top_level_seed_offset": probe.get(
            "declared_top_level_seed_offset"
        ),
        "declared_nested_seed_offset": probe.get("declared_nested_seed_offset"),
        "effective_seed": effective_seed,
        "resolved_hyperparameters": resolved_hyperparameters,
        "resolved_hyperparameters_sha256": _json_sha256(
            resolved_hyperparameters
        ),
        "registry": registry,
        "registry_sha256": _json_sha256(registry),
        "agent_access": agent_access,
        "agent_access_sha256": agent_access_sha256,
        "agent_access_binding_sha256": _agent_access_binding_sha256(
            source=source,
            resolved_hyperparameters_sha256=_json_sha256(
                resolved_hyperparameters
            ),
            semantic_environment=semantic_environment,
            registry=registry,
            agent_access_sha256=agent_access_sha256,
        ),
        "environment": semantic_environment,
        "configured_env_steps": configured_env_steps,
        "requested_max_env_steps": request.max_env_steps,
        "rollout_steps": rollout_steps if family == "ppo" else None,
        "configured_updates": configured_updates,
        "max_steps_argument": max_steps_argument,
        "max_steps_argument_semantics": max_steps_semantics,
        "expected_result_env_steps": expected_result_env_steps,
    }
    return OfficialForagaxRunPlan(
        request=dataclasses.replace(
            request,
            repository=repository,
            config_path=Path(config_relative),
            interpreter=interpreter,
            output_dir=output_dir,
            config_commit=config_commit,
            expected_repository=expected_repository,
        ),
        source=source,
        run=run,
        claim=_claim(
            execution_commit=request.execution_commit,
            config_commit=config_commit,
        ),
        command=tuple(command),
        environment_overrides=_environment_overrides(gpu=request.gpu),
        relevant_environment=_relevant_environment(environment),
        interpreter_sha256=_sha256(interpreter),
        package_freeze=freeze,
        package_freeze_sha256=_text_sha256(freeze),
        runtime=runtime,
        config_snapshot_bytes=historical_config,
        execution_config_bytes=execution_config,
    )


def _batch_run_entry(
    *,
    first_plan: OfficialForagaxRunPlan,
    index: int,
    probe: Mapping[str, Any],
    expected_seed: int | None,
) -> dict[str, Any]:
    """Validate one probed index against the batch's compilation contract."""
    first_run = first_plan.run
    family = cast(Literal["continuing", "ppo"], first_run["entrypoint_family"])
    resolved_hyperparameters = _validated_resolved_hyperparameters(
        probe,
        forbidden_host_paths=(
            first_plan.request.repository,
            first_plan.request.interpreter,
            first_plan.output_dir,
        ),
    )
    registry = _validated_registry_identity(probe.get("registry"))
    compared_probe_values: dict[str, Any] = {
        "resolved_hyperparameters": resolved_hyperparameters,
        "resolved_hyperparameters_sha256": _json_sha256(
            resolved_hyperparameters
        ),
        "registry": registry,
        "registry_sha256": _json_sha256(registry),
        "rollout_steps": probe.get("rollout_steps"),
    }
    for key, actual in compared_probe_values.items():
        expected = first_run.get(key)
        if actual != expected:
            raise OfficialForagaxValidationError(
                f"index {index} changes {key} within a native batch "
                f"({actual!r} != {expected!r})"
            )
    if family == "ppo":
        actual_updates = probe.get("num_updates")
        if actual_updates is None:
            actual_updates = int(first_run["configured_env_steps"]) // int(
                first_run["rollout_steps"]
            ) + 1
        if actual_updates != first_run.get("configured_updates"):
            raise OfficialForagaxValidationError(
                f"index {index} changes configured_updates within a native batch"
            )
    semantic_environment = _semantic_environment(probe)
    if semantic_environment != first_run.get("environment"):
        raise OfficialForagaxValidationError(
            f"index {index} changes environment hyperparameters within a native batch"
        )
    stored_seed = probe.get("stored_seed")
    if isinstance(stored_seed, bool) or not isinstance(stored_seed, int):
        raise OfficialForagaxValidationError(
            f"index {index} resolved a non-integer stored seed"
        )
    offset_key = (
        "declared_top_level_seed_offset"
        if family == "ppo"
        else "declared_nested_seed_offset"
    )
    applied_seed_offset = probe.get(offset_key)
    if isinstance(applied_seed_offset, bool) or not isinstance(
        applied_seed_offset, int
    ):
        raise OfficialForagaxValidationError(
            f"index {index} resolved a non-integer applied seed offset"
        )
    effective_seed = stored_seed + applied_seed_offset
    if expected_seed is not None and effective_seed != expected_seed:
        raise OfficialForagaxValidationError(
            f"index {index} has effective seed {effective_seed}; "
            f"expected {expected_seed}"
        )
    return {
        "index": index,
        "stored_seed": stored_seed,
        "applied_seed_offset": applied_seed_offset,
        "declared_top_level_seed_offset": probe.get(
            "declared_top_level_seed_offset"
        ),
        "declared_nested_seed_offset": probe.get("declared_nested_seed_offset"),
        "effective_seed": effective_seed,
        "resolved_hyperparameters_sha256": compared_probe_values[
            "resolved_hyperparameters_sha256"
        ],
        "registry_sha256": first_run["registry_sha256"],
        "agent_access_sha256": first_run["agent_access_sha256"],
        "agent_access_binding_sha256": first_run[
            "agent_access_binding_sha256"
        ],
        "expected_result_env_steps": first_run["expected_result_env_steps"],
    }


def prepare_official_foragax_batch_run(
    request: OfficialForagaxBatchRunRequest,
) -> OfficialForagaxBatchRunPlan:
    """Validate every index/seed and construct one official range command."""
    expected_seeds = request.expected_seeds
    first_request = OfficialForagaxRunRequest(
        repository=request.repository,
        execution_commit=request.execution_commit,
        config_path=request.config_path,
        config_commit=request.config_commit,
        interpreter=request.interpreter,
        output_dir=request.output_dir,
        index=request.indices[0],
        expected_seed=None if expected_seeds is None else expected_seeds[0],
        max_env_steps=request.max_env_steps,
        gpu=request.gpu,
        expected_repository=request.expected_repository,
    )
    first_plan = prepare_official_foragax_run(first_request)
    run_entries = [
        {
            key: first_plan.run[key]
            for key in (
                "index",
                "stored_seed",
                "applied_seed_offset",
                "declared_top_level_seed_offset",
                "declared_nested_seed_offset",
                "effective_seed",
                "resolved_hyperparameters_sha256",
                "registry_sha256",
                "agent_access_sha256",
                "agent_access_binding_sha256",
                "expected_result_env_steps",
            )
        }
    ]
    environment = _command_environment(gpu=request.gpu)
    if len(request.indices) > 1:
        with tempfile.TemporaryDirectory(
            prefix="alberta-foragax-batch-config-probe-"
        ) as directory:
            probe_config = Path(directory) / "config.snapshot.json"
            probe_config.write_bytes(first_plan.config_snapshot_bytes)
            for position, index in enumerate(request.indices[1:], start=1):
                probe = _probe_experiment(
                    repository=first_plan.request.repository,
                    interpreter=first_plan.request.interpreter,
                    config_path=probe_config,
                    index=index,
                    environment=environment,
                )
                run_entries.append(
                    _batch_run_entry(
                        first_plan=first_plan,
                        index=index,
                        probe=probe,
                        expected_seed=(
                            None
                            if expected_seeds is None
                            else expected_seeds[position]
                        ),
                    )
                )
    stored_seeds = tuple(int(item["stored_seed"]) for item in run_entries)
    effective_seeds = tuple(int(item["effective_seed"]) for item in run_entries)
    if len(set(stored_seeds)) != len(stored_seeds):
        raise OfficialForagaxValidationError(
            "official batch resolved duplicate stored seeds"
        )
    if len(set(effective_seeds)) != len(effective_seeds):
        raise OfficialForagaxValidationError(
            "official batch resolved duplicate effective seeds"
        )

    command = list(first_plan.command)
    index_argument = command.index("-i") + 1
    command[index_argument] = request.index_expression
    normalized_request = OfficialForagaxBatchRunRequest(
        repository=first_plan.request.repository,
        execution_commit=first_plan.request.execution_commit,
        config_path=first_plan.request.config_path,
        config_commit=first_plan.request.config_commit,
        interpreter=first_plan.request.interpreter,
        output_dir=first_plan.output_dir,
        indices=request.indices,
        expected_seeds=expected_seeds,
        max_env_steps=request.max_env_steps,
        gpu=request.gpu,
        expected_repository=first_plan.request.expected_repository,
    )
    static_run = {
        key: value
        for key, value in first_plan.run.items()
        if key
        not in {
            "index",
            "stored_seed",
            "applied_seed_offset",
            "declared_top_level_seed_offset",
            "declared_nested_seed_offset",
            "effective_seed",
        }
    }
    run = {
        **static_run,
        "index_expression": request.index_expression,
        "index_expression_semantics": (
            "official parse_indices expands Python's half-open "
            "range(START, STOP); 0:30 means indices 0 through 29"
        ),
        "indices": list(request.indices),
        "stored_seeds": list(stored_seeds),
        "effective_seeds": list(effective_seeds),
        "count": len(request.indices),
        "native_single_process_batch": True,
        "runs": run_entries,
    }
    return OfficialForagaxBatchRunPlan(
        request=normalized_request,
        source=first_plan.source,
        run=run,
        claim=first_plan.claim,
        command=tuple(command),
        environment_overrides=first_plan.environment_overrides,
        relevant_environment=first_plan.relevant_environment,
        interpreter_sha256=first_plan.interpreter_sha256,
        package_freeze=first_plan.package_freeze,
        package_freeze_sha256=first_plan.package_freeze_sha256,
        runtime=first_plan.runtime,
        config_snapshot_bytes=first_plan.config_snapshot_bytes,
        execution_config_bytes=first_plan.execution_config_bytes,
    )


def _fsync_directory(path: Path) -> None:
    descriptor, _metadata = _open_directory_path_nofollow(
        path,
        label="fsync directory",
    )
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _unlink_and_fsync(path: Path, *, missing_ok: bool = False) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        if not missing_ok:
            raise
        return
    _fsync_directory(path.parent)


def _atomic_write_bytes(path: Path, contents: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(contents)
            handle.flush()
            os.fsync(handle.fileno())
        temporary_path.replace(path)
        _fsync_directory(path.parent)
    finally:
        _unlink_and_fsync(temporary_path, missing_ok=True)


def _atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    encoded = (
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode()
    _atomic_write_bytes(path, encoded)


def _inspect_log(root: Path, relative_path: str) -> dict[str, Any]:
    metadata, _ = _read_bound_regular_file(
        root,
        relative_path,
        label="log",
    )
    return {
        "path": relative_path,
        **metadata,
    }


def _scan_bound_output_tree(
    root: Path,
    *,
    allow_running_lock: bool,
) -> list[dict[str, Any]]:
    """Inspect every output entry except the self-hashed manifest and live lock.

    Traversal retains no-follow directory descriptors, hashes regular files
    through no-follow file descriptors, and verifies every directory entry
    before and after it is visited.
    """
    root = _absolute_without_resolving_symlinks(root)
    entries: list[dict[str, Any]] = []
    root_descriptor, root_identity = _open_directory_path_nofollow(
        root,
        label="output root",
    )

    def scan_directory(descriptor: int, prefix: tuple[str, ...]) -> None:
        try:
            before = os.fstat(descriptor)
            names_before = sorted(os.listdir(descriptor))
        except OSError as exc:
            raise OfficialForagaxValidationError(
                f"official output tree cannot be enumerated safely: {exc}"
            ) from exc
        for name in names_before:
            relative_parts = (*prefix, name)
            relative = "/".join(relative_parts)
            if relative == "manifest.json":
                metadata = os.stat(
                    name,
                    dir_fd=descriptor,
                    follow_symlinks=False,
                )
                if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(
                    metadata.st_mode
                ):
                    raise OfficialForagaxValidationError(
                        "official manifest.json is not a regular file"
                    )
                continue
            if relative == ".running":
                lock_metadata = os.stat(
                    name,
                    dir_fd=descriptor,
                    follow_symlinks=False,
                )
                if (
                    allow_running_lock
                    and stat.S_ISREG(lock_metadata.st_mode)
                    and not stat.S_ISLNK(lock_metadata.st_mode)
                    and lock_metadata.st_size == 0
                ):
                    running_file_metadata, _contents, _identity = (
                        _read_regular_at_nofollow(
                            descriptor,
                            name,
                            label="running lock",
                            capture_bytes=False,
                        )
                    )
                    if running_file_metadata["byte_size"] == 0:
                        continue
                raise OfficialForagaxValidationError(
                    "official output tree contains a stale running lock"
                )
            if name.endswith((".partial", ".tmp")):
                raise OfficialForagaxValidationError(
                    f"official output tree contains a construction leftover: {relative}"
                )
            metadata = os.stat(
                name,
                dir_fd=descriptor,
                follow_symlinks=False,
            )
            if stat.S_ISLNK(metadata.st_mode):
                raise OfficialForagaxValidationError(
                    f"official output tree contains a symlink: {relative}"
                )
            if stat.S_ISDIR(metadata.st_mode):
                child_descriptor, child_identity = _open_directory_at_nofollow(
                    descriptor,
                    name,
                    label=f"output directory {relative}",
                )
                entries.append({"path": relative, "type": "directory"})
                try:
                    scan_directory(child_descriptor, relative_parts)
                finally:
                    os.close(child_descriptor)
                current = os.stat(
                    name,
                    dir_fd=descriptor,
                    follow_symlinks=False,
                )
                if _stat_object_identity(current) != _stat_object_identity(
                    child_identity
                ):
                    raise OfficialForagaxValidationError(
                        f"official output directory changed during scan: {relative}"
                    )
                continue
            if not stat.S_ISREG(metadata.st_mode):
                raise OfficialForagaxValidationError(
                    f"official output tree contains a non-regular file: {relative}"
                )
            file_metadata, _contents, _identity = _read_regular_at_nofollow(
                descriptor,
                name,
                label=f"output file {relative}",
                capture_bytes=False,
            )
            entries.append(
                {"path": relative, "type": "file", **file_metadata}
            )
        try:
            names_after = sorted(os.listdir(descriptor))
            after = os.fstat(descriptor)
        except OSError as exc:
            raise OfficialForagaxValidationError(
                f"official output tree changed during enumeration: {exc}"
            ) from exc
        if names_after != names_before or _stat_object_identity(
            after
        ) != _stat_object_identity(before):
            raise OfficialForagaxValidationError(
                "official output directory entries changed during scan"
            )

    try:
        scan_directory(root_descriptor, ())
        root_after = root.lstat()
        if _stat_object_identity(root_after) != _stat_object_identity(root_identity):
            raise OfficialForagaxValidationError(
                "official output root changed during scan"
            )
    finally:
        os.close(root_descriptor)
    return sorted(
        entries,
        key=lambda item: (cast(str, item["path"]), cast(str, item["type"])),
    )


def _output_tree_sections(
    root: Path,
    *,
    primary_paths: Sequence[str],
    allow_running_lock: bool,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    for primary_path in primary_paths:
        _canonical_relative_path(primary_path, label="primary output path")
    if len(set(primary_paths)) != len(primary_paths):
        raise OfficialForagaxValidationError(
            "official output manifest contains duplicate primary file paths"
        )
    scanned = _scan_bound_output_tree(
        root,
        allow_running_lock=allow_running_lock,
    )
    scanned_files = [
        item for item in scanned if item.get("type") == "file"
    ]
    scanned_file_paths = {
        cast(str, item["path"]) for item in scanned_files
    }
    missing = sorted(set(primary_paths) - scanned_file_paths)
    if missing:
        raise OfficialForagaxValidationError(
            f"official output tree is missing primary files: {missing}"
        )
    primary = set(primary_paths)
    auxiliary = [
        item
        for item in scanned_files
        if cast(str, item["path"]) not in primary
    ]
    directories = [
        item for item in scanned if item.get("type") == "directory"
    ]
    output_tree = {
        "hash_scheme": OFFICIAL_FORAGAX_OUTPUT_TREE_HASH_SCHEME,
        "entry_count": len(scanned),
        "file_count": len(scanned_files),
        "directory_count": len(directories),
        "sha256": _json_sha256(scanned),
    }
    return auxiliary, directories, output_tree


def _verify_output_tree_sections(
    root: Path,
    *,
    primary_paths: Sequence[str],
    manifest: Mapping[str, Any],
    allow_running_lock: bool,
) -> None:
    auxiliary, directories, output_tree = _output_tree_sections(
        root,
        primary_paths=primary_paths,
        allow_running_lock=allow_running_lock,
    )
    if manifest.get("auxiliary_files") != auxiliary:
        raise OfficialForagaxValidationError(
            "official auxiliary file set, metadata, or hash does not verify"
        )
    if manifest.get("output_directories") != directories:
        raise OfficialForagaxValidationError(
            "official output directory set or type does not verify"
        )
    if manifest.get("output_tree") != output_tree:
        raise OfficialForagaxValidationError(
            "official complete output-tree digest does not verify"
        )


def _publish_sanitized_log(
    partial_path: Path,
    destination: Path,
    plan: OfficialForagaxRunPlan | OfficialForagaxBatchRunPlan,
) -> None:
    """Publish a byte-faithful log except for host-local path placeholders."""
    relative_partial = partial_path.relative_to(plan.output_dir).as_posix()
    _metadata, contents = _read_bound_regular_file(
        plan.output_dir,
        relative_partial,
        label="partial execution log",
        capture_bytes=True,
    )
    assert contents is not None
    interpreter = _absolute_without_resolving_symlinks(plan.request.interpreter)
    replacements = {
        str(plan.output_dir).encode(): b"<OUTPUT_DIR>",
        str(plan.request.repository).encode(): b"<OFFICIAL_CHECKOUT>",
        str(interpreter).encode(): b"<OFFICIAL_PYTHON>",
        str(interpreter.parent.parent).encode(): b"<OFFICIAL_ENV>",
    }
    for original, logical in sorted(
        replacements.items(),
        key=lambda item: len(item[0]),
        reverse=True,
    ):
        if original:
            contents = contents.replace(original, logical)
    _atomic_write_bytes(destination, contents)
    _unlink_and_fsync(partial_path, missing_ok=True)


def _completion_attestation(
    plan: OfficialForagaxRunPlan | OfficialForagaxBatchRunPlan,
) -> dict[str, Any]:
    """Re-probe all mutable execution inputs and fail on any mid-run drift."""
    repository = plan.request.repository
    environment = _command_environment(gpu=plan.request.gpu)
    snapshot_relative = cast(str, plan.source["config_snapshot_path"])
    snapshot_metadata, snapshot_bytes = _read_bound_regular_file(
        plan.output_dir,
        snapshot_relative,
        label="historical config snapshot",
        capture_bytes=True,
    )
    if snapshot_bytes != plan.config_snapshot_bytes:
        raise OfficialForagaxValidationError(
            "official historical config snapshot changed during execution"
    )
    execution_config_relative = cast(str, plan.source["execution_config_path"])
    execution_config_metadata, execution_config_bytes = _read_bound_regular_file(
        plan.output_dir,
        execution_config_relative,
        label="execution config copy",
        capture_bytes=True,
    )
    if execution_config_bytes != plan.execution_config_bytes:
        raise OfficialForagaxValidationError(
            "official execution config changed during execution"
        )
    status = _git_text(
        repository,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
    )
    actual_runtime = _sanitized_runtime(
        _probe_runtime(
            repository=repository,
            interpreter=plan.request.interpreter,
            environment=environment,
        )
    )
    actual_freeze = _package_freeze(
        repository=repository,
        interpreter=plan.request.interpreter,
        environment=environment,
    )
    config_commit = cast(str, plan.source["config_commit"])
    config_path = cast(str, plan.source["config_path"])
    historical_config = _git_bytes(
        repository,
        "show",
        f"{config_commit}:{config_path}",
    )
    historical_lock = _git_bytes(repository, "show", f"{config_commit}:uv.lock")
    execution_config = _git_bytes(repository, "show", "HEAD:config.json")
    origin = _canonical_repository_url(
        _git_text(repository, "remote", "get-url", "origin")
    )
    entrypoint = cast(str, plan.source["entrypoint"])
    actual = {
        "execution_commit": _git_text(
            repository, "rev-parse", "--verify", "HEAD^{commit}"
        ),
        "execution_tree_git_sha1": _git_text(
            repository, "rev-parse", "HEAD^{tree}"
        ),
        "origin": origin,
        "worktree_clean": not status,
        "source_tree_sha256": _tracked_tree_sha256(repository, "src"),
        "lock_sha256": _sha256(repository / "uv.lock"),
        "entrypoint_sha256": _sha256(repository / entrypoint),
        "config_git_blob_sha1": _git_text(
            repository,
            "rev-parse",
            f"{config_commit}:{config_path}",
        ),
        "config_sha256": hashlib.sha256(historical_config).hexdigest(),
        "config_commit_lock_sha256": hashlib.sha256(historical_lock).hexdigest(),
        "config_snapshot_sha256": snapshot_metadata["sha256"],
        "execution_config_git_blob_sha1": _git_text(
            repository,
            "rev-parse",
            "HEAD:config.json",
        ),
        "execution_config_sha256": hashlib.sha256(execution_config).hexdigest(),
        "execution_config_copy_sha256": execution_config_metadata["sha256"],
        "harness_module_sha256": _harness_sha256(),
        "interpreter_sha256": _sha256(plan.request.interpreter),
        "package_freeze_sha256": _text_sha256(actual_freeze),
        "runtime_sha256": _json_sha256(actual_runtime),
        "execution_environment_sha256": _json_sha256(
            _relevant_environment(environment)
        ),
        "foragax_install_tree_sha256": cast(
            Mapping[str, Any],
            actual_runtime["foragax_implementation"],
        )["install_tree_sha256"],
    }
    expected = {
        "execution_commit": plan.source["execution_commit"],
        "execution_tree_git_sha1": plan.source["execution_tree_git_sha1"],
        "origin": plan.source["origin"],
        "worktree_clean": True,
        "source_tree_sha256": plan.source["source_tree_sha256"],
        "lock_sha256": plan.source["lock_sha256"],
        "entrypoint_sha256": plan.source["entrypoint_sha256"],
        "config_git_blob_sha1": plan.source["config_git_blob_sha1"],
        "config_sha256": plan.source["config_sha256"],
        "config_commit_lock_sha256": plan.source[
            "config_commit_lock_sha256"
        ],
        "config_snapshot_sha256": plan.source["config_sha256"],
        "execution_config_git_blob_sha1": plan.source[
            "execution_config_git_blob_sha1"
        ],
        "execution_config_sha256": plan.source["execution_config_sha256"],
        "execution_config_copy_sha256": plan.source["execution_config_sha256"],
        "harness_module_sha256": plan.source["harness_module_sha256"],
        "interpreter_sha256": plan.interpreter_sha256,
        "package_freeze_sha256": plan.package_freeze_sha256,
        "runtime_sha256": _json_sha256(plan.runtime),
        "execution_environment_sha256": _json_sha256(
            plan.relevant_environment
        ),
        "foragax_install_tree_sha256": cast(
            Mapping[str, Any],
            plan.runtime["foragax_implementation"],
        )["install_tree_sha256"],
    }
    mismatches = [
        key for key, expected_value in expected.items()
        if actual.get(key) != expected_value
    ]
    if mismatches:
        detail = ", ".join(
            f"{key}: {actual.get(key)!r} != {expected[key]!r}"
            for key in mismatches
        )
        raise OfficialForagaxValidationError(
            "official source/runtime changed during execution: " + detail
        )
    return actual


def _inspect_npz(
    root: Path,
    relative_path: str,
    *,
    expected_steps: int,
) -> dict[str, Any]:
    metadata, archive_bytes = _read_bound_regular_file(
        root,
        relative_path,
        label="result artifact",
        capture_bytes=True,
    )
    assert archive_bytes is not None
    try:
        with np.load(io.BytesIO(archive_bytes), allow_pickle=False) as archive:
            if "rewards" not in archive:
                raise OfficialForagaxValidationError(
                    f"{relative_path} does not contain a rewards array"
                )
            original_rewards = np.asarray(archive["rewards"])
    except (OSError, ValueError) as exc:
        raise OfficialForagaxValidationError(
            f"{relative_path} is not a valid safe NPZ"
        ) from exc
    rewards = np.squeeze(original_rewards)
    if rewards.ndim != 1 or rewards.size == 0:
        raise OfficialForagaxValidationError(
            f"{relative_path} rewards must be non-empty and one-dimensional after squeeze"
        )
    finite = bool(np.all(np.isfinite(rewards)))
    if not finite:
        raise OfficialForagaxValidationError(
            f"{relative_path} rewards contain non-finite values"
        )
    if int(rewards.size) != expected_steps:
        raise OfficialForagaxValidationError(
            f"{relative_path} contains {rewards.size} rewards; expected {expected_steps}"
        )
    return {
        **metadata,
        "rewards_original_shape": list(original_rewards.shape),
        "rewards_shape_after_squeeze": list(rewards.shape),
        "rewards_dtype": str(rewards.dtype),
        "rewards_length": int(rewards.size),
        "rewards_all_finite": finite,
    }


def _find_result(plan: OfficialForagaxRunPlan) -> Path:
    index = cast(int, plan.run["index"])
    candidates = [
        plan.output_dir / cast(str, item["path"])
        for item in _scan_bound_output_tree(
            plan.output_dir,
            allow_running_lock=True,
        )
        if item.get("type") == "file"
        and Path(cast(str, item["path"])).name == f"{index}.npz"
        and Path(cast(str, item["path"])).parent.name == "data"
    ]
    if len(candidates) != 1:
        raise OfficialForagaxValidationError(
            f"expected exactly one official data/{index}.npz under "
            f"{plan.output_dir / 'official-results'}, "
            f"found {len(candidates)}"
        )
    return candidates[0]


def _find_batch_results(plan: OfficialForagaxBatchRunPlan) -> tuple[Path, ...]:
    """Return the exact requested artifact set, rejecting extras/duplicates."""
    candidates = [
        plan.output_dir / cast(str, item["path"])
        for item in _scan_bound_output_tree(
            plan.output_dir,
            allow_running_lock=True,
        )
        if item.get("type") == "file"
        and Path(cast(str, item["path"])).suffix == ".npz"
        and Path(cast(str, item["path"])).parent.name == "data"
    ]
    expected_indices = tuple(plan.request.indices)
    by_index: dict[int, list[Path]] = {}
    invalid_names: list[Path] = []
    for path in candidates:
        try:
            index = int(path.stem)
        except ValueError:
            invalid_names.append(path)
            continue
        if path.name != f"{index}.npz":
            invalid_names.append(path)
            continue
        by_index.setdefault(index, []).append(path)
    missing = [index for index in expected_indices if index not in by_index]
    extra = sorted(index for index in by_index if index not in expected_indices)
    duplicate = sorted(
        index for index, paths in by_index.items() if len(paths) != 1
    )
    if missing or extra or duplicate or invalid_names:
        raise OfficialForagaxValidationError(
            "official batch artifact set mismatch: "
            f"missing={missing}, extra={extra}, duplicate={duplicate}, "
            f"invalid_names={[path.name for path in invalid_names]}"
        )
    return tuple(by_index[index][0] for index in expected_indices)


def _manifest_payload(
    plan: OfficialForagaxRunPlan,
    *,
    artifact_path: Path,
    artifact: Mapping[str, Any],
    completion_attestation: Mapping[str, Any],
    logs: Mapping[str, Any],
    started_at: datetime,
    completed_at: datetime,
    duration_s: float,
) -> dict[str, Any]:
    relative_artifact = artifact_path.relative_to(plan.output_dir).as_posix()
    primary_paths = [
        cast(str, plan.source["config_snapshot_path"]),
        cast(str, plan.source["execution_config_path"]),
        cast(str, cast(Mapping[str, Any], logs["stdout"])["path"]),
        cast(str, cast(Mapping[str, Any], logs["stderr"])["path"]),
        relative_artifact,
    ]
    auxiliary_files, output_directories, output_tree = _output_tree_sections(
        plan.output_dir,
        primary_paths=primary_paths,
        allow_running_lock=True,
    )
    payload: dict[str, Any] = {
        "schema_version": OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION,
        "manifest_kind": "official_foragax_single",
        "status": "completed",
        "claim": dict(plan.claim),
        "source": dict(plan.source),
        "source_at_completion": dict(completion_attestation),
        "run": dict(plan.run),
        "environment": _manifest_environment(plan),
        "execution": {
            "command": _normalized_command(plan),
            "command_sha256": _json_sha256(_normalized_command(plan)),
            "cwd": "<OUTPUT_DIR>",
            "environment_overrides": dict(plan.environment_overrides),
            "relevant_environment": dict(plan.relevant_environment),
            "interpreter": "<OFFICIAL_PYTHON>",
            "interpreter_sha256": plan.interpreter_sha256,
            "interpreter_sha256_at_completion": completion_attestation[
                "interpreter_sha256"
            ],
            "package_freeze_method": "importlib.metadata_with_pep610",
            "package_freeze": list(plan.package_freeze),
            "package_inventory": list(_package_inventory(plan.package_freeze)),
            "package_inventory_sha256": _text_sha256(
                _package_inventory(plan.package_freeze)
            ),
            "package_freeze_sha256": plan.package_freeze_sha256,
            "package_freeze_sha256_at_completion": completion_attestation[
                "package_freeze_sha256"
            ],
            "runtime": dict(plan.runtime),
            "runtime_sha256": _json_sha256(plan.runtime),
            "runtime_sha256_at_completion": completion_attestation[
                "runtime_sha256"
            ],
            "harness_module_sha256_at_completion": plan.source[
                "harness_module_sha256"
            ],
            "started_at_utc": started_at.isoformat(),
            "completed_at_utc": completed_at.isoformat(),
            "duration_s": duration_s,
            "returncode": 0,
            "logs": dict(logs),
        },
        "artifact": {
            "path": relative_artifact,
            **dict(artifact),
        },
        "auxiliary_files": auxiliary_files,
        "output_directories": output_directories,
        "output_tree": output_tree,
    }
    payload["manifest_sha256"] = _canonical_json_sha256(payload)
    return payload


def _batch_manifest_payload(
    plan: OfficialForagaxBatchRunPlan,
    *,
    artifact_paths: Sequence[Path],
    artifacts: Sequence[Mapping[str, Any]],
    completion_attestation: Mapping[str, Any],
    logs: Mapping[str, Any],
    started_at: datetime,
    completed_at: datetime,
    duration_s: float,
) -> dict[str, Any]:
    run_entries = cast(Sequence[Mapping[str, Any]], plan.run["runs"])
    artifact_entries = [
        {
            "index": int(run_entry["index"]),
            "stored_seed": int(run_entry["stored_seed"]),
            "effective_seed": int(run_entry["effective_seed"]),
            "path": artifact_path.relative_to(plan.output_dir).as_posix(),
            **dict(artifact),
        }
        for run_entry, artifact_path, artifact in zip(
            run_entries,
            artifact_paths,
            artifacts,
            strict=True,
        )
    ]
    artifact_set_identity = [
        {
            "index": entry["index"],
            "stored_seed": entry["stored_seed"],
            "effective_seed": entry["effective_seed"],
            "path": entry["path"],
            "sha256": entry["sha256"],
        }
        for entry in artifact_entries
    ]
    primary_paths = [
        cast(str, plan.source["config_snapshot_path"]),
        cast(str, plan.source["execution_config_path"]),
        cast(str, cast(Mapping[str, Any], logs["stdout"])["path"]),
        cast(str, cast(Mapping[str, Any], logs["stderr"])["path"]),
        *(cast(str, entry["path"]) for entry in artifact_entries),
    ]
    auxiliary_files, output_directories, output_tree = _output_tree_sections(
        plan.output_dir,
        primary_paths=primary_paths,
        allow_running_lock=True,
    )
    payload: dict[str, Any] = {
        "schema_version": OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION,
        "manifest_kind": "official_foragax_batch",
        "status": "completed",
        "claim": dict(plan.claim),
        "source": dict(plan.source),
        "source_at_completion": dict(completion_attestation),
        "run": dict(plan.run),
        "environment": _manifest_environment(plan),
        "execution": {
            "command": _normalized_command(plan),
            "command_sha256": _json_sha256(_normalized_command(plan)),
            "cwd": "<OUTPUT_DIR>",
            "environment_overrides": dict(plan.environment_overrides),
            "relevant_environment": dict(plan.relevant_environment),
            "interpreter": "<OFFICIAL_PYTHON>",
            "interpreter_sha256": plan.interpreter_sha256,
            "interpreter_sha256_at_completion": completion_attestation[
                "interpreter_sha256"
            ],
            "package_freeze_method": "importlib.metadata_with_pep610",
            "package_freeze": list(plan.package_freeze),
            "package_inventory": list(_package_inventory(plan.package_freeze)),
            "package_inventory_sha256": _text_sha256(
                _package_inventory(plan.package_freeze)
            ),
            "package_freeze_sha256": plan.package_freeze_sha256,
            "package_freeze_sha256_at_completion": completion_attestation[
                "package_freeze_sha256"
            ],
            "runtime": dict(plan.runtime),
            "runtime_sha256": _json_sha256(plan.runtime),
            "runtime_sha256_at_completion": completion_attestation[
                "runtime_sha256"
            ],
            "harness_module_sha256_at_completion": completion_attestation[
                "harness_module_sha256"
            ],
            "started_at_utc": started_at.isoformat(),
            "completed_at_utc": completed_at.isoformat(),
            "duration_s": duration_s,
            "returncode": 0,
            "logs": dict(logs),
        },
        "artifacts": artifact_entries,
        "artifact_set": {
            "count": len(artifact_entries),
            "ordered_indices": list(plan.request.indices),
            "ordered_effective_seeds": list(plan.run["effective_seeds"]),
            "sha256": _json_sha256(artifact_set_identity),
        },
        "auxiliary_files": auxiliary_files,
        "output_directories": output_directories,
        "output_tree": output_tree,
    }
    payload["manifest_sha256"] = _canonical_json_sha256(payload)
    return payload


def _load_manifest(path: Path) -> dict[str, Any]:
    try:
        _metadata, contents = _read_bound_regular_file(
            path.parent,
            path.name,
            label="manifest",
            capture_bytes=True,
        )
        assert contents is not None
        payload = json.loads(contents.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise OfficialForagaxValidationError(f"{path} is not a valid manifest") from exc
    if not isinstance(payload, dict):
        raise OfficialForagaxValidationError("official manifest must be a JSON object")
    return cast(dict[str, Any], payload)


def _manifest_relative_file(
    root: Path,
    value: Any,
    *,
    label: str,
) -> Path:
    if not isinstance(value, str):
        raise OfficialForagaxValidationError(f"official manifest {label} is invalid")
    relative = _canonical_relative_path(value, label=f"manifest {label}")
    return root / relative


def _required_mapping(
    parent: Mapping[str, Any],
    key: str,
    *,
    label: str = "manifest",
) -> Mapping[str, Any]:
    value = parent.get(key)
    if not isinstance(value, dict):
        raise OfficialForagaxValidationError(
            f"official {label} {key} is invalid"
        )
    return value


def _verify_config_snapshot_run_identity(
    snapshot_bytes: bytes,
    *,
    run: Mapping[str, Any],
) -> None:
    try:
        config = json.loads(snapshot_bytes)
    except json.JSONDecodeError as exc:
        raise OfficialForagaxValidationError(
            "official historical config snapshot is not valid JSON"
        ) from exc
    if not isinstance(config, dict):
        raise OfficialForagaxValidationError(
            "official historical config snapshot is not an object"
        )
    expected_pairs = {
        "agent": run.get("agent"),
        "problem": run.get("problem"),
        "total_steps": run.get("configured_env_steps"),
    }
    mismatches = [
        key for key, expected in expected_pairs.items()
        if config.get(key) != expected
    ]
    if mismatches or not isinstance(config.get("metaParameters"), dict):
        raise OfficialForagaxValidationError(
            "official run identity does not match its historical config "
            "snapshot"
        )


def _verify_execution_and_logs(
    *,
    root: Path,
    execution: Mapping[str, Any],
) -> None:
    command = execution.get("command")
    if not isinstance(command, list) or not all(
        isinstance(argument, str) for argument in command
    ):
        raise OfficialForagaxValidationError("official manifest command is invalid")
    if any(Path(argument).is_absolute() for argument in command):
        raise OfficialForagaxValidationError(
            "official manifest command contains a host-absolute path"
        )
    if execution.get("command_sha256") != _json_sha256(command):
        raise OfficialForagaxValidationError(
            "official manifest command hash does not verify"
        )
    if execution.get("cwd") != "<OUTPUT_DIR>":
        raise OfficialForagaxValidationError(
            "official manifest cwd must use the logical output placeholder"
        )
    if execution.get("interpreter") != "<OFFICIAL_PYTHON>":
        raise OfficialForagaxValidationError(
            "official manifest interpreter must use the logical placeholder"
        )
    freeze = execution.get("package_freeze")
    if (
        not isinstance(freeze, list)
        or not freeze
        or not all(isinstance(item, str) and item for item in freeze)
        or freeze != sorted(set(freeze))
    ):
        raise OfficialForagaxValidationError(
            "official manifest package freeze is invalid"
        )
    if execution.get("package_freeze_sha256") != _text_sha256(freeze):
        raise OfficialForagaxValidationError(
            "recorded package freeze hash does not verify"
        )
    inventory = execution.get("package_inventory")
    if (
        not isinstance(inventory, list)
        or inventory != list(_package_inventory(freeze))
        or execution.get("package_inventory_sha256")
        != _text_sha256(cast(list[str], inventory))
    ):
        raise OfficialForagaxValidationError(
            "recorded package inventory does not verify"
        )
    runtime = execution.get("runtime")
    if not isinstance(runtime, dict):
        raise OfficialForagaxValidationError(
            "official manifest runtime is invalid"
        )
    if execution.get("runtime_sha256") != _json_sha256(runtime):
        raise OfficialForagaxValidationError(
            "recorded runtime hash does not verify"
        )
    relevant_environment = execution.get("relevant_environment")
    required_environment_keys = {
        "LANG",
        "LC_ALL",
        "PATH",
        "PYTHONHASHSEED",
        "PYTHONNOUSERSITE",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUTF8",
        "TZ",
    }
    if (
        not isinstance(relevant_environment, dict)
        or not required_environment_keys <= relevant_environment.keys()
        or any(
            not isinstance(key, str) or not isinstance(value, str)
            for key, value in relevant_environment.items()
        )
    ):
        raise OfficialForagaxValidationError(
            "official manifest execution environment is incomplete"
        )
    logs = _required_mapping(execution, "logs", label="manifest execution")
    if set(logs) != {"stdout", "stderr"}:
        raise OfficialForagaxValidationError(
            "official manifest must bind exactly stdout and stderr logs"
        )
    for name in ("stdout", "stderr"):
        metadata = logs.get(name)
        if not isinstance(metadata, dict):
            raise OfficialForagaxValidationError(
                f"official manifest {name} log metadata is invalid"
            )
        _manifest_relative_file(
            root,
            metadata.get("path"),
            label=f"{name} log path",
        )
        expected = _inspect_log(root, cast(str, metadata.get("path")))
        if metadata != expected:
            raise OfficialForagaxValidationError(
                f"official {name} log metadata or hash does not verify"
            )


def verify_official_foragax_manifest(
    manifest_path: Path,
    *,
    expected_plan: OfficialForagaxRunPlan | None = None,
    _allow_running_lock: bool = False,
) -> VerifiedOfficialForagaxManifest:
    """Fail closed unless the manifest, provenance, logs, and NPZ all match."""
    path = _absolute_without_resolving_symlinks(manifest_path)
    if not path.is_file():
        raise FileNotFoundError(path)
    manifest = _load_manifest(path)
    schema_version = manifest.get("schema_version")
    if schema_version in _ARCHIVAL_MANIFEST_SCHEMA_VERSIONS:
        raise OfficialForagaxValidationError(
            f"official manifest schema {schema_version} predates exact "
            "hyperparameter/agent-access and typed output-tree binding; preserve "
            "it as archival evidence and rerun with schema 1.3 before using it "
            "as a fully verified result"
        )
    if schema_version != OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION:
        raise OfficialForagaxValidationError(
            f"unsupported official manifest schema {schema_version!r}"
        )
    if manifest.get("status") != "completed":
        raise OfficialForagaxValidationError("official manifest is not completed")
    if manifest.get("manifest_kind") != "official_foragax_single":
        raise OfficialForagaxValidationError(
            "official manifest is not a single-index result"
        )
    recorded_manifest_hash = manifest.get("manifest_sha256")
    computed_manifest_hash = _canonical_json_sha256(manifest)
    if recorded_manifest_hash != computed_manifest_hash:
        raise OfficialForagaxValidationError("official manifest hash does not verify")

    source = _required_mapping(manifest, "source")
    run = _required_mapping(manifest, "run")
    execution = _required_mapping(manifest, "execution")
    source_at_completion = _required_mapping(manifest, "source_at_completion")
    environment_provenance = _required_mapping(manifest, "environment")
    _verified_agent_access_sections(source=source, run=run)
    if expected_plan is not None:
        expected_static = {
            "claim": dict(expected_plan.claim),
            "source": dict(expected_plan.source),
            "run": dict(expected_plan.run),
            "environment": _manifest_environment(expected_plan),
        }
        for key, expected_value in expected_static.items():
            if manifest.get(key) != expected_value:
                raise OfficialForagaxValidationError(
                    f"official manifest {key} does not match current verified plan"
                )
        actual_completion = _completion_attestation(expected_plan)
        if source_at_completion != actual_completion:
            raise OfficialForagaxValidationError(
                "official completion provenance does not match current verified inputs"
            )

    snapshot_relative = source.get("config_snapshot_path")
    _manifest_relative_file(
        path.parent,
        snapshot_relative,
        label="config snapshot path",
    )
    snapshot_metadata, snapshot_bytes = _read_bound_regular_file(
        path.parent,
        cast(str, snapshot_relative),
        label="historical config snapshot",
        capture_bytes=True,
    )
    if snapshot_metadata["sha256"] != source.get("config_sha256"):
        raise OfficialForagaxValidationError(
            "official historical config snapshot does not verify"
        )
    assert snapshot_bytes is not None
    _verify_config_snapshot_run_identity(snapshot_bytes, run=run)
    if (
        expected_plan is not None
        and snapshot_bytes != expected_plan.config_snapshot_bytes
    ):
        raise OfficialForagaxValidationError(
            "official historical config snapshot bytes do not match the verified plan"
        )
    execution_config_relative = source.get("execution_config_path")
    _manifest_relative_file(
        path.parent,
        execution_config_relative,
        label="execution config path",
    )
    execution_config_metadata, execution_config_bytes = _read_bound_regular_file(
        path.parent,
        cast(str, execution_config_relative),
        label="execution config copy",
        capture_bytes=True,
    )
    if execution_config_metadata["sha256"] != source.get(
        "execution_config_sha256"
    ):
        raise OfficialForagaxValidationError(
            "official execution config copy does not verify"
        )
    if (
        expected_plan is not None
        and execution_config_bytes != expected_plan.execution_config_bytes
    ):
        raise OfficialForagaxValidationError(
            "official execution config bytes do not match the verified plan"
        )
    _verify_execution_and_logs(root=path.parent, execution=execution)
    expected_execution: dict[str, Any] = {
        "command": (
            None
            if expected_plan is None
            else _normalized_command(expected_plan)
        ),
        "environment_overrides": (
            None
            if expected_plan is None
            else dict(expected_plan.environment_overrides)
        ),
        "relevant_environment": (
            None
            if expected_plan is None
            else dict(expected_plan.relevant_environment)
        ),
        "interpreter_sha256": (
            None if expected_plan is None else expected_plan.interpreter_sha256
        ),
        "package_freeze_sha256": (
            None
            if expected_plan is None
            else expected_plan.package_freeze_sha256
        ),
        "runtime": (
            None if expected_plan is None else dict(expected_plan.runtime)
        ),
    }
    if expected_plan is not None:
        for key, execution_expected in expected_execution.items():
            if execution.get(key) != execution_expected:
                raise OfficialForagaxValidationError(
                    f"official manifest execution.{key} does not match verified plan"
                )
    if execution.get("returncode") != 0:
        raise OfficialForagaxValidationError(
            "official manifest does not attest a successful command"
        )
    runtime = cast(Mapping[str, Any], execution["runtime"])
    expected_environment = {
        "semantic": dict(cast(Mapping[str, Any], run.get("environment"))),
        "implementation": dict(
            cast(Mapping[str, Any], runtime.get("foragax_implementation"))
        ),
    }
    if environment_provenance != expected_environment:
        raise OfficialForagaxValidationError(
            "official environment provenance does not match run/runtime metadata"
        )
    implementation = cast(
        Mapping[str, Any], environment_provenance["implementation"]
    )
    if (
        implementation.get("distribution") != "continual-foragax"
        or implementation.get("package") != "foragax"
        or implementation.get("install_tree_hash_scheme")
        != "relative-path+size+bytes-v1"
        or implementation.get("verified") is not True
        or not isinstance(implementation.get("install_tree_sha256"), str)
    ):
        raise OfficialForagaxValidationError(
            "official Foragax implementation provenance is not verified"
        )
    completion_pairs = {
        "execution_commit": source.get("execution_commit"),
        "execution_tree_git_sha1": source.get("execution_tree_git_sha1"),
        "origin": source.get("origin"),
        "worktree_clean": True,
        "source_tree_sha256": source.get("source_tree_sha256"),
        "lock_sha256": source.get("lock_sha256"),
        "entrypoint_sha256": source.get("entrypoint_sha256"),
        "config_git_blob_sha1": source.get("config_git_blob_sha1"),
        "config_sha256": source.get("config_sha256"),
        "config_commit_lock_sha256": source.get(
            "config_commit_lock_sha256"
        ),
        "config_snapshot_sha256": source.get("config_sha256"),
        "execution_config_git_blob_sha1": source.get(
            "execution_config_git_blob_sha1"
        ),
        "execution_config_sha256": source.get("execution_config_sha256"),
        "execution_config_copy_sha256": source.get("execution_config_sha256"),
        "harness_module_sha256": source.get("harness_module_sha256"),
        "interpreter_sha256": execution.get("interpreter_sha256"),
        "package_freeze_sha256": execution.get("package_freeze_sha256"),
        "runtime_sha256": execution.get("runtime_sha256"),
        "execution_environment_sha256": _json_sha256(
            cast(Mapping[str, Any], execution.get("relevant_environment"))
        ),
        "foragax_install_tree_sha256": implementation.get(
            "install_tree_sha256"
        ),
    }
    if source_at_completion != completion_pairs:
        raise OfficialForagaxValidationError(
            "official start/completion source or runtime hashes do not agree"
        )

    artifact = _required_mapping(manifest, "artifact")
    relative_value = artifact.get("path")
    artifact_path = _manifest_relative_file(
        path.parent,
        relative_value,
        label="artifact path",
    )
    expected_steps = run.get("expected_result_env_steps")
    if (
        isinstance(expected_steps, bool)
        or not isinstance(expected_steps, int)
        or expected_steps < 1
    ):
        raise OfficialForagaxValidationError(
            "official manifest expected reward length is invalid"
        )
    inspected = _inspect_npz(
        path.parent,
        cast(str, relative_value),
        expected_steps=expected_steps,
    )
    expected_artifact = {"path": relative_value, **inspected}
    if artifact != expected_artifact:
        raise OfficialForagaxValidationError(
            "official result artifact metadata or hash does not verify"
        )
    logs = cast(Mapping[str, Mapping[str, Any]], execution["logs"])
    _verify_output_tree_sections(
        path.parent,
        primary_paths=[
            cast(str, source["config_snapshot_path"]),
            cast(str, source["execution_config_path"]),
            cast(str, logs["stdout"]["path"]),
            cast(str, logs["stderr"]["path"]),
            cast(str, relative_value),
        ],
        manifest=manifest,
        allow_running_lock=_allow_running_lock,
    )
    if _load_manifest(path) != manifest:
        raise OfficialForagaxValidationError(
            "official manifest changed during verification"
        )
    return VerifiedOfficialForagaxManifest(
        manifest_path=path,
        artifact_path=artifact_path,
        manifest=manifest,
    )


def verify_official_foragax_batch_manifest(
    manifest_path: Path,
    *,
    expected_plan: OfficialForagaxBatchRunPlan | None = None,
    _allow_running_lock: bool = False,
) -> VerifiedOfficialForagaxBatchManifest:
    """Verify a native batch and its exact ordered artifact set."""
    path = _absolute_without_resolving_symlinks(manifest_path)
    if not path.is_file():
        raise FileNotFoundError(path)
    manifest = _load_manifest(path)
    schema_version = manifest.get("schema_version")
    if schema_version in _ARCHIVAL_MANIFEST_SCHEMA_VERSIONS:
        raise OfficialForagaxValidationError(
            f"official manifest schema {schema_version} predates exact "
            "hyperparameter/agent-access and typed output-tree binding; preserve "
            "it as archival evidence and rerun with schema 1.3 before using it "
            "as a fully verified result"
        )
    if schema_version != OFFICIAL_FORAGAX_MANIFEST_SCHEMA_VERSION:
        raise OfficialForagaxValidationError(
            f"unsupported official manifest schema {schema_version!r}"
        )
    if (
        manifest.get("status") != "completed"
        or manifest.get("manifest_kind") != "official_foragax_batch"
    ):
        raise OfficialForagaxValidationError(
            "official manifest is not a completed native batch"
        )
    if manifest.get("manifest_sha256") != _canonical_json_sha256(manifest):
        raise OfficialForagaxValidationError("official manifest hash does not verify")

    source = _required_mapping(manifest, "source")
    run = _required_mapping(manifest, "run")
    execution = _required_mapping(manifest, "execution")
    source_at_completion = _required_mapping(manifest, "source_at_completion")
    environment_provenance = _required_mapping(manifest, "environment")
    _verified_agent_access_sections(source=source, run=run)
    if expected_plan is not None:
        expected_static = {
            "claim": dict(expected_plan.claim),
            "source": dict(expected_plan.source),
            "run": dict(expected_plan.run),
            "environment": _manifest_environment(expected_plan),
        }
        for key, expected_value in expected_static.items():
            if manifest.get(key) != expected_value:
                raise OfficialForagaxValidationError(
                    f"official batch manifest {key} does not match verified plan"
                )
        actual_completion = _completion_attestation(expected_plan)
        if source_at_completion != actual_completion:
            raise OfficialForagaxValidationError(
                "official batch completion provenance does not match current inputs"
            )

    snapshot_relative = source.get("config_snapshot_path")
    _manifest_relative_file(
        path.parent,
        snapshot_relative,
        label="config snapshot path",
    )
    snapshot_metadata, snapshot_bytes = _read_bound_regular_file(
        path.parent,
        cast(str, snapshot_relative),
        label="historical config snapshot",
        capture_bytes=True,
    )
    if snapshot_metadata["sha256"] != source.get("config_sha256"):
        raise OfficialForagaxValidationError(
            "official historical config snapshot does not verify"
        )
    assert snapshot_bytes is not None
    _verify_config_snapshot_run_identity(snapshot_bytes, run=run)
    if (
        expected_plan is not None
        and snapshot_bytes != expected_plan.config_snapshot_bytes
    ):
        raise OfficialForagaxValidationError(
            "official historical config snapshot bytes do not match the batch plan"
        )
    execution_config_relative = source.get("execution_config_path")
    _manifest_relative_file(
        path.parent,
        execution_config_relative,
        label="execution config path",
    )
    execution_config_metadata, execution_config_bytes = _read_bound_regular_file(
        path.parent,
        cast(str, execution_config_relative),
        label="execution config copy",
        capture_bytes=True,
    )
    if execution_config_metadata["sha256"] != source.get(
        "execution_config_sha256"
    ):
        raise OfficialForagaxValidationError(
            "official execution config copy does not verify"
        )
    if (
        expected_plan is not None
        and execution_config_bytes != expected_plan.execution_config_bytes
    ):
        raise OfficialForagaxValidationError(
            "official execution config bytes do not match the batch plan"
        )
    _verify_execution_and_logs(root=path.parent, execution=execution)
    if expected_plan is not None:
        expected_execution: dict[str, Any] = {
            "command": _normalized_command(expected_plan),
            "environment_overrides": dict(expected_plan.environment_overrides),
            "relevant_environment": dict(expected_plan.relevant_environment),
            "interpreter_sha256": expected_plan.interpreter_sha256,
            "package_freeze_sha256": expected_plan.package_freeze_sha256,
            "runtime": dict(expected_plan.runtime),
        }
        for key, execution_expected in expected_execution.items():
            if execution.get(key) != execution_expected:
                raise OfficialForagaxValidationError(
                    f"official batch execution.{key} does not match verified plan"
                )
    if execution.get("returncode") != 0:
        raise OfficialForagaxValidationError(
            "official batch did not complete successfully"
        )
    runtime = _required_mapping(execution, "runtime", label="manifest execution")
    semantic_environment = run.get("environment")
    implementation = runtime.get("foragax_implementation")
    if not isinstance(semantic_environment, dict) or not isinstance(
        implementation, dict
    ):
        raise OfficialForagaxValidationError(
            "official batch environment provenance is invalid"
        )
    if environment_provenance != {
        "semantic": semantic_environment,
        "implementation": implementation,
    }:
        raise OfficialForagaxValidationError(
            "official batch environment provenance does not match runtime"
        )
    if (
        implementation.get("distribution") != "continual-foragax"
        or implementation.get("package") != "foragax"
        or implementation.get("install_tree_hash_scheme")
        != "relative-path+size+bytes-v1"
        or implementation.get("verified") is not True
    ):
        raise OfficialForagaxValidationError(
            "official batch Foragax implementation is not verified"
        )
    completion_pairs = {
        "execution_commit": source.get("execution_commit"),
        "execution_tree_git_sha1": source.get("execution_tree_git_sha1"),
        "origin": source.get("origin"),
        "worktree_clean": True,
        "source_tree_sha256": source.get("source_tree_sha256"),
        "lock_sha256": source.get("lock_sha256"),
        "entrypoint_sha256": source.get("entrypoint_sha256"),
        "config_git_blob_sha1": source.get("config_git_blob_sha1"),
        "config_sha256": source.get("config_sha256"),
        "config_commit_lock_sha256": source.get(
            "config_commit_lock_sha256"
        ),
        "config_snapshot_sha256": source.get("config_sha256"),
        "execution_config_git_blob_sha1": source.get(
            "execution_config_git_blob_sha1"
        ),
        "execution_config_sha256": source.get("execution_config_sha256"),
        "execution_config_copy_sha256": source.get("execution_config_sha256"),
        "harness_module_sha256": source.get("harness_module_sha256"),
        "interpreter_sha256": execution.get("interpreter_sha256"),
        "package_freeze_sha256": execution.get("package_freeze_sha256"),
        "runtime_sha256": execution.get("runtime_sha256"),
        "execution_environment_sha256": _json_sha256(
            cast(Mapping[str, Any], execution.get("relevant_environment"))
        ),
        "foragax_install_tree_sha256": implementation.get(
            "install_tree_sha256"
        ),
    }
    if source_at_completion != completion_pairs:
        raise OfficialForagaxValidationError(
            "official batch start/completion source or runtime hashes disagree"
        )

    indices = run.get("indices")
    effective_seeds = run.get("effective_seeds")
    run_entries = run.get("runs")
    artifacts = manifest.get("artifacts")
    if (
        not isinstance(indices, list)
        or not isinstance(effective_seeds, list)
        or not isinstance(run_entries, list)
        or not isinstance(artifacts, list)
        or not indices
        or len(indices)
        != len(effective_seeds)
        != len(run_entries)
        != len(artifacts)
        or run.get("count") != len(indices)
    ):
        raise OfficialForagaxValidationError(
            "official batch ordered run/artifact metadata is invalid"
        )
    if (
        any(
            isinstance(index, bool) or not isinstance(index, int)
            for index in indices
        )
        or any(
            isinstance(seed, bool) or not isinstance(seed, int)
            for seed in effective_seeds
        )
        or indices != list(range(indices[0], indices[-1] + 1))
        or run.get("index_expression") != f"{indices[0]}:{indices[-1] + 1}"
        or len(set(cast(list[int], effective_seeds))) != len(effective_seeds)
    ):
        raise OfficialForagaxValidationError(
            "official batch range or seed identity is invalid"
        )
    artifact_paths: list[Path] = []
    artifact_set_identity: list[dict[str, Any]] = []
    for position, (index, effective_seed, run_entry, artifact) in enumerate(
        zip(indices, effective_seeds, run_entries, artifacts, strict=True)
    ):
        if (
            isinstance(index, bool)
            or not isinstance(index, int)
            or not isinstance(effective_seed, int)
            or not isinstance(run_entry, dict)
            or not isinstance(artifact, dict)
            or run_entry.get("index") != index
            or run_entry.get("effective_seed") != effective_seed
            or artifact.get("index") != index
            or artifact.get("stored_seed") != run_entry.get("stored_seed")
            or artifact.get("effective_seed") != effective_seed
            or any(
                run_entry.get(key) != run.get(key)
                for key in (
                    "resolved_hyperparameters_sha256",
                    "registry_sha256",
                    "agent_access_sha256",
                    "agent_access_binding_sha256",
                )
            )
        ):
            raise OfficialForagaxValidationError(
                f"official batch entry {position} is inconsistent"
            )
        artifact_path = _manifest_relative_file(
            path.parent,
            artifact.get("path"),
            label=f"artifact {index} path",
        )
        expected_steps = run_entry.get("expected_result_env_steps")
        if (
            isinstance(expected_steps, bool)
            or not isinstance(expected_steps, int)
            or expected_steps < 1
        ):
            raise OfficialForagaxValidationError(
                f"official batch index {index} expected length is invalid"
            )
        inspected = _inspect_npz(
            path.parent,
            cast(str, artifact.get("path")),
            expected_steps=expected_steps,
        )
        identity = {
            "index": index,
            "stored_seed": run_entry["stored_seed"],
            "effective_seed": effective_seed,
            "path": artifact["path"],
            "sha256": inspected["sha256"],
        }
        expected_artifact = {
            "index": index,
            "stored_seed": run_entry["stored_seed"],
            "effective_seed": effective_seed,
            "path": artifact["path"],
            **inspected,
        }
        if artifact != expected_artifact:
            raise OfficialForagaxValidationError(
                f"official batch artifact {index} metadata or hash does not verify"
            )
        artifact_paths.append(artifact_path)
        artifact_set_identity.append(identity)
    all_data_artifacts = {
        path.parent / cast(str, item["path"])
        for item in _scan_bound_output_tree(
            path.parent,
            allow_running_lock=_allow_running_lock,
        )
        if item.get("type") == "file"
        and Path(cast(str, item["path"])).suffix == ".npz"
        and Path(cast(str, item["path"])).parent.name == "data"
    }
    if all_data_artifacts != set(artifact_paths):
        raise OfficialForagaxValidationError(
            "official batch contains missing, extra, or duplicate data artifacts"
        )
    artifact_set = _required_mapping(manifest, "artifact_set")
    expected_set = {
        "count": len(artifact_paths),
        "ordered_indices": indices,
        "ordered_effective_seeds": effective_seeds,
        "sha256": _json_sha256(artifact_set_identity),
    }
    if artifact_set != expected_set:
        raise OfficialForagaxValidationError(
            "official aggregate artifact-set hash does not verify"
        )
    logs = cast(Mapping[str, Mapping[str, Any]], execution["logs"])
    _verify_output_tree_sections(
        path.parent,
        primary_paths=[
            cast(str, source["config_snapshot_path"]),
            cast(str, source["execution_config_path"]),
            cast(str, logs["stdout"]["path"]),
            cast(str, logs["stderr"]["path"]),
            *(str(item["path"]) for item in artifacts),
        ],
        manifest=manifest,
        allow_running_lock=_allow_running_lock,
    )
    if _load_manifest(path) != manifest:
        raise OfficialForagaxValidationError(
            "official batch manifest changed during verification"
        )
    return VerifiedOfficialForagaxBatchManifest(
        manifest_path=path,
        artifact_paths=tuple(artifact_paths),
        manifest=manifest,
    )


def run_official_foragax(
    request: OfficialForagaxRunRequest,
    *,
    dry_run: bool = False,
    resume: bool = False,
) -> OfficialForagaxRunPlan | OfficialForagaxRun:
    """Run one official index, or verify and reuse a completed manifest."""
    if dry_run and resume:
        raise OfficialForagaxValidationError("dry_run and resume are mutually exclusive")
    plan = prepare_official_foragax_run(request)
    if dry_run:
        return plan
    if resume:
        verified = verify_official_foragax_manifest(
            plan.manifest_path,
            expected_plan=plan,
        )
        return OfficialForagaxRun(
            manifest_path=verified.manifest_path,
            artifact_path=verified.artifact_path,
            manifest=verified.manifest,
            resumed=True,
        )

    output_dir = plan.output_dir
    if output_dir.exists() and any(output_dir.iterdir()):
        raise OfficialForagaxValidationError(
            f"output directory is not empty: {output_dir}; use resume only for "
            "a fully verified completed manifest"
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    lock_path = output_dir / ".running"
    try:
        lock_descriptor = os.open(
            lock_path,
            os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            0o600,
        )
    except FileExistsError as exc:
        raise OfficialForagaxValidationError(
            f"another official run may be active in {output_dir}"
        ) from exc
    os.close(lock_descriptor)

    stdout_partial = output_dir / ".stdout.log.partial"
    stderr_partial = output_dir / ".stderr.log.partial"
    started_at = datetime.now(UTC)
    started_clock = time.monotonic()
    try:
        if _harness_sha256() != plan.source["harness_module_sha256"]:
            raise OfficialForagaxValidationError(
                "official runner harness changed after preflight"
            )
        _atomic_write_bytes(
            output_dir / cast(str, plan.source["config_snapshot_path"]),
            plan.config_snapshot_bytes,
        )
        _atomic_write_bytes(
            output_dir / cast(str, plan.source["execution_config_path"]),
            plan.execution_config_bytes,
        )
        environment = _command_environment(gpu=request.gpu)
        if _relevant_environment(environment) != plan.relevant_environment:
            raise OfficialForagaxValidationError(
                "official execution environment changed after preflight"
            )
        with (
            stdout_partial.open("wb") as stdout_handle,
            stderr_partial.open("wb") as stderr_handle,
        ):
            completed = subprocess.run(
                plan.command,
                cwd=plan.output_dir,
                env=environment,
                check=False,
                stdout=stdout_handle,
                stderr=stderr_handle,
            )
            stdout_handle.flush()
            stderr_handle.flush()
            os.fsync(stdout_handle.fileno())
            os.fsync(stderr_handle.fileno())
        _publish_sanitized_log(
            stdout_partial,
            output_dir / "stdout.log",
            plan,
        )
        _publish_sanitized_log(
            stderr_partial,
            output_dir / "stderr.log",
            plan,
        )
        if completed.returncode != 0:
            raise OfficialForagaxValidationError(
                f"official command failed with exit code {completed.returncode}; "
                f"see {output_dir / 'stderr.log'}"
            )
        _completion_attestation(plan)
        artifact_path = _find_result(plan)
        relative_artifact = artifact_path.relative_to(output_dir).as_posix()
        artifact = _inspect_npz(
            output_dir,
            relative_artifact,
            expected_steps=cast(int, plan.run["expected_result_env_steps"]),
        )
        logs = {
            "stdout": _inspect_log(output_dir, "stdout.log"),
            "stderr": _inspect_log(output_dir, "stderr.log"),
        }
        completion_attestation = _completion_attestation(plan)
        completed_at = datetime.now(UTC)
        payload = _manifest_payload(
            plan,
            artifact_path=artifact_path,
            artifact=artifact,
            completion_attestation=completion_attestation,
            logs=logs,
            started_at=started_at,
            completed_at=completed_at,
            duration_s=time.monotonic() - started_clock,
        )
        try:
            _atomic_write_json(plan.manifest_path, payload)
            verified = verify_official_foragax_manifest(
                plan.manifest_path,
                expected_plan=plan,
                _allow_running_lock=True,
            )
        except BaseException:
            # This manifest belongs to the just-started run.  Never leave a
            # completed claim behind if the post-publication verification
            # catches a final source/runtime or filesystem race.
            _unlink_and_fsync(plan.manifest_path, missing_ok=True)
            raise
        return OfficialForagaxRun(
            manifest_path=verified.manifest_path,
            artifact_path=verified.artifact_path,
            manifest=verified.manifest,
            resumed=False,
        )
    finally:
        _unlink_and_fsync(lock_path, missing_ok=True)


def run_official_foragax_batch(
    request: OfficialForagaxBatchRunRequest,
    *,
    dry_run: bool = False,
    resume: bool = False,
) -> OfficialForagaxBatchRunPlan | OfficialForagaxBatchRun:
    """Run one native official range, or verify/reuse its complete manifest."""
    if dry_run and resume:
        raise OfficialForagaxValidationError("dry_run and resume are mutually exclusive")
    plan = prepare_official_foragax_batch_run(request)
    if dry_run:
        return plan
    if resume:
        verified = verify_official_foragax_batch_manifest(
            plan.manifest_path,
            expected_plan=plan,
        )
        return OfficialForagaxBatchRun(
            manifest_path=verified.manifest_path,
            artifact_paths=verified.artifact_paths,
            manifest=verified.manifest,
            resumed=True,
        )

    output_dir = plan.output_dir
    if output_dir.exists() and any(output_dir.iterdir()):
        raise OfficialForagaxValidationError(
            f"output directory is not empty: {output_dir}; use resume only for "
            "a fully verified completed manifest"
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    lock_path = output_dir / ".running"
    try:
        lock_descriptor = os.open(
            lock_path,
            os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            0o600,
        )
    except FileExistsError as exc:
        raise OfficialForagaxValidationError(
            f"another official batch may be active in {output_dir}"
        ) from exc
    os.close(lock_descriptor)

    stdout_partial = output_dir / ".stdout.log.partial"
    stderr_partial = output_dir / ".stderr.log.partial"
    started_at = datetime.now(UTC)
    started_clock = time.monotonic()
    try:
        if _harness_sha256() != plan.source["harness_module_sha256"]:
            raise OfficialForagaxValidationError(
                "official runner harness changed after batch preflight"
            )
        _atomic_write_bytes(
            output_dir / cast(str, plan.source["config_snapshot_path"]),
            plan.config_snapshot_bytes,
        )
        _atomic_write_bytes(
            output_dir / cast(str, plan.source["execution_config_path"]),
            plan.execution_config_bytes,
        )
        environment = _command_environment(gpu=request.gpu)
        if _relevant_environment(environment) != plan.relevant_environment:
            raise OfficialForagaxValidationError(
                "official execution environment changed after batch preflight"
            )
        with (
            stdout_partial.open("wb") as stdout_handle,
            stderr_partial.open("wb") as stderr_handle,
        ):
            completed = subprocess.run(
                plan.command,
                cwd=plan.output_dir,
                env=environment,
                check=False,
                stdout=stdout_handle,
                stderr=stderr_handle,
            )
            stdout_handle.flush()
            stderr_handle.flush()
            os.fsync(stdout_handle.fileno())
            os.fsync(stderr_handle.fileno())
        _publish_sanitized_log(
            stdout_partial,
            output_dir / "stdout.log",
            plan,
        )
        _publish_sanitized_log(
            stderr_partial,
            output_dir / "stderr.log",
            plan,
        )
        if completed.returncode != 0:
            raise OfficialForagaxValidationError(
                f"official batch command failed with exit code {completed.returncode}; "
                f"see {output_dir / 'stderr.log'}"
            )
        _completion_attestation(plan)
        artifact_paths = _find_batch_results(plan)
        run_entries = cast(Sequence[Mapping[str, Any]], plan.run["runs"])
        artifacts = tuple(
            _inspect_npz(
                output_dir,
                artifact_path.relative_to(output_dir).as_posix(),
                expected_steps=int(run_entry["expected_result_env_steps"]),
            )
            for artifact_path, run_entry in zip(
                artifact_paths,
                run_entries,
                strict=True,
            )
        )
        logs = {
            "stdout": _inspect_log(output_dir, "stdout.log"),
            "stderr": _inspect_log(output_dir, "stderr.log"),
        }
        completion_attestation = _completion_attestation(plan)
        completed_at = datetime.now(UTC)
        payload = _batch_manifest_payload(
            plan,
            artifact_paths=artifact_paths,
            artifacts=artifacts,
            completion_attestation=completion_attestation,
            logs=logs,
            started_at=started_at,
            completed_at=completed_at,
            duration_s=time.monotonic() - started_clock,
        )
        try:
            _atomic_write_json(plan.manifest_path, payload)
            verified = verify_official_foragax_batch_manifest(
                plan.manifest_path,
                expected_plan=plan,
                _allow_running_lock=True,
            )
        except BaseException:
            _unlink_and_fsync(plan.manifest_path, missing_ok=True)
            raise
        return OfficialForagaxBatchRun(
            manifest_path=verified.manifest_path,
            artifact_paths=verified.artifact_paths,
            manifest=verified.manifest,
            resumed=False,
        )
    finally:
        _unlink_and_fsync(lock_path, missing_ok=True)


def _forager_environment_from_manifest(
    environment_provenance: Mapping[str, Any],
    supplied_environment: Any | None,
) -> Any:
    if supplied_environment is not None:
        return supplied_environment
    from alberta_framework.benchmarks.forager import ForagerEnvConfig

    semantic = cast(Mapping[str, Any], environment_provenance["semantic"])
    return ForagerEnvConfig(
        preset=cast(Any, semantic["preset"]),
        env_id=str(semantic["env_id"]),
        aperture_size=int(semantic["aperture_size"]),
        observation_type=cast(Any, semantic["observation_type"]),
        reward_delay=int(semantic["reward_delay"]),
        random_shift_max_steps=int(semantic["random_shift_max_steps"]),
        extra_kwargs=cast(Mapping[str, Any], semantic["extra_kwargs"]),
    )


def _official_spec_shared_kwargs(
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    source = cast(Mapping[str, Any], manifest["source"])
    run = cast(Mapping[str, Any], manifest["run"])
    execution = cast(Mapping[str, Any], manifest["execution"])
    package_freeze = execution.get("package_freeze")
    runtime = execution.get("runtime")
    relevant_environment = execution.get("relevant_environment")
    environment_provenance = manifest.get("environment")
    if (
        not isinstance(package_freeze, list)
        or not all(isinstance(item, str) for item in package_freeze)
        or not isinstance(runtime, dict)
        or not isinstance(relevant_environment, dict)
        or not isinstance(environment_provenance, dict)
    ):
        raise OfficialForagaxValidationError(
            "verified manifest lacks importer execution provenance"
        )
    resolved_hyperparameters, agent_access, registry = (
        _verified_agent_access_sections(source=source, run=run)
    )
    if agent_access.get("classified") is not True:
        raise OfficialForagaxValidationError(
            "strict official import refuses an unclassified agent "
            "implementation or information-access contract"
        )
    return {
        "source_repository": str(source["repository"]),
        "source_commit": str(source["execution_commit"]),
        "execution_commit": str(source["execution_commit"]),
        "config_commit": str(source["config_commit"]),
        "config_path": str(source["config_path"]),
        "config_sha256": str(source["config_sha256"]),
        "config_git_blob_sha1": str(source["config_git_blob_sha1"]),
        "config_commit_lock_sha256": str(
            source["config_commit_lock_sha256"]
        ),
        "execution_lock_sha256": str(source["lock_sha256"]),
        "source_tree_sha256": str(source["source_tree_sha256"]),
        "interpreter_sha256": str(execution["interpreter_sha256"]),
        "package_freeze": tuple(cast(list[str], package_freeze)),
        "package_freeze_sha256": str(execution["package_freeze_sha256"]),
        "execution_runtime": runtime,
        "relevant_environment": cast(
            Mapping[str, str], relevant_environment
        ),
        "environment_provenance": environment_provenance,
        "resolved_hyperparameters": resolved_hyperparameters,
        "resolved_hyperparameters_sha256": str(
            run["resolved_hyperparameters_sha256"]
        ),
        "registry": registry,
        "registry_sha256": str(run["registry_sha256"]),
        "agent_access": agent_access,
        "agent_access_sha256": str(run["agent_access_sha256"]),
        "agent_access_binding_sha256": str(
            run["agent_access_binding_sha256"]
        ),
        "manifest_sha256": str(manifest["manifest_sha256"]),
    }


def official_foragax_batch_run_specs_from_manifest(
    manifest_path: Path,
    *,
    environment: Any | None = None,
) -> tuple[Any, ...]:
    """Build ordered, fully attested import specs for every batch artifact."""
    verified = verify_official_foragax_batch_manifest(manifest_path)
    manifest = verified.manifest
    run = cast(Mapping[str, Any], manifest["run"])
    run_entries = cast(Sequence[Mapping[str, Any]], run["runs"])
    artifacts = cast(Sequence[Mapping[str, Any]], manifest["artifacts"])
    environment_provenance = cast(
        Mapping[str, Any], manifest["environment"]
    )
    resolved_environment = _forager_environment_from_manifest(
        environment_provenance,
        environment,
    )
    from alberta_framework.benchmarks.forager_results import (
        _verified_official_foragax_run_spec,
    )

    shared = _official_spec_shared_kwargs(manifest)
    agent_access = cast(Mapping[str, Any], shared["agent_access"])
    privileged = cast(bool, agent_access["privileged"])
    specs: list[Any] = []
    for run_entry, artifact_path, artifact in zip(
        run_entries,
        verified.artifact_paths,
        artifacts,
        strict=True,
    ):
        index = int(run_entry["index"])
        effective_seed = int(run_entry["effective_seed"])
        if index != effective_seed:
            raise OfficialForagaxValidationError(
                "the NPZ importer cannot safely represent an official batch "
                f"entry whose index ({index}) differs from effective seed "
                f"({effective_seed})"
            )
        specs.append(
            _verified_official_foragax_run_spec(
                agent=str(run["agent"]),
                seed=effective_seed,
                path=artifact_path,
                environment=resolved_environment,
                privileged=privileged,
                artifact_relative_path=str(artifact["path"]),
                expected_archive_sha256=str(artifact["sha256"]),
                expected_steps=int(run_entry["expected_result_env_steps"]),
                **shared,
            )
        )
    return tuple(specs)


def official_foragax_run_spec_from_manifest(
    manifest_path: Path,
    *,
    environment: Any | None = None,
) -> Any:
    """Build an import spec only after computing protocol attestation.

    The existing result importer names official archives by seed.  Final
    evaluation configs have ``index == effective_seed``; swept/offset configs
    do not, and are rejected here rather than silently pairing the wrong seed.
    """
    verified = verify_official_foragax_manifest(manifest_path)
    run = cast(Mapping[str, Any], verified.manifest["run"])
    artifact = cast(Mapping[str, Any], verified.manifest["artifact"])
    environment_provenance = cast(
        Mapping[str, Any], verified.manifest["environment"]
    )
    index = int(run["index"])
    effective_seed = int(run["effective_seed"])
    if index != effective_seed:
        raise OfficialForagaxValidationError(
            "the current NPZ importer cannot safely represent an official run "
            f"whose index ({index}) differs from effective seed ({effective_seed})"
        )
    from alberta_framework.benchmarks.forager_results import (
        _verified_official_foragax_run_spec,
    )

    resolved_environment = _forager_environment_from_manifest(
        environment_provenance,
        environment,
    )
    shared = _official_spec_shared_kwargs(verified.manifest)
    agent_access = cast(Mapping[str, Any], shared["agent_access"])
    return _verified_official_foragax_run_spec(
        agent=str(run["agent"]),
        seed=effective_seed,
        path=verified.artifact_path,
        environment=resolved_environment,
        privileged=cast(bool, agent_access["privileged"]),
        artifact_relative_path=str(artifact["path"]),
        expected_archive_sha256=str(artifact["sha256"]),
        expected_steps=int(run["expected_result_env_steps"]),
        **shared,
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run one index or one native half-open index range through the "
            "hash-attested official continual-Foragax agents."
        )
    )
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--execution-commit", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--config-commit")
    parser.add_argument("--interpreter", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    index_group = parser.add_mutually_exclusive_group(required=True)
    index_group.add_argument("--index", type=int)
    index_group.add_argument(
        "--index-range",
        help="native half-open START:STOP range (for example 0:30)",
    )
    parser.add_argument("--expected-seed", type=int)
    parser.add_argument("--expected-seeds", type=int, nargs="+")
    parser.add_argument("--max-env-steps", type=int)
    parser.add_argument("--gpu", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--resume", action="store_true")
    return parser


def _parse_index_range(value: str) -> tuple[int, ...]:
    match = re.fullmatch(r"([0-9]+):([0-9]+)", value)
    if match is None:
        raise OfficialForagaxValidationError(
            "index range must be an explicit non-negative START:STOP slice"
        )
    start, stop = (int(item) for item in match.groups())
    if stop <= start:
        raise OfficialForagaxValidationError(
            "index range STOP must be greater than START"
        )
    return tuple(range(start, stop))


def _configure_logging() -> None:
    if LOGGER.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    LOGGER.addHandler(handler)
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point for ``python -m ...official_foragax``."""
    _configure_logging()
    args = _parser().parse_args(argv)
    if args.index_range is None:
        if args.expected_seeds is not None:
            raise OfficialForagaxValidationError(
                "--expected-seeds is valid only with --index-range"
            )
        request = OfficialForagaxRunRequest(
            repository=args.repository,
            execution_commit=args.execution_commit,
            config_path=args.config,
            config_commit=args.config_commit,
            interpreter=args.interpreter,
            output_dir=args.output_dir,
            index=args.index,
            expected_seed=args.expected_seed,
            max_env_steps=args.max_env_steps,
            gpu=args.gpu,
        )
        result: (
            OfficialForagaxRunPlan
            | OfficialForagaxRun
            | OfficialForagaxBatchRunPlan
            | OfficialForagaxBatchRun
        ) = run_official_foragax(
            request,
            dry_run=args.dry_run,
            resume=args.resume,
        )
    else:
        if args.expected_seed is not None:
            raise OfficialForagaxValidationError(
                "--expected-seed is valid only with --index"
            )
        batch_request = OfficialForagaxBatchRunRequest(
            repository=args.repository,
            execution_commit=args.execution_commit,
            config_path=args.config,
            config_commit=args.config_commit,
            interpreter=args.interpreter,
            output_dir=args.output_dir,
            indices=_parse_index_range(args.index_range),
            expected_seeds=(
                None
                if args.expected_seeds is None
                else tuple(args.expected_seeds)
            ),
            max_env_steps=args.max_env_steps,
            gpu=args.gpu,
        )
        result = run_official_foragax_batch(
            batch_request,
            dry_run=args.dry_run,
            resume=args.resume,
        )
    if isinstance(result, (OfficialForagaxRunPlan, OfficialForagaxBatchRunPlan)):
        payload = result.to_dict()
    else:
        payload = dict(result.manifest)
        payload["resumed"] = result.resumed
    LOGGER.info(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
