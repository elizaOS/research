"""Streaming actor-critic with exact RTRL recurrent trace units.

This module is an Alberta-native, JAX-only implementation of the discrete
stream AC(lambda) construction described by Farr et al.,
`arXiv:2605.24709v2 <https://arxiv.org/abs/2605.24709>`_.  The RTU equations and
ObGD ordering were cross-checked against the Apache-2.0 Memorax implementation
at commit ``94dd21dba5ab6eee4a0281066a5f49643d052174`` (in particular
``networks/sequence_models/rtu.py`` and ``algorithms/stream_ac.py``).  The code
here has no runtime dependency on Memorax, Flax, or Optax.

The recurrent state uses a diagonal complex transition represented by paired
real arrays.  Its compressed RTRL sensitivity is exact: cross-unit recurrent
derivatives are structurally zero, so the retained tensors contain every
non-zero derivative while requiring linear memory in the RTU parameter count.
An explicit reverse/forward chain-rule contraction turns those sensitivities
into gradients of the policy or value head.  The sparse encoder receives the
paper's explicit one-step approximation rather than an inaccurately labelled
history trace.  The RTU input matrices themselves use the dense LeCun-normal
initialization of the audited reference.  These per-step gradients then enter
ordinary streaming eligibility traces; the TD error is applied exactly once,
by the final ObGD update.

This is a research core, not a claim of state-of-the-art performance.  Online
parameter changes make retained RTRL sensitivities stale in the precise sense
discussed by Farr et al.; exactness tests therefore freeze parameters while
unrolling a comparison sequence.
"""

from __future__ import annotations

import dataclasses
import functools
import math
from collections.abc import Callable
from typing import Any, NamedTuple, Self, cast

import jax
import jax.numpy as jnp
import jax.random as jr
from jax import Array
from jax.nn.initializers import lecun_normal

from alberta_framework.core.initializers import sparse_init

_FLOAT32_TINY = float(
    jnp.finfo(jnp.float32).tiny  # type: ignore[no-untyped-call]
)
_MINIMUM_EXP_LOG = math.log(_FLOAT32_TINY)
_MAXIMUM_NU_LOG = math.log(-math.log(_FLOAT32_TINY))
_MAXIMUM_THETA_LOG = math.log(2.0 * math.pi)
_INT32_MAX = 2**31 - 1


class RTUParameters(NamedTuple):
    """Trainable parameters of one diagonal complex RTU layer.

    ``nu_log`` and ``theta_log`` parameterize the radius and phase as
    ``r = exp(-exp(nu_log))`` and ``theta = exp(theta_log)``.  ``b_real`` and
    ``b_imag`` are the real and imaginary input projections.  Their names use
    lower case to follow Python conventions; they are the ``B`` parameters in
    the RTU equations.
    """

    nu_log: Array
    theta_log: Array
    b_real: Array
    b_imag: Array

    @property
    def B_real(self) -> Array:  # noqa: N802 - matches the published equation
        """Alias for the real input matrix using the paper's ``B`` notation."""
        return self.b_real

    @property
    def B_imag(self) -> Array:  # noqa: N802 - matches the published equation
        """Alias for the imaginary input matrix using the paper's notation."""
        return self.b_imag


class RTUState(NamedTuple):
    """Paired real representation of a complex RTU hidden state."""

    real: Array
    imaginary: Array


class RTUSensitivities(NamedTuple):
    """Compressed exact sensitivity ``d RTUState / d RTUParameters``.

    The first axis of every leaf selects real or imaginary hidden state.
    Shapes are ``(2, H)`` for the two diagonal recurrent parameter vectors
    and ``(2, H, F)`` for the two input matrices.
    """

    nu_log: Array
    theta_log: Array
    b_real: Array
    b_imag: Array

    @property
    def B_real(self) -> Array:  # noqa: N802 - matches the published equation
        """Alias for sensitivities of the real ``B`` matrix."""
        return self.b_real

    @property
    def B_imag(self) -> Array:  # noqa: N802 - matches the published equation
        """Alias for sensitivities of the imaginary ``B`` matrix."""
        return self.b_imag


class RTUNetworkParameters(NamedTuple):
    """Sparse feedforward/head and dense-input RTU parameters."""

    encoder_weights: Array
    encoder_bias: Array
    rtu: RTUParameters
    output_weights: Array
    output_bias: Array
    head_weights: Array
    head_bias: Array


class RunningStatistics(NamedTuple):
    """Welford running moments for one scalar or feature vector."""

    sample_count: Array
    mean: Array
    m2: Array


class RewardStatistics(NamedTuple):
    """Running return moments used by canonical stream-AC reward scaling."""

    sample_count: Array
    mean: Array
    m2: Array
    discounted_return: Array


class RecurrentTraceActorCriticState(NamedTuple):
    """Immutable state of :class:`RecurrentTraceActorCriticAgent`.

    Actor and critic recurrence, RTRL sensitivities, and AC(lambda)
    eligibility traces are deliberately separate.  ``last_observation``,
    ``last_action``, ``rng_key``, and ``step_count`` mirror the lifecycle
    fields used by Alberta's existing control cores.
    """

    actor_params: RTUNetworkParameters
    critic_params: RTUNetworkParameters
    actor_rtu_state: RTUState
    critic_rtu_state: RTUState
    actor_sensitivities: RTUSensitivities
    critic_sensitivities: RTUSensitivities
    actor_traces: RTUNetworkParameters
    critic_traces: RTUNetworkParameters
    observation_statistics: RunningStatistics
    reward_statistics: RewardStatistics
    last_normalized_observation: Array
    last_observation: Array
    last_action: Array
    rng_key: Array
    step_count: Array
    started: Array

    def replace(self, **changes: Any) -> Self:
        """Return a state with selected fields replaced, like ``chex.dataclass``."""
        return self._replace(**changes)


class RecurrentTraceActorCriticUpdateResult(NamedTuple):
    """Diagnostics and state returned from one consumed transition."""

    state: RecurrentTraceActorCriticState
    action: Array
    policy: Array
    value: Array
    next_value: Array
    td_error: Array
    entropy: Array
    normalized_reward: Array
    actor_step_size: Array
    critic_step_size: Array
    actor_obgd_scale: Array
    critic_obgd_scale: Array


class ObGDUpdate(NamedTuple):
    """Tree update and scalar diagnostics from observation-bounded GD."""

    updates: Any
    step_size: Array
    scale: Array


@dataclasses.dataclass(frozen=True)
class RecurrentTraceActorCriticConfig:
    """Configuration for an exact-RTRL discrete streaming actor-critic.

    Each independent network has a sparse input block, one RTU layer with
    dense LeCun-normal input matrices, a sparse output block, and a sparse
    linear head.  Parameterless layer normalization precedes LeakyReLU in both
    feedforward blocks.  As in Farr et al., the RTU parameters receive their
    exact full-history RTRL gradient while the encoder receives the explicit
    one-step gradient through the current RTU transition; retaining exact
    history sensitivities for the encoder would defeat the intended
    linear-memory construction.

    ``actor_alpha``/``critic_alpha`` and ``actor_kappa``/``critic_kappa`` are
    independent because actor and critic trace magnitudes generally differ.
    Normalization follows the audited Memorax stream-AC wrappers: the current
    observation updates Welford population moments before it is centered and
    scaled; rewards are divided (without centering) by the running standard
    deviation of the discounted return.  Both are causal because only the
    current and earlier samples enter their statistics.
    """

    n_actions: int
    hidden_size: int = 192
    encoder_width: int = 64
    output_width: int = 64
    gamma: float = 0.99
    actor_lamda: float = 0.8
    critic_lamda: float = 0.8
    actor_alpha: float = 1.0
    critic_alpha: float = 1.0
    actor_kappa: float = 3.0
    critic_kappa: float = 2.0
    entropy_coefficient: float = 0.095
    temperature: float = 1.0
    sparsity: float = 0.9
    r_min: float = 0.0
    r_max: float = 1.0
    max_phase: float = 6.28
    rtu_epsilon: float = 1e-8
    layer_norm_epsilon: float = 1e-5
    leaky_relu_slope: float = 0.01
    normalize_observations: bool = True
    normalize_rewards: bool = True
    normalization_epsilon: float = 1e-8

    def __post_init__(self) -> None:
        """Validate shape and numerical invariants eagerly."""
        for integer_name, integer_value in (
            ("n_actions", self.n_actions),
            ("hidden_size", self.hidden_size),
            ("encoder_width", self.encoder_width),
            ("output_width", self.output_width),
        ):
            if (
                isinstance(integer_value, bool)
                or not isinstance(integer_value, int)
                or integer_value <= 0
            ):
                raise ValueError(f"{integer_name} must be a positive integer")

        for width_name, width_value in (
            ("encoder_width", self.encoder_width),
            ("output_width", self.output_width),
        ):
            if width_value < 2:
                raise ValueError(
                    f"{width_name} must be at least 2 because parameterless "
                    "layer normalization makes a width-1 block identically zero"
                )

        for numeric_name, numeric_value in (
            ("gamma", self.gamma),
            ("actor_lamda", self.actor_lamda),
            ("critic_lamda", self.critic_lamda),
            ("actor_alpha", self.actor_alpha),
            ("critic_alpha", self.critic_alpha),
            ("actor_kappa", self.actor_kappa),
            ("critic_kappa", self.critic_kappa),
            ("entropy_coefficient", self.entropy_coefficient),
            ("temperature", self.temperature),
            ("sparsity", self.sparsity),
            ("r_min", self.r_min),
            ("r_max", self.r_max),
            ("max_phase", self.max_phase),
            ("rtu_epsilon", self.rtu_epsilon),
            ("layer_norm_epsilon", self.layer_norm_epsilon),
            ("leaky_relu_slope", self.leaky_relu_slope),
            ("normalization_epsilon", self.normalization_epsilon),
        ):
            if isinstance(numeric_value, bool):
                raise ValueError(f"{numeric_name} must be numeric, not bool")

        for interval_name, interval_value in (
            ("gamma", self.gamma),
            ("actor_lamda", self.actor_lamda),
            ("critic_lamda", self.critic_lamda),
        ):
            if not math.isfinite(interval_value) or not 0.0 <= interval_value <= 1.0:
                raise ValueError(f"{interval_name} must be finite and lie in [0, 1]")

        for nonnegative_name, nonnegative_value in (
            ("actor_alpha", self.actor_alpha),
            ("critic_alpha", self.critic_alpha),
            ("entropy_coefficient", self.entropy_coefficient),
            ("leaky_relu_slope", self.leaky_relu_slope),
        ):
            if not math.isfinite(nonnegative_value) or nonnegative_value < 0.0:
                raise ValueError(f"{nonnegative_name} must be finite and non-negative")

        for positive_name, positive_value in (
            ("actor_kappa", self.actor_kappa),
            ("critic_kappa", self.critic_kappa),
            ("temperature", self.temperature),
            ("max_phase", self.max_phase),
            ("rtu_epsilon", self.rtu_epsilon),
            ("layer_norm_epsilon", self.layer_norm_epsilon),
            ("normalization_epsilon", self.normalization_epsilon),
        ):
            if not math.isfinite(positive_value) or positive_value <= 0.0:
                raise ValueError(f"{positive_name} must be finite and positive")

        if not math.isfinite(self.sparsity) or not 0.0 <= self.sparsity < 1.0:
            raise ValueError("sparsity must be finite and lie in [0, 1)")
        if (
            not math.isfinite(self.r_min)
            or not math.isfinite(self.r_max)
            or not 0.0 <= self.r_min < self.r_max <= 1.0
        ):
            raise ValueError("r_min and r_max must satisfy 0 <= r_min < r_max <= 1")
        if self.r_max**2 < _FLOAT32_TINY:
            raise ValueError("r_max is below the representable float32 RTU radius range")
        if self.max_phase > 2.0 * math.pi:
            raise ValueError("max_phase must not exceed 2*pi")
        if self.rtu_epsilon >= 1.0:
            raise ValueError("rtu_epsilon must be less than 1")
        for name, value in (
            ("normalize_observations", self.normalize_observations),
            ("normalize_rewards", self.normalize_rewards),
        ):
            if not isinstance(value, bool):
                raise ValueError(f"{name} must be a bool")

    def to_config(self) -> dict[str, Any]:
        """Return a JSON-compatible configuration mapping."""
        return dataclasses.asdict(self)

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any],
    ) -> RecurrentTraceActorCriticConfig:
        """Reconstruct and validate a configuration mapping."""
        return cls(**dict(config))


def parameterless_layer_norm(inputs: Array, epsilon: float = 1e-5) -> Array:
    """Normalize the final axis without learned scale or offset parameters."""
    mean = jnp.mean(inputs, axis=-1, keepdims=True)
    centered = inputs - mean
    variance = jnp.mean(jnp.square(centered), axis=-1, keepdims=True)
    return centered * jax.lax.rsqrt(variance + jnp.asarray(epsilon, inputs.dtype))


def leaky_relu(inputs: Array, negative_slope: float = 0.01) -> Array:
    """Apply a parameterless LeakyReLU with an explicit slope at zero."""
    slope = jnp.asarray(negative_slope, dtype=inputs.dtype)
    return jnp.where(inputs >= 0.0, inputs, slope * inputs)


def zero_rtu_state(hidden_size: int, dtype: jnp.dtype[Any] = jnp.float32) -> RTUState:
    """Construct a zero RTU state."""
    zeros = jnp.zeros((hidden_size,), dtype=dtype)
    return RTUState(real=zeros, imaginary=zeros)


def zero_rtu_sensitivities(
    hidden_size: int,
    input_dim: int,
    dtype: jnp.dtype[Any] = jnp.float32,
) -> RTUSensitivities:
    """Construct zero compressed RTRL sensitivities."""
    recurrent = jnp.zeros((2, hidden_size), dtype=dtype)
    inputs = jnp.zeros((2, hidden_size, input_dim), dtype=dtype)
    return RTUSensitivities(
        nu_log=recurrent,
        theta_log=recurrent,
        b_real=inputs,
        b_imag=inputs,
    )


def _rtu_coefficients(
    params: RTUParameters,
    epsilon: float,
) -> tuple[Array, Array, Array, Array, Array, Array]:
    """Return coefficients and derivatives under representable log bounds.

    The input norm uses an explicit piecewise floor.  Its analytic derivative
    uses the identical branch predicate, so the saturated-radius branch is
    constant with derivative zero rather than silently differentiating the
    unfloored expression.  Bounds correspond to the useful float32
    exponential range, the smallest useful radius, and one full phase
    rotation.  They prevent ``exp`` overflow, underflow-driven parameter
    drift, and meaningless large-angle trigonometry after long online runs;
    the transform is constant, with zero derivative, beyond either bound.
    """
    minimum_exp_log = jnp.asarray(
        _MINIMUM_EXP_LOG,
        dtype=params.nu_log.dtype,
    )
    maximum_nu_log = jnp.asarray(_MAXIMUM_NU_LOG, dtype=params.nu_log.dtype)
    nu_branch_active = (params.nu_log >= minimum_exp_log) & (params.nu_log <= maximum_nu_log)
    bounded_nu_log = jnp.where(
        params.nu_log < minimum_exp_log,
        minimum_exp_log,
        jnp.where(
            params.nu_log > maximum_nu_log,
            maximum_nu_log,
            params.nu_log,
        ),
    )
    exp_nu = jnp.exp(bounded_nu_log)
    d_exp_nu_d_nu_log = jnp.where(
        nu_branch_active,
        exp_nu,
        jnp.zeros_like(exp_nu),
    )
    radius = jnp.exp(-exp_nu)
    maximum_theta_log = jnp.asarray(
        _MAXIMUM_THETA_LOG,
        dtype=params.theta_log.dtype,
    )
    theta_branch_active = (params.theta_log >= minimum_exp_log) & (
        params.theta_log <= maximum_theta_log
    )
    bounded_theta_log = jnp.where(
        params.theta_log < minimum_exp_log,
        minimum_exp_log,
        jnp.where(
            params.theta_log > maximum_theta_log,
            maximum_theta_log,
            params.theta_log,
        ),
    )
    theta = jnp.exp(bounded_theta_log)
    d_theta_d_theta_log = jnp.where(
        theta_branch_active,
        theta,
        jnp.zeros_like(theta),
    )
    g = radius * jnp.cos(theta)
    phi = radius * jnp.sin(theta)
    raw_one_minus_radius_sq = 1.0 - jnp.square(radius)
    epsilon_array = jnp.asarray(epsilon, dtype=radius.dtype)
    norm_branch_active = raw_one_minus_radius_sq > epsilon_array
    stabilized_one_minus_radius_sq = jnp.where(
        norm_branch_active,
        raw_one_minus_radius_sq,
        epsilon_array,
    )
    norm_denominator = jnp.sqrt(stabilized_one_minus_radius_sq)
    norm = norm_denominator + epsilon_array
    dnorm_d_nu_log = jnp.where(
        norm_branch_active,
        d_exp_nu_d_nu_log * jnp.square(radius) / norm_denominator,
        jnp.zeros_like(radius),
    )
    return (
        g,
        phi,
        norm,
        d_exp_nu_d_nu_log,
        d_theta_d_theta_log,
        dnorm_d_nu_log,
    )


def rtu_forward(
    params: RTUParameters,
    state: RTUState,
    inputs: Array,
    *,
    epsilon: float = 1e-8,
) -> RTUState:
    """Advance the nonlinear diagonal complex recurrence by one sample."""
    g, phi, norm, _, _, _ = _rtu_coefficients(params, epsilon)
    input_real = params.b_real @ inputs
    input_imaginary = params.b_imag @ inputs
    pre_real = g * state.real - phi * state.imaginary + norm * input_real
    pre_imaginary = g * state.imaginary + phi * state.real + norm * input_imaginary
    return RTUState(
        real=jnp.tanh(pre_real),
        imaginary=jnp.tanh(pre_imaginary),
    )


def _propagate_sensitivity(
    sensitivity: Array,
    direct: Array,
    g: Array,
    phi: Array,
    derivative_real: Array,
    derivative_imaginary: Array,
) -> Array:
    """Apply the diagonal state Jacobian and add an immediate Jacobian."""
    trailing_axes = sensitivity.ndim - 2
    coefficient_shape = (g.shape[0],) + (1,) * trailing_axes
    g_broadcast = jnp.reshape(g, coefficient_shape)
    phi_broadcast = jnp.reshape(phi, coefficient_shape)
    derivative_real_broadcast = jnp.reshape(derivative_real, coefficient_shape)
    derivative_imaginary_broadcast = jnp.reshape(
        derivative_imaginary,
        coefficient_shape,
    )
    propagated_real = g_broadcast * sensitivity[0] - phi_broadcast * sensitivity[1] + direct[0]
    propagated_imaginary = phi_broadcast * sensitivity[0] + g_broadcast * sensitivity[1] + direct[1]
    return jnp.stack(
        (
            derivative_real_broadcast * propagated_real,
            derivative_imaginary_broadcast * propagated_imaginary,
        ),
        axis=0,
    )


def rtu_step(
    params: RTUParameters,
    state: RTUState,
    sensitivities: RTUSensitivities,
    inputs: Array,
    *,
    epsilon: float = 1e-8,
) -> tuple[RTUState, RTUSensitivities]:
    """Advance an RTU state and its exact forward RTRL sensitivities.

    This is the chain rule ``S_t = J_t S_{t-1} + I_t`` specialized to a
    diagonal complex recurrence.  Only structurally non-zero derivatives are
    retained; no gradient truncation or approximation occurs.
    """
    (
        g,
        phi,
        norm,
        d_exp_nu_d_nu_log,
        d_theta_d_theta_log,
        dnorm_d_nu_log,
    ) = _rtu_coefficients(
        params,
        epsilon,
    )
    input_real = params.b_real @ inputs
    input_imaginary = params.b_imag @ inputs
    pre_real = g * state.real - phi * state.imaginary + norm * input_real
    pre_imaginary = g * state.imaginary + phi * state.real + norm * input_imaginary
    next_state = RTUState(
        real=jnp.tanh(pre_real),
        imaginary=jnp.tanh(pre_imaginary),
    )
    derivative_real = 1.0 - jnp.square(next_state.real)
    derivative_imaginary = 1.0 - jnp.square(next_state.imaginary)

    dg_d_nu_log = -d_exp_nu_d_nu_log * g
    dphi_d_nu_log = -d_exp_nu_d_nu_log * phi
    direct_nu = jnp.stack(
        (
            dg_d_nu_log * state.real
            - dphi_d_nu_log * state.imaginary
            + dnorm_d_nu_log * input_real,
            dg_d_nu_log * state.imaginary
            + dphi_d_nu_log * state.real
            + dnorm_d_nu_log * input_imaginary,
        ),
        axis=0,
    )

    dg_d_theta_log = -phi * d_theta_d_theta_log
    dphi_d_theta_log = g * d_theta_d_theta_log
    direct_theta = jnp.stack(
        (
            dg_d_theta_log * state.real - dphi_d_theta_log * state.imaginary,
            dg_d_theta_log * state.imaginary + dphi_d_theta_log * state.real,
        ),
        axis=0,
    )

    projected_inputs = norm[:, None] * inputs[None, :]
    zeros = jnp.zeros_like(projected_inputs)
    direct_b_real = jnp.stack((projected_inputs, zeros), axis=0)
    direct_b_imaginary = jnp.stack((zeros, projected_inputs), axis=0)

    next_sensitivities = RTUSensitivities(
        nu_log=_propagate_sensitivity(
            sensitivities.nu_log,
            direct_nu,
            g,
            phi,
            derivative_real,
            derivative_imaginary,
        ),
        theta_log=_propagate_sensitivity(
            sensitivities.theta_log,
            direct_theta,
            g,
            phi,
            derivative_real,
            derivative_imaginary,
        ),
        b_real=_propagate_sensitivity(
            sensitivities.b_real,
            direct_b_real,
            g,
            phi,
            derivative_real,
            derivative_imaginary,
        ),
        b_imag=_propagate_sensitivity(
            sensitivities.b_imag,
            direct_b_imaginary,
            g,
            phi,
            derivative_real,
            derivative_imaginary,
        ),
    )
    return next_state, next_sensitivities


def rtu_network_encode(
    params: RTUNetworkParameters,
    observation: Array,
    *,
    layer_norm_epsilon: float = 1e-5,
    negative_slope: float = 0.01,
) -> Array:
    """Apply the sparse input block that supplies one RTU input vector."""
    preactivation = params.encoder_weights @ observation + params.encoder_bias
    return leaky_relu(
        parameterless_layer_norm(preactivation, layer_norm_epsilon),
        negative_slope,
    )


def rtu_network_output(
    params: RTUNetworkParameters,
    state: RTUState,
    *,
    layer_norm_epsilon: float = 1e-5,
    negative_slope: float = 0.01,
) -> Array:
    """Apply the sparse output block and linear policy or value head."""
    hidden = jnp.concatenate((state.real, state.imaginary), axis=-1)
    features = leaky_relu(
        parameterless_layer_norm(
            params.output_weights @ hidden + params.output_bias,
            layer_norm_epsilon,
        ),
        negative_slope,
    )
    return params.head_weights @ features + params.head_bias


def exact_rtrl_gradient(
    params: RTUNetworkParameters,
    state: RTUState,
    sensitivities: RTUSensitivities,
    objective: Callable[[Array], Array],
    *,
    encoder_input: Array | None = None,
    rtu_epsilon: float = 1e-8,
    layer_norm_epsilon: float = 1e-5,
    negative_slope: float = 0.01,
) -> tuple[Array, RTUNetworkParameters]:
    """Differentiate a scalar objective using RTU-RTRL and local encoder AD.

    Reverse-mode differentiation supplies the objective cotangent with
    respect to the current paired RTU state.  Explicit contraction with the
    forward sensitivities supplies gradients for every RTU parameter.  This
    is equivalent to phantom-gradient injection but makes the chain rule
    visible and testable without a neural-network framework.  When
    ``encoder_input`` is supplied, encoder parameters receive the paper's
    one-step gradient through the current RTU transition.  Their older
    influence on recurrent state is intentionally not retained.
    """

    def scalar_objective(
        output_weights: Array,
        output_bias: Array,
        head_weights: Array,
        head_bias: Array,
        real: Array,
        imaginary: Array,
    ) -> Array:
        candidate_params = RTUNetworkParameters(
            encoder_weights=params.encoder_weights,
            encoder_bias=params.encoder_bias,
            rtu=params.rtu,
            output_weights=output_weights,
            output_bias=output_bias,
            head_weights=head_weights,
            head_bias=head_bias,
        )
        output = rtu_network_output(
            candidate_params,
            RTUState(real=real, imaginary=imaginary),
            layer_norm_epsilon=layer_norm_epsilon,
            negative_slope=negative_slope,
        )
        return jnp.reshape(objective(output), ())

    value, direct_gradients = jax.value_and_grad(
        scalar_objective,
        argnums=(0, 1, 2, 3, 4, 5),
    )(
        params.output_weights,
        params.output_bias,
        params.head_weights,
        params.head_bias,
        state.real,
        state.imaginary,
    )
    (
        output_weights_gradient,
        output_bias_gradient,
        head_weights_gradient,
        head_bias_gradient,
        real_cotangent,
        imaginary_cotangent,
    ) = direct_gradients
    state_cotangent = jnp.stack((real_cotangent, imaginary_cotangent), axis=0)
    rtu_gradient = RTUParameters(
        nu_log=jnp.sum(state_cotangent * sensitivities.nu_log, axis=0),
        theta_log=jnp.sum(
            state_cotangent * sensitivities.theta_log,
            axis=0,
        ),
        b_real=jnp.sum(
            state_cotangent[:, :, None] * sensitivities.b_real,
            axis=0,
        ),
        b_imag=jnp.sum(
            state_cotangent[:, :, None] * sensitivities.b_imag,
            axis=0,
        ),
    )

    if encoder_input is None:
        encoder_weights_gradient = jnp.zeros_like(params.encoder_weights)
        encoder_bias_gradient = jnp.zeros_like(params.encoder_bias)
    else:
        _, _, norm, _, _, _ = _rtu_coefficients(params.rtu, rtu_epsilon)
        preactivation_real_cotangent = real_cotangent * (1.0 - jnp.square(state.real))
        preactivation_imaginary_cotangent = imaginary_cotangent * (
            1.0 - jnp.square(state.imaginary)
        )
        rtu_input_cotangent = params.rtu.b_real.T @ (
            norm * preactivation_real_cotangent
        ) + params.rtu.b_imag.T @ (norm * preactivation_imaginary_cotangent)

        def encoder_features(
            encoder_weights: Array,
            encoder_bias: Array,
        ) -> Array:
            preactivation = encoder_weights @ encoder_input + encoder_bias
            return leaky_relu(
                parameterless_layer_norm(
                    preactivation,
                    layer_norm_epsilon,
                ),
                negative_slope,
            )

        _, encoder_pullback = jax.vjp(
            encoder_features,
            params.encoder_weights,
            params.encoder_bias,
        )
        encoder_weights_gradient, encoder_bias_gradient = encoder_pullback(rtu_input_cotangent)

    return value, RTUNetworkParameters(
        encoder_weights=encoder_weights_gradient,
        encoder_bias=encoder_bias_gradient,
        rtu=rtu_gradient,
        output_weights=output_weights_gradient,
        output_bias=output_bias_gradient,
        head_weights=head_weights_gradient,
        head_bias=head_bias_gradient,
    )


def obgd_update(
    traces: Any,
    signal: Array,
    *,
    alpha: float,
    kappa: float,
) -> ObGDUpdate:
    """Apply one observation-bounded gradient update to a trace tree.

    For ``z_sum = sum(abs(z))``, the effective step size is
    ``alpha / max(1, alpha * kappa * max(abs(signal), 1) * z_sum)``.
    The returned parameter change is then ``step_size * signal * z``.  The
    signal is intentionally absent from ``traces`` and is multiplied here
    exactly once.
    """
    signal = jnp.reshape(jnp.asarray(signal), ())
    z_sum = jnp.asarray(0.0, dtype=signal.dtype)
    for leaf in jax.tree_util.tree_leaves(traces):
        z_sum = z_sum + jnp.sum(jnp.abs(leaf))
    denominator = jnp.maximum(
        1.0,
        jnp.asarray(alpha, dtype=signal.dtype)
        * jnp.asarray(kappa, dtype=signal.dtype)
        * jnp.maximum(jnp.abs(signal), 1.0)
        * z_sum,
    )
    scale = jnp.reciprocal(denominator)
    step_size = jnp.asarray(alpha, dtype=signal.dtype) * scale
    updates = jax.tree_util.tree_map(
        lambda trace: step_size * signal * trace,
        traces,
    )
    return ObGDUpdate(updates=updates, step_size=step_size, scale=scale)


def _initialize_rtu_parameters(
    key: Array,
    input_dim: int,
    config: RecurrentTraceActorCriticConfig,
) -> RTUParameters:
    """Initialize stable polar dynamics and dense LeCun-normal RTU inputs."""
    nu_key, theta_key, real_key, imaginary_key = jr.split(key, 4)
    radius_squared = jr.uniform(
        nu_key,
        (config.hidden_size,),
        minval=config.r_min**2,
        maxval=config.r_max**2,
        dtype=jnp.float32,
    )
    radius_squared = jnp.maximum(
        radius_squared,
        jnp.asarray(_FLOAT32_TINY, dtype=jnp.float32),
    )
    nu_log = jnp.log(-0.5 * jnp.log(radius_squared))
    phase = config.max_phase * jr.uniform(
        theta_key,
        (config.hidden_size,),
        dtype=jnp.float32,
    )
    phase = jnp.maximum(
        phase,
        jnp.asarray(_FLOAT32_TINY, dtype=jnp.float32),
    )
    theta_log = jnp.log(phase)
    dense_input_initializer = lecun_normal()
    return RTUParameters(
        nu_log=nu_log,
        theta_log=theta_log,
        b_real=dense_input_initializer(
            real_key,
            (config.hidden_size, input_dim),
            jnp.float32,
        ),
        b_imag=dense_input_initializer(
            imaginary_key,
            (config.hidden_size, input_dim),
            jnp.float32,
        ),
    )


def _live_sparse_init(
    key: Array,
    shape: tuple[int, int],
    sparsity: float,
) -> Array:
    """Sparse-initialize while retaining at least one input per output row."""
    fan_in = shape[1]
    maximum_live_sparsity = (fan_in - 1) / fan_in
    return sparse_init(
        key,
        shape,
        sparsity=min(sparsity, maximum_live_sparsity),
    )


def initialize_rtu_network_parameters(
    key: Array,
    input_dim: int,
    output_dim: int,
    config: RecurrentTraceActorCriticConfig,
) -> RTUNetworkParameters:
    """Initialize sparse feedforward/head blocks and a dense-input RTU."""
    encoder_key, rtu_key, output_key, head_key = jr.split(key, 4)
    return RTUNetworkParameters(
        encoder_weights=_live_sparse_init(
            encoder_key,
            (config.encoder_width, input_dim),
            config.sparsity,
        ),
        encoder_bias=jnp.zeros((config.encoder_width,), dtype=jnp.float32),
        rtu=_initialize_rtu_parameters(
            rtu_key,
            config.encoder_width,
            config,
        ),
        output_weights=_live_sparse_init(
            output_key,
            (config.output_width, 2 * config.hidden_size),
            config.sparsity,
        ),
        output_bias=jnp.zeros((config.output_width,), dtype=jnp.float32),
        head_weights=_live_sparse_init(
            head_key,
            (output_dim, config.output_width),
            config.sparsity,
        ),
        head_bias=jnp.zeros((output_dim,), dtype=jnp.float32),
    )


def _zero_network_like(params: RTUNetworkParameters) -> RTUNetworkParameters:
    """Construct a zero tree with the same network parameter structure."""
    return cast(
        RTUNetworkParameters,
        jax.tree_util.tree_map(jnp.zeros_like, params),
    )


def _initial_running_statistics(shape: tuple[int, ...]) -> RunningStatistics:
    """Initialize moments exactly as the stream-AC observation wrapper."""
    return RunningStatistics(
        sample_count=jnp.asarray(1, dtype=jnp.int32),
        mean=jnp.zeros(shape, dtype=jnp.float32),
        m2=jnp.ones(shape, dtype=jnp.float32),
    )


def _initial_reward_statistics() -> RewardStatistics:
    """Initialize moments exactly as the stream-AC reward wrapper."""
    scalar_zero = jnp.asarray(0.0, dtype=jnp.float32)
    return RewardStatistics(
        sample_count=jnp.asarray(1, dtype=jnp.int32),
        mean=scalar_zero,
        m2=jnp.asarray(1.0, dtype=jnp.float32),
        discounted_return=scalar_zero,
    )


def _saturating_int32_increment(value: Array) -> tuple[Array, Array]:
    """Increment a non-negative int32 counter without allowing wraparound.

    The boolean result marks whether the increment was accepted.  Callers that
    maintain running moments use it to freeze those moments once the largest
    portable JAX int32 count has been represented exactly.
    """
    maximum = jnp.asarray(_INT32_MAX, dtype=jnp.int32)
    can_increment = value < maximum
    return value + can_increment.astype(jnp.int32), can_increment


def _update_running_statistics(
    statistics: RunningStatistics,
    sample: Array,
) -> RunningStatistics:
    """Consume one sample with Welford's stable online recurrence."""
    sample = jnp.asarray(sample, dtype=statistics.mean.dtype)
    sample_count, can_increment = _saturating_int32_increment(
        statistics.sample_count,
    )
    delta = sample - statistics.mean
    candidate_mean = statistics.mean + delta / sample_count
    delta_after = sample - candidate_mean
    candidate_m2 = statistics.m2 + delta * delta_after
    return RunningStatistics(
        sample_count=sample_count,
        mean=jnp.where(can_increment, candidate_mean, statistics.mean),
        m2=jnp.where(can_increment, candidate_m2, statistics.m2),
    )


def _population_standard_deviation(
    m2: Array,
    sample_count: Array,
    epsilon: float,
) -> Array:
    """Return the population standard deviation used by stream-AC wrappers."""
    variance = m2 / sample_count
    return jnp.sqrt(variance + jnp.asarray(epsilon, dtype=variance.dtype))


def _project_rtu_parameter_logs(
    params: RTUNetworkParameters,
) -> RTUNetworkParameters:
    """Project learned RTU logs back into the stable forward-transform range."""
    nu_limit = jnp.asarray(_MAXIMUM_NU_LOG, dtype=params.rtu.nu_log.dtype)
    theta_limit = jnp.asarray(
        _MAXIMUM_THETA_LOG,
        dtype=params.rtu.theta_log.dtype,
    )
    return params._replace(
        rtu=params.rtu._replace(
            nu_log=jnp.clip(
                params.rtu.nu_log,
                jnp.asarray(_MINIMUM_EXP_LOG, dtype=params.rtu.nu_log.dtype),
                nu_limit,
            ),
            theta_log=jnp.clip(
                params.rtu.theta_log,
                jnp.asarray(
                    _MINIMUM_EXP_LOG,
                    dtype=params.rtu.theta_log.dtype,
                ),
                theta_limit,
            ),
        )
    )


def _validated_scalar(
    name: str,
    value: Array | bool | float,
    *,
    boolean: bool,
    unit_interval: bool = False,
) -> Array:
    """Validate the static facts available before entering a jitted update."""
    scalar = jnp.asarray(value)
    if scalar.shape != ():
        raise ValueError(f"{name} must be scalar-shaped")
    if boolean:
        if scalar.dtype != jnp.bool_:
            raise ValueError(f"{name} must have boolean dtype")
    else:
        if not jnp.issubdtype(scalar.dtype, jnp.number) or jnp.issubdtype(
            scalar.dtype,
            jnp.bool_,
        ):
            raise ValueError(f"{name} must have numeric dtype")
        if unit_interval and not isinstance(scalar, jax.core.Tracer):
            concrete = float(scalar)
            if not math.isfinite(concrete) or not 0.0 <= concrete <= 1.0:
                raise ValueError(f"{name} must be finite and lie in [0, 1]")
    return scalar


def _runtime_checked_value(
    value: Array,
    predicate: Array,
    message: str,
) -> Array:
    """Return ``value`` while enforcing a dynamic assertion inside JAX transforms.

    JAX's functional ``checkify`` errors cannot be thrown from a function that
    an outer caller subsequently wraps in ``jax.jit``.  A conditional debug
    callback is therefore used at this public API boundary.  The callback is
    absent from the ordinary valid scalar execution branch.  Under ``vmap``,
    JAX may evaluate the callback branch for every lane, so the host callback
    rechecks the lane predicate before raising.

    A failed compiled check surfaces on synchronization as
    :class:`jax.errors.JaxRuntimeError` wrapping the ``ValueError`` raised by
    the host callback.
    """
    predicate = jnp.reshape(jnp.asarray(predicate, dtype=jnp.bool_), ())

    def valid_branch(operand: tuple[Array, Array]) -> Array:
        checked_value, _ = operand
        return checked_value

    def invalid_branch(operand: tuple[Array, Array]) -> Array:
        checked_value, runtime_predicate = operand

        def raise_if_false(concrete_predicate: Any) -> None:
            if not bool(concrete_predicate):
                raise ValueError(message)

        jax.debug.callback(
            raise_if_false,
            runtime_predicate,
            ordered=True,
        )
        return checked_value

    return cast(
        Array,
        jax.lax.cond(
            predicate,
            valid_branch,
            invalid_branch,
            (value, predicate),
        ),
    )


class RecurrentTraceActorCriticAgent:
    """One-transition-at-a-time softmax actor-critic with RTU-RTRL.

    ``start`` advances both independent RTUs on the initial observation and
    samples the first action.  Each call to ``update`` consumes exactly the
    transition held in ``state.last_observation``/``state.last_action`` plus
    the supplied reward and next observation.  No replay or trajectory buffer
    exists in the state.

    A boundary transition still updates from its current gradient, then clears
    stored AC(lambda) traces.  Its supplied observation is always the
    history-continuing bootstrap observation.  A distinct ``reset_observation``
    may seed the next episode's zeroed recurrence; for legacy callers that
    omit it, the bootstrap observation is reused as that first observation.
    """

    def __init__(self, config: RecurrentTraceActorCriticConfig):
        self._config = config

    @property
    def config(self) -> RecurrentTraceActorCriticConfig:
        """Return the immutable agent configuration."""
        return self._config

    def to_config(self) -> dict[str, Any]:
        """Serialize the agent without array state."""
        return {
            "type": type(self).__name__,
            "config": self._config.to_config(),
        }

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any],
    ) -> RecurrentTraceActorCriticAgent:
        """Reconstruct an agent from :meth:`to_config` output."""
        payload = dict(config)
        agent_type = payload.pop("type", cls.__name__)
        if agent_type != cls.__name__:
            raise ValueError(f"unsupported agent type {agent_type!r}")
        if "config" in payload:
            raw_config = payload.pop("config")
            if payload:
                unknown = ", ".join(sorted(payload))
                raise ValueError(f"unknown serialized agent fields: {unknown}")
        else:
            raw_config = payload
        if not isinstance(raw_config, dict):
            raise ValueError("serialized config must be a dictionary")
        return cls(RecurrentTraceActorCriticConfig.from_config(raw_config))

    def init(self, feature_dim: int, key: Array) -> RecurrentTraceActorCriticState:
        """Initialize independent actor/critic parameters and streaming state."""
        if isinstance(feature_dim, bool) or not isinstance(feature_dim, int) or feature_dim <= 0:
            raise ValueError("feature_dim must be a positive integer")
        actor_key, critic_key, policy_key = jr.split(key, 3)
        actor_params = initialize_rtu_network_parameters(
            actor_key,
            feature_dim,
            self._config.n_actions,
            self._config,
        )
        critic_params = initialize_rtu_network_parameters(
            critic_key,
            feature_dim,
            1,
            self._config,
        )
        hidden_size = self._config.hidden_size
        return RecurrentTraceActorCriticState(
            actor_params=actor_params,
            critic_params=critic_params,
            actor_rtu_state=zero_rtu_state(hidden_size),
            critic_rtu_state=zero_rtu_state(hidden_size),
            actor_sensitivities=zero_rtu_sensitivities(
                hidden_size,
                self._config.encoder_width,
            ),
            critic_sensitivities=zero_rtu_sensitivities(
                hidden_size,
                self._config.encoder_width,
            ),
            actor_traces=_zero_network_like(actor_params),
            critic_traces=_zero_network_like(critic_params),
            observation_statistics=_initial_running_statistics((feature_dim,)),
            reward_statistics=_initial_reward_statistics(),
            last_normalized_observation=jnp.zeros(
                (feature_dim,),
                dtype=jnp.float32,
            ),
            last_observation=jnp.zeros((feature_dim,), dtype=jnp.float32),
            last_action=jnp.asarray(-1, dtype=jnp.int32),
            rng_key=policy_key,
            step_count=jnp.asarray(0, dtype=jnp.int32),
            started=jnp.asarray(False),
        )

    def _network_output(
        self,
        params: RTUNetworkParameters,
        rtu_state: RTUState,
    ) -> Array:
        """Evaluate one configured network head."""
        return rtu_network_output(
            params,
            rtu_state,
            layer_norm_epsilon=self._config.layer_norm_epsilon,
            negative_slope=self._config.leaky_relu_slope,
        )

    def _network_encode(
        self,
        params: RTUNetworkParameters,
        observation: Array,
    ) -> Array:
        """Evaluate one configured sparse input block."""
        return rtu_network_encode(
            params,
            observation,
            layer_norm_epsilon=self._config.layer_norm_epsilon,
            negative_slope=self._config.leaky_relu_slope,
        )

    def _normalize_observation(
        self,
        state: RecurrentTraceActorCriticState,
        observation: Array,
    ) -> tuple[Array, RunningStatistics]:
        """Update population moments with the observation, then normalize it."""
        observation = jnp.asarray(
            observation,
            dtype=state.observation_statistics.mean.dtype,
        )
        statistics = _update_running_statistics(
            state.observation_statistics,
            observation,
        )
        if self._config.normalize_observations:
            normalized = (observation - statistics.mean) / (
                _population_standard_deviation(
                    statistics.m2,
                    statistics.sample_count,
                    self._config.normalization_epsilon,
                )
            )
        else:
            normalized = observation
        return normalized, statistics

    def _normalize_reward(
        self,
        state: RecurrentTraceActorCriticState,
        reward: Array,
        boundary: Array,
    ) -> tuple[Array, RewardStatistics]:
        """Scale reward by current discounted-return population moments."""
        statistics = state.reward_statistics
        reward = jnp.reshape(
            jnp.asarray(reward, dtype=statistics.mean.dtype),
            (),
        )
        continuing = 1.0 - boundary.astype(reward.dtype)
        discounted_return = reward + self._config.gamma * statistics.discounted_return * continuing
        sample_count, can_increment = _saturating_int32_increment(
            statistics.sample_count,
        )
        delta = discounted_return - statistics.mean
        candidate_mean = statistics.mean + delta / sample_count
        delta_after = discounted_return - candidate_mean
        candidate_m2 = statistics.m2 + delta * delta_after
        mean = jnp.where(can_increment, candidate_mean, statistics.mean)
        m2 = jnp.where(can_increment, candidate_m2, statistics.m2)
        if self._config.normalize_rewards:
            normalized = reward / _population_standard_deviation(
                m2,
                sample_count,
                self._config.normalization_epsilon,
            )
        else:
            normalized = reward
        next_statistics = RewardStatistics(
            sample_count=sample_count,
            mean=mean,
            m2=m2,
            discounted_return=discounted_return * continuing,
        )
        return normalized, next_statistics

    @functools.partial(jax.jit, static_argnums=(0,))
    def policy(
        self,
        state: RecurrentTraceActorCriticState,
    ) -> Array:
        """Return the softmax policy of the already-advanced actor state."""
        logits = self._network_output(state.actor_params, state.actor_rtu_state)
        return jax.nn.softmax(logits / self._config.temperature)

    @functools.partial(jax.jit, static_argnums=(0,))
    def value(
        self,
        state: RecurrentTraceActorCriticState,
    ) -> Array:
        """Return the scalar value represented by the current critic state."""
        return jnp.reshape(
            self._network_output(state.critic_params, state.critic_rtu_state)[0],
            (),
        )

    @functools.partial(jax.jit, static_argnums=(0,))
    def select_action(
        self,
        state: RecurrentTraceActorCriticState,
    ) -> tuple[Array, Array, Array]:
        """Sample from the current recurrent policy without advancing it."""
        logits = self._network_output(state.actor_params, state.actor_rtu_state)
        tempered_logits = logits / self._config.temperature
        probabilities = jax.nn.softmax(tempered_logits)
        key, sample_key = jr.split(state.rng_key)
        action = jr.categorical(sample_key, tempered_logits).astype(jnp.int32)
        return action, key, probabilities

    def _advance_actor(
        self,
        state: RecurrentTraceActorCriticState,
        inputs: Array,
        *,
        reset: Array,
    ) -> tuple[RTUState, RTUSensitivities]:
        """Advance actor recurrence, optionally from a zero episode state."""
        hidden_size = self._config.hidden_size
        input_dim = inputs.shape[0]
        source_state = jax.tree_util.tree_map(
            lambda current, zero: jnp.where(reset, zero, current),
            state.actor_rtu_state,
            zero_rtu_state(hidden_size),
        )
        source_sensitivities = jax.tree_util.tree_map(
            lambda current, zero: jnp.where(reset, zero, current),
            state.actor_sensitivities,
            zero_rtu_sensitivities(hidden_size, input_dim),
        )
        return rtu_step(
            state.actor_params.rtu,
            cast(RTUState, source_state),
            cast(RTUSensitivities, source_sensitivities),
            inputs,
            epsilon=self._config.rtu_epsilon,
        )

    def _advance_critic(
        self,
        state: RecurrentTraceActorCriticState,
        inputs: Array,
        *,
        reset: Array,
    ) -> tuple[RTUState, RTUSensitivities]:
        """Advance critic recurrence, optionally from a zero episode state."""
        hidden_size = self._config.hidden_size
        input_dim = inputs.shape[0]
        source_state = jax.tree_util.tree_map(
            lambda current, zero: jnp.where(reset, zero, current),
            state.critic_rtu_state,
            zero_rtu_state(hidden_size),
        )
        source_sensitivities = jax.tree_util.tree_map(
            lambda current, zero: jnp.where(reset, zero, current),
            state.critic_sensitivities,
            zero_rtu_sensitivities(hidden_size, input_dim),
        )
        return rtu_step(
            state.critic_params.rtu,
            cast(RTUState, source_state),
            cast(RTUSensitivities, source_sensitivities),
            inputs,
            epsilon=self._config.rtu_epsilon,
        )

    @functools.partial(jax.jit, static_argnums=(0,))
    def start(
        self,
        state: RecurrentTraceActorCriticState,
        observation: Array,
    ) -> tuple[RecurrentTraceActorCriticState, Array, Array]:
        """Reset recurrent episode state, consume an observation, and act."""
        normalized, statistics = self._normalize_observation(state, observation)
        actor_inputs = self._network_encode(state.actor_params, normalized)
        critic_inputs = self._network_encode(state.critic_params, normalized)
        reset = jnp.asarray(True)
        actor_rtu_state, actor_sensitivities = self._advance_actor(
            state,
            actor_inputs,
            reset=reset,
        )
        critic_rtu_state, critic_sensitivities = self._advance_critic(
            state,
            critic_inputs,
            reset=reset,
        )
        advanced = state.replace(
            actor_rtu_state=actor_rtu_state,
            critic_rtu_state=critic_rtu_state,
            actor_sensitivities=actor_sensitivities,
            critic_sensitivities=critic_sensitivities,
            actor_traces=_zero_network_like(state.actor_params),
            critic_traces=_zero_network_like(state.critic_params),
            observation_statistics=statistics,
            reward_statistics=state.reward_statistics._replace(
                discounted_return=jnp.zeros_like(state.reward_statistics.discounted_return)
            ),
            last_normalized_observation=normalized,
            last_observation=jnp.asarray(observation, dtype=jnp.float32),
            started=jnp.asarray(True),
        )
        action, key, probabilities = self.select_action(advanced)
        return (
            advanced.replace(last_action=action, rng_key=key),
            action,
            probabilities,
        )

    def _critic_gradient(
        self,
        state: RecurrentTraceActorCriticState,
    ) -> tuple[Array, RTUNetworkParameters]:
        """Return value with exact RTU-history and local encoder gradients."""

        def value_objective(output: Array) -> Array:
            return output[0]

        return exact_rtrl_gradient(
            state.critic_params,
            state.critic_rtu_state,
            state.critic_sensitivities,
            value_objective,
            encoder_input=state.last_normalized_observation,
            rtu_epsilon=self._config.rtu_epsilon,
            layer_norm_epsilon=self._config.layer_norm_epsilon,
            negative_slope=self._config.leaky_relu_slope,
        )

    def _actor_gradient(
        self,
        state: RecurrentTraceActorCriticState,
        td_error: Array,
    ) -> tuple[Array, RTUNetworkParameters]:
        """Return entropy-regularized log-policy objective and its gradient."""
        action = state.last_action
        entropy_sign = jax.lax.stop_gradient(jnp.sign(td_error))

        def policy_objective(logits: Array) -> Array:
            log_probabilities = jax.nn.log_softmax(logits / self._config.temperature)
            probabilities = jnp.exp(log_probabilities)
            entropy = -jnp.sum(probabilities * log_probabilities)
            return (
                log_probabilities[action]
                + self._config.entropy_coefficient * entropy_sign * entropy
            )

        return exact_rtrl_gradient(
            state.actor_params,
            state.actor_rtu_state,
            state.actor_sensitivities,
            policy_objective,
            encoder_input=state.last_normalized_observation,
            rtu_epsilon=self._config.rtu_epsilon,
            layer_norm_epsilon=self._config.layer_norm_epsilon,
            negative_slope=self._config.leaky_relu_slope,
        )

    def update(
        self,
        state: RecurrentTraceActorCriticState,
        reward: Array,
        observation: Array,
        terminated: Array | None = None,
        discount: Array | None = None,
        episode_boundary: Array | None = None,
        reset_observation: Array | None = None,
    ) -> RecurrentTraceActorCriticUpdateResult:
        """Validate and consume one transition.

        ``observation`` is always advanced from the current critic history for
        the bootstrap target.  On an episode boundary, stored recurrence and
        traces reset independently; ``reset_observation`` optionally supplies
        the first observation to process from zeros.  Omitting it reuses
        ``observation`` for backward compatibility.  When both observations
        are supplied on a boundary, both enter observation-normalization
        statistics in that order.

        ``discount`` takes precedence over ``terminated`` only for the numeric
        TD bootstrap.  Boundary precedence is ``episode_boundary``, then
        ``terminated``, then an explicitly supplied zero ``discount``.  A call
        that supplies none of them is continuing even when configured
        ``gamma`` is zero.

        Examples:
            A true environment termination can use ``terminated=True``.
            A time-limit truncation can use
            ``discount=config.gamma, episode_boundary=True`` and pass the
            reset observation separately.

        Raises:
            RuntimeError: If called eagerly before :meth:`start`.
            ValueError: If eager transition inputs violate their scalar, dtype,
                shape, or range contracts.
            jax.errors.JaxRuntimeError: If a dynamic lifecycle or discount
                violation occurs when an outer ``jax.jit`` wraps this complete
                public method.  The wrapped ``ValueError`` message identifies
                the failed contract; the error surfaces when the result is
                synchronized and no updated state is returned.
        """
        started = state.started
        if started.shape != ():
            raise ValueError("state.started must be scalar-shaped")
        if started.dtype != jnp.bool_:
            raise ValueError("state.started must have boolean dtype")
        if not isinstance(started, jax.core.Tracer) and not bool(started):
            raise RuntimeError("start must be called before update")

        reward_scalar = _validated_scalar(
            "reward",
            reward,
            boolean=False,
        )
        expected_observation_shape = state.last_observation.shape
        observation_array = jnp.asarray(observation)
        if observation_array.shape != expected_observation_shape:
            raise ValueError("observation shape must match the initialized feature shape")
        if terminated is not None:
            terminated = _validated_scalar(
                "terminated",
                terminated,
                boolean=True,
            )
        if discount is not None:
            discount = _validated_scalar(
                "discount",
                discount,
                boolean=False,
                unit_interval=True,
            )
        if episode_boundary is not None:
            episode_boundary = _validated_scalar(
                "episode_boundary",
                episode_boundary,
                boolean=True,
            )
        if reset_observation is not None:
            reset_observation = jnp.asarray(reset_observation)
            if reset_observation.shape != expected_observation_shape:
                raise ValueError("reset_observation shape must match the initialized feature shape")
        return cast(
            RecurrentTraceActorCriticUpdateResult,
            self._update(
                state,
                reward_scalar,
                observation_array,
                terminated,
                discount,
                episode_boundary,
                reset_observation,
            ),
        )

    @functools.partial(jax.jit, static_argnums=(0,))
    def _update(
        self,
        state: RecurrentTraceActorCriticState,
        reward: Array,
        observation: Array,
        terminated: Array | None,
        discount: Array | None,
        episode_boundary: Array | None,
        reset_observation: Array | None,
    ) -> RecurrentTraceActorCriticUpdateResult:
        """Jitted implementation of one checked streaming update."""
        reward = _runtime_checked_value(
            reward,
            state.started,
            "start must be called before update",
        )
        if discount is not None:
            discount = _runtime_checked_value(
                discount,
                jnp.isfinite(discount) & (discount >= 0.0) & (discount <= 1.0),
                "discount must be finite and lie in [0, 1]",
            )
        if discount is None:
            if terminated is None:
                transition_discount = jnp.asarray(
                    self._config.gamma,
                    dtype=jnp.float32,
                )
            else:
                transition_discount = jnp.where(
                    terminated,
                    jnp.asarray(0.0, dtype=jnp.float32),
                    jnp.asarray(self._config.gamma, dtype=jnp.float32),
                )
        else:
            transition_discount = jnp.reshape(
                jnp.asarray(discount, dtype=jnp.float32),
                (),
            )
        if episode_boundary is None:
            if terminated is not None:
                boundary = jnp.reshape(
                    jnp.asarray(terminated, dtype=jnp.bool_),
                    (),
                )
            elif discount is not None:
                boundary = transition_discount == 0.0
            else:
                boundary = jnp.asarray(False)
        else:
            boundary = jnp.reshape(
                jnp.asarray(episode_boundary, dtype=jnp.bool_),
                (),
            )
        current_policy = self.policy(state)
        current_log_policy = jnp.log(jnp.maximum(current_policy, 1e-8))
        current_entropy = -jnp.sum(current_policy * current_log_policy)

        bootstrap_observation, bootstrap_statistics = self._normalize_observation(
            state, observation
        )
        if reset_observation is None:
            stored_observation = bootstrap_observation
            observation_statistics = bootstrap_statistics
            stored_raw_observation = jnp.asarray(
                observation,
                dtype=jnp.float32,
            )
        else:
            reset_statistics_state = state.replace(
                observation_statistics=bootstrap_statistics,
            )
            normalized_reset_observation, reset_statistics = self._normalize_observation(
                reset_statistics_state,
                reset_observation,
            )
            stored_observation = jnp.where(
                boundary,
                normalized_reset_observation,
                bootstrap_observation,
            )
            observation_statistics = RunningStatistics(
                sample_count=jnp.where(
                    boundary,
                    reset_statistics.sample_count,
                    bootstrap_statistics.sample_count,
                ),
                mean=jnp.where(
                    boundary,
                    reset_statistics.mean,
                    bootstrap_statistics.mean,
                ),
                m2=jnp.where(
                    boundary,
                    reset_statistics.m2,
                    bootstrap_statistics.m2,
                ),
            )
            stored_raw_observation = jnp.where(
                boundary,
                jnp.asarray(reset_observation, dtype=jnp.float32),
                jnp.asarray(observation, dtype=jnp.float32),
            )
        normalized_reward, reward_statistics = self._normalize_reward(
            state,
            reward,
            boundary,
        )

        bootstrap_critic_inputs = self._network_encode(
            state.critic_params,
            bootstrap_observation,
        )
        bootstrap_critic_state = rtu_forward(
            state.critic_params.rtu,
            state.critic_rtu_state,
            bootstrap_critic_inputs,
            epsilon=self._config.rtu_epsilon,
        )

        value, critic_gradient = self._critic_gradient(state)
        next_value = jnp.reshape(
            self._network_output(
                state.critic_params,
                bootstrap_critic_state,
            )[0],
            (),
        )
        td_error = (
            normalized_reward + transition_discount * jax.lax.stop_gradient(next_value) - value
        )
        _, actor_gradient = self._actor_gradient(state, td_error)

        # The terminating reward must still credit traces accumulated within
        # the episode.  Stream AC(lambda) therefore applies gamma*lambda first
        # and clears the stored trace only after the terminal update.
        trace_discount = jnp.where(
            boundary,
            jnp.asarray(self._config.gamma, dtype=transition_discount.dtype),
            transition_discount,
        )
        actor_decay = trace_discount * self._config.actor_lamda
        critic_decay = trace_discount * self._config.critic_lamda
        actor_traces = cast(
            RTUNetworkParameters,
            jax.tree_util.tree_map(
                lambda trace, gradient: actor_decay * trace + gradient,
                state.actor_traces,
                actor_gradient,
            ),
        )
        critic_traces = cast(
            RTUNetworkParameters,
            jax.tree_util.tree_map(
                lambda trace, gradient: critic_decay * trace + gradient,
                state.critic_traces,
                critic_gradient,
            ),
        )

        actor_obgd = obgd_update(
            actor_traces,
            td_error,
            alpha=self._config.actor_alpha,
            kappa=self._config.actor_kappa,
        )
        critic_obgd = obgd_update(
            critic_traces,
            td_error,
            alpha=self._config.critic_alpha,
            kappa=self._config.critic_kappa,
        )
        actor_params = cast(
            RTUNetworkParameters,
            jax.tree_util.tree_map(
                lambda parameter, change: parameter + change,
                state.actor_params,
                actor_obgd.updates,
            ),
        )
        actor_params = _project_rtu_parameter_logs(actor_params)
        critic_params = cast(
            RTUNetworkParameters,
            jax.tree_util.tree_map(
                lambda parameter, change: parameter + change,
                state.critic_params,
                critic_obgd.updates,
            ),
        )
        critic_params = _project_rtu_parameter_logs(critic_params)

        stored_actor_traces = cast(
            RTUNetworkParameters,
            jax.tree_util.tree_map(
                lambda trace: jnp.where(boundary, jnp.zeros_like(trace), trace),
                actor_traces,
            ),
        )
        stored_critic_traces = cast(
            RTUNetworkParameters,
            jax.tree_util.tree_map(
                lambda trace: jnp.where(boundary, jnp.zeros_like(trace), trace),
                critic_traces,
            ),
        )

        parameter_state = state.replace(
            actor_params=actor_params,
            critic_params=critic_params,
        )
        next_actor_inputs = self._network_encode(
            actor_params,
            stored_observation,
        )
        next_critic_inputs = self._network_encode(
            critic_params,
            stored_observation,
        )
        next_actor_state, next_actor_sensitivities = self._advance_actor(
            parameter_state,
            next_actor_inputs,
            reset=boundary,
        )
        next_critic_state, next_critic_sensitivities = self._advance_critic(
            parameter_state,
            next_critic_inputs,
            reset=boundary,
        )

        step_count, _ = _saturating_int32_increment(state.step_count)
        updated = parameter_state.replace(
            actor_rtu_state=next_actor_state,
            critic_rtu_state=next_critic_state,
            actor_sensitivities=next_actor_sensitivities,
            critic_sensitivities=next_critic_sensitivities,
            actor_traces=stored_actor_traces,
            critic_traces=stored_critic_traces,
            observation_statistics=observation_statistics,
            reward_statistics=reward_statistics,
            last_normalized_observation=stored_observation,
            last_observation=stored_raw_observation,
            step_count=step_count,
        )
        next_action, key, next_policy = self.select_action(updated)
        updated = updated.replace(
            last_action=next_action,
            rng_key=key,
        )
        return RecurrentTraceActorCriticUpdateResult(
            state=updated,
            action=next_action,
            policy=next_policy,
            value=value,
            next_value=next_value,
            td_error=td_error,
            entropy=current_entropy,
            normalized_reward=normalized_reward,
            actor_step_size=actor_obgd.step_size,
            critic_step_size=critic_obgd.step_size,
            actor_obgd_scale=actor_obgd.scale,
            critic_obgd_scale=critic_obgd.scale,
        )


# Short aliases make integration with existing Alberta naming less cumbersome.
RTUActorCriticConfig = RecurrentTraceActorCriticConfig
RTUActorCriticState = RecurrentTraceActorCriticState
RTUActorCriticUpdateResult = RecurrentTraceActorCriticUpdateResult
RTUActorCriticAgent = RecurrentTraceActorCriticAgent
