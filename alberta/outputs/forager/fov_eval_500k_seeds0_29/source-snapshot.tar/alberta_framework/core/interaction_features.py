"""Fixed-budget pairwise interaction feature discovery.

This module is a concrete Step 2 probe.  It restricts feature construction to
pairwise products of existing scalar observations, then studies whether an
online learner can manage a bounded set of those constructed features by
testing, scoring, promoting, and replacing them.
"""

import functools
import math
import time
from numbers import Real
from typing import Any, cast

import chex
import jax
import jax.numpy as jnp
import jax.random as jr
from jax import Array
from jaxtyping import Bool, Float, Int, PRNGKeyArray

from alberta_framework.core.feature_discovery import (
    GENERATOR_IMPRINT,
    GENERATOR_MUTATE_PARENT,
    GENERATOR_RANDOM,
)
from alberta_framework.core.future_utility import one_step_output_loss_reduction


@chex.dataclass(frozen=True)
class InteractionFeatureState:
    """State for ``FixedBudgetInteractionLearner``."""

    key: PRNGKeyArray
    feature_left: Int[Array, " n_features"]
    feature_right: Int[Array, " n_features"]
    output_weights: Float[Array, "n_tasks n_features"]
    output_biases: Float[Array, " n_tasks"]
    utilities: Float[Array, " n_features"]
    evidence_idle_steps: Int[Array, " n_features"]
    task_activity_ema: Float[Array, " n_tasks"]
    ages: Int[Array, " n_features"]
    candidate_left: Int[Array, " n_candidates"]
    candidate_right: Int[Array, " n_candidates"]
    candidate_output_weights: Float[Array, "n_tasks n_candidates"]
    candidate_utilities: Float[Array, " n_candidates"]
    candidate_ages: Int[Array, " n_candidates"]
    feature_second_moments: Float[Array, " n_feature_normalizers"]
    candidate_second_moments: Float[Array, " n_candidate_normalizers"]
    target_second_moments: Float[Array, " n_target_normalizers"]
    feature_parent_a: Int[Array, " n_features"]
    feature_parent_b: Int[Array, " n_features"]
    feature_generator: Int[Array, " n_features"]
    candidate_parent_a: Int[Array, " n_candidates"]
    candidate_parent_b: Int[Array, " n_candidates"]
    candidate_generator: Int[Array, " n_candidates"]
    step_count: Int[Array, ""]
    birth_timestamp: float = 0.0
    uptime_s: float = 0.0


@chex.dataclass(frozen=True)
class InteractionFeatureUpdateResult:
    """Result of one pairwise interaction feature update."""

    state: InteractionFeatureState
    predictions: Float[Array, " n_tasks"]
    errors: Float[Array, " n_tasks"]
    metrics: Float[Array, " 7"]
    replaced_slot: Int[Array, ""]
    promoted_candidate: Int[Array, ""]
    retired_slot: Int[Array, ""]
    retired_left: Int[Array, ""]
    retired_right: Int[Array, ""]
    evidence_refreshed: Bool[Array, " n_features"]
    matching_candidate_reset_mask: Bool[Array, " n_candidates"]
    live_feature_count: Int[Array, ""]
    vacancy_count: Int[Array, ""]
    promoted_into_vacancy: Bool[Array, ""]


@chex.dataclass(frozen=True)
class InteractionFeatureLearningResult:
    """Result from a scan-based interaction feature run."""

    state: InteractionFeatureState
    metrics: Float[Array, "num_steps 7"]


class FixedBudgetInteractionLearner:
    """Fixed-budget learner over constructed pairwise product features.

    Active features are products ``x[left] * x[right]``.  Optional candidates
    are trained against residual error without contributing to predictions.
    Periodic replacement either promotes the best candidate into the worst
    active slot or refreshes the worst candidate.

    ``scale_robust=True`` opts into per-coordinate normalized output updates
    and signed loss-intervention utilities.  The default remains the original
    LMS/OBGD contribution-utility path.  Robust mode adds one second moment
    per active feature and candidate plus one per task; this fixed cost is
    exposed by :meth:`memory_accounting`.
    """

    def __init__(
        self,
        n_features: int,
        n_tasks: int,
        step_size_output: float = 0.03,
        utility_decay: float = 0.995,
        replacement_interval: int = 100,
        min_feature_age: int = 50,
        candidate_count: int = 0,
        candidate_min_age: int = 25,
        promotion_margin: float = 1.05,
        promotion_blend: float = 1.0,
        generator_mix: tuple[float, float, float] = (1.0, 0.0, 0.0),
        candidate_strategy: str = "random",
        utility_aggregation: str = "mean",
        utility_top_k: int = 1,
        utility_task_balancing: str = "none",
        task_activity_decay: float = 0.995,
        future_utility_mix: float = 0.0,
        utility_retention_decay: float | None = None,
        utility_retention_grace_steps: int | None = None,
        utility_evidence_threshold: float = 0.0,
        retire_stale_features: bool = False,
        candidate_promotion_floor: float = 0.0,
        candidate_utility_retention_decay: float | None = None,
        refresh_candidates: bool = True,
        refresh_promoted_candidate: bool = True,
        include_squares: bool = False,
        use_obgd: bool = True,
        obgd_kappa: float = 2.0,
        scale_robust: bool = False,
        scale_normalizer_decay: float = 0.99,
        scale_normalizer_epsilon: float = 1e-6,
    ):
        if n_features < 1:
            raise ValueError("n_features must be positive")
        if n_tasks < 1:
            raise ValueError("n_tasks must be positive")
        if candidate_count < 0:
            raise ValueError("candidate_count must be non-negative")
        if not 0.0 <= utility_decay < 1.0:
            raise ValueError("utility_decay must be in [0, 1)")
        if replacement_interval < 0:
            raise ValueError("replacement_interval must be non-negative")
        if (
            isinstance(promotion_margin, bool)
            or not isinstance(cast(object, promotion_margin), Real)
            or not math.isfinite(float(promotion_margin))
            or promotion_margin <= 0.0
        ):
            raise ValueError("promotion_margin must be finite and positive")
        if not 0.0 <= promotion_blend <= 1.0:
            raise ValueError("promotion_blend must be in [0, 1]")
        if candidate_strategy not in {"random", "all_pairs"}:
            raise ValueError("candidate_strategy must be 'random' or 'all_pairs'")
        if utility_aggregation not in {"mean", "max", "topk"}:
            raise ValueError("utility_aggregation must be 'mean', 'max', or 'topk'")
        if utility_top_k < 1:
            raise ValueError("utility_top_k must be positive")
        if utility_task_balancing not in {"none", "active", "active_inverse_frequency"}:
            raise ValueError(
                "utility_task_balancing must be 'none', 'active', or 'active_inverse_frequency'"
            )
        if not 0.0 <= task_activity_decay < 1.0:
            raise ValueError("task_activity_decay must be in [0, 1)")
        if not 0.0 <= future_utility_mix <= 1.0:
            raise ValueError("future_utility_mix must be in [0, 1]")
        if utility_retention_decay is not None and not (
            utility_decay <= utility_retention_decay < 1.0
        ):
            raise ValueError("utility_retention_decay must be in [utility_decay, 1) when set")
        if utility_retention_grace_steps is not None and (
            isinstance(utility_retention_grace_steps, bool)
            or not isinstance(utility_retention_grace_steps, int)
            or not 0 <= utility_retention_grace_steps < 2**31 - 1
        ):
            raise ValueError(
                "utility_retention_grace_steps must be None or an int32-safe non-negative integer"
            )
        if (
            isinstance(utility_evidence_threshold, bool)
            or not isinstance(cast(object, utility_evidence_threshold), Real)
            or not math.isfinite(float(utility_evidence_threshold))
            or utility_evidence_threshold < 0.0
        ):
            raise ValueError("utility_evidence_threshold must be finite and non-negative")
        if utility_retention_grace_steps is not None and utility_evidence_threshold <= 0.0:
            raise ValueError(
                "utility_evidence_threshold must be positive when an evidence lease is enabled"
            )
        if not isinstance(retire_stale_features, bool):
            raise ValueError("retire_stale_features must be boolean")
        if retire_stale_features and utility_retention_grace_steps is None:
            raise ValueError("retire_stale_features requires utility_retention_grace_steps")
        if (
            isinstance(candidate_promotion_floor, bool)
            or not isinstance(cast(object, candidate_promotion_floor), Real)
            or not math.isfinite(float(candidate_promotion_floor))
            or candidate_promotion_floor < 0.0
        ):
            raise ValueError("candidate_promotion_floor must be finite and non-negative")
        if retire_stale_features and replacement_interval <= 0:
            raise ValueError("retire_stale_features requires a positive replacement_interval")
        if retire_stale_features and candidate_promotion_floor <= 0.0:
            raise ValueError("retire_stale_features requires a positive candidate_promotion_floor")
        if candidate_utility_retention_decay is not None and not (
            utility_decay <= candidate_utility_retention_decay < 1.0
        ):
            raise ValueError(
                "candidate_utility_retention_decay must be in [utility_decay, 1) when set"
            )
        if not 0.0 <= scale_normalizer_decay < 1.0:
            raise ValueError("scale_normalizer_decay must be in [0, 1)")
        if scale_normalizer_epsilon <= 0.0:
            raise ValueError("scale_normalizer_epsilon must be positive")
        if scale_robust and future_utility_mix != 0.0:
            raise ValueError(
                "future_utility_mix must be 0 when scale_robust=True; "
                "the robust loss proxy replaces the raw LMS counterfactual"
            )

        mix = jnp.array(generator_mix, dtype=jnp.float32)
        if mix.shape != (3,):
            raise ValueError("generator_mix must have three entries")
        mix_sum = float(jnp.sum(mix))
        if mix_sum <= 0.0:
            raise ValueError("generator_mix must contain positive mass")

        self._n_features = n_features
        self._n_tasks = n_tasks
        self._step_size_output = step_size_output
        self._utility_decay = utility_decay
        self._replacement_interval = replacement_interval
        self._min_feature_age = min_feature_age
        self._candidate_count = candidate_count
        self._candidate_min_age = candidate_min_age
        self._promotion_margin = promotion_margin
        self._promotion_blend = promotion_blend
        self._generator_mix = tuple(float(v) / mix_sum for v in generator_mix)
        self._candidate_strategy = candidate_strategy
        self._utility_aggregation = utility_aggregation
        self._utility_top_k = utility_top_k
        self._utility_task_balancing = utility_task_balancing
        self._task_activity_decay = task_activity_decay
        self._future_utility_mix = future_utility_mix
        self._utility_retention_decay = utility_retention_decay
        self._utility_retention_grace_steps = utility_retention_grace_steps
        self._utility_evidence_threshold = utility_evidence_threshold
        self._retire_stale_features = retire_stale_features
        self._candidate_promotion_floor = candidate_promotion_floor
        self._candidate_utility_retention_decay = candidate_utility_retention_decay
        self._refresh_candidates = refresh_candidates
        self._refresh_promoted_candidate = refresh_promoted_candidate
        self._include_squares = include_squares
        self._use_obgd = use_obgd
        self._obgd_kappa = obgd_kappa
        self._scale_robust = scale_robust
        self._scale_normalizer_decay = scale_normalizer_decay
        self._scale_normalizer_epsilon = scale_normalizer_epsilon

    @property
    def n_features(self) -> int:
        """Number of active features."""
        return self._n_features

    @property
    def n_tasks(self) -> int:
        """Number of output tasks."""
        return self._n_tasks

    def memory_accounting(self, state: InteractionFeatureState) -> dict[str, int | bool]:
        """Return exact persistent-array accounting for an initialized state.

        ``persistent_array_bytes`` counts every JAX array in the state,
        including the PRNG key, pair descriptors, archive heads, utilities,
        ages, provenance, and optional scale normalizers.  It intentionally
        excludes Python object overhead, compiled executables, and the two
        host timing floats.  The candidate archive is counted even though its
        features do not contribute directly to predictions.
        """
        scientific_fields = (
            value
            for name, value in vars(state).items()
            if name not in {"birth_timestamp", "uptime_s"}
        )
        array_bytes = sum(
            int(getattr(leaf, "nbytes", 0))
            for value in scientific_fields
            for leaf in jax.tree_util.tree_leaves(value)
        )
        normalizer_scalars = (
            state.feature_second_moments.size
            + state.candidate_second_moments.size
            + state.target_second_moments.size
        )
        return {
            "active_pair_slots": self._n_features,
            "candidate_archive_slots": self._candidate_count,
            "candidate_archive_is_counted": True,
            "active_pair_descriptor_scalars": 2 * self._n_features,
            "candidate_pair_descriptor_scalars": 2 * self._candidate_count,
            "active_output_weight_scalars": self._n_tasks * self._n_features,
            "candidate_output_weight_scalars": self._n_tasks * self._candidate_count,
            "evidence_idle_step_scalars": int(state.evidence_idle_steps.size),
            "evidence_idle_step_bytes": int(state.evidence_idle_steps.size) * 4,
            "normalizer_scalars": int(normalizer_scalars),
            "normalizer_bytes": int(normalizer_scalars) * 4,
            "persistent_array_bytes": array_bytes,
        }

    def to_config(self) -> dict[str, Any]:
        """Serialize learner configuration."""
        return {
            "type": "FixedBudgetInteractionLearner",
            "n_features": self._n_features,
            "n_tasks": self._n_tasks,
            "step_size_output": self._step_size_output,
            "utility_decay": self._utility_decay,
            "replacement_interval": self._replacement_interval,
            "min_feature_age": self._min_feature_age,
            "candidate_count": self._candidate_count,
            "candidate_min_age": self._candidate_min_age,
            "promotion_margin": self._promotion_margin,
            "promotion_blend": self._promotion_blend,
            "generator_mix": list(self._generator_mix),
            "candidate_strategy": self._candidate_strategy,
            "utility_aggregation": self._utility_aggregation,
            "utility_top_k": self._utility_top_k,
            "utility_task_balancing": self._utility_task_balancing,
            "task_activity_decay": self._task_activity_decay,
            "future_utility_mix": self._future_utility_mix,
            "utility_retention_decay": self._utility_retention_decay,
            "utility_retention_grace_steps": self._utility_retention_grace_steps,
            "utility_evidence_threshold": self._utility_evidence_threshold,
            "retire_stale_features": self._retire_stale_features,
            "candidate_promotion_floor": self._candidate_promotion_floor,
            "candidate_utility_retention_decay": (self._candidate_utility_retention_decay),
            "refresh_candidates": self._refresh_candidates,
            "refresh_promoted_candidate": self._refresh_promoted_candidate,
            "include_squares": self._include_squares,
            "use_obgd": self._use_obgd,
            "obgd_kappa": self._obgd_kappa,
            "scale_robust": self._scale_robust,
            "scale_normalizer_decay": self._scale_normalizer_decay,
            "scale_normalizer_epsilon": self._scale_normalizer_epsilon,
        }

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "FixedBudgetInteractionLearner":
        """Reconstruct learner from ``to_config`` output."""
        config = dict(config)
        config.pop("type", None)
        generator_mix = config.pop("generator_mix", (1.0, 0.0, 0.0))
        return cls(generator_mix=tuple(generator_mix), **config)

    def init(self, feature_dim: int, key: Array) -> InteractionFeatureState:
        """Initialize active and candidate pair banks."""
        if feature_dim < 2 and not self._include_squares:
            raise ValueError("feature_dim must be at least 2 when squares are disabled")

        key, k_active, k_candidate = jr.split(key, 3)
        feature_left, feature_right = self._random_pairs(k_active, self._n_features, feature_dim)
        if self._candidate_strategy == "all_pairs":
            candidate_left, candidate_right = self._candidate_pairs(
                k_candidate, self._candidate_count, feature_dim
            )
        else:
            candidate_left, candidate_right = self._random_pairs(
                k_candidate, self._candidate_count, feature_dim
            )

        normalizer_feature_count = self._n_features if self._scale_robust else 0
        normalizer_candidate_count = self._candidate_count if self._scale_robust else 0
        normalizer_target_count = self._n_tasks if self._scale_robust else 0
        return InteractionFeatureState(
            key=key,
            feature_left=feature_left,
            feature_right=feature_right,
            output_weights=jnp.zeros((self._n_tasks, self._n_features), dtype=jnp.float32),
            output_biases=jnp.zeros(self._n_tasks, dtype=jnp.float32),
            utilities=jnp.zeros(self._n_features, dtype=jnp.float32),
            evidence_idle_steps=jnp.zeros(self._n_features, dtype=jnp.int32),
            task_activity_ema=jnp.zeros(self._n_tasks, dtype=jnp.float32),
            ages=jnp.zeros(self._n_features, dtype=jnp.int32),
            candidate_left=candidate_left,
            candidate_right=candidate_right,
            candidate_output_weights=jnp.zeros(
                (self._n_tasks, self._candidate_count), dtype=jnp.float32
            ),
            candidate_utilities=jnp.zeros(self._candidate_count, dtype=jnp.float32),
            candidate_ages=jnp.zeros(self._candidate_count, dtype=jnp.int32),
            feature_second_moments=jnp.zeros(normalizer_feature_count, dtype=jnp.float32),
            candidate_second_moments=jnp.zeros(normalizer_candidate_count, dtype=jnp.float32),
            target_second_moments=jnp.zeros(normalizer_target_count, dtype=jnp.float32),
            feature_parent_a=jnp.full(self._n_features, -1, dtype=jnp.int32),
            feature_parent_b=jnp.full(self._n_features, -1, dtype=jnp.int32),
            feature_generator=jnp.full(self._n_features, GENERATOR_RANDOM, dtype=jnp.int32),
            candidate_parent_a=jnp.full(self._candidate_count, -1, dtype=jnp.int32),
            candidate_parent_b=jnp.full(self._candidate_count, -1, dtype=jnp.int32),
            candidate_generator=jnp.full(self._candidate_count, GENERATOR_RANDOM, dtype=jnp.int32),
            step_count=jnp.array(0, dtype=jnp.int32),
            birth_timestamp=time.time(),
            uptime_s=0.0,
        )

    def _all_pairs(self, feature_dim: int) -> tuple[Array, Array]:
        pairs = []
        for i in range(feature_dim):
            start = i if self._include_squares else i + 1
            for j in range(start, feature_dim):
                pairs.append((i, j))
        arr = jnp.array(pairs, dtype=jnp.int32)
        return arr[:, 0], arr[:, 1]

    def _candidate_pairs(
        self,
        key: Array,
        count: int,
        feature_dim: int,
    ) -> tuple[Array, Array]:
        """Generate candidate pairs, optionally covering the whole pair space."""
        if count == 0:
            empty = jnp.zeros((0,), dtype=jnp.int32)
            return empty, empty

        pair_left, pair_right = self._all_pairs(feature_dim)
        n_pairs = pair_left.shape[0]
        if count >= n_pairs:
            repeats = (count + n_pairs - 1) // n_pairs
            left = jnp.tile(pair_left, repeats)[:count]
            right = jnp.tile(pair_right, repeats)[:count]
            return left, right

        perm = jr.permutation(key, n_pairs)[:count]
        return pair_left[perm], pair_right[perm]

    def _random_pairs(
        self,
        key: Array,
        count: int,
        feature_dim: int,
    ) -> tuple[Array, Array]:
        """Generate canonical random pairs."""
        if count == 0:
            empty = jnp.zeros((0,), dtype=jnp.int32)
            return empty, empty

        k_left, k_offset = jr.split(key)
        left = jr.randint(k_left, (count,), 0, feature_dim, dtype=jnp.int32)
        if self._include_squares:
            right = jr.randint(k_offset, (count,), 0, feature_dim, dtype=jnp.int32)
        else:
            offset = jr.randint(k_offset, (count,), 1, feature_dim, dtype=jnp.int32)
            right = (left + offset) % feature_dim
        return self._canonicalize(left, right)

    def _canonicalize(self, left: Array, right: Array) -> tuple[Array, Array]:
        if self._include_squares:
            return left, right
        return jnp.minimum(left, right), jnp.maximum(left, right)

    def _live_descriptor_mask(
        self,
        left: Array,
        right: Array,
        feature_dim: int,
    ) -> Array:
        ordered = left <= right if self._include_squares else left < right
        return (left >= 0) & (right >= 0) & (left < feature_dim) & (right < feature_dim) & ordered

    def _values(self, left: Array, right: Array, observation: Array) -> Array:
        live = self._live_descriptor_mask(left, right, observation.shape[0])
        safe_left = jnp.where(live, left, 0)
        safe_right = jnp.where(live, right, 0)
        return observation[safe_left] * observation[safe_right] * live.astype(jnp.float32)

    def _task_activity_update(
        self,
        old_activity: Array,
        active_mask: Array,
    ) -> Array:
        """Track how often each task is observed for opt-in utility balancing."""
        return self._task_activity_decay * old_activity + (
            1.0 - self._task_activity_decay
        ) * active_mask.astype(jnp.float32)

    def _utility_signal(
        self,
        output_weights: Array,
        features: Array,
        active_mask: Array,
        task_activity_ema: Array,
    ) -> Array:
        """Score feature usefulness from current outgoing weights and activity."""
        weighted_activity = jnp.abs(output_weights) * jnp.abs(features)[None, :]
        if self._utility_task_balancing != "none":
            active = active_mask.astype(jnp.float32)
            if self._utility_task_balancing == "active_inverse_frequency":
                frequency_floor = jnp.array(1.0 - self._task_activity_decay, dtype=jnp.float32)
                task_weights = active / jnp.maximum(task_activity_ema, frequency_floor)
            else:
                task_weights = active
            weighted_activity = weighted_activity * task_weights[:, None]

        if self._utility_aggregation == "max":
            return jnp.max(weighted_activity, axis=0)
        if self._utility_aggregation == "topk":
            k = min(self._utility_top_k, self._n_tasks)
            return jnp.mean(jnp.sort(weighted_activity, axis=0)[-k:, :], axis=0)

        if self._utility_task_balancing == "active":
            active_count = jnp.maximum(jnp.sum(active_mask.astype(jnp.float32)), 1.0)
            return jnp.sum(weighted_activity, axis=0) / active_count
        if self._utility_task_balancing == "active_inverse_frequency":
            active_count = jnp.maximum(jnp.sum(active_mask.astype(jnp.float32)), 1.0)
            return jnp.sum(weighted_activity, axis=0) / active_count
        return jnp.mean(weighted_activity, axis=0)

    def _mixed_utility_signal(
        self,
        old_output_weights: Array,
        new_output_weights: Array,
        features: Array,
        errors: Array,
        active_mask: Array,
        task_activity_ema: Array,
        active_count: Array,
        effective_step_size: Array,
    ) -> Array:
        current_signal = self._utility_signal(
            old_output_weights, features, active_mask, task_activity_ema
        )
        if self._future_utility_mix == 0.0:
            return current_signal
        del new_output_weights
        future_signal = self._future_utility_signal(
            errors,
            features,
            active_mask,
            task_activity_ema,
            active_count,
            effective_step_size,
        )
        return (
            1.0 - self._future_utility_mix
        ) * current_signal + self._future_utility_mix * future_signal

    def _future_utility_signal(
        self,
        errors: Array,
        features: Array,
        active_mask: Array,
        task_activity_ema: Array,
        active_count: Array,
        effective_step_size: Array,
    ) -> Array:
        reductions = one_step_output_loss_reduction(
            errors,
            features,
            active_mask,
            effective_step_size,
            active_count,
        )
        return self._aggregate_task_feature_signal(
            reductions,
            active_mask,
            task_activity_ema,
        )

    def _aggregate_task_feature_signal(
        self,
        task_feature_signal: Array,
        active_mask: Array,
        task_activity_ema: Array,
    ) -> Array:
        weighted_signal = task_feature_signal
        if self._utility_task_balancing != "none":
            active = active_mask.astype(jnp.float32)
            if self._utility_task_balancing == "active_inverse_frequency":
                frequency_floor = jnp.array(1.0 - self._task_activity_decay, dtype=jnp.float32)
                task_weights = active / jnp.maximum(task_activity_ema, frequency_floor)
            else:
                task_weights = active
            weighted_signal = weighted_signal * task_weights[:, None]

        if self._utility_aggregation == "max":
            return jnp.max(weighted_signal, axis=0)
        if self._utility_aggregation == "topk":
            k = min(self._utility_top_k, self._n_tasks)
            return jnp.mean(jnp.sort(weighted_signal, axis=0)[-k:, :], axis=0)
        if self._utility_task_balancing in {"active", "active_inverse_frequency"}:
            active_count = jnp.maximum(jnp.sum(active_mask.astype(jnp.float32)), 1.0)
            return jnp.sum(weighted_signal, axis=0) / active_count
        return jnp.mean(weighted_signal, axis=0)

    def _second_moment_update(self, old_moment: Array, values: Array) -> Array:
        """Update a causal scale estimate used by the opt-in robust path."""
        return (
            self._scale_normalizer_decay * old_moment
            + (1.0 - self._scale_normalizer_decay) * values**2
        )

    def _normalized_output_deltas(
        self,
        errors: Array,
        features: Array,
        second_moments: Array,
        active_count: Array,
    ) -> tuple[Array, Array]:
        """Diagonally preconditioned NLMS for the deployed linear head.

        The diagonal contains the causal feature second moment, the current
        squared value, and the current bank's mean energy.  The shared energy
        term is a scale-equivariant ridge: a near-zero Gaussian product cannot
        receive an enormous ``error / feature`` weight merely because it was
        small on one sample.  Dividing by ``1 + phi.T D^-1 phi`` (the one is
        the bias coordinate) bounds the aggregate current-sample prediction
        change by ``alpha * abs(error)``.
        """
        bank_energy = jnp.mean(features**2)
        denominator = jnp.maximum(
            jnp.maximum(
                jnp.maximum(second_moments, features**2),
                bank_energy,
            ),
            self._scale_normalizer_epsilon,
        )
        leverage = 1.0 + jnp.sum(features**2 / denominator)
        normalization = jnp.maximum(leverage, 1.0)
        weight_delta = (
            self._step_size_output
            * errors[:, None]
            * features[None, :]
            / denominator[None, :]
            / normalization
            / active_count
        )
        bias_delta = self._step_size_output * errors / normalization / active_count
        return weight_delta, bias_delta

    def _normalized_candidate_delta(
        self,
        candidate_errors: Array,
        features: Array,
        second_moments: Array,
        active_count: Array,
    ) -> Array:
        """Independent normalized residual-probe updates for dormant candidates.

        Candidate heads are not summed into the deployed prediction, so each
        is a separate one-coordinate probe rather than one 91-coordinate
        model.  Its error is the deployed residual minus its own proposed
        contribution; this makes the head a stable residual predictor rather
        than an unbounded accumulator of deployed gradients.  The common
        bank-energy ridge still prevents a near-zero product from taking an
        unbounded parameter step.
        """
        bank_energy = jnp.mean(features**2)
        denominator = jnp.maximum(
            jnp.maximum(
                jnp.maximum(second_moments, features**2),
                bank_energy,
            ),
            self._scale_normalizer_epsilon,
        )
        return (
            self._step_size_output
            * candidate_errors
            * features[None, :]
            / denominator[None, :]
            / active_count
        )

    def _loss_proxy_utility_signal(
        self,
        output_weights: Array,
        features: Array,
        errors: Array,
        active_mask: Array,
        task_activity_ema: Array,
        target_second_moments: Array,
        *,
        deployed: bool,
    ) -> Array:
        """Bounded, scale-free signed utility from one-feature interventions.

        For a deployed feature with contribution ``q = w * phi``, removing it
        changes the residual from ``e`` to ``e + q``.  Its utility is the
        positive part of that deletion's loss increase.  A dormant candidate
        instead uses the positive loss reduction from changing ``e`` to
        ``e - q``.  Both are divided by the causal target second moment and
        squashed into ``[0, 1)`` before the utility EMA.

        This rejects a large wrong-sign shock contribution, unlike
        ``abs(w * phi)``.  It is still a one-coordinate proxy: correlated or
        redundant features can receive misleading deletion credit.
        """
        target_scale = jnp.sqrt(jnp.maximum(target_second_moments, self._scale_normalizer_epsilon))
        normalized_error = errors / target_scale
        normalized_contribution = output_weights * features[None, :] / target_scale[:, None]

        # The robust update keeps these values moderate from initialization,
        # but finite clipping makes the utility path fail-safe if handed a
        # manually corrupted or legacy state.
        clip = jnp.array(1e6, dtype=jnp.float32)
        normalized_error = jnp.clip(
            jnp.nan_to_num(normalized_error, nan=0.0, posinf=1e6, neginf=-1e6),
            -clip,
            clip,
        )
        normalized_contribution = jnp.clip(
            jnp.nan_to_num(
                normalized_contribution,
                nan=0.0,
                posinf=1e6,
                neginf=-1e6,
            ),
            -clip,
            clip,
        )

        signed_cross = normalized_error[:, None] * normalized_contribution
        contribution_energy = 0.5 * normalized_contribution**2
        if deployed:
            normalized_loss_change = signed_cross + contribution_energy
        else:
            normalized_loss_change = signed_cross - contribution_energy
        positive = jnp.maximum(normalized_loss_change, 0.0)
        bounded = positive / (1.0 + positive)
        bounded = jnp.where(active_mask[:, None], bounded, 0.0)
        return self._aggregate_task_feature_signal(
            bounded,
            active_mask,
            task_activity_ema,
        )

    def _utility_update_with_retention(
        self,
        old_utilities: Array,
        utility_signal: Array,
        retention_decay: float | None,
    ) -> Array:
        """Update utility with an optional recurrent-context retention floor."""
        ema = self._utility_decay * old_utilities + (1.0 - self._utility_decay) * utility_signal
        if retention_decay is None:
            return ema
        retained = retention_decay * old_utilities
        return jnp.maximum(ema, retained)

    def _utility_update(self, old_utilities: Array, utility_signal: Array) -> Array:
        """Update deployed-feature utility with optional slower retention."""
        return self._utility_update_with_retention(
            old_utilities,
            utility_signal,
            self._utility_retention_decay,
        )

    def _leased_utility_update(
        self,
        old_utilities: Array,
        utility_signal: Array,
        old_idle_steps: Array,
        live: Array,
    ) -> tuple[Array, Array, Array]:
        """Apply optional evidence-bounded retention and update idle counters.

        Without a configured grace period this is exactly the historical
        retention update and the fixed-shape idle counters remain zero.  With
        a lease, sufficiently strong instantaneous utility evidence refreshes
        a live slot.  The slower retention floor applies only through the grace
        horizon; expired slots resume the ordinary utility EMA and can be
        retired independently at the next curation cadence.
        """
        if self._utility_retention_grace_steps is None:
            utilities = self._utility_update(old_utilities, utility_signal)
            return (
                jnp.where(live, utilities, 0.0),
                jnp.zeros_like(old_idle_steps),
                jnp.zeros_like(live),
            )

        grace = self._utility_retention_grace_steps
        evidence_refreshed = live & (
            utility_signal >= jnp.asarray(self._utility_evidence_threshold, dtype=jnp.float32)
        )
        idle_cap = jnp.asarray(2**31 - 1, dtype=jnp.int32)
        incremented = jnp.minimum(old_idle_steps, idle_cap - 1) + 1
        idle_steps = jnp.where(
            live,
            jnp.where(evidence_refreshed, 0, incremented),
            0,
        )
        ema = self._utility_decay * old_utilities + (1.0 - self._utility_decay) * utility_signal
        if self._utility_retention_decay is None:
            utilities = ema
        else:
            retained = self._utility_retention_decay * old_utilities
            protected = live & (idle_steps <= grace)
            utilities = jnp.where(protected, jnp.maximum(ema, retained), ema)
        return jnp.where(live, utilities, 0.0), idle_steps, evidence_refreshed

    def _generate_one(
        self,
        key: Array,
        observation: Array,
        active_left: Array,
        active_right: Array,
        utilities: Array,
    ) -> tuple[Array, Array, Array, Array, Array]:
        """Generate one candidate pair using random, mutation, or imprint."""
        feature_dim = observation.shape[0]
        key_kind, key_random, key_parent, key_mutate = jr.split(key, 4)
        mix = jnp.array(self._generator_mix, dtype=jnp.float32)
        generator = jr.categorical(key_kind, jnp.log(mix + 1e-8))
        live_parent = self._live_descriptor_mask(
            active_left,
            active_right,
            feature_dim,
        )
        has_live_parent = jnp.any(live_parent)
        generator = jnp.where(
            has_live_parent,
            generator,
            jnp.asarray(GENERATOR_RANDOM, dtype=jnp.int32),
        )

        random_left, random_right = self._random_pairs(key_random, 1, feature_dim)
        random_left = random_left[0]
        random_right = random_right[0]

        parent_logits = jnp.where(
            live_parent,
            jnp.log(jnp.maximum(utilities, 0.0) + 1e-3),
            -jnp.inf,
        )
        parent_idx = jr.categorical(key_parent, parent_logits).astype(jnp.int32)
        safe_parent_idx = jnp.where(has_live_parent, parent_idx, 0)
        parent_left = jnp.where(
            has_live_parent,
            active_left[safe_parent_idx],
            random_left,
        )
        parent_right = jnp.where(
            has_live_parent,
            active_right[safe_parent_idx],
            random_right,
        )
        key_dim, key_side = jr.split(key_mutate)
        mutate_dim = jr.randint(key_dim, (), 0, feature_dim, dtype=jnp.int32)
        mutate_left_side = jr.bernoulli(key_side)
        mutate_left = jnp.where(mutate_left_side, mutate_dim, parent_left)
        mutate_right = jnp.where(mutate_left_side, parent_right, mutate_dim)
        if not self._include_squares:
            mutate_right = jnp.where(
                mutate_left == mutate_right,
                (mutate_right + 1) % feature_dim,
                mutate_right,
            )
        mutate_left, mutate_right = self._canonicalize(mutate_left, mutate_right)

        top_two = jnp.argsort(jnp.abs(observation))[-2:]
        imprint_left, imprint_right = self._canonicalize(top_two[0], top_two[1])

        def random_branch() -> tuple[Array, Array, Array, Array, Array]:
            return (
                random_left,
                random_right,
                jnp.array(-1, dtype=jnp.int32),
                jnp.array(-1, dtype=jnp.int32),
                jnp.array(GENERATOR_RANDOM, dtype=jnp.int32),
            )

        def mutate_branch() -> tuple[Array, Array, Array, Array, Array]:
            return (
                mutate_left,
                mutate_right,
                safe_parent_idx,
                jnp.array(-1, dtype=jnp.int32),
                jnp.array(GENERATOR_MUTATE_PARENT, dtype=jnp.int32),
            )

        def imprint_branch() -> tuple[Array, Array, Array, Array, Array]:
            return (
                imprint_left,
                imprint_right,
                jnp.array(-1, dtype=jnp.int32),
                jnp.array(-1, dtype=jnp.int32),
                jnp.array(GENERATOR_IMPRINT, dtype=jnp.int32),
            )

        return jax.lax.switch(generator, (random_branch, mutate_branch, imprint_branch))

    @functools.partial(jax.jit, static_argnums=(0,))
    def constructed_features(
        self,
        state: InteractionFeatureState,
        observation: Array,
    ) -> Array:
        """Return active constructed pair-product features for ``observation``.

        These are literal Step 2 features made by combining existing features.
        Downstream GVF/Horde learners can consume them as a fixed representation
        or concatenate them with raw observations.
        """
        return self._values(state.feature_left, state.feature_right, observation)

    @functools.partial(jax.jit, static_argnums=(0,))
    def augmented_observation(
        self,
        state: InteractionFeatureState,
        observation: Array,
    ) -> Array:
        """Concatenate raw observation with active pair-product features."""
        return jnp.concatenate([observation, self.constructed_features(state, observation)])

    @functools.partial(jax.jit, static_argnums=(0,))
    def predict(self, state: InteractionFeatureState, observation: Array) -> Array:
        """Predict all tasks from active interaction features."""
        features = self.constructed_features(state, observation)
        return state.output_weights @ features + state.output_biases

    @functools.partial(jax.jit, static_argnums=(0,))
    def update(
        self,
        state: InteractionFeatureState,
        observation: Array,
        targets: Array,
    ) -> InteractionFeatureUpdateResult:
        """Perform one temporally-uniform interaction-feature update."""
        active_mask = ~jnp.isnan(targets)
        safe_targets = jnp.where(active_mask, targets, 0.0)
        active_count = jnp.maximum(jnp.sum(active_mask.astype(jnp.float32)), 1.0)
        task_activity_ema = self._task_activity_update(state.task_activity_ema, active_mask)

        feature_dim = observation.shape[0]
        live_features = self._live_descriptor_mask(
            state.feature_left,
            state.feature_right,
            feature_dim,
        )
        features = self._values(state.feature_left, state.feature_right, observation)
        predictions = state.output_weights @ features + state.output_biases
        errors = jnp.where(active_mask, safe_targets - predictions, 0.0)
        reported_errors = jnp.where(active_mask, errors, jnp.nan)

        candidate_features = jnp.zeros(self._candidate_count, dtype=jnp.float32)
        if self._candidate_count > 0:
            candidate_features = self._values(
                state.candidate_left, state.candidate_right, observation
            )

        feature_second_moments = state.feature_second_moments
        candidate_second_moments = state.candidate_second_moments
        target_second_moments = state.target_second_moments
        if self._scale_robust:
            feature_second_moments = self._second_moment_update(feature_second_moments, features)
            candidate_second_moments = self._second_moment_update(
                candidate_second_moments, candidate_features
            )
            updated_target_moments = self._second_moment_update(target_second_moments, safe_targets)
            target_second_moments = jnp.where(
                active_mask,
                updated_target_moments,
                target_second_moments,
            )
            utility_target_moments = jnp.maximum(
                target_second_moments,
                safe_targets**2,
            )
            output_delta, output_bias_delta = self._normalized_output_deltas(
                errors,
                features,
                feature_second_moments,
                active_count,
            )
            candidate_output_delta = jnp.zeros_like(state.candidate_output_weights)
            if self._candidate_count > 0:
                candidate_errors = jnp.where(
                    active_mask[:, None],
                    errors[:, None]
                    - (state.candidate_output_weights * candidate_features[None, :]),
                    0.0,
                )
                candidate_output_delta = self._normalized_candidate_delta(
                    candidate_errors,
                    candidate_features,
                    candidate_second_moments,
                    active_count,
                )
        else:
            utility_target_moments = target_second_moments
            output_delta = (
                self._step_size_output * errors[:, None] * features[None, :] / active_count
            )
            output_bias_delta = self._step_size_output * errors / active_count
            candidate_output_delta = jnp.zeros_like(state.candidate_output_weights)
            if self._candidate_count > 0:
                candidate_output_delta = (
                    self._step_size_output
                    * errors[:, None]
                    * candidate_features[None, :]
                    / active_count
                )

        if self._candidate_count == 0:
            candidate_output_delta = jnp.zeros_like(state.candidate_output_weights)

        bounding_scale = jnp.array(1.0, dtype=jnp.float32)
        if self._use_obgd and not self._scale_robust:
            total_step = (
                jnp.sum(jnp.abs(output_delta))
                + jnp.sum(jnp.abs(output_bias_delta))
                + jnp.sum(jnp.abs(candidate_output_delta))
            )
            err_norm = jnp.linalg.norm(errors)
            bound_magnitude = self._obgd_kappa * jnp.maximum(err_norm, 1.0) * total_step
            bounding_scale = 1.0 / jnp.maximum(bound_magnitude, 1.0)
            output_delta = bounding_scale * output_delta
            output_bias_delta = bounding_scale * output_bias_delta
            candidate_output_delta = bounding_scale * candidate_output_delta

        output_weights = state.output_weights + output_delta
        output_biases = state.output_biases + output_bias_delta
        candidate_output_weights = state.candidate_output_weights + candidate_output_delta
        if self._scale_robust:
            utility_signal = self._loss_proxy_utility_signal(
                state.output_weights,
                features,
                errors,
                active_mask,
                task_activity_ema,
                utility_target_moments,
                deployed=True,
            )
        else:
            utility_signal = self._mixed_utility_signal(
                state.output_weights,
                output_weights,
                features,
                errors,
                active_mask,
                task_activity_ema,
                active_count,
                self._step_size_output * bounding_scale,
            )
        (
            new_utilities,
            evidence_idle_steps,
            evidence_refreshed,
        ) = self._leased_utility_update(
            state.utilities,
            utility_signal,
            state.evidence_idle_steps,
            live_features,
        )
        if self._candidate_count > 0:
            if self._scale_robust:
                candidate_signal = self._loss_proxy_utility_signal(
                    state.candidate_output_weights,
                    candidate_features,
                    errors,
                    active_mask,
                    task_activity_ema,
                    utility_target_moments,
                    deployed=False,
                )
            else:
                candidate_signal = self._mixed_utility_signal(
                    state.candidate_output_weights,
                    candidate_output_weights,
                    candidate_features,
                    errors,
                    active_mask,
                    task_activity_ema,
                    active_count,
                    self._step_size_output * bounding_scale,
                )
            # Candidate scores are testing evidence, not deployed memory. By
            # default they decay normally so a chance correlation from an old
            # context cannot become an immortal promotion candidate.
            new_candidate_utilities = self._utility_update_with_retention(
                state.candidate_utilities,
                candidate_signal,
                self._candidate_utility_retention_decay,
            )
        else:
            new_candidate_utilities = state.candidate_utilities
        ages = jnp.where(live_features, state.ages + 1, 0)
        candidate_ages = state.candidate_ages + 1
        step_count = state.step_count + 1
        key, replacement_key = jr.split(state.key)

        feature_left = state.feature_left
        feature_right = state.feature_right
        candidate_left = state.candidate_left
        candidate_right = state.candidate_right
        feature_parent_a = state.feature_parent_a
        feature_parent_b = state.feature_parent_b
        feature_generator = state.feature_generator
        candidate_parent_a = state.candidate_parent_a
        candidate_parent_b = state.candidate_parent_b
        candidate_generator = state.candidate_generator

        replaced_slot = jnp.array(-1, dtype=jnp.int32)
        promoted_candidate = jnp.array(-1, dtype=jnp.int32)
        retired_slot = jnp.array(-1, dtype=jnp.int32)
        retired_left = jnp.array(-1, dtype=jnp.int32)
        retired_right = jnp.array(-1, dtype=jnp.int32)

        should_try_replace = (self._replacement_interval > 0) & (
            step_count % jnp.array(max(self._replacement_interval, 1)) == 0
        )
        stale_scores = jnp.where(
            live_features
            & (ages >= self._min_feature_age)
            & (
                evidence_idle_steps
                > (
                    -1
                    if self._utility_retention_grace_steps is None
                    else self._utility_retention_grace_steps
                )
            ),
            evidence_idle_steps,
            -1,
        )
        stale_slot = jnp.argmax(stale_scores).astype(jnp.int32)
        has_stale_slot = jnp.any(stale_scores >= 0)
        has_vacancy_before = jnp.any(~live_features)
        should_retire = (
            should_try_replace & self._retire_stale_features & has_stale_slot & ~has_vacancy_before
        )
        retired_slot = jnp.where(should_retire, stale_slot, retired_slot)
        retired_left = jnp.where(
            should_retire,
            feature_left[stale_slot],
            retired_left,
        )
        retired_right = jnp.where(
            should_retire,
            feature_right[stale_slot],
            retired_right,
        )
        retired_candidate_mask = (
            should_retire
            & (candidate_left == feature_left[stale_slot])
            & (candidate_right == feature_right[stale_slot])
        )
        feature_left = jax.lax.select(
            should_retire,
            feature_left.at[stale_slot].set(-1),
            feature_left,
        )
        feature_right = jax.lax.select(
            should_retire,
            feature_right.at[stale_slot].set(-1),
            feature_right,
        )
        output_weights = jax.lax.select(
            should_retire,
            output_weights.at[:, stale_slot].set(0.0),
            output_weights,
        )
        new_utilities = jax.lax.select(
            should_retire,
            new_utilities.at[stale_slot].set(0.0),
            new_utilities,
        )
        evidence_idle_steps = jax.lax.select(
            should_retire,
            evidence_idle_steps.at[stale_slot].set(0),
            evidence_idle_steps,
        )
        ages = jax.lax.select(
            should_retire,
            ages.at[stale_slot].set(0),
            ages,
        )
        feature_parent_a = jax.lax.select(
            should_retire,
            feature_parent_a.at[stale_slot].set(-1),
            feature_parent_a,
        )
        feature_parent_b = jax.lax.select(
            should_retire,
            feature_parent_b.at[stale_slot].set(-1),
            feature_parent_b,
        )
        feature_generator = jax.lax.select(
            should_retire,
            feature_generator.at[stale_slot].set(-1),
            feature_generator,
        )
        candidate_output_weights = jnp.where(
            retired_candidate_mask[None, :],
            0.0,
            candidate_output_weights,
        )
        new_candidate_utilities = jnp.where(
            retired_candidate_mask,
            0.0,
            new_candidate_utilities,
        )
        candidate_ages = jnp.where(
            retired_candidate_mask,
            0,
            candidate_ages,
        )
        if self._scale_robust:
            feature_second_moments = jax.lax.select(
                should_retire,
                feature_second_moments.at[stale_slot].set(0.0),
                feature_second_moments,
            )
            candidate_second_moments = jnp.where(
                retired_candidate_mask,
                0.0,
                candidate_second_moments,
            )

        live_after_retirement = (feature_left >= 0) & (feature_right >= 0)
        inactive_slots = ~live_after_retirement
        first_inactive = jnp.argmax(inactive_slots).astype(jnp.int32)
        has_inactive_slot = jnp.any(inactive_slots)
        eligible_active = live_after_retirement & (ages >= self._min_feature_age)
        active_scores = jnp.where(eligible_active, new_utilities, jnp.inf)
        worst_active = jnp.argmin(active_scores).astype(jnp.int32)
        has_active_slot = jnp.any(eligible_active)
        destination_slot = jnp.where(
            has_inactive_slot,
            first_inactive,
            worst_active,
        )
        destination_utility = jnp.where(
            has_inactive_slot,
            0.0,
            new_utilities[worst_active],
        )
        has_destination = has_inactive_slot | has_active_slot

        if self._candidate_count > 0:
            # Promoting a pair that is already active wastes a fixed-budget
            # slot and can erase useful output weights for no representational
            # gain.  This matters especially for ``all_pairs`` candidate banks:
            # retained candidates intentionally remain available as an archive
            # after promotion, so they must be dormant until their matching
            # active feature has actually been evicted.
            candidate_matches_active = jnp.any(
                (candidate_left[:, None] == feature_left[None, :])
                & (candidate_right[:, None] == feature_right[None, :]),
                axis=1,
            )
            eligible_candidates = (
                candidate_ages >= self._candidate_min_age
            ) & ~candidate_matches_active
            candidate_scores = jnp.where(eligible_candidates, new_candidate_utilities, -jnp.inf)
            best_candidate = jnp.argmax(candidate_scores).astype(jnp.int32)
            worst_candidate = jnp.argmin(new_candidate_utilities).astype(jnp.int32)
            has_candidate = jnp.any(eligible_candidates)
            should_promote = (
                should_try_replace
                & ~should_retire
                & has_destination
                & has_candidate
                & (
                    new_candidate_utilities[best_candidate]
                    > jnp.maximum(
                        jnp.asarray(
                            self._candidate_promotion_floor,
                            dtype=jnp.float32,
                        ),
                        self._promotion_margin * destination_utility,
                    )
                )
            )

            def promote_branch(
                args: tuple[
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                ],
            ) -> tuple[
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
            ]:
                (
                    fl,
                    fr,
                    ow,
                    util,
                    age,
                    cl,
                    cr,
                    cow,
                    cutil,
                    cage,
                    fpa,
                    fpb,
                    fg,
                    cpa,
                    cpb,
                    cg,
                ) = args
                fl = fl.at[destination_slot].set(cl[best_candidate])
                fr = fr.at[destination_slot].set(cr[best_candidate])
                ow = ow.at[:, destination_slot].set(self._promotion_blend * cow[:, best_candidate])
                util = util.at[destination_slot].set(cutil[best_candidate])
                age = age.at[destination_slot].set(0)
                fpa = fpa.at[destination_slot].set(cpa[best_candidate])
                fpb = fpb.at[destination_slot].set(cpb[best_candidate])
                fg = fg.at[destination_slot].set(cg[best_candidate])

                if self._refresh_promoted_candidate:
                    new_l, new_r, new_pa, new_pb, new_gen = self._generate_one(
                        replacement_key, observation, fl, fr, util
                    )
                    cl = cl.at[best_candidate].set(new_l)
                    cr = cr.at[best_candidate].set(new_r)
                    cpa = cpa.at[best_candidate].set(new_pa)
                    cpb = cpb.at[best_candidate].set(new_pb)
                    cg = cg.at[best_candidate].set(new_gen)
                cow = cow.at[:, best_candidate].set(0.0)
                cutil = cutil.at[best_candidate].set(0.0)
                cage = cage.at[best_candidate].set(0)
                return fl, fr, ow, util, age, cl, cr, cow, cutil, cage, fpa, fpb, fg, cpa, cpb, cg

            def refresh_candidate_branch(
                args: tuple[
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                    Array,
                ],
            ) -> tuple[
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
                Array,
            ]:
                (
                    fl,
                    fr,
                    ow,
                    util,
                    age,
                    cl,
                    cr,
                    cow,
                    cutil,
                    cage,
                    fpa,
                    fpb,
                    fg,
                    cpa,
                    cpb,
                    cg,
                ) = args
                new_l, new_r, new_pa, new_pb, new_gen = self._generate_one(
                    replacement_key, observation, fl, fr, util
                )
                do_refresh = should_try_replace & ~should_retire & self._refresh_candidates
                cl = jax.lax.select(do_refresh, cl.at[worst_candidate].set(new_l), cl)
                cr = jax.lax.select(do_refresh, cr.at[worst_candidate].set(new_r), cr)
                cow = jax.lax.select(do_refresh, cow.at[:, worst_candidate].set(0.0), cow)
                cutil = jax.lax.select(do_refresh, cutil.at[worst_candidate].set(0.0), cutil)
                cage = jax.lax.select(do_refresh, cage.at[worst_candidate].set(0), cage)
                cpa = jax.lax.select(do_refresh, cpa.at[worst_candidate].set(new_pa), cpa)
                cpb = jax.lax.select(do_refresh, cpb.at[worst_candidate].set(new_pb), cpb)
                cg = jax.lax.select(do_refresh, cg.at[worst_candidate].set(new_gen), cg)
                return fl, fr, ow, util, age, cl, cr, cow, cutil, cage, fpa, fpb, fg, cpa, cpb, cg

            carry = (
                feature_left,
                feature_right,
                output_weights,
                new_utilities,
                ages,
                candidate_left,
                candidate_right,
                candidate_output_weights,
                new_candidate_utilities,
                candidate_ages,
                feature_parent_a,
                feature_parent_b,
                feature_generator,
                candidate_parent_a,
                candidate_parent_b,
                candidate_generator,
            )
            (
                feature_left,
                feature_right,
                output_weights,
                new_utilities,
                ages,
                candidate_left,
                candidate_right,
                candidate_output_weights,
                new_candidate_utilities,
                candidate_ages,
                feature_parent_a,
                feature_parent_b,
                feature_generator,
                candidate_parent_a,
                candidate_parent_b,
                candidate_generator,
            ) = jax.lax.cond(should_promote, promote_branch, refresh_candidate_branch, carry)
            replaced_slot = jnp.where(
                should_promote,
                destination_slot,
                replaced_slot,
            )
            evidence_idle_steps = jax.lax.select(
                should_promote,
                evidence_idle_steps.at[destination_slot].set(0),
                evidence_idle_steps,
            )
            promoted_candidate = jnp.where(should_promote, best_candidate, promoted_candidate)
            if self._scale_robust:
                promoted_feature_moments = feature_second_moments.at[destination_slot].set(
                    candidate_second_moments[best_candidate]
                )
                feature_second_moments = jax.lax.select(
                    should_promote,
                    promoted_feature_moments,
                    feature_second_moments,
                )
                descriptor_was_refreshed = (should_promote & self._refresh_promoted_candidate) | (
                    ~should_promote & should_try_replace & ~should_retire & self._refresh_candidates
                )
                refreshed_candidate_moments = candidate_second_moments.at[
                    jnp.where(
                        should_promote,
                        best_candidate,
                        worst_candidate,
                    )
                ].set(0.0)
                candidate_second_moments = jax.lax.select(
                    descriptor_was_refreshed,
                    refreshed_candidate_moments,
                    candidate_second_moments,
                )
        else:

            def replace_active_branch(
                args: tuple[Array, Array, Array, Array, Array, Array, Array, Array],
            ) -> tuple[Array, Array, Array, Array, Array, Array, Array, Array]:
                fl, fr, ow, util, age, fpa, fpb, fg = args
                new_l, new_r, new_pa, new_pb, new_gen = self._generate_one(
                    replacement_key, observation, fl, fr, util
                )
                fl = fl.at[destination_slot].set(new_l)
                fr = fr.at[destination_slot].set(new_r)
                ow = ow.at[:, destination_slot].set(0.0)
                util = util.at[destination_slot].set(0.0)
                age = age.at[destination_slot].set(0)
                fpa = fpa.at[destination_slot].set(new_pa)
                fpb = fpb.at[destination_slot].set(new_pb)
                fg = fg.at[destination_slot].set(new_gen)
                return fl, fr, ow, util, age, fpa, fpb, fg

            def keep_active_branch(
                args: tuple[Array, Array, Array, Array, Array, Array, Array, Array],
            ) -> tuple[Array, Array, Array, Array, Array, Array, Array, Array]:
                return args

            do_replace = should_try_replace & ~should_retire & has_destination
            (
                feature_left,
                feature_right,
                output_weights,
                new_utilities,
                ages,
                feature_parent_a,
                feature_parent_b,
                feature_generator,
            ) = jax.lax.cond(
                do_replace,
                replace_active_branch,
                keep_active_branch,
                (
                    feature_left,
                    feature_right,
                    output_weights,
                    new_utilities,
                    ages,
                    feature_parent_a,
                    feature_parent_b,
                    feature_generator,
                ),
            )
            replaced_slot = jnp.where(do_replace, destination_slot, replaced_slot)
            evidence_idle_steps = jax.lax.select(
                do_replace,
                evidence_idle_steps.at[destination_slot].set(0),
                evidence_idle_steps,
            )
            if self._scale_robust:
                reset_feature_moments = feature_second_moments.at[destination_slot].set(0.0)
                feature_second_moments = jax.lax.select(
                    do_replace,
                    reset_feature_moments,
                    feature_second_moments,
                )

        new_state = InteractionFeatureState(
            key=key,
            feature_left=feature_left,
            feature_right=feature_right,
            output_weights=output_weights,
            output_biases=output_biases,
            utilities=new_utilities,
            evidence_idle_steps=evidence_idle_steps,
            task_activity_ema=task_activity_ema,
            ages=ages,
            candidate_left=candidate_left,
            candidate_right=candidate_right,
            candidate_output_weights=candidate_output_weights,
            candidate_utilities=new_candidate_utilities,
            candidate_ages=candidate_ages,
            feature_second_moments=feature_second_moments,
            candidate_second_moments=candidate_second_moments,
            target_second_moments=target_second_moments,
            feature_parent_a=feature_parent_a,
            feature_parent_b=feature_parent_b,
            feature_generator=feature_generator,
            candidate_parent_a=candidate_parent_a,
            candidate_parent_b=candidate_parent_b,
            candidate_generator=candidate_generator,
            step_count=step_count,
            birth_timestamp=state.birth_timestamp,
            uptime_s=state.uptime_s,
        )

        loss = jnp.sum(errors**2) / active_count
        mean_abs_error = jnp.sum(jnp.abs(errors)) / active_count
        max_candidate_utility = (
            jnp.max(new_candidate_utilities)
            if self._candidate_count > 0
            else jnp.array(0.0, dtype=jnp.float32)
        )
        replacement_flag = (replaced_slot >= 0).astype(jnp.float32)
        metrics = jnp.array(
            [
                loss,
                mean_abs_error,
                jnp.mean(new_utilities),
                jnp.min(new_utilities),
                max_candidate_utility,
                replacement_flag,
                bounding_scale,
            ],
            dtype=jnp.float32,
        )

        return InteractionFeatureUpdateResult(
            state=new_state,
            predictions=predictions,
            errors=reported_errors,
            metrics=metrics,
            replaced_slot=replaced_slot,
            promoted_candidate=promoted_candidate,
            retired_slot=retired_slot,
            retired_left=retired_left,
            retired_right=retired_right,
            evidence_refreshed=evidence_refreshed,
            matching_candidate_reset_mask=retired_candidate_mask,
            live_feature_count=jnp.sum(
                (feature_left >= 0) & (feature_right >= 0),
                dtype=jnp.int32,
            ),
            vacancy_count=jnp.sum(
                (feature_left < 0) | (feature_right < 0),
                dtype=jnp.int32,
            ),
            promoted_into_vacancy=(promoted_candidate >= 0) & has_inactive_slot,
        )


def run_interaction_feature_arrays(
    learner: FixedBudgetInteractionLearner,
    state: InteractionFeatureState,
    observations: Array,
    targets: Array,
) -> InteractionFeatureLearningResult:
    """Run an interaction-feature learner over pre-collected arrays."""

    def step_fn(
        carry: InteractionFeatureState,
        inputs: tuple[Array, Array],
    ) -> tuple[InteractionFeatureState, Array]:
        observation, target = inputs
        result = learner.update(carry, observation, target)
        return result.state, result.metrics

    t0 = time.time()
    final_state, metrics = jax.lax.scan(step_fn, state, (observations, targets))
    elapsed = time.time() - t0
    final_state = final_state.replace(uptime_s=final_state.uptime_s + elapsed)  # type: ignore[attr-defined]
    return InteractionFeatureLearningResult(state=final_state, metrics=metrics)


def run_interaction_feature_loop(
    learner: FixedBudgetInteractionLearner,
    stream: Any,
    num_steps: int,
    key: Array,
    learner_state: InteractionFeatureState | None = None,
) -> InteractionFeatureLearningResult:
    """Run interaction feature discovery directly from a scan-compatible stream."""
    stream_key, learner_key = jr.split(key)
    stream_state = stream.init(stream_key)
    if learner_state is None:
        learner_state = learner.init(stream.feature_dim, learner_key)

    def step_fn(
        carry: tuple[InteractionFeatureState, Any],
        idx: Array,
    ) -> tuple[tuple[InteractionFeatureState, Any], Array]:
        l_state, s_state = carry
        timestep, new_s_state = stream.step(s_state, idx)
        result = learner.update(l_state, timestep.observation, timestep.target)
        return (result.state, new_s_state), result.metrics

    t0 = time.time()
    (final_state, _), metrics = jax.lax.scan(
        step_fn, (learner_state, stream_state), jnp.arange(num_steps)
    )
    elapsed = time.time() - t0
    final_state = final_state.replace(uptime_s=final_state.uptime_s + elapsed)  # type: ignore[attr-defined]
    return InteractionFeatureLearningResult(state=final_state, metrics=metrics)
