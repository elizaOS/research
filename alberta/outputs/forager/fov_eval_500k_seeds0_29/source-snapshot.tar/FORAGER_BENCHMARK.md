# Forager benchmark

This integration evaluates Alberta agents in the partially observable,
continuing-control testbed introduced by *Forager: a lightweight testbed for
continual learning with partial observability in reinforcement learning*
([arXiv:2605.01131](https://arxiv.org/abs/2605.01131)).

The paper contributes a testbed and evaluation protocol, not a new agent
algorithm. Alberta uses the authors' official JAX environment at runtime and
keeps the environment state opaque to learning policies.

## Install

Use the optional dependency group:

```bash
python -m pip install -e '.[forager]'
```

This installs `continual-foragax==0.55.0` (imported as `foragax`) and
`gymnax==0.0.9`. The unrelated PyPI distribution named `foragax` is not used.

The environment repository currently publishes no license file or license
metadata. Its source is therefore not vendored into this Apache-2.0 repository;
the integration is an optional runtime dependency. Version 0.55.0 was also
released after the arXiv v1 submission. Results must be labelled a
**Foragax 0.55.0 reproduction**, not an exact reconstruction of the
submission-time environment.

## Quick run

Run Alberta and a uniform-random lower control on one short paired seed:

```bash
alberta-forager-benchmark \
  --preset relearning \
  --steps 10000 \
  --seeds 0 \
  --agent alberta \
  --agent random \
  --output outputs/forager/smoke.json
```

Both methods use bounded-memory `jax.lax.scan` runners. The output contains
per-seed curves, bootstrap summaries, paired differences, exact environment and
agent configurations, package/device/git provenance, timing split into setup,
compilation, and execution, and a payload hash.

The Alberta method in this benchmark is `alberta_horde_ac`: a nonlinear Horde
actor-critic with Autostep and ObGD. It learns once from each transition without
replay or task-boundary signals. Its state contains the flattened visible
image, optional public cue, visible-image channel means, previous action,
scaled previous reward, and a biased multi-timescale reward-trace bank.
Those extra channel means and traces make it an Alberta method, not a
paper-faithful DQN/PPO baseline.

The stationary field-of-view study also exposes
`alberta_causal_map`, a learned cognitive-map/world-model candidate:

```bash
alberta-forager-benchmark \
  --preset field_of_view \
  --steps 10000 \
  --seeds 1000000,1000001 \
  --agent causal-map
```

This variant assigns the initial location an arbitrary origin, dead-reckons
only from its own actions under the task's public 15×15 toroidal movement
semantics, and projects raw egocentric one-hot observations into a fixed-size
relative map. It learns reward signs and magnitudes per observed channel from
its own collections. Respawn scheduling begins from one channel-agnostic retry
prior, backs off after an estimated-ready cell is observed empty, and learns
per-channel collection-to-reappearance intervals. It retains separate exact
consecutive-visibility diagnostics, schedules from all interval-censored
samples to avoid policy-dependent exact-sample selection bias, and corrects
early estimates through observed-empty retry backoff. Known learned-negative
cells are excluded from targets and immediate moves whenever a safe move
exists.

The policy does not receive `ForagerAgentContext`, global position, object or
reward grids, biome/task labels, evaluator `info`, or environment time. Its
finite state is serializable and its single-seed, `vmap`, and strict
`lax.map` runners use the same pure transition. The implementation is specific
to the stationary `ForagaxTwoBiomeLarge-v1` color-observation task; selecting it
for relearning, Big-v5, delayed rewards, or custom environment kwargs fails
closed. It is a candidate method, not a SOTA claim without a frozen disjoint
tuning record and matched-seed confirmation against the strongest admissible
learning baseline.

The repository's broader `PrototypeAgent` is deliberately excluded from this
initial runner. Its primitive-action credit and option lifecycle now have
focused regressions, but no Prototype configuration has been tuned or frozen
for Forager, and enabling its hand-specified options would not test the
learned-state/feature-lifecycle gap that motivates this lane. It should enter
only as a separately declared method after a causal observation contract,
resource budget, development sweep, and held-out protocol are fixed.

## Paper protocols

The packaged presets and primary statistics are:

| Study | Foragax ID | Horizon | Tuning | Primary statistic |
|---|---|---:|---:|---|
| Field of view | `ForagaxTwoBiomeLarge-v1` | 500,000 × 30 seeds | 10,000 × 5 disjoint seeds | Mean over final 10% of unadjusted EMA curve (decay 0.999, sampled every 100 rewards) |
| Relearning | `ForagaxSquareWaveTwoBiome-v11` | 10,000,000 × 30 seeds | 1,000,000 × 10 disjoint seeds | Lifetime mean of adjusted EMA, α=0.001 |
| Unending tasks | `ForagaxBig-v5` | 10,000,000 × 30 seeds | 1,000,000 × 10 disjoint seeds | Final adjusted EMA, α=1e-5 |

SquareWave has a 500,000-step waveform and changes reward regime every
250,000 steps. A frozen-at-5M run is a separate relearning ablation, not the
default continuously learning condition:

```bash
alberta-forager-benchmark \
  --preset relearning \
  --paper-protocol \
  --agent alberta \
  --freeze-after-steps 5000000 \
  --output outputs/forager/relearning_alberta_frozen_5m.json
```

Evaluation commands for the continuously learning conditions are:

```bash
alberta-forager-benchmark \
  --preset field_of_view --paper-protocol \
  --agent alberta --agent random \
  --output outputs/forager/fov9.json

alberta-forager-benchmark \
  --preset relearning --paper-protocol \
  --agent alberta --agent random \
  --output outputs/forager/relearning.json

alberta-forager-benchmark \
  --preset unending --paper-protocol \
  --agent alberta --agent random \
  --output outputs/forager/unending.json
```

`--paper-protocol` applies the evaluation horizon and seeds 0–29. It does not
claim that Alberta's hyperparameters have completed the paper's separate
tuning stage. Artifacts record this explicitly as
`tuning_stage_executed: false` and report individual evaluation-conformance
checks. Run tuning on the disjoint seed offset 1,000,000 before promoting a
full-protocol result.

Inspect a protocol or the complete baseline manifest without running:

```bash
alberta-forager-benchmark --preset relearning --protocol-only
alberta-forager-benchmark --preset relearning --list-paper-baselines
```

## SOTA comparison

The paper compares DQN, plasticity interventions, PPO, reward-trace methods,
DRQN, and RTU-PPO. These architectures are not silently approximated with
Alberta's MLP actor-critic. Run them from the authors' MIT-licensed
[`continual-foragax-agents`](https://github.com/steventango/continual-foragax-agents)
repository, then import each seed archive:

```bash
alberta-forager-benchmark \
  --preset relearning \
  --steps 10000000 \
  --seeds 0,1 \
  --agent alberta \
  --reference-npz RTU-PPO:0:/path/to/rtu/data/0.npz \
  --reference-npz RTU-PPO:1:/path/to/rtu/data/1.npz \
  --reference-source-repository https://github.com/steventango/continual-foragax-agents \
  --reference-source-commit 6c3175729377e634460ed41621fed7de06432cf8 \
  --reference-config RTU-PPO:experiments/X33-ForagaxSquareWaveTwoBiome-v11/foragax/ForagaxSquareWaveTwoBiome-v11/9/RealTimeActorCriticMLP.json \
  --attest-reference-protocol \
  --output outputs/forager/alberta_vs_rtu.json
```

Only pass `--attest-reference-protocol` after verifying the archive's
environment, observation augmentation, horizon, seed, and selected config.
The official repository, config path, and full source commit are mandatory for
attested imports, and the original `<seed>.npz` filename must be retained.
Imported archives are
hashed. Unattested official archives can be inspected and summarized, but are
excluded from paired comparisons. Paired comparisons require identical seed
sets, environment contracts, interaction budgets, metric transformations
(EMA decay/bias correction and final window), and internally consistent method
configs; mixed or duplicate runs fail closed.
Use one repeated `--reference-config NAME:CONFIG_PATH` per method when
importing several baselines in the same artifact.
Repository and commit defaults are preset-specific: the paper-era FOV study
uses `steventango/forager-agents@696b3a06…`, while relearning and Big-v5 use
`steventango/continual-foragax-agents@6c317572…`.

The historical FOV repository records collector data in SQLite and runs the
pre-Foragax NumPy environment. Those historical curves are unpaired orientation
evidence for a current Foragax 0.55.0 Alberta run, even when their statistic is
recomputed exactly. A paired FOV claim requires rerunning every compared method
and Alberta in the same executable environment; relabelling a historical run as
a Foragax result is invalid.

Official Search baselines use privileged global state and must be labelled so
they cannot be confused with admissible learning agents. The historical FOV
repository does not write raw NPZ rewards: its SQLite `reward` rows are already
EMA-smoothed and subsampled. The raw-NPZ importer rejects that repository
instead of double-smoothing the curve or inventing an interaction count.

Historical FOV databases have a separate fail-closed API:

```python
from pathlib import Path

from alberta_framework.benchmarks import (
    LegacyFOVSQLiteRunSpec,
    import_legacy_fov_sqlite,
)

run = import_legacy_fov_sqlite(
    LegacyFOVSQLiteRunSpec(
        agent="DQN",
        path=Path("/results/ForagerTwoBiomeLarge/DQN-9/results.db"),
        config_path=Path("/checkout/experiments/forager-two-biome-large/"
                         "ForagerTwoBiomeLarge/DQN-9.json"),
        run_index=0,
        stored_seed=0,
        expected_config_agent="DQN-9",
        expected_aperture_size=9,
        expected_stored_seeds=tuple(range(30)),
        # Pin these when publishing an artifact:
        expected_database_sha256="<64 lowercase hex characters>",
        expected_config_sha256="<64 lowercase hex characters>",
    )
)
```

The importer checks SQLite integrity and the exact PyExpUtils v2 schema,
matches the database hyperparameter row to the flattened config JSON, checks
the declared seed set, and requires one finite unique value at every frame
`0, 100, ..., 499900`. It records separate run-index, stored-seed, and
effective-seed fields plus database, config, and flattened-config hashes.
Only `fov_last_10pct_ema_auc` is finite: it is the mean of the final 10% of
the stored EMA curve. The importer never smooths the values again. The runtime
is labelled `historical_numpy_forager`, source is `official_fov_sqlite`, and
paired comparison with a current Foragax result is rejected explicitly.

No exact raw seed results or numeric tables accompany the paper. The CLI
therefore includes clearly labelled, figure-digitized central estimates for
orientation only. Notable relearning estimates are RTU-PPO ≈1.30, DQN Simple
Memory ≈0.97, DQN+cReLU ≈0.95, and privileged Search Oracle ≈1.59 on lifetime
mean EMA. Big-v5 estimates are PPO ≈0.089, RTU-PPO ≈0.118, and privileged
Search Oracle ≈0.214 on final EMA. These are not acceptance thresholds and
cannot replace seed-level bootstrap comparisons.

The paper-time Big-v5 “PPO Simple Memory” config is ambiguous: it nested its
reward-trace flag where the checked-in code did not read it. The manifest and
digitized target retain that warning.

## Fairness boundary

Learning policies receive only the visible image, public Big-v5 cue, and their
own causal action/reward history. They never receive position, environment
state, biome ID/regret, hidden time/switch labels, or `info["rewards"]`.
The runner passes full context only to policies explicitly marked privileged.

`OracleSearchForagerAgent` is an in-tree, blocking-aware privileged diagnostic.
It is intentionally named `privileged_blocking_search` in results: it is not
the paper's exact Search Oracle and not a mathematical upper bound. Import the
official Search Oracle archives for paper comparisons.

Foragax 0.55.0 has known differences from the paper prose, including generated
reward periods and normalization. The executable 0.55.0 semantics define this
reproduction. Exact-mode runs verify the installed package payload against the
audited 0.55.0 wheel and record the release wheel hash plus both expected and
observed package-tree hashes.

## Validation

Run the focused integration suite:

```bash
pytest -q tests/test_forager_benchmark.py tests/test_causal_map_forager.py
```

It checks causal state construction, disjoint agent/environment RNG namespaces,
privilege isolation, host/scan lifecycle parity, bounded compiled runners,
causal-map reward/respawn learning, state serialization, chunk and batch
parity, negative-cell avoidance, official NPZ metric import, strict paired
statistics, task-specific protocols, and the installed official environment
API.
