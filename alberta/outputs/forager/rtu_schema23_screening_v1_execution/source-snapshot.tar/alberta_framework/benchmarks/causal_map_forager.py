"""Observation-causal cognitive-map planner for stationary Forager.

This module provides an Alberta field-of-view variant that learns a compact
world model online.  Its state consists only of:

* a relative, toroidal map assembled from egocentric observations;
* empirical reward means for the observation channels it has collected;
* collection and reappearance times used to learn respawn schedules; and
* visit counts and the policy's own previous action.

The arbitrary map origin is the agent's initial location.  No evaluator
context, global position, reward grid, object id, task label, biome id, hidden
clock, or privileged ``info`` value enters the policy transition.  The
benchmark runner sees environment state only to execute the ordinary public
environment API and to collect evaluator metrics.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import math
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from statistics import NormalDist
from typing import Any, NamedTuple, cast

import jax
import jax.numpy as jnp
import jax.random as jr
import numpy as np
from jax import Array

from alberta_framework.benchmarks.forager import (
    FORAGER_ENVIRONMENT_RNG_SCHEDULE,
    FORAGER_FOV_EMA_DECAY,
    FORAGER_FOV_EMA_SUBSAMPLE,
    ForagerAgentContext,
    ForagerBatchMode,
    ForagerBenchmarkConfig,
    ForagerRewardTraceSinkFactory,
    ForagerRunResult,
    _abort_reward_trace_sinks,
    _adjusted_ewm_chunk,
    _append_reward_trace,
    _create_reward_trace_sinks,
    _exact_float32_biome_regret,
    _finalize_reward_trace_sinks,
    _fov_last_tenth_ema_auc,
    _observation_parts,
    _unadjusted_ema_chunk,
    environment_rng_schedule_sha256,
    forager_metric_contract,
)

CAUSAL_MAP_STATE_SCHEMA = "alberta.forager_causal_map_state.v3"
CAUSAL_MAP_VARIANT_KIND = "alberta_causal_map"
_CAUSAL_MAP_RNG_NAMESPACE = 0xCA05A14
_INT32_MAX = int(np.iinfo(np.int32).max)
_DIRECTION_STEPS = (
    (0, 1),   # action 0: +y
    (1, 0),   # action 1: +x
    (0, -1),  # action 2: -y
    (-1, 0),  # action 3: -x
)
_DIRECTIONS = jnp.asarray(
    _DIRECTION_STEPS,
    dtype=jnp.int32,
)


def causal_map_rng_contract() -> dict[str, Any]:
    """Describe the causal-map agent's seed-isolated PRNG root."""
    return {
        "root": "jax.random.fold_in(jax.random.key(seed), namespace)",
        "namespace": _CAUSAL_MAP_RNG_NAMESPACE,
        "environment_key_shared_with_agent": False,
    }


def _finite_float32(value: Any) -> bool:
    """Return whether a scalar remains finite in the planner's JAX dtype."""
    with np.errstate(over="ignore", invalid="ignore"):
        converted = np.float32(value)
    return bool(np.isfinite(converted))


@dataclass(frozen=True)
class CausalMapForagerConfig:
    """Configuration for the learned stationary field-of-view planner.

    ``world_shape`` and the four-action movement convention are public task
    semantics, not evaluator state.  ``initial_retry_delay`` is deliberately
    channel-agnostic.  Once any mapped cell is observed to reappear, the
    channel's schedule is estimated from observed collection-to-reappearance
    intervals rather than an object-specific constant.
    """

    world_shape: tuple[int, int] = (15, 15)
    optimistic_unknown_reward: float = 2.0
    negative_reward_threshold: float = -1e-6
    reward_observation_epsilon: float = 1e-7
    initial_retry_delay: int = 10
    maximum_retry_delay: int = 1_024
    maximum_retry_exponent: int = 10
    minimum_respawn_samples: int = 1
    maximum_exact_interval_width: int = 0
    respawn_safety_quantile: float = 0.75
    respawn_safety_factor: float = 1.0
    minimum_respawn_delay: int = 1
    maximum_respawn_delay: int = 4_096
    distance_cost: float = 0.08
    reverse_action_penalty: float = 0.35
    visit_penalty: float = 0.0
    retry_penalty: float = 0.2
    tie_break_scale: float = 1e-4
    exploration_probability: float = 0.05
    one_hot_tolerance: float = 1e-5

    def __post_init__(self) -> None:
        if (
            not isinstance(self.world_shape, tuple)
            or len(self.world_shape) != 2
            or any(
                isinstance(value, bool) or not isinstance(value, int) or value < 1
                or value > _INT32_MAX
                for value in self.world_shape
            )
            or math.prod(self.world_shape) >= _INT32_MAX
        ):
            raise ValueError(
                "world_shape must contain two positive int32-compatible integers"
            )
        object.__setattr__(
            self,
            "world_shape",
            tuple(int(value) for value in self.world_shape),
        )
        for name in (
            "optimistic_unknown_reward",
            "negative_reward_threshold",
        ):
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float, np.integer, np.floating))
                or not math.isfinite(value)
                or not _finite_float32(value)
            ):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, float(value))
        positive_float = (
            "reward_observation_epsilon",
            "respawn_safety_factor",
            "distance_cost",
            "tie_break_scale",
            "one_hot_tolerance",
        )
        for name in positive_float:
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float, np.integer, np.floating))
                or not math.isfinite(value)
                or value <= 0.0
                or not _finite_float32(value)
                or np.float32(value) <= 0.0
            ):
                raise ValueError(f"{name} must be finite and positive")
            object.__setattr__(self, name, float(value))
        nonnegative_float = (
            "reverse_action_penalty",
            "visit_penalty",
            "retry_penalty",
        )
        for name in nonnegative_float:
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float, np.integer, np.floating))
                or not math.isfinite(value)
                or value < 0.0
                or not _finite_float32(value)
            ):
                raise ValueError(f"{name} must be finite and non-negative")
            object.__setattr__(self, name, float(value))
        if (
            isinstance(self.exploration_probability, bool)
            or not isinstance(
                self.exploration_probability,
                (int, float, np.integer, np.floating),
            )
            or not math.isfinite(self.exploration_probability)
            or not 0.0 <= self.exploration_probability <= 1.0
            or not _finite_float32(self.exploration_probability)
        ):
            raise ValueError("exploration_probability must lie in [0, 1]")
        object.__setattr__(
            self,
            "exploration_probability",
            float(self.exploration_probability),
        )
        positive_int = (
            "initial_retry_delay",
            "maximum_retry_delay",
            "minimum_respawn_samples",
            "minimum_respawn_delay",
            "maximum_respawn_delay",
        )
        for name in positive_int:
            value = getattr(self, name)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, np.integer))
                or value < 1
                or value > _INT32_MAX
            ):
                raise ValueError(f"{name} must be a positive integer")
            object.__setattr__(self, name, int(value))
        if (
            isinstance(self.maximum_retry_exponent, bool)
            or not isinstance(self.maximum_retry_exponent, (int, np.integer))
            or self.maximum_retry_exponent < 0
            or self.maximum_retry_exponent > _INT32_MAX
        ):
            raise ValueError("maximum_retry_exponent must be a non-negative integer")
        object.__setattr__(
            self,
            "maximum_retry_exponent",
            int(self.maximum_retry_exponent),
        )
        if (
            isinstance(self.maximum_exact_interval_width, bool)
            or not isinstance(self.maximum_exact_interval_width, (int, np.integer))
            or self.maximum_exact_interval_width < 0
            or self.maximum_exact_interval_width > _INT32_MAX
        ):
            raise ValueError(
                "maximum_exact_interval_width must be a non-negative integer"
            )
        object.__setattr__(
            self,
            "maximum_exact_interval_width",
            int(self.maximum_exact_interval_width),
        )
        if self.maximum_exact_interval_width != 0:
            raise ValueError(
                "maximum_exact_interval_width must be zero; intervals with "
                "nonzero width are censored rather than exact"
            )
        if self.maximum_retry_delay < self.initial_retry_delay:
            raise ValueError("maximum_retry_delay must be at least initial_retry_delay")
        if self.maximum_respawn_delay < self.minimum_respawn_delay:
            raise ValueError(
                "maximum_respawn_delay must be at least minimum_respawn_delay"
            )
        if (
            isinstance(self.respawn_safety_quantile, bool)
            or not isinstance(
                self.respawn_safety_quantile,
                (int, float, np.integer, np.floating),
            )
            or not math.isfinite(self.respawn_safety_quantile)
            or not 0.5 <= self.respawn_safety_quantile < 1.0
            or not _finite_float32(self.respawn_safety_quantile)
        ):
            raise ValueError("respawn_safety_quantile must lie in [0.5, 1)")
        object.__setattr__(
            self,
            "respawn_safety_quantile",
            float(self.respawn_safety_quantile),
        )
        if not _finite_float32(self.respawn_quantile_z):
            raise ValueError("respawn_safety_quantile produces a non-finite float32 z")
        if not 0.0 < self.one_hot_tolerance < 0.5:
            raise ValueError("one_hot_tolerance must lie strictly between 0 and 0.5")

    @property
    def height(self) -> int:
        """Map height."""
        return self.world_shape[0]

    @property
    def width(self) -> int:
        """Map width."""
        return self.world_shape[1]

    @property
    def respawn_quantile_z(self) -> float:
        """One-sided normal quantile used with online Welford statistics."""
        return float(NormalDist().inv_cdf(self.respawn_safety_quantile))

    def to_dict(self) -> dict[str, Any]:
        """Return a fully explicit JSON-compatible configuration."""
        data = dataclasses.asdict(self)
        data = {
            name: value.item() if isinstance(value, np.generic) else value
            for name, value in data.items()
        }
        data["world_shape"] = [
            value.item() if isinstance(value, np.generic) else value
            for value in self.world_shape
        ]
        data["respawn_quantile_z"] = self.respawn_quantile_z
        return data

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> CausalMapForagerConfig:
        """Restore a configuration, rejecting unknown or derived fields."""
        if not isinstance(payload, Mapping):
            raise ValueError("causal-map config must be a mapping")
        data = dict(payload)
        declared_quantile_z = data.pop("respawn_quantile_z", None)
        if "world_shape" in data:
            value = data["world_shape"]
            if (
                not isinstance(value, Sequence)
                or isinstance(value, (str, bytes))
                or len(value) != 2
            ):
                raise ValueError("world_shape must contain two integers")
            data["world_shape"] = tuple(value)
        known = {item.name for item in dataclasses.fields(cls)}
        unknown = set(data) - known
        if unknown:
            raise ValueError(f"unknown causal-map config fields: {sorted(unknown)}")
        config = cls(**data)
        if declared_quantile_z is not None and (
            isinstance(declared_quantile_z, bool)
            or not isinstance(declared_quantile_z, (int, float))
            or not math.isclose(
                float(declared_quantile_z),
                config.respawn_quantile_z,
                rel_tol=0.0,
                abs_tol=1e-15,
            )
        ):
            raise ValueError(
                "respawn_quantile_z does not match respawn_safety_quantile"
            )
        return config

    def fingerprint(self) -> str:
        """Return a canonical SHA-256 suitable for benchmark provenance."""
        encoded = json.dumps(
            self.to_dict(),
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode()
        return hashlib.sha256(encoded).hexdigest()


class CausalMapForagerState(NamedTuple):
    """Finite JAX state for the observation-causal map and planner."""

    step_count: Array
    initial_seed: Array
    position: Array
    last_action: Array
    last_target_channel: Array
    last_target_position: Array
    last_target_expected_active: Array
    rng_key: Array
    cell_channel: Array
    cell_active: Array
    cell_collection_step: Array
    cell_ready_step: Array
    cell_retry_count: Array
    cell_last_seen_step: Array
    cell_last_absent_step: Array
    visit_count: Array
    reward_sum: Array
    reward_count: Array
    respawn_count: Array
    respawn_mean: Array
    respawn_m2: Array
    respawn_exact_count: Array
    respawn_exact_mean: Array
    respawn_exact_m2: Array


class CausalMapStepDiagnostics(NamedTuple):
    """Small causal diagnostics emitted by one planner transition."""

    learned_reward: Array
    learned_respawn: Array
    retry_miss: Array
    known_cells: Array
    known_negative_cells: Array


_STATE_INTEGER_FIELDS = frozenset(
    {
        "step_count",
        "position",
        "last_action",
        "last_target_channel",
        "last_target_position",
        "cell_channel",
        "cell_collection_step",
        "cell_ready_step",
        "cell_retry_count",
        "cell_last_seen_step",
        "cell_last_absent_step",
        "visit_count",
        "reward_count",
        "respawn_count",
        "respawn_exact_count",
    }
)
_STATE_UINT32_FIELDS = frozenset({"initial_seed"})
_STATE_BOOLEAN_FIELDS = frozenset(
    {"last_target_expected_active", "cell_active"}
)
_STATE_FLOAT_FIELDS = frozenset(CausalMapForagerState._fields) - (
    _STATE_INTEGER_FIELDS
    | _STATE_UINT32_FIELDS
    | _STATE_BOOLEAN_FIELDS
    | {"rng_key"}
)
_STATE_SERIALIZED_DTYPES = {
    name: (
        "uint32-key-data"
        if name == "rng_key"
        else (
            "uint32"
            if name in _STATE_UINT32_FIELDS
            else
            "int32"
            if name in _STATE_INTEGER_FIELDS
            else "bool"
            if name in _STATE_BOOLEAN_FIELDS
            else "float32"
        )
    )
    for name in CausalMapForagerState._fields
}


def _image(observation: Any) -> Array:
    image, _ = _observation_parts(observation)
    return jnp.asarray(image, dtype=jnp.float32)


def _validate_observation_host(
    observation: Any,
    config: CausalMapForagerConfig,
) -> tuple[int, int, int]:
    image = np.asarray(_image(observation), dtype=np.float32)
    if image.ndim != 3:
        raise ValueError("causal-map Forager observation must have rank 3")
    aperture_h, aperture_w, channels = image.shape
    if channels < 1:
        raise ValueError("causal-map Forager requires at least one object/color channel")
    if (
        aperture_h < 3
        or aperture_w < 3
        or aperture_h % 2 == 0
        or aperture_w % 2 == 0
    ):
        raise ValueError(
            "causal-map Forager requires an odd aperture of at least 3; "
            "aperture 1 cannot causally identify a collected destination channel"
        )
    if aperture_h > config.height or aperture_w > config.width:
        raise ValueError("aperture cannot exceed the configured toroidal world")
    if not np.all(np.isfinite(image)):
        raise ValueError("observation must be finite")
    tolerance = config.one_hot_tolerance
    if np.any(image < -tolerance) or np.any(image > 1.0 + tolerance):
        raise ValueError("observation channels must lie in [0, 1]")
    channel_sums = np.sum(image, axis=-1)
    if np.any(channel_sums > 1.0 + tolerance):
        raise ValueError("causal-map planner requires one-hot color/object channels")
    near_binary = np.isclose(image, 0.0, atol=tolerance) | np.isclose(
        image, 1.0, atol=tolerance
    )
    if not bool(np.all(near_binary)):
        raise ValueError("causal-map planner requires binary one-hot observations")
    return aperture_h, aperture_w, channels


def _validate_static_observation_shape(
    image: Array,
    config: CausalMapForagerConfig,
) -> None:
    """Validate shape-only invariants that remain static while tracing JAX."""
    if image.ndim != 3:
        raise ValueError("causal-map Forager observation must have rank 3")
    aperture_h, aperture_w, channels = image.shape
    if channels < 1:
        raise ValueError("causal-map Forager requires at least one object/color channel")
    if (
        aperture_h < 3
        or aperture_w < 3
        or aperture_h % 2 == 0
        or aperture_w % 2 == 0
    ):
        raise ValueError(
            "causal-map Forager requires an odd aperture of at least 3; "
            "aperture 1 cannot causally identify a collected destination channel"
        )
    if aperture_h > config.height or aperture_w > config.width:
        raise ValueError("aperture cannot exceed the configured toroidal world")


def _empty_state(
    channels: int,
    config: CausalMapForagerConfig,
    seed: int | Array,
) -> CausalMapForagerState:
    map_shape = config.world_shape
    zero_i = jnp.asarray(0, dtype=jnp.int32)
    return CausalMapForagerState(
        step_count=zero_i,
        initial_seed=jnp.asarray(seed, dtype=jnp.uint32),
        position=jnp.zeros((2,), dtype=jnp.int32),
        last_action=jnp.asarray(-1, dtype=jnp.int32),
        last_target_channel=jnp.asarray(-1, dtype=jnp.int32),
        last_target_position=jnp.zeros((2,), dtype=jnp.int32),
        last_target_expected_active=jnp.asarray(False),
        rng_key=jr.fold_in(jr.key(seed), _CAUSAL_MAP_RNG_NAMESPACE),
        cell_channel=jnp.full(map_shape, -1, dtype=jnp.int32),
        cell_active=jnp.zeros(map_shape, dtype=jnp.bool_),
        cell_collection_step=jnp.full(map_shape, -1, dtype=jnp.int32),
        cell_ready_step=jnp.full(map_shape, -1, dtype=jnp.int32),
        cell_retry_count=jnp.zeros(map_shape, dtype=jnp.int32),
        cell_last_seen_step=jnp.full(map_shape, -1, dtype=jnp.int32),
        cell_last_absent_step=jnp.full(map_shape, -1, dtype=jnp.int32),
        visit_count=jnp.zeros(map_shape, dtype=jnp.int32),
        reward_sum=jnp.zeros((channels,), dtype=jnp.float32),
        reward_count=jnp.zeros((channels,), dtype=jnp.int32),
        respawn_count=jnp.zeros((channels,), dtype=jnp.int32),
        respawn_mean=jnp.zeros((channels,), dtype=jnp.float32),
        respawn_m2=jnp.zeros((channels,), dtype=jnp.float32),
        respawn_exact_count=jnp.zeros((channels,), dtype=jnp.int32),
        respawn_exact_mean=jnp.zeros((channels,), dtype=jnp.float32),
        respawn_exact_m2=jnp.zeros((channels,), dtype=jnp.float32),
    )


def _saturating_add_int32(value: Array, increment: Array) -> Array:
    """Add non-negative int32 values without allowing signed wraparound."""
    value = jnp.asarray(value, dtype=jnp.int32)
    increment = jnp.asarray(increment, dtype=jnp.int32)
    maximum = jnp.asarray(_INT32_MAX, dtype=jnp.int32)
    return jnp.where(
        value >= maximum - increment,
        maximum,
        value + increment,
    )


def _require_unsaturated_step_count(step_count: Array) -> Array:
    """Reject a transition once the finite int32 lifetime is exhausted."""
    predicate = jnp.reshape(
        jnp.asarray(step_count < _INT32_MAX, dtype=jnp.bool_),
        (),
    )

    def valid_branch(operand: tuple[Array, Array]) -> Array:
        value, _ = operand
        return value

    def invalid_branch(operand: tuple[Array, Array]) -> Array:
        value, runtime_predicate = operand

        def raise_if_false(concrete_predicate: Any) -> None:
            if not bool(concrete_predicate):
                raise OverflowError(
                    "causal-map step_count is saturated; no further transition "
                    "can preserve the finite-state timestamp contract"
                )

        jax.debug.callback(
            raise_if_false,
            runtime_predicate,
            ordered=True,
        )
        return value

    return cast(
        Array,
        jax.lax.cond(
            predicate,
            valid_branch,
            invalid_branch,
            (step_count, predicate),
        ),
    )


def _increment_retry_count(
    retry_count: Array,
    config: CausalMapForagerConfig,
) -> Array:
    """Increment a retry exponent without overflowing its int32 storage."""
    if config.maximum_retry_exponent == 0:
        return jnp.zeros_like(retry_count, dtype=jnp.int32)
    ceiling_minus_one = jnp.asarray(
        config.maximum_retry_exponent - 1,
        dtype=jnp.int32,
    )
    return jnp.minimum(jnp.asarray(retry_count, dtype=jnp.int32), ceiling_minus_one) + 1


def _retry_delay(
    retry_count: Array,
    config: CausalMapForagerConfig,
) -> Array:
    """Return a positive, saturating exponential retry delay."""
    maximum_safe_exponent = (
        _INT32_MAX // config.initial_retry_delay
    ).bit_length() - 1
    safe_exponent = jnp.minimum(
        jnp.asarray(retry_count, dtype=jnp.int32),
        jnp.asarray(maximum_safe_exponent, dtype=jnp.int32),
    )
    shifted = jnp.left_shift(
        jnp.asarray(config.initial_retry_delay, dtype=jnp.int32),
        safe_exponent,
    )
    saturated = jnp.where(
        jnp.asarray(retry_count, dtype=jnp.int32) > maximum_safe_exponent,
        jnp.asarray(config.maximum_retry_delay, dtype=jnp.int32),
        jnp.minimum(
            shifted,
            jnp.asarray(config.maximum_retry_delay, dtype=jnp.int32),
        ),
    )
    return jnp.maximum(saturated, jnp.asarray(1, dtype=jnp.int32))


def _estimated_respawn_delay(
    state: CausalMapForagerState,
    channel: Array,
    config: CausalMapForagerConfig,
) -> Array:
    safe_channel = jnp.maximum(channel, 0)
    count = state.respawn_count[safe_channel]

    def safety_estimate(sample_count: Array, mean: Array, m2: Array) -> Array:
        denominator = jnp.maximum(sample_count - 1, 1)
        variance = jnp.where(
            sample_count > 1,
            m2 / denominator.astype(jnp.float32),
            0.0,
        )
        upper = mean + jnp.asarray(
            config.respawn_quantile_z, dtype=jnp.float32
        ) * jnp.sqrt(jnp.maximum(variance, 0.0))
        estimate = jnp.ceil(
            jnp.asarray(config.respawn_safety_factor, dtype=jnp.float32) * upper
        ).astype(jnp.int32)
        return jnp.clip(
            estimate,
            config.minimum_respawn_delay,
            config.maximum_respawn_delay,
        )

    lower_censored_estimate = safety_estimate(
        count,
        state.respawn_mean[safe_channel],
        state.respawn_m2[safe_channel],
    )
    # Consecutive absence-to-presence observations enter this same population
    # as exact values. Other observations contribute only their causal lower
    # bounds. Keeping one prespecified population avoids switching to the
    # policy-conditioned subset of locations that happened to remain visible.
    # The resulting schedule is deliberately early/conservative; visible-miss
    # retry backoff corrects it online without imputing hidden delays.
    return jnp.where(
        count >= config.minimum_respawn_samples,
        lower_censored_estimate,
        jnp.asarray(config.initial_retry_delay, dtype=jnp.int32),
    )


def _merge_channel_samples(
    count: Array,
    mean: Array,
    m2: Array,
    channels: Array,
    samples: Array,
    sample_mask: Array,
) -> tuple[Array, Array, Array]:
    """Merge visible scalar samples into per-channel Welford populations."""
    raw_indicators = jax.nn.one_hot(
        channels,
        count.shape[0],
        dtype=jnp.float32,
    ) * sample_mask[:, None].astype(jnp.float32)
    sample_ranks = jnp.cumsum(
        raw_indicators.astype(jnp.int32),
        axis=0,
    )
    remaining_capacity = (
        jnp.asarray(_INT32_MAX, dtype=jnp.int32)
        - jnp.asarray(count, dtype=jnp.int32)
    )
    indicators = raw_indicators * (
        sample_ranks <= remaining_capacity[None, :]
    ).astype(jnp.float32)
    batch_count = jnp.sum(indicators, axis=0).astype(jnp.int32)
    batch_sum = jnp.sum(indicators * samples[:, None], axis=0)
    batch_sum_squares = jnp.sum(
        indicators * jnp.square(samples[:, None]),
        axis=0,
    )
    safe_batch_count = jnp.maximum(batch_count, 1).astype(jnp.float32)
    batch_mean = batch_sum / safe_batch_count
    batch_m2 = jnp.maximum(
        batch_sum_squares - jnp.square(batch_sum) / safe_batch_count,
        0.0,
    )
    combined_count = count + batch_count
    safe_combined_count = jnp.maximum(combined_count, 1).astype(jnp.float32)
    delta = batch_mean - mean
    combined_mean = mean + (
        delta * batch_count.astype(jnp.float32) / safe_combined_count
    )
    cross_m2 = (
        jnp.square(delta)
        * count.astype(jnp.float32)
        * batch_count.astype(jnp.float32)
        / safe_combined_count
    )
    combined_m2 = m2 + batch_m2 + cross_m2
    has_batch = batch_count > 0
    return (
        combined_count,
        jnp.where(has_batch, combined_mean, mean),
        jnp.where(has_batch, combined_m2, m2),
    )


def _integrate_observation(
    state: CausalMapForagerState,
    observation: Any,
    config: CausalMapForagerConfig,
) -> tuple[CausalMapForagerState, Array, Array]:
    """Project an egocentric image into the relative map and learn reappearance."""
    image = _image(observation)
    _validate_static_observation_shape(image, config)
    aperture_h, aperture_w, _ = image.shape
    center_y, center_x = aperture_h // 2, aperture_w // 2
    active = jnp.sum(image, axis=-1) > 0.5
    channels = jnp.argmax(image, axis=-1).astype(jnp.int32)
    rows, cols = jnp.meshgrid(
        jnp.arange(aperture_h, dtype=jnp.int32),
        jnp.arange(aperture_w, dtype=jnp.int32),
        indexing="ij",
    )
    ys = jnp.mod(
        state.position[1] + rows - center_y,
        config.height,
    ).reshape(-1)
    xs = jnp.mod(
        state.position[0] + cols - center_x,
        config.width,
    ).reshape(-1)
    flat_active = active.reshape(-1)
    flat_channels = channels.reshape(-1)
    old_channel = state.cell_channel[ys, xs]
    old_collection = state.cell_collection_step[ys, xs]
    old_ready = state.cell_ready_step[ys, xs]
    old_retry = state.cell_retry_count[ys, xs]
    old_last_absent = state.cell_last_absent_step[ys, xs]
    reappeared = flat_active & (old_collection >= 0)
    upper_elapsed = (state.step_count - old_collection).astype(jnp.float32)
    lower_elapsed = jnp.maximum(
        old_last_absent + 1 - old_collection,
        1,
    ).astype(jnp.float32)
    interval_width = upper_elapsed - lower_elapsed
    exact_reappearance = reappeared & (
        interval_width
        <= jnp.asarray(config.maximum_exact_interval_width, dtype=jnp.float32)
    )
    # Exact consecutive observations use their point interval.  A reappearance
    # after an observation gap contributes only the causal lower bound supplied
    # by the last observed absence; the policy's later return time is discarded.
    elapsed_evidence = jnp.where(
        exact_reappearance,
        upper_elapsed,
        lower_elapsed,
    )
    sample_channels = jnp.where(old_channel >= 0, old_channel, flat_channels)

    # Combine conservative lower-censored evidence with lifetime scheduling
    # statistics, and retain a stronger population for exact consecutive
    # absence-to-presence observations.
    respawn_count, respawn_mean, respawn_m2 = _merge_channel_samples(
        state.respawn_count,
        state.respawn_mean,
        state.respawn_m2,
        sample_channels,
        elapsed_evidence,
        reappeared,
    )
    (
        respawn_exact_count,
        respawn_exact_mean,
        respawn_exact_m2,
    ) = _merge_channel_samples(
        state.respawn_exact_count,
        state.respawn_exact_mean,
        state.respawn_exact_m2,
        sample_channels,
        upper_elapsed,
        exact_reappearance,
    )

    visible_retry_miss = (
        ~flat_active
        & (old_collection >= 0)
        & (old_ready >= 0)
        & (state.step_count >= old_ready)
    )
    next_retry = _increment_retry_count(old_retry, config)
    retry_delay = _retry_delay(next_retry, config)
    missed_ready = _saturating_add_int32(state.step_count, retry_delay)

    cell_channel = state.cell_channel.at[ys, xs].set(
        jnp.where(flat_active, flat_channels, old_channel)
    )
    cell_active = state.cell_active.at[ys, xs].set(flat_active)
    collection_step = state.cell_collection_step.at[ys, xs].set(
        jnp.where(reappeared, -1, old_collection)
    )
    ready_step = state.cell_ready_step.at[ys, xs].set(
        jnp.where(
            reappeared,
            -1,
            jnp.where(visible_retry_miss, missed_ready, old_ready),
        )
    )
    retry_count = state.cell_retry_count.at[ys, xs].set(
        jnp.where(
            reappeared,
            0,
            jnp.where(visible_retry_miss, next_retry, old_retry),
        )
    )
    last_seen = state.cell_last_seen_step.at[ys, xs].set(state.step_count)
    last_absent = state.cell_last_absent_step.at[ys, xs].set(
        jnp.where(~flat_active, state.step_count, old_last_absent)
    )
    learned_count = jnp.sum(reappeared, dtype=jnp.int32)
    visible_retry_count = jnp.sum(visible_retry_miss, dtype=jnp.int32)
    return state._replace(
        cell_channel=cell_channel,
        cell_active=cell_active,
        cell_collection_step=collection_step,
        cell_ready_step=ready_step,
        cell_retry_count=retry_count,
        cell_last_seen_step=last_seen,
        cell_last_absent_step=last_absent,
        respawn_count=respawn_count,
        respawn_mean=respawn_mean,
        respawn_m2=respawn_m2,
        respawn_exact_count=respawn_exact_count,
        respawn_exact_mean=respawn_exact_mean,
        respawn_exact_m2=respawn_exact_m2,
    ), learned_count, visible_retry_count


def _channel_values(
    state: CausalMapForagerState,
    config: CausalMapForagerConfig,
) -> Array:
    return jnp.where(
        state.reward_count > 0,
        state.reward_sum / jnp.maximum(state.reward_count, 1).astype(jnp.float32),
        jnp.asarray(config.optimistic_unknown_reward, dtype=jnp.float32),
    )


def _negative_channels(
    state: CausalMapForagerState,
    config: CausalMapForagerConfig,
) -> Array:
    return (state.reward_count > 0) & (
        _channel_values(state, config) < config.negative_reward_threshold
    )


def _toroidal_distance_grid(
    position: Array,
    config: CausalMapForagerConfig,
) -> Array:
    ys = jnp.arange(config.height, dtype=jnp.int32)[:, None]
    xs = jnp.arange(config.width, dtype=jnp.int32)[None, :]
    dx_forward = jnp.mod(xs - position[0], config.width)
    dx_reverse = jnp.mod(position[0] - xs, config.width)
    dy_forward = jnp.mod(ys - position[1], config.height)
    dy_reverse = jnp.mod(position[1] - ys, config.height)
    return (
        jnp.minimum(dx_forward, dx_reverse) + jnp.minimum(dy_forward, dy_reverse)
    )


def _safe_distance_grid(
    source: Array,
    negative_cells: Array,
    config: CausalMapForagerConfig,
) -> Array:
    """Return exact toroidal shortest-path distances around learned negatives."""
    infinity = jnp.asarray(config.height * config.width + 1, dtype=jnp.int32)
    source_x, source_y = source[0], source[1]
    passable = (~negative_cells).at[source_y, source_x].set(True)
    distances = jnp.full(config.world_shape, infinity, dtype=jnp.int32)
    distances = distances.at[source_y, source_x].set(0)

    def relax(current: Array) -> Array:
        neighbor_minimum = jnp.minimum(
            jnp.minimum(
                jnp.roll(current, 1, axis=0),
                jnp.roll(current, -1, axis=0),
            ),
            jnp.minimum(
                jnp.roll(current, 1, axis=1),
                jnp.roll(current, -1, axis=1),
            ),
        )
        candidate = jnp.minimum(current, neighbor_minimum + 1)
        return jnp.where(passable, candidate, infinity)

    # Synchronous relaxation discovers every cell at its exact graph distance:
    # after iteration k, all paths of at most k edges have been considered.
    # A shortest simple path visits at most V cells, so V - 1 iterations reach
    # every reachable cell and one final iteration detects the fixed point.
    # The V-iteration cap is also the former unconditional loop bound, making
    # this fail-safe result identical even if early convergence does not occur.
    maximum_iterations = config.height * config.width

    def not_fixed(carry: tuple[Array, Array, Array]) -> Array:
        _, changed, iteration = carry
        return changed & (iteration < maximum_iterations)

    def relax_once(
        carry: tuple[Array, Array, Array],
    ) -> tuple[Array, Array, Array]:
        current, _, iteration = carry
        updated = relax(current)
        return updated, jnp.any(updated != current), iteration + 1

    fixed_distances, _, _ = jax.lax.while_loop(
        not_fixed,
        relax_once,
        (
            distances,
            jnp.asarray(True),
            jnp.asarray(0, dtype=jnp.int32),
        ),
    )
    return fixed_distances


def _choose_action(
    state: CausalMapForagerState,
    config: CausalMapForagerConfig,
) -> tuple[CausalMapForagerState, Array]:
    """Choose a safe one-step move toward the best learned available cell."""
    key, target_key, action_key, exploration_key = jr.split(state.rng_key, 4)
    channel_values = _channel_values(state, config)
    negative_channels = _negative_channels(state, config)
    safe_channel = jnp.maximum(state.cell_channel, 0)
    known = state.cell_channel >= 0
    negative_cells = known & negative_channels[safe_channel]
    predicted_ready = (
        (state.cell_collection_step >= 0)
        & (state.cell_ready_step >= 0)
        & (state.step_count >= state.cell_ready_step)
    )
    available = state.cell_active | predicted_ready
    path_distances = _safe_distance_grid(
        state.position,
        negative_cells,
        config,
    )
    path_infinity = jnp.asarray(
        config.height * config.width + 1,
        dtype=jnp.int32,
    )
    reachable = path_distances < path_infinity
    candidate = known & available & ~negative_cells & reachable
    distances = path_distances.astype(jnp.float32)
    target_noise = jr.uniform(
        target_key,
        state.cell_channel.shape,
        dtype=jnp.float32,
    ) * jnp.asarray(config.tie_break_scale, dtype=jnp.float32)
    cell_values = channel_values[safe_channel]
    target_scores = (
        cell_values
        - jnp.asarray(config.distance_cost, dtype=jnp.float32) * distances
        - jnp.asarray(config.retry_penalty, dtype=jnp.float32)
        * state.cell_retry_count.astype(jnp.float32)
        + target_noise
    )
    target_scores = jnp.where(candidate, target_scores, -jnp.inf)
    has_exploitation_target = jnp.any(candidate)
    exploitation_flat = jnp.argmax(target_scores.reshape(-1))
    exploitation_target = jnp.asarray(
        (
            exploitation_flat % config.width,
            exploitation_flat // config.width,
        ),
        dtype=jnp.int32,
    )

    unobserved = state.cell_last_seen_step < 0
    unknown_reachable = unobserved & ~negative_cells & reachable
    has_unknown_reachable = jnp.any(unknown_reachable)
    safe_reachable = ~negative_cells & reachable
    coverage_candidate = jnp.where(
        has_unknown_reachable,
        unknown_reachable,
        safe_reachable,
    )
    coverage_scores = (
        -state.visit_count.astype(jnp.float32)
        - jnp.asarray(config.distance_cost, dtype=jnp.float32) * distances
        + target_noise
    )
    coverage_scores = jnp.where(coverage_candidate, coverage_scores, -jnp.inf)
    has_coverage_target = jnp.any(coverage_candidate)
    coverage_flat = jnp.argmax(coverage_scores.reshape(-1))
    coverage_target = jnp.asarray(
        (coverage_flat % config.width, coverage_flat // config.width),
        dtype=jnp.int32,
    )
    explore = jr.uniform(exploration_key, (), dtype=jnp.float32) < jnp.asarray(
        config.exploration_probability,
        dtype=jnp.float32,
    )
    use_coverage = has_coverage_target & (explore | ~has_exploitation_target)
    target = jnp.where(use_coverage, coverage_target, exploitation_target)
    has_target = jnp.where(
        use_coverage,
        has_coverage_target,
        has_exploitation_target,
    )

    neighbor_positions = jnp.mod(
        state.position[None, :] + _DIRECTIONS,
        jnp.asarray((config.width, config.height), dtype=jnp.int32),
    )
    neighbor_x = neighbor_positions[:, 0]
    neighbor_y = neighbor_positions[:, 1]
    neighbor_negative = negative_cells[neighbor_y, neighbor_x]
    all_neighbors_negative = jnp.all(neighbor_negative)
    allowed = ~neighbor_negative | all_neighbors_negative

    target_distance_grid = _safe_distance_grid(
        target,
        negative_cells,
        config,
    )
    target_distances_int = target_distance_grid[neighbor_y, neighbor_x]
    target_distances = target_distances_int.astype(jnp.float32)
    route_available = jnp.any(
        allowed & (target_distances_int < path_infinity)
    )
    neighbor_visits = state.visit_count[neighbor_y, neighbor_x].astype(jnp.float32)
    reverse_action = jnp.mod(state.last_action + 2, 4)
    reverse_cost = (
        (state.last_action >= 0)
        & (jnp.arange(4, dtype=jnp.int32) == reverse_action)
    ).astype(jnp.float32) * jnp.asarray(
        config.reverse_action_penalty,
        dtype=jnp.float32,
    )
    action_noise = jr.uniform(action_key, (4,), dtype=jnp.float32) * jnp.asarray(
        config.tie_break_scale,
        dtype=jnp.float32,
    )
    pursuit_cost = (
        target_distances
        + jnp.asarray(config.visit_penalty, dtype=jnp.float32)
        * jnp.log1p(neighbor_visits)
        + reverse_cost
        + action_noise
    )
    exploration_cost = (
        neighbor_visits
        + reverse_cost
        + action_noise
    )
    costs = jnp.where(has_target & route_available, pursuit_cost, exploration_cost)
    costs = jnp.where(allowed, costs, jnp.inf)
    action = jnp.argmin(costs).astype(jnp.int32)

    destination = neighbor_positions[action]
    destination_y, destination_x = destination[1], destination[0]
    destination_channel = state.cell_channel[destination_y, destination_x]
    destination_predicted = predicted_ready[destination_y, destination_x]
    destination_expected_active = (
        state.cell_active[destination_y, destination_x] | destination_predicted
    ) & (destination_channel >= 0)
    return state._replace(
        rng_key=key,
        last_action=action,
        last_target_channel=destination_channel,
        last_target_position=destination,
        last_target_expected_active=destination_expected_active,
    ), action


def causal_map_start(
    observation: Any,
    config: CausalMapForagerConfig,
    seed: int | Array,
) -> tuple[CausalMapForagerState, Array]:
    """Initialize from the first raw observation and choose the first action."""
    image = _image(observation)
    _validate_static_observation_shape(image, config)
    state = _empty_state(int(image.shape[-1]), config, seed)
    state = state._replace(
        visit_count=state.visit_count.at[0, 0].set(1),
    )
    state, _, _ = _integrate_observation(state, observation, config)
    return _choose_action(state, config)


def causal_map_step(
    state: CausalMapForagerState,
    reward: Array,
    observation: Any,
    config: CausalMapForagerConfig,
) -> tuple[CausalMapForagerState, Array, CausalMapStepDiagnostics]:
    """Consume one ordinary transition and choose the next action.

    The only transition inputs are the reward, current observation, and state
    generated from the policy's own prior inputs/actions.
    """
    reward = jnp.asarray(reward, dtype=jnp.float32)
    checked_step_count = _require_unsaturated_step_count(state.step_count)
    position = jnp.mod(
        state.position + _DIRECTIONS[state.last_action],
        jnp.asarray((config.width, config.height), dtype=jnp.int32),
    )
    step_count = _saturating_add_int32(
        checked_step_count,
        jnp.asarray(1, dtype=jnp.int32),
    )
    next_visit_count = _saturating_add_int32(
        state.visit_count[position[1], position[0]],
        jnp.asarray(1, dtype=jnp.int32),
    )
    visit_count = state.visit_count.at[position[1], position[0]].set(
        next_visit_count
    )
    state = state._replace(
        step_count=step_count,
        position=position,
        visit_count=visit_count,
    )

    valid_channel = state.last_target_channel >= 0
    observed_reward = (
        valid_channel
        & jnp.isfinite(reward)
        & (jnp.abs(reward) > config.reward_observation_epsilon)
    )
    safe_channel = jnp.maximum(state.last_target_channel, 0)
    reward_sum = state.reward_sum.at[safe_channel].add(
        jnp.where(observed_reward, reward, 0.0)
    )
    next_reward_count = _saturating_add_int32(
        state.reward_count[safe_channel],
        observed_reward.astype(jnp.int32),
    )
    reward_count = state.reward_count.at[safe_channel].set(
        next_reward_count
    )

    learned_delay = _estimated_respawn_delay(state, safe_channel, config)
    current_y, current_x = position[1], position[0]
    cell_active = state.cell_active.at[current_y, current_x].set(
        jnp.where(observed_reward, False, state.cell_active[current_y, current_x])
    )
    collection_step = state.cell_collection_step.at[current_y, current_x].set(
        jnp.where(
            observed_reward,
            step_count,
            state.cell_collection_step[current_y, current_x],
        )
    )
    ready_step = state.cell_ready_step.at[current_y, current_x].set(
        jnp.where(
            observed_reward,
            _saturating_add_int32(step_count, learned_delay),
            state.cell_ready_step[current_y, current_x],
        )
    )
    retry_count = state.cell_retry_count.at[current_y, current_x].set(
        jnp.where(observed_reward, 0, state.cell_retry_count[current_y, current_x])
    )
    state = state._replace(
        reward_sum=reward_sum,
        reward_count=reward_count,
        cell_active=cell_active,
        cell_collection_step=collection_step,
        cell_ready_step=ready_step,
        cell_retry_count=retry_count,
    )
    state, learned_respawn, visible_retry_count = _integrate_observation(
        state,
        observation,
        config,
    )
    retry_miss = visible_retry_count > 0
    state, action = _choose_action(state, config)
    negative_channels = _negative_channels(state, config)
    known_channels = jnp.maximum(state.cell_channel, 0)
    diagnostics = CausalMapStepDiagnostics(
        learned_reward=observed_reward,
        learned_respawn=learned_respawn,
        retry_miss=retry_miss,
        known_cells=jnp.sum(state.cell_channel >= 0, dtype=jnp.int32),
        known_negative_cells=jnp.sum(
            (state.cell_channel >= 0) & negative_channels[known_channels],
            dtype=jnp.int32,
        ),
    )
    return state, action, diagnostics


def validate_causal_map_state(
    state: CausalMapForagerState,
    config: CausalMapForagerConfig,
    *,
    observation_channels: int | None = None,
) -> None:
    """Validate exact dtype, shape, domain, and cross-field state invariants."""
    if not isinstance(state, CausalMapForagerState):
        raise ValueError("state must be a CausalMapForagerState")
    if not isinstance(config, CausalMapForagerConfig):
        raise ValueError("config must be a CausalMapForagerConfig")
    arrays: dict[str, np.ndarray[Any, Any]] = {}
    for name, value in state._asdict().items():
        if name == "rng_key":
            try:
                array = np.asarray(jr.key_data(value))
            except (TypeError, ValueError) as exc:
                raise ValueError("rng_key must be a valid JAX PRNG key") from exc
            if array.shape != (2,) or array.dtype != np.dtype(np.uint32):
                raise ValueError("rng_key must contain exactly two uint32 words")
        else:
            array = np.asarray(value)
            expected_dtype = np.dtype(
                np.uint32
                if name in _STATE_UINT32_FIELDS
                else np.int32
                if name in _STATE_INTEGER_FIELDS
                else np.bool_
                if name in _STATE_BOOLEAN_FIELDS
                else np.float32
            )
            if array.dtype != expected_dtype:
                raise ValueError(
                    f"{name} must have dtype {expected_dtype}, found {array.dtype}"
                )
        arrays[name] = array

    scalar_fields = (
        "step_count",
        "initial_seed",
        "last_action",
        "last_target_channel",
        "last_target_expected_active",
    )
    for name in scalar_fields:
        if arrays[name].shape != ():
            raise ValueError(f"{name} must be a scalar")
    map_shape = config.world_shape
    map_fields = (
        "cell_channel",
        "cell_active",
        "cell_collection_step",
        "cell_ready_step",
        "cell_retry_count",
        "cell_last_seen_step",
        "cell_last_absent_step",
        "visit_count",
    )
    for name in map_fields:
        if arrays[name].shape != map_shape:
            raise ValueError(f"{name} must have shape {map_shape}")
    channel_fields = (
        "reward_sum",
        "reward_count",
        "respawn_count",
        "respawn_mean",
        "respawn_m2",
        "respawn_exact_count",
        "respawn_exact_mean",
        "respawn_exact_m2",
    )
    if arrays["reward_sum"].ndim != 1:
        raise ValueError("reward_sum must be one-dimensional")
    channel_count = arrays["reward_sum"].shape[0]
    if channel_count < 1:
        raise ValueError("state must contain at least one observation channel")
    if observation_channels is not None and (
        isinstance(observation_channels, bool)
        or not isinstance(observation_channels, (int, np.integer))
        or observation_channels < 1
    ):
        raise ValueError("observation_channels must be a positive integer")
    if observation_channels is not None and channel_count != int(observation_channels):
        raise ValueError("state channel count does not match observation")
    for name in channel_fields:
        if arrays[name].shape != (channel_count,):
            raise ValueError(f"{name} must have shape ({channel_count},)")
    if arrays["position"].shape != (2,) or arrays["last_target_position"].shape != (2,):
        raise ValueError("position fields must have shape (2,)")
    for name in ("position", "last_target_position"):
        x, y = (int(value) for value in arrays[name])
        if not (0 <= x < config.width and 0 <= y < config.height):
            raise ValueError(f"{name} lies outside configured toroidal world")

    step_count = int(arrays["step_count"])
    if step_count < 0:
        raise ValueError("step_count must be non-negative")
    initial_seed = int(arrays["initial_seed"])
    if not 0 <= initial_seed <= np.iinfo(np.uint32).max:
        raise ValueError("initial_seed must be uint32-compatible")
    last_action = int(arrays["last_action"])
    if last_action not in (-1, 0, 1, 2, 3):
        raise ValueError("last_action must be -1 or one of the four public actions")
    if step_count > 0 and last_action < 0:
        raise ValueError("a non-initial state must record its previous action")
    last_target_channel = int(arrays["last_target_channel"])
    if not -1 <= last_target_channel < channel_count:
        raise ValueError("last_target_channel contains an invalid channel index")
    if bool(arrays["last_target_expected_active"]) and last_target_channel < 0:
        raise ValueError("an expected-active target must have a known channel")

    channels = arrays["cell_channel"]
    if np.any((channels < -1) | (channels >= channel_count)):
        raise ValueError("cell_channel contains an invalid channel index")
    if np.any(arrays["cell_active"] & (channels < 0)):
        raise ValueError("active cells must have a known channel")

    if (
        np.any(arrays["reward_count"] < 0)
        or np.any(arrays["respawn_count"] < 0)
        or np.any(arrays["respawn_exact_count"] < 0)
    ):
        raise ValueError("learning counts must be non-negative")
    if (
        np.any(arrays["cell_retry_count"] < 0)
        or np.any(arrays["cell_retry_count"] > config.maximum_retry_exponent)
        or np.any(arrays["visit_count"] < 0)
    ):
        raise ValueError("map counts must be non-negative")
    if np.any(arrays["reward_count"] > step_count):
        raise ValueError("reward_count cannot exceed step_count")
    if int(np.sum(arrays["reward_count"], dtype=np.int64)) > step_count:
        raise ValueError("total reward_count cannot exceed step_count")
    maximum_reappearances = step_count * config.height * config.width
    for name in ("respawn_count", "respawn_exact_count"):
        if np.any(arrays[name] > maximum_reappearances):
            raise ValueError(f"{name} exceeds the causal map/step bound")
        if int(np.sum(arrays[name], dtype=np.int64)) > maximum_reappearances:
            raise ValueError(f"total {name} exceeds the causal map/step bound")
    if np.any(arrays["respawn_exact_count"] > arrays["respawn_count"]):
        raise ValueError("exact respawn counts cannot exceed all reappearance counts")
    if np.any(arrays["visit_count"] > min(step_count + 1, _INT32_MAX)):
        raise ValueError("visit_count cannot exceed the number of visited states")
    total_visits = int(np.sum(arrays["visit_count"], dtype=np.int64))
    if step_count < _INT32_MAX and total_visits != step_count + 1:
        raise ValueError("visit_count total must equal step_count + 1")
    if step_count == _INT32_MAX and total_visits < _INT32_MAX:
        raise ValueError("saturated step_count requires at least int32-max visits")

    timestamp_fields = (
        "cell_collection_step",
        "cell_ready_step",
        "cell_last_seen_step",
        "cell_last_absent_step",
    )
    for name in timestamp_fields:
        if np.any(arrays[name] < -1):
            raise ValueError(f"{name} timestamps must be -1 or non-negative")
    for name in (
        "cell_collection_step",
        "cell_last_seen_step",
        "cell_last_absent_step",
    ):
        if np.any(arrays[name] > step_count):
            raise ValueError(f"{name} cannot exceed step_count")
    collection = arrays["cell_collection_step"]
    ready = arrays["cell_ready_step"]
    retry = arrays["cell_retry_count"]
    has_collection = collection >= 0
    if np.any((ready >= 0) != has_collection):
        raise ValueError("collection and ready timestamps must be present together")
    if np.any(has_collection & (ready <= collection)):
        raise ValueError("ready timestamps must follow their collection timestamps")
    if np.any(has_collection & arrays["cell_active"]):
        raise ValueError("a collected cell cannot simultaneously be active")
    if np.any(has_collection & (channels < 0)):
        raise ValueError("collected cells must have a known channel")
    if np.any(~has_collection & (retry != 0)):
        raise ValueError("retry counts require a pending collected cell")
    last_seen = arrays["cell_last_seen_step"]
    last_absent = arrays["cell_last_absent_step"]
    if np.any((last_absent >= 0) & (last_seen < last_absent)):
        raise ValueError("last absence cannot follow the last observation")
    if np.any((channels >= 0) & (last_seen < 0)):
        raise ValueError("known cells must have an observation timestamp")
    position_x, position_y = (int(value) for value in arrays["position"])
    if arrays["visit_count"][position_y, position_x] < 1:
        raise ValueError("current position must have a positive visit count")
    if last_seen[position_y, position_x] != step_count:
        raise ValueError("current position must be observed at step_count")
    expected_cell_active = last_seen > last_absent
    if not np.array_equal(arrays["cell_active"], expected_cell_active):
        raise ValueError(
            "cell_active must exactly match whether the last observation "
            "followed the last absence"
        )
    if np.any(has_collection & (last_absent < collection)):
        raise ValueError("collected cells must be observed absent at collection time")

    if last_action >= 0:
        direction_x, direction_y = _DIRECTION_STEPS[last_action]
        expected_target = np.asarray(
            (
                (int(arrays["position"][0]) + direction_x) % config.width,
                (int(arrays["position"][1]) + direction_y) % config.height,
            ),
            dtype=np.int32,
        )
        if not np.array_equal(arrays["last_target_position"], expected_target):
            raise ValueError(
                "last_target_position must be the destination of last_action"
            )
        target_x, target_y = (int(value) for value in expected_target)
        expected_channel = int(channels[target_y, target_x])
        if last_target_channel != expected_channel:
            raise ValueError(
                "last_target_channel must match the destination map cell"
            )
        predicted_ready = bool(
            collection[target_y, target_x] >= 0
            and ready[target_y, target_x] >= 0
            and step_count >= ready[target_y, target_x]
        )
        expected_active = bool(
            expected_channel >= 0
            and (
                arrays["cell_active"][target_y, target_x]
                or predicted_ready
            )
        )
        if bool(arrays["last_target_expected_active"]) != expected_active:
            raise ValueError(
                "last_target_expected_active does not match destination state"
            )
    elif (
        last_target_channel != -1
        or bool(arrays["last_target_expected_active"])
        or not np.array_equal(arrays["last_target_position"], arrays["position"])
    ):
        raise ValueError("an action-free initial state cannot declare a target")

    for name in (
        "reward_sum",
        "respawn_mean",
        "respawn_m2",
        "respawn_exact_mean",
        "respawn_exact_m2",
    ):
        if not np.all(np.isfinite(arrays[name])):
            raise ValueError(f"{name} must remain finite")
    if np.any(arrays["respawn_m2"] < 0.0) or np.any(
        arrays["respawn_exact_m2"] < 0.0
    ):
        raise ValueError("respawn M2 statistics must be non-negative")
    if np.any((arrays["reward_count"] == 0) & (arrays["reward_sum"] != 0.0)):
        raise ValueError("zero-count reward statistics must have zero sums")
    for prefix in ("respawn", "respawn_exact"):
        empty = arrays[f"{prefix}_count"] == 0
        if np.any(
            empty
            & (
                (arrays[f"{prefix}_mean"] != 0.0)
                | (arrays[f"{prefix}_m2"] != 0.0)
            )
        ):
            raise ValueError(f"zero-count {prefix} statistics must be zero")
        if np.any(
            (arrays[f"{prefix}_count"] <= 1)
            & (arrays[f"{prefix}_m2"] != 0.0)
        ):
            raise ValueError(f"{prefix} M2 must be zero with at most one sample")
        populated = ~empty
        if np.any(populated & (arrays[f"{prefix}_mean"] < 1.0)):
            raise ValueError(f"populated {prefix} means must be at least one step")
        if np.any(populated & (arrays[f"{prefix}_mean"] > step_count)):
            raise ValueError(f"populated {prefix} means cannot exceed step_count")
    exact_population = arrays["respawn_exact_count"] == arrays["respawn_count"]
    overall_mean_bits = arrays["respawn_mean"].view(np.uint32)
    exact_mean_bits = arrays["respawn_exact_mean"].view(np.uint32)
    overall_m2_bits = arrays["respawn_m2"].view(np.uint32)
    exact_m2_bits = arrays["respawn_exact_m2"].view(np.uint32)
    if np.any(
        exact_population
        & (
            (overall_mean_bits != exact_mean_bits)
            | (overall_m2_bits != exact_m2_bits)
        )
    ):
        raise ValueError(
            "equal exact/all respawn populations must have bit-identical "
            "statistics"
        )


def causal_map_state_to_dict(
    state: CausalMapForagerState,
    config: CausalMapForagerConfig,
) -> dict[str, Any]:
    """Serialize a validated state without host-specific paths or objects."""
    validate_causal_map_state(state, config)
    fields: dict[str, Any] = {}
    for name, value in state._asdict().items():
        if name == "rng_key":
            array = np.asarray(jr.key_data(value), dtype=np.uint32)
        else:
            array = np.asarray(value)
        fields[name] = array.tolist()
    return {
        "schema": CAUSAL_MAP_STATE_SCHEMA,
        "config": config.to_dict(),
        "config_sha256": config.fingerprint(),
        "dtypes": dict(_STATE_SERIALIZED_DTYPES),
        "fields": fields,
    }


def _raw_json_array(
    raw: Any,
    *,
    name: str,
    shape: tuple[int, ...],
    kind: str,
) -> None:
    """Validate a JSON field without relying on coercive NumPy conversion."""
    def require_json_shape(value: Any, dimensions: tuple[int, ...]) -> None:
        if not dimensions:
            if isinstance(value, (list, tuple, Mapping)):
                raise ValueError(f"serialized {name} must contain JSON scalars")
            return
        if type(value) is not list or len(value) != dimensions[0]:
            raise ValueError(
                f"serialized {name} must use JSON arrays with shape {shape}"
            )
        for child in value:
            require_json_shape(child, dimensions[1:])

    require_json_shape(raw, shape)
    try:
        array = np.asarray(raw, dtype=object)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"serialized {name} is not rectangular") from exc
    if array.shape != shape:
        raise ValueError(f"serialized {name} must have shape {shape}")

    for value in array.reshape(-1):
        if kind == "int32":
            valid = (
                type(value) is int
                and np.iinfo(np.int32).min <= value <= np.iinfo(np.int32).max
            )
        elif kind == "uint32-key-data":
            valid = type(value) is int and 0 <= value <= np.iinfo(np.uint32).max
        elif kind == "uint32":
            valid = type(value) is int and 0 <= value <= np.iinfo(np.uint32).max
        elif kind == "bool":
            valid = type(value) is bool
        elif kind == "float32":
            valid = type(value) is float and math.isfinite(value)
            if valid:
                valid = (
                    abs(value) <= np.finfo(np.float32).max
                    and float(np.float32(value)) == value
                )
        else:  # pragma: no cover - internal schema table is closed
            raise RuntimeError(f"unknown serialized state kind {kind!r}")
        if not valid:
            raise ValueError(
                f"serialized {name} contains a value incompatible with {kind}"
            )


def _require_raw_json_value(value: Any, *, path: str) -> None:
    """Reject Python-only containers and scalar types in serialized payloads."""
    if type(value) is dict:
        for key, child in value.items():
            if type(key) is not str:
                raise ValueError(f"{path} JSON object keys must be strings")
            _require_raw_json_value(child, path=f"{path}.{key}")
        return
    if type(value) is list:
        for index, child in enumerate(value):
            _require_raw_json_value(child, path=f"{path}[{index}]")
        return
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    raise ValueError(f"{path} must contain only raw JSON values")


def causal_map_state_from_dict(
    payload: Mapping[str, Any],
    config: CausalMapForagerConfig,
) -> CausalMapForagerState:
    """Restore and validate a state serialized by :func:`causal_map_state_to_dict`."""
    if not isinstance(payload, Mapping):
        raise ValueError("serialized state must be a mapping")
    if not isinstance(config, CausalMapForagerConfig):
        raise ValueError("config must be a CausalMapForagerConfig")
    expected_top_level = {
        "schema",
        "config",
        "config_sha256",
        "dtypes",
        "fields",
    }
    if set(payload) != expected_top_level:
        raise ValueError("serialized state top-level fields do not match the schema")
    if payload.get("schema") != CAUSAL_MAP_STATE_SCHEMA:
        raise ValueError("unsupported causal-map state schema")
    if payload.get("config_sha256") != config.fingerprint():
        raise ValueError("serialized state configuration does not match")
    declared_config_value = payload.get("config")
    _require_raw_json_value(
        declared_config_value,
        path="serialized state config",
    )
    try:
        declared_config = json.dumps(
            declared_config_value,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        expected_config = json.dumps(
            config.to_dict(),
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise ValueError("serialized state config is not canonical JSON") from exc
    if declared_config != expected_config:
        raise ValueError("serialized state embeds a different configuration")
    raw_dtypes = payload.get("dtypes")
    if not isinstance(raw_dtypes, Mapping) or dict(raw_dtypes) != _STATE_SERIALIZED_DTYPES:
        raise ValueError("serialized state dtype table does not match the schema")
    raw_fields = payload.get("fields")
    if not isinstance(raw_fields, Mapping):
        raise ValueError("serialized state fields must be a mapping")
    expected = set(CausalMapForagerState._fields)
    if set(raw_fields) != expected:
        raise ValueError("serialized state fields do not match the schema")

    raw_reward_sum = raw_fields["reward_sum"]
    if not isinstance(raw_reward_sum, list) or not raw_reward_sum:
        raise ValueError("serialized reward_sum must be a non-empty JSON array")
    channel_count = len(raw_reward_sum)
    map_fields = {
        "cell_channel",
        "cell_active",
        "cell_collection_step",
        "cell_ready_step",
        "cell_retry_count",
        "cell_last_seen_step",
        "cell_last_absent_step",
        "visit_count",
    }
    channel_fields = {
        "reward_sum",
        "reward_count",
        "respawn_count",
        "respawn_mean",
        "respawn_m2",
        "respawn_exact_count",
        "respawn_exact_mean",
        "respawn_exact_m2",
    }
    vector_fields = {"position", "last_target_position", "rng_key"}
    for name in CausalMapForagerState._fields:
        shape = (
            config.world_shape
            if name in map_fields
            else (channel_count,)
            if name in channel_fields
            else (2,)
            if name in vector_fields
            else ()
        )
        _raw_json_array(
            raw_fields[name],
            name=name,
            shape=shape,
            kind=_STATE_SERIALIZED_DTYPES[name],
        )

    values: dict[str, Array] = {}
    for name in CausalMapForagerState._fields:
        raw = raw_fields[name]
        if name == "rng_key":
            key_data = jnp.asarray(raw, dtype=jnp.uint32)
            values[name] = jr.wrap_key_data(key_data)
        elif name in _STATE_UINT32_FIELDS:
            values[name] = jnp.asarray(raw, dtype=jnp.uint32)
        elif name in _STATE_INTEGER_FIELDS:
            values[name] = jnp.asarray(raw, dtype=jnp.int32)
        elif name in _STATE_BOOLEAN_FIELDS:
            values[name] = jnp.asarray(raw, dtype=jnp.bool_)
        else:
            values[name] = jnp.asarray(raw, dtype=jnp.float32)
    state = CausalMapForagerState(**values)
    validate_causal_map_state(state, config)
    return state


class CausalMapForagerAgent:
    """Host policy facade over the pure causal-map transition."""

    def __init__(
        self,
        config: CausalMapForagerConfig | None = None,
        *,
        seed: int = 0,
    ) -> None:
        if config is not None and not isinstance(config, CausalMapForagerConfig):
            raise TypeError("config must be a CausalMapForagerConfig")
        self.config = config if config is not None else CausalMapForagerConfig()
        if isinstance(seed, bool) or not isinstance(seed, (int, np.integer)):
            raise ValueError("seed must be a uint32-compatible integer")
        self.seed = int(seed)
        if not 0 <= self.seed <= np.iinfo(np.uint32).max:
            raise ValueError("seed must be a uint32-compatible integer")
        self._state: CausalMapForagerState | None = None

    @property
    def name(self) -> str:
        """Stable benchmark method name."""
        return CAUSAL_MAP_VARIANT_KIND

    @property
    def privileged(self) -> bool:
        """The policy never receives evaluator context."""
        return False

    @property
    def state(self) -> CausalMapForagerState:
        """Current finite planner state."""
        if self._state is None:
            raise RuntimeError("start() must be called before state")
        return self._state

    def start(
        self,
        observation: Any,
        context: ForagerAgentContext | None = None,
    ) -> int:
        """Build the initial relative map and select an action."""
        del context
        _validate_observation_host(observation, self.config)
        self._state, action = causal_map_start(observation, self.config, self.seed)
        return int(action)

    def step(
        self,
        reward: float,
        observation: Any,
        context: ForagerAgentContext | None = None,
    ) -> int:
        """Learn once from the transition and replan."""
        del context
        if self._state is None:
            raise RuntimeError("start() must be called before step()")
        if isinstance(reward, (bool, np.bool_)) or not isinstance(
            reward,
            (int, float, np.integer, np.floating),
        ):
            raise ValueError("reward must be one finite real scalar")
        try:
            reward_value = float(reward)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("reward must be one finite real scalar") from exc
        if (
            not math.isfinite(reward_value)
            or abs(reward_value) > float(np.finfo(np.float32).max)
            or not _finite_float32(reward_value)
        ):
            raise ValueError("reward must be one finite float32 scalar")
        _, _, channels = _validate_observation_host(observation, self.config)
        if channels != self._state.reward_sum.shape[0]:
            raise ValueError(
                "observation channel count changed during the continuing run"
            )
        self._state, action, _ = causal_map_step(
            self._state,
            jnp.asarray(reward_value, dtype=jnp.float32),
            observation,
            self.config,
        )
        return int(action)

    def metadata(self) -> Mapping[str, Any]:
        """Return explicit algorithm and non-privilege provenance."""
        return {
            "name": self.name,
            "privileged": False,
            "seed": self.seed,
            "variant_kind": CAUSAL_MAP_VARIANT_KIND,
            "state_schema": CAUSAL_MAP_STATE_SCHEMA,
            "config": self.config.to_dict(),
            "config_sha256": self.config.fingerprint(),
            "status_claim": "candidate; no SOTA claim without matched-seed evidence",
            "update_semantics": (
                "one causal map/reward/schedule update per transition; no replay"
            ),
            "world_model": {
                "kind": "relative_toroidal_cognitive_map",
                "origin": "arbitrary initial agent location",
                "reward_model": "online empirical mean per observed channel",
                "unknown_value": "optimistic configurable prior",
                "respawn_model": (
                    "channel-agnostic initial retry prior, exponential empty-retry "
                    "backoff on every visible due miss, and one conservative "
                    "population combining exact reappearances with causal lower "
                    "bounds; exact continuously-observed statistics are retained "
                    "as diagnostics without scheduler subset switching"
                ),
                "negative_avoidance": (
                    "exact toroidal shortest-path routing around known learned-negative "
                    "cells, with an explicit all-neighbors-negative fallback"
                ),
                "coverage": (
                    "seeded persistent coverage exploration toward reachable unknown "
                    "or least-visited cells"
                ),
            },
            "nonprivilege_contract": {
                "policy_inputs": [
                    "raw current observation",
                    "current scalar reward",
                    "own previous action",
                    "own finite causal state",
                    "public 4-action and 15x15 toroidal task semantics",
                ],
                "forbidden_inputs": [
                    "ForagerAgentContext",
                    "environment state",
                    "global position",
                    "global object or reward grid",
                    "biome id or task label",
                    "evaluator info",
                    "hidden environment time",
                ],
                "context_consumed": False,
            },
        }

    def state_dict(self) -> dict[str, Any]:
        """Serialize the current validated state."""
        if int(self.state.initial_seed) != self.seed:
            raise ValueError("state initial_seed does not match agent seed")
        return causal_map_state_to_dict(self.state, self.config)

    def load_state_dict(self, payload: Mapping[str, Any]) -> None:
        """Restore a validated state."""
        restored = causal_map_state_from_dict(payload, self.config)
        if int(restored.initial_seed) != self.seed:
            raise ValueError("checkpoint initial_seed does not match agent seed")
        self._state = restored


def causal_map_variant_spec(
    config: CausalMapForagerConfig,
) -> dict[str, Any]:
    """Return a matrix-runner-friendly immutable variant description."""
    if not isinstance(config, CausalMapForagerConfig):
        raise TypeError("config must be a CausalMapForagerConfig")
    return {
        "kind": CAUSAL_MAP_VARIANT_KIND,
        "agent": CAUSAL_MAP_VARIANT_KIND,
        "privileged": False,
        "state_schema": CAUSAL_MAP_STATE_SCHEMA,
        "config": config.to_dict(),
        "config_sha256": config.fingerprint(),
        "implementation": (
            "alberta_framework.benchmarks.causal_map_forager:"
            "CausalMapForagerAgent"
        ),
    }


def _validate_benchmark_contract(
    agent_config: CausalMapForagerConfig,
    benchmark_config: ForagerBenchmarkConfig,
) -> None:
    env = benchmark_config.environment
    if (
        isinstance(benchmark_config.steps, bool)
        or not isinstance(benchmark_config.steps, int)
        or benchmark_config.steps < 1
        or benchmark_config.steps >= _INT32_MAX
    ):
        raise ValueError(
            "causal-map benchmark steps must be a positive int below int32 maximum"
        )
    if (
        isinstance(benchmark_config.jax_chunk_size, bool)
        or not isinstance(benchmark_config.jax_chunk_size, int)
        or benchmark_config.jax_chunk_size < 1
        or benchmark_config.jax_chunk_size >= _INT32_MAX
    ):
        raise ValueError(
            "causal-map jax_chunk_size must be a positive int below int32 maximum"
        )
    if env.preset != "field_of_view" or env.resolved_env_id != "ForagaxTwoBiomeLarge-v1":
        raise ValueError(
            "causal-map variant is defined only for stationary Forager field_of_view"
        )
    if env.resolved_observation_type != "color":
        raise ValueError("causal-map variant requires one-hot color observations")
    if env.reward_delay != 0:
        raise ValueError("causal-map variant currently requires immediate rewards")
    if env.random_shift_max_steps != 0:
        raise ValueError("stationary causal-map protocol forbids random time shifts")
    if env.extra_kwargs:
        raise ValueError("stationary causal-map protocol forbids extra environment kwargs")
    if agent_config.world_shape != (15, 15):
        raise ValueError("ForagaxTwoBiomeLarge-v1 has public world_shape (15, 15)")
    if env.aperture_size == -1:
        raise ValueError("causal-map variant is a partial field-of-view policy")
    if env.aperture_size < 3:
        raise ValueError(
            "causal-map Forager requires an odd aperture of at least 3; "
            "aperture 1 cannot causally identify a collected destination channel"
        )
    if env.aperture_size > min(agent_config.world_shape):
        raise ValueError("aperture cannot exceed the configured world")
    maximum_batch_observations = env.aperture_size * env.aperture_size
    if benchmark_config.steps * maximum_batch_observations >= _INT32_MAX:
        raise ValueError(
            "causal-map horizon and aperture can overflow int32 reappearance counts"
        )


class _LaneMetrics:
    """Bounded host-side metric accumulator for one device lane."""

    def __init__(self, config: ForagerBenchmarkConfig) -> None:
        self.config = config
        self.target_steps = [1]
        self.target_steps.extend(
            range(config.record_every, config.steps + 1, config.record_every)
        )
        if self.target_steps[-1] != config.steps:
            self.target_steps.append(config.steps)
        self.target_steps = sorted(set(self.target_steps))
        self.target_index = 0
        self.curve_steps: list[int] = []
        self.curve_ewm: list[float] = []
        self.curve_window: list[float] = []
        self.reward_tail = np.zeros((0,), dtype=np.float64)
        self.total_reward = 0.0
        self.ewm_total = 0.0
        self.ewm_filter_state = np.zeros((1,), dtype=np.float64)
        self.fov_filter_state = np.zeros((1,), dtype=np.float64)
        self.fov_samples: list[float] = []
        self.final_ewm = math.nan
        self.regret_total = 0.0
        self.regret_count = 0
        self.final_regret = math.nan
        self.all_finite = True

    def add(
        self,
        rewards: np.ndarray,
        regrets: np.ndarray,
        finite: np.ndarray,
        *,
        completed: int,
    ) -> None:
        active = rewards.size
        ewm, self.ewm_filter_state = _adjusted_ewm_chunk(
            rewards,
            decay=self.config.ewm_decay,
            completed_steps=completed,
            filter_state=self.ewm_filter_state,
        )
        fov, self.fov_filter_state = _unadjusted_ema_chunk(
            rewards,
            decay=FORAGER_FOV_EMA_DECAY,
            filter_state=self.fov_filter_state,
        )
        fov_mask = (
            np.arange(completed, completed + active) % FORAGER_FOV_EMA_SUBSAMPLE
            == 0
        )
        self.fov_samples.extend(float(value) for value in fov[fov_mask])
        self.final_ewm = float(ewm[-1])
        self.all_finite = self.all_finite and bool(np.all(finite))
        self.total_reward += float(np.sum(rewards, dtype=np.float64))
        self.ewm_total += float(np.sum(ewm, dtype=np.float64))
        finite_regrets = regrets[np.isfinite(regrets)]
        if finite_regrets.size:
            self.regret_total += float(np.sum(finite_regrets, dtype=np.float64))
            self.regret_count += int(finite_regrets.size)
            self.final_regret = float(regrets[-1])

        combined = np.concatenate((self.reward_tail, rewards))
        prefix = np.concatenate(
            (np.zeros((1,), dtype=np.float64), np.cumsum(combined, dtype=np.float64))
        )
        while (
            self.target_index < len(self.target_steps)
            and self.target_steps[self.target_index] <= completed + active
        ):
            step_number = self.target_steps[self.target_index]
            local_count = step_number - completed
            end = self.reward_tail.size + local_count
            start = max(0, end - self.config.final_window)
            self.curve_steps.append(step_number)
            self.curve_ewm.append(float(ewm[local_count - 1]))
            self.curve_window.append(
                float((prefix[end] - prefix[start]) / (end - start))
            )
            self.target_index += 1
        self.reward_tail = combined[
            -min(self.config.final_window, combined.size) :
        ]


def _make_scan_chunk(
    env: Any,
    params: Any,
    agent_config: CausalMapForagerConfig,
    benchmark_config: ForagerBenchmarkConfig,
) -> Any:
    def scan_chunk(
        initial_carry: tuple[Any, Array, CausalMapForagerState, Array],
        active_steps: Array,
    ) -> tuple[
        tuple[Any, Array, CausalMapForagerState, Array],
        tuple[Array, Array, Array, Array],
    ]:
        def active_step(
            carry: tuple[Any, Array, CausalMapForagerState, Array],
        ) -> tuple[
            tuple[Any, Array, CausalMapForagerState, Array],
            tuple[Array, Array, Array, Array],
        ]:
            env_state, env_key, agent_state, action = carry
            env_key, step_key = jr.split(env_key)
            observation, next_env_state, reward, done, info = env.step(
                step_key,
                env_state,
                action,
                params,
            )
            next_agent_state, next_action, _ = causal_map_step(
                agent_state,
                reward,
                observation,
                agent_config,
            )
            finite = jnp.isfinite(reward) & jnp.all(
                jnp.asarray(
                    (
                        jnp.all(jnp.isfinite(next_agent_state.reward_sum)),
                        jnp.all(jnp.isfinite(next_agent_state.respawn_mean)),
                        jnp.all(jnp.isfinite(next_agent_state.respawn_m2)),
                    )
                )
            )
            return (
                next_env_state,
                env_key,
                next_agent_state,
                next_action,
            ), (
                reward,
                _exact_float32_biome_regret(info),
                done,
                finite,
            )

        def inactive_step(
            carry: tuple[Any, Array, CausalMapForagerState, Array],
        ) -> tuple[
            tuple[Any, Array, CausalMapForagerState, Array],
            tuple[Array, Array, Array, Array],
        ]:
            zero = jnp.asarray(0.0, dtype=jnp.float32)
            return carry, (
                zero,
                zero,
                jnp.asarray(False),
                jnp.asarray(True),
            )

        def body(
            carry: tuple[Any, Array, CausalMapForagerState, Array],
            index: Array,
        ) -> tuple[
            tuple[Any, Array, CausalMapForagerState, Array],
            tuple[Array, Array, Array, Array],
        ]:
            return cast(
                tuple[
                    tuple[Any, Array, CausalMapForagerState, Array],
                    tuple[Array, Array, Array, Array],
                ],
                jax.lax.cond(
                    index < active_steps,
                    active_step,
                    inactive_step,
                    carry,
                ),
            )

        return jax.lax.scan(
            body,
            initial_carry,
            jnp.arange(benchmark_config.jax_chunk_size, dtype=jnp.int32),
        )

    return scan_chunk


def _run_causal_map_lanes(
    agent_config: CausalMapForagerConfig,
    benchmark_config: ForagerBenchmarkConfig,
    seeds: tuple[int, ...],
    *,
    mode: ForagerBatchMode,
    reward_trace_sink_factory: ForagerRewardTraceSinkFactory | None = None,
) -> tuple[tuple[ForagerRunResult, ...], CausalMapForagerState | None]:
    _validate_benchmark_contract(agent_config, benchmark_config)
    cfg = benchmark_config
    trace_sinks = _create_reward_trace_sinks(
        reward_trace_sink_factory,
        seeds,
        steps=cfg.steps,
    )
    overall_started = time.perf_counter()
    env, params = cfg.environment.make()
    seed_values = jnp.asarray(seeds, dtype=jnp.uint32)

    def init_one(
        seed: Array,
    ) -> tuple[Any, Array, CausalMapForagerState, Array]:
        env_key = jr.key(seed)
        env_key, reset_key = jr.split(env_key)
        observation, env_state = env.reset(reset_key, params)
        agent_state, action = causal_map_start(observation, agent_config, seed)
        return env_state, env_key, agent_state, action

    initialize = jax.jit(jax.vmap(init_one))
    carry = initialize(seed_values)
    jax.block_until_ready(carry)  # type: ignore[no-untyped-call]
    seed_chunk = _make_scan_chunk(env, params, agent_config, cfg)
    if mode == "vmap":
        chunk_function = jax.jit(jax.vmap(seed_chunk, in_axes=(0, None)))
    else:

        def strict_chunk(carries: Any, active_steps: Array) -> Any:
            return jax.lax.map(
                lambda lane_carry: seed_chunk(lane_carry, active_steps),
                carries,
            )

        chunk_function = jax.jit(strict_chunk)

    compile_started = time.perf_counter()
    compiled_chunk = chunk_function.lower(
        carry,
        jnp.asarray(cfg.jax_chunk_size, dtype=jnp.int32),
    ).compile()
    compile_duration = time.perf_counter() - compile_started
    metrics = [_LaneMetrics(cfg) for _ in seeds]
    completed = 0
    execution_started = time.perf_counter()
    while completed < cfg.steps:
        active = min(cfg.jax_chunk_size, cfg.steps - completed)
        carry, outputs = compiled_chunk(
            carry,
            jnp.asarray(active, dtype=jnp.int32),
        )
        rewards_device, regrets_device, done_device, finite_device = outputs
        jax.block_until_ready(outputs)  # type: ignore[no-untyped-call]
        raw_rewards = np.asarray(rewards_device[:, :active])
        raw_regrets = np.asarray(regrets_device[:, :active])
        if (
            raw_rewards.dtype != np.dtype(np.float32)
            or raw_regrets.dtype != np.dtype(np.float32)
        ):
            _abort_reward_trace_sinks(trace_sinks)
            raise TypeError("Foragax evaluator outputs must retain exact float32 dtype")
        rewards = raw_rewards.astype(np.float64)
        regrets = raw_regrets.astype(np.float64)
        done = np.asarray(done_device[:, :active], dtype=np.bool_)
        finite = np.asarray(finite_device[:, :active], dtype=np.bool_)
        if np.any(done):
            _abort_reward_trace_sinks(trace_sinks)
            raise RuntimeError("Foragax paper presets must remain continuing")
        for lane, lane_metrics in enumerate(metrics):
            _append_reward_trace(
                trace_sinks,
                lane,
                raw_rewards[lane],
                raw_regrets[lane],
            )
            lane_metrics.add(
                rewards[lane],
                regrets[lane],
                finite[lane],
                completed=completed,
            )
        completed += active
    execution_duration = time.perf_counter() - execution_started
    overall_duration = time.perf_counter() - overall_started
    final_agent_states = carry[2]
    final_leaves = jax.device_get(jax.tree_util.tree_leaves(final_agent_states))
    state_finite = all(
        bool(np.all(np.isfinite(leaf)))
        for leaf in final_leaves
        if jnp.issubdtype(leaf.dtype, jnp.inexact)
    )
    if not state_finite or not all(item.all_finite for item in metrics):
        _abort_reward_trace_sinks(trace_sinks)
        raise FloatingPointError("causal-map Alberta variant produced non-finite values")
    trace_metadata = _finalize_reward_trace_sinks(trace_sinks)

    count = len(seeds)
    aggregate_fps = count * cfg.steps / max(execution_duration, 1e-12)
    effective_seed_fps = cfg.steps / max(execution_duration, 1e-12)
    results: list[ForagerRunResult] = []
    for lane, (seed, lane_metrics) in enumerate(zip(seeds, metrics, strict=True)):
        metadata = dict(CausalMapForagerAgent(agent_config, seed=seed).metadata())
        metadata["environment_rng_schedule"] = (
            FORAGER_ENVIRONMENT_RNG_SCHEDULE
        )
        metadata["environment_rng_schedule_sha256"] = (
            environment_rng_schedule_sha256()
        )
        lane_state = jax.device_get(
            jax.tree_util.tree_map(lambda value: value[lane], final_agent_states)
        )
        lane_reward_sum = np.asarray(lane_state.reward_sum, dtype=np.float64)
        lane_reward_count = np.asarray(lane_state.reward_count, dtype=np.int64)
        lane_respawn_count = np.asarray(lane_state.respawn_count, dtype=np.int64)
        lane_respawn_mean = np.asarray(lane_state.respawn_mean, dtype=np.float64)
        lane_respawn_m2 = np.asarray(lane_state.respawn_m2, dtype=np.float64)
        lane_respawn_exact_count = np.asarray(
            lane_state.respawn_exact_count,
            dtype=np.int64,
        )
        lane_respawn_exact_mean = np.asarray(
            lane_state.respawn_exact_mean,
            dtype=np.float64,
        )
        lane_respawn_exact_m2 = np.asarray(
            lane_state.respawn_exact_m2,
            dtype=np.float64,
        )
        learned_reward_means = [
            (
                float(lane_reward_sum[index] / lane_reward_count[index])
                if lane_reward_count[index] > 0
                else None
            )
            for index in range(lane_reward_count.size)
        ]
        learned_respawn_std = [
            (
                float(
                    math.sqrt(
                        max(
                            0.0,
                            lane_respawn_m2[index]
                            / (lane_respawn_count[index] - 1),
                        )
                    )
                )
                if lane_respawn_count[index] > 1
                else 0.0
            )
            for index in range(lane_respawn_count.size)
        ]
        learned_respawn_exact_std = [
            (
                float(
                    math.sqrt(
                        max(
                            0.0,
                            lane_respawn_exact_m2[index]
                            / (lane_respawn_exact_count[index] - 1),
                        )
                    )
                )
                if lane_respawn_exact_count[index] > 1
                else 0.0
            )
            for index in range(lane_respawn_exact_count.size)
        ]
        lane_cell_channel = np.asarray(lane_state.cell_channel, dtype=np.int32)
        negative_channel_mask = np.asarray(
            [
                count > 0
                and mean is not None
                and mean < agent_config.negative_reward_threshold
                for count, mean in zip(
                    lane_reward_count,
                    learned_reward_means,
                    strict=True,
                )
            ],
            dtype=np.bool_,
        )
        known_mask = lane_cell_channel >= 0
        known_negative_mask = known_mask & negative_channel_mask[
            np.maximum(lane_cell_channel, 0)
        ]
        metadata["final_causal_diagnostics"] = {
            "reward_count_by_observed_channel": lane_reward_count.tolist(),
            "reward_sum_by_observed_channel": lane_reward_sum.tolist(),
            "reward_mean_by_observed_channel": learned_reward_means,
            "respawn_reappearance_count_by_observed_channel": (
                lane_respawn_count.tolist()
            ),
            "respawn_delay_mean_by_observed_channel": lane_respawn_mean.tolist(),
            "respawn_delay_sample_std_by_observed_channel": learned_respawn_std,
            "exact_respawn_count_by_observed_channel": (
                lane_respawn_exact_count.tolist()
            ),
            "exact_respawn_delay_mean_by_observed_channel": (
                lane_respawn_exact_mean.tolist()
            ),
            "exact_respawn_delay_sample_std_by_observed_channel": (
                learned_respawn_exact_std
            ),
            "known_fixed_cells": int(np.sum(known_mask)),
            "known_learned_negative_cells": int(np.sum(known_negative_mask)),
            "map_cells": int(agent_config.height * agent_config.width),
        }
        metadata["runner"] = {
            "kind": "jax_scan" if count == 1 else "jax_batched_scan",
            "batch_mode": mode,
            "batch_size": count,
            "batch_seeds": list(seeds),
            "chunk_size": cfg.jax_chunk_size,
            "overall_duration_s": overall_duration,
            "setup_duration_s": compile_started - overall_started,
            "compile_duration_s": compile_duration,
            "execution_duration_s": execution_duration,
            "aggregate_transitions_per_second": aggregate_fps,
            "per_seed_effective_frames_per_second": effective_seed_fps,
            "bounded_reward_buffer_steps_per_seed": min(cfg.final_window, cfg.steps),
            "full_reward_history_retained": False,
            "rounding_contract": (
                "pure per-lane map transition; vmap and lax.map trajectories are exact"
            ),
        }
        if trace_metadata:
            metadata["raw_metric_trace"] = dict(trace_metadata[lane])
        results.append(
            ForagerRunResult(
                agent=CAUSAL_MAP_VARIANT_KIND,
                privileged=False,
                seed=seed,
                steps=cfg.steps,
                total_reward=lane_metrics.total_reward,
                mean_reward=lane_metrics.total_reward / cfg.steps,
                final_window_mean_reward=float(np.mean(lane_metrics.reward_tail)),
                final_ewm_reward=lane_metrics.final_ewm,
                mean_ewm_reward=lane_metrics.ewm_total / cfg.steps,
                fov_last_10pct_ema_auc=_fov_last_tenth_ema_auc(
                    lane_metrics.fov_samples
                ),
                mean_biome_regret=(
                    lane_metrics.regret_total / lane_metrics.regret_count
                    if lane_metrics.regret_count
                    else math.nan
                ),
                final_biome_regret=lane_metrics.final_regret,
                curve_steps=tuple(lane_metrics.curve_steps),
                curve_ewm_reward=tuple(lane_metrics.curve_ewm),
                curve_window_reward=tuple(lane_metrics.curve_window),
                duration_s=execution_duration,
                frames_per_second=effective_seed_fps,
                environment=cfg.environment.to_dict(),
                metric_contract=forager_metric_contract(
                    ewm_decay=cfg.ewm_decay,
                    final_window=cfg.final_window,
                    record_every=cfg.record_every,
                    steps=cfg.steps,
                ),
                agent_metadata=metadata,
            )
        )
    single_state = (
        jax.tree_util.tree_map(lambda value: value[0], final_agent_states)
        if count == 1
        else None
    )
    return tuple(results), single_state


def run_causal_map_forager(
    policy: CausalMapForagerAgent,
    benchmark_config: ForagerBenchmarkConfig,
) -> ForagerRunResult:
    """Run one seed with a compiled bounded-memory JAX scan."""
    if not isinstance(policy, CausalMapForagerAgent):
        raise TypeError("policy must be a CausalMapForagerAgent")
    if not isinstance(benchmark_config, ForagerBenchmarkConfig):
        raise TypeError("benchmark_config must be a ForagerBenchmarkConfig")
    if policy.seed != benchmark_config.seed:
        raise ValueError("policy seed must equal benchmark_config.seed")
    results, final_state = _run_causal_map_lanes(
        policy.config,
        benchmark_config,
        (policy.seed,),
        mode="vmap",
    )
    if final_state is None:  # pragma: no cover - count is statically one
        raise RuntimeError("single-lane runner did not return final state")
    policy._state = final_state
    return results[0]


def run_causal_map_forager_seeds(
    agent_config: CausalMapForagerConfig,
    benchmark_config: ForagerBenchmarkConfig,
    seeds: Sequence[int],
    *,
    mode: ForagerBatchMode = "vmap",
    reward_trace_sink_factory: ForagerRewardTraceSinkFactory | None = None,
) -> tuple[ForagerRunResult, ...]:
    """Run unique seeds with one compiled executable and bounded host memory."""
    if not isinstance(agent_config, CausalMapForagerConfig):
        raise TypeError("agent_config must be a CausalMapForagerConfig")
    if not isinstance(benchmark_config, ForagerBenchmarkConfig):
        raise TypeError("benchmark_config must be a ForagerBenchmarkConfig")
    raw_seeds = tuple(seeds)
    if not raw_seeds:
        raise ValueError("seeds must be non-empty")
    if any(
        isinstance(seed, bool) or not isinstance(seed, (int, np.integer))
        for seed in raw_seeds
    ):
        raise ValueError("seeds must be uint32-compatible integers without coercion")
    ordered = tuple(int(seed) for seed in raw_seeds)
    if len(set(ordered)) != len(ordered):
        raise ValueError("seeds must be unique")
    if any(seed < 0 or seed > np.iinfo(np.uint32).max for seed in ordered):
        raise ValueError("seeds must be uint32-compatible non-negative integers")
    if mode not in ("vmap", "strict"):
        raise ValueError("mode must be 'vmap' or 'strict'")
    results, _ = _run_causal_map_lanes(
        agent_config,
        benchmark_config,
        ordered,
        mode=mode,
        reward_trace_sink_factory=reward_trace_sink_factory,
    )
    return results


__all__ = [
    "CAUSAL_MAP_STATE_SCHEMA",
    "CAUSAL_MAP_VARIANT_KIND",
    "CausalMapForagerAgent",
    "CausalMapForagerConfig",
    "CausalMapForagerState",
    "CausalMapStepDiagnostics",
    "causal_map_start",
    "causal_map_rng_contract",
    "causal_map_state_from_dict",
    "causal_map_state_to_dict",
    "causal_map_step",
    "causal_map_variant_spec",
    "run_causal_map_forager",
    "run_causal_map_forager_seeds",
    "validate_causal_map_state",
]
