"""Development-only v4 lifecycle metrics and evidence-lease tuning grid.

This module closes the endpoint loopholes in the original hidden-partner
diagnostic.  Feature presence is indexed by the representation available for
decision ``t``.  A lifecycle event produced while processing transition ``t``
therefore first changes presence at decision ``t + 1``.

The exhaustive 66-pair archive is reported separately from the scarce
deployed bank.  Retirement means release of deployed capacity and reset of the
candidate's learned head; it does not erase the enumerated descriptor.
"""

from __future__ import annotations

import base64
import dataclasses
import hashlib
import json
import math
import zlib
from collections.abc import Sequence
from typing import cast

import numpy as np

from alberta_framework.core.integrated_hidden_partner import (
    IntegratedHiddenPartnerConfig,
)
from alberta_framework.evaluation.hidden_partner_development import (
    HiddenPartnerCondition,
    HiddenPartnerDevelopmentProtocol,
    HiddenPartnerDevelopmentRunner,
    HiddenPartnerRunResult,
    HiddenPartnerRunSummary,
    HiddenPartnerSeedPair,
    derive_hidden_partner_seed_pairs,
)

HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA = "alberta.hidden-partner-development.lifecycle.v4"
CRITICAL_RUN_PRIMITIVES_SCHEMA = "alberta.hidden-partner-development.critical-run-primitives.v3"
# Earlier v3 development seeds were inspected while diagnosing downstream
# consumer interference.  This fresh namespace is reserved for the frozen
# evidence-gated grid and must not be reused for adaptive debugging.
LEASE_TUNING_NAMESPACE = "hidden-partner-v0-dev-v4-evidence-gated-lease-grid-a-v1"
LEASE_TUNING_SEED_COUNT = 8
TUNING_SELECTION_RULE: dict[str, object] = {
    "feasibility": (
        "all finite/contracts; mean reward >=0.85; minimum reward "
        ">=0.80; and at least 75% per-life joint C-retain/D-retire success"
    ),
    "lexicographic_maximum": [
        "joint_success_count",
        "minimum_seed_reward",
        "mean_reward",
        "negative_total_d_repromotions",
        "negative_median_d_retirement_latency_steps",
        "negative_cell_index",
    ],
    "no_feasible_cell_result": None,
}

FEATURE_LEARNING_WINDOW = 128
RETIREMENT_CONFIRMATION_WINDOW = 128
FINAL_ABSENCE_WINDOW = 256
RECURRENT_ENTRY_WINDOW = 128
CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD = 0.80
CRITICAL_COLUMN_LEARNING_NLL_GAIN_THRESHOLD = 0.05
CRITICAL_COLUMN_LEARNING_POSITIVE_FRACTION_THRESHOLD = 0.55
CRITICAL_COLUMN_TARGET_CREATED_SHARE_THRESHOLD = 0.50
CRITICAL_MASKED_NLL_INCREASE_THRESHOLD = 0.005
CRITICAL_MASKED_NLL_POSITIVE_FRACTION_THRESHOLD = 0.55
RECURRENT_EARLY_REWARD_THRESHOLD = 0.75
INITIAL_LATE_REWARD_THRESHOLD = 0.75
RETENTION_RATIO_THRESHOLD = 0.80
MINIMUM_JOINT_SUCCESS_FRACTION = 0.75
CHANCE_REWARD = 0.50

LEASE_TUNING_SCOPE_LIMITS = (
    "scripted nonlearning partner",
    "hard-coded C and D identities",
    "fixed schedule with unequal recurrence gaps",
    "exhaustive enumerated pair archive",
    "interaction-task utility only",
    (
        "uncommitted interaction heads bootstrap plastically until first confirmation "
        "or confirmed-evidence lease expiry/retirement; only committed durable heads "
        "are confirmation-gated"
    ),
    "pre-confirmation bootstrap plasticity is an intentional interference risk",
    "confirmed pair-specific evidence gates behavior/control durable writes",
    (
        "raw one-step pair-specific evidence acquires downstream behavior/control "
        "reads under a fixed lease"
    ),
    "feature masking is a same-state diagnostic, not an executed intervention",
    "retirement releases deployed capacity but preserves the descriptor archive",
    "artifact sha256 detects drift but is not an external signature or publication timestamp",
    "development tuning seeds cannot promote evidence",
)

_C_PAIR = (0, 2)
_D_PAIR = (4, 5)


@dataclasses.dataclass(frozen=True)
class EvidenceLeaseTuningCell:
    """One immutable cell in the reserved v4 confirmed-memory grid."""

    index: int
    grace_steps: int
    evidence_threshold: float
    candidate_promotion_floor: float = 0.01

    def agent_config(self) -> IntegratedHiddenPartnerConfig:
        return IntegratedHiddenPartnerConfig(
            active_utility_retention_grace_steps=self.grace_steps,
            active_utility_evidence_threshold=self.evidence_threshold,
            retire_stale_features=True,
            candidate_promotion_floor=self.candidate_promotion_floor,
            evidence_gated_feature_memory=True,
            feature_evidence_confirmation_steps=8,
            evidence_gated_consumer_memory=True,
            consumer_evidence_confirmation_steps=8,
            consumer_read_confirmation_steps=1,
            consumer_read_lease_steps=32,
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "index": self.index,
            "grace_steps": self.grace_steps,
            "evidence_threshold": self.evidence_threshold,
            "candidate_promotion_floor": self.candidate_promotion_floor,
            "agent_config": self.agent_config().to_config(),
        }


LEASE_TUNING_GRID: tuple[EvidenceLeaseTuningCell, ...] = tuple(
    EvidenceLeaseTuningCell(index=index, grace_steps=grace, evidence_threshold=threshold)
    for index, (grace, threshold) in enumerate(
        (
            (2_048, 0.075),
            (2_048, 0.10),
            (3_072, 0.10),
            (3_072, 0.15),
            (3_072, 0.20),
            (4_096, 0.10),
            (4_096, 0.20),
            (4_096, 0.40),
        )
    )
)


@dataclasses.dataclass(frozen=True)
class CriticalPairLifecycleInterval:
    """Canonical half-open run of critical-pair bank locations."""

    start: int
    end_exclusive: int
    deployed_slot: int
    shadow_slot: int
    candidate_slot: int

    def to_dict(self) -> dict[str, int]:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class CriticalLifecycleV2Summary:
    """Continuous C/D lifecycle metrics with v4 causal memory contracts."""

    cycle_steps: int
    decision_state_count: int
    representation_link_contract_valid: bool
    consumer_gate_contract_valid: bool
    feature_memory_enabled: bool
    feature_memory_contract_valid: bool
    c_shadow_deployed_mismatch_steps: int
    d_shadow_deployed_mismatch_steps: int
    c_promotion_event_steps: tuple[int, ...]
    c_target_evidence_refresh_steps: tuple[int, ...]
    c_acquisition_step: int | None
    c_first_late_reward: float
    c_first_late_intended_accuracy: float
    c_first_late_online_nll: float
    c_first_late_entry_frozen_critical_nll: float
    c_critical_column_learning_nll_gain: float
    c_critical_column_learning_positive_fraction: float
    c_critical_column_target_created_share: float
    c_first_late_entry_frozen_critical_accuracy: float
    c_critical_column_learning_accuracy_gain: float
    c_first_late_masked_nll_increase: float
    c_first_late_masked_nll_positive_fraction: float
    c_task_learned: bool
    c_survival_end_exclusive: int
    c_survival_gap_steps: int | None
    c_first_survival_gap_step: int | None
    c_evictions_after_acquisition: int
    c_repromotions_after_acquisition: int
    c_continuously_survived: bool
    c_recurrent_early_reward: float
    c_recurrent_early_excess_reward_retention: float
    c_recurrent_early_intended_accuracy: float
    c_recurrent_early_masked_nll_increase: float
    c_recurrent_early_masked_nll_positive_fraction: float
    c_retained_and_used: bool
    d_promotion_event_steps: tuple[int, ...]
    d_target_evidence_refresh_steps: tuple[int, ...]
    d_acquisition_step: int | None
    d_deployed_through_exit: bool
    d_late_reward: float
    d_late_intended_accuracy: float
    d_late_online_nll: float
    d_late_entry_frozen_critical_nll: float
    d_critical_column_learning_nll_gain: float
    d_critical_column_learning_positive_fraction: float
    d_critical_column_target_created_share: float
    d_late_entry_frozen_critical_accuracy: float
    d_critical_column_learning_accuracy_gain: float
    d_late_masked_nll_increase: float
    d_late_masked_nll_positive_fraction: float
    d_task_learned: bool
    d_retirement_event_step: int | None
    d_retirement_step: int | None
    d_retirement_event_latency_steps: int | None
    d_retirement_latency_steps: int | None
    d_post_exit_live_slot_steps: int
    d_post_exit_live_fraction: float
    d_post_exit_promotion_count: int
    d_repromotions_after_retirement: int
    d_absent_entire_final_window: bool
    d_retirement_event_steps: tuple[int, ...]
    d_retirement_event_reset_counts: tuple[int, ...]
    d_retirement_event_candidate_utility_post: tuple[float, ...]
    d_retirement_event_candidate_head_linf_post: tuple[float, ...]
    d_retirement_event_candidate_age_post: tuple[int, ...]
    d_retirement_event_count: int
    d_matching_candidate_reset_count: int
    d_linked_matching_candidate_reset_count: int | None
    d_linked_candidate_utility_post: float | None
    d_linked_candidate_head_linf_post: float | None
    d_linked_candidate_age_post: int | None
    d_retirement_event_aligned: bool
    d_learned_then_stably_retired: bool
    joint_memory_management_success: bool
    candidate_archive_contract_valid: bool
    c_candidate_utility_at_life_end: float
    d_candidate_utility_at_life_end: float
    c_lifecycle_rle: tuple[CriticalPairLifecycleInterval, ...]
    d_lifecycle_rle: tuple[CriticalPairLifecycleInterval, ...]

    def to_dict(self) -> dict[str, object]:
        payload = dataclasses.asdict(self)
        for field in (
            "c_promotion_event_steps",
            "c_target_evidence_refresh_steps",
            "d_promotion_event_steps",
            "d_target_evidence_refresh_steps",
            "d_retirement_event_steps",
            "d_retirement_event_reset_counts",
            "d_retirement_event_candidate_utility_post",
            "d_retirement_event_candidate_head_linf_post",
            "d_retirement_event_candidate_age_post",
        ):
            payload[field] = list(payload[field])
        payload["c_lifecycle_rle"] = [interval.to_dict() for interval in self.c_lifecycle_rle]
        payload["d_lifecycle_rle"] = [interval.to_dict() for interval in self.d_lifecycle_rle]
        return payload


def _descriptor_slots(
    descriptors: np.ndarray,
    pair: tuple[int, int],
    *,
    require_exactly_one: bool,
) -> np.ndarray:
    target = np.asarray(pair, dtype=np.int32)
    matches = np.all(descriptors == target, axis=-1)
    counts = np.sum(matches, axis=1)
    if np.any(counts > 1):
        raise ValueError(f"descriptor {pair!r} appears in multiple slots")
    if require_exactly_one and np.any(counts != 1):
        raise ValueError(f"candidate archive does not contain exactly one {pair!r}")
    return np.where(counts == 1, np.argmax(matches, axis=1), -1).astype(np.int32)


def _descriptor_live_mask(descriptors: np.ndarray) -> np.ndarray:
    left = descriptors[..., 0]
    right = descriptors[..., 1]
    return (left >= 0) & (right >= 0) & (left < 12) & (right < 12) & (left < right)


@dataclasses.dataclass(frozen=True)
class _ConsumerGateContractAudit:
    """Exact read/write audit plus per-slot durable-write violations."""

    valid: bool
    write_violation_bits: np.ndarray


def _invalid_consumer_gate_audit(steps: int) -> _ConsumerGateContractAudit:
    safe_steps = max(steps, 0)
    return _ConsumerGateContractAudit(
        valid=False,
        write_violation_bits=np.ones((safe_steps, 12), dtype=np.bool_),
    )


def _consumer_gate_contract_audit(
    deployed_pre: np.ndarray,
    deployed_post: np.ndarray,
    evidence: np.ndarray,
    write_gate: np.ndarray,
    read_idle_pre: np.ndarray,
    read_idle_post: np.ndarray,
    mask_pre: np.ndarray,
    mask_post: np.ndarray,
    representations: np.ndarray,
    behavior_weights_pre: np.ndarray,
    behavior_weights_post: np.ndarray,
    control_q_weights_pre: np.ndarray,
    control_q_weights_post: np.ndarray,
    control_q_trace_pre: np.ndarray,
    control_q_trace_post: np.ndarray,
    config: IntegratedHiddenPartnerConfig,
) -> _ConsumerGateContractAudit:
    """Reconstruct the gate and audit every persisted pair-column write.

    Durable columns are compared by descriptor identity across the curation
    transaction.  A closed confirmed-write gate must preserve behavior and Q
    columns bit-for-bit, while its eligibility trace is erased.  A new
    identity or vacancy starts at exact positive-zero bits.  With the gate
    disabled, survivor writes remain unrestricted, but finite-state,
    continuity, routing, and new-zero invariants still apply.
    """
    steps = deployed_pre.shape[0] if deployed_pre.ndim >= 1 else 0
    expected_shape = (steps, 12)
    if any(
        values.shape != expected_shape
        for values in (
            evidence,
            write_gate,
            read_idle_pre,
            read_idle_post,
            mask_pre,
            mask_post,
            representations,
        )
    ) or deployed_pre.shape != (steps, 12, 2) or deployed_post.shape != (
        steps,
        12,
        2,
    ) or any(
        values.shape != (steps, 2, 12)
        for values in (
            behavior_weights_pre,
            behavior_weights_post,
            control_q_weights_pre,
            control_q_weights_post,
            control_q_trace_pre,
            control_q_trace_post,
        )
    ):
        return _invalid_consumer_gate_audit(steps)

    write_violations = np.zeros(expected_shape, dtype=np.bool_)
    vacancy_pre = np.all(deployed_pre == -1, axis=2)
    vacancy_post = np.all(deployed_post == -1, axis=2)
    live_pre = _descriptor_live_mask(deployed_pre)
    live_post = _descriptor_live_mask(deployed_post)
    structural_valid = bool(
        np.all(live_pre | vacancy_pre) and np.all(live_post | vacancy_post)
    )
    for states in (deployed_pre, deployed_post):
        for bank in states:
            descriptors = [tuple(int(value) for value in pair) for pair in bank if pair[0] >= 0]
            if len(descriptors) != len(set(descriptors)):
                structural_valid = False
    linked_descriptors = bool(
        steps == 1 or np.array_equal(deployed_pre[1:], deployed_post[:-1])
    )
    linked_masks = bool(steps == 1 or np.array_equal(mask_pre[1:], mask_post[:-1]))
    finite_representations = bool(np.all(np.isfinite(representations)))
    closed_reads_zero = bool(
        finite_representations and np.all(representations[~mask_pre] == 0.0)
    )

    pre_codes = deployed_pre[..., 0] * 12 + deployed_pre[..., 1]
    post_codes = deployed_post[..., 0] * 12 + deployed_post[..., 1]
    identity_matches = (
        (post_codes[:, :, None] == pre_codes[:, None, :])
        & live_post[:, :, None]
        & live_pre[:, None, :]
    )
    post_has_source = np.any(identity_matches, axis=2)
    destination_for_pre = np.argmax(identity_matches, axis=1)
    pre_has_destination = np.any(identity_matches, axis=1)

    consumer_arrays = (
        behavior_weights_pre,
        behavior_weights_post,
        control_q_weights_pre,
        control_q_weights_post,
        control_q_trace_pre,
        control_q_trace_post,
    )
    consumer_bits = tuple(_float32_bits(values) for values in consumer_arrays)
    for values in consumer_arrays:
        write_violations |= np.any(~np.isfinite(values), axis=1)

    # Every initial pair column is newly initialized; vacancies remain exact
    # zero.  Post-curation identities without a pre-state source also begin at
    # zero rather than inheriting the physical slot's old contents.
    if steps > 0:
        for pre_bits in consumer_bits[::2]:
            write_violations[0] |= np.any(pre_bits[0] != 0, axis=0)
    no_source_post = ~post_has_source
    for post_bits in consumer_bits[1::2]:
        write_violations |= no_source_post & np.any(post_bits != 0, axis=1)
    for pre_bits in consumer_bits[::2]:
        write_violations |= vacancy_pre & np.any(pre_bits != 0, axis=1)

    # A state sequence is exact only when every next pre-state is the previous
    # post-state bit-for-bit, including signed zero and NaN payload bits.
    if steps > 1:
        for pre_bits, post_bits in zip(
            consumer_bits[::2],
            consumer_bits[1::2],
            strict=True,
        ):
            write_violations[1:] |= np.any(
                pre_bits[1:] != post_bits[:-1],
                axis=1,
            )

    if config.evidence_gated_consumer_memory:
        closed_survivor = live_pre & pre_has_destination & ~write_gate
        for pre_bits, post_bits in (
            (consumer_bits[0], consumer_bits[1]),
            (consumer_bits[2], consumer_bits[3]),
        ):
            routed_post = np.take_along_axis(
                post_bits,
                destination_for_pre[:, None, :],
                axis=2,
            )
            write_violations |= closed_survivor & np.any(
                pre_bits != routed_post,
                axis=1,
            )
        routed_trace_post = np.take_along_axis(
            consumer_bits[5],
            destination_for_pre[:, None, :],
            axis=2,
        )
        write_violations |= closed_survivor & np.any(
            routed_trace_post != 0,
            axis=1,
        )

    structural_valid = bool(
        structural_valid
        and linked_descriptors
        and linked_masks
        and closed_reads_zero
    )
    if not config.evidence_gated_consumer_memory:
        gate_valid = bool(
            np.all(write_gate)
            and not np.any(read_idle_pre)
            and not np.any(read_idle_post)
            and np.array_equal(mask_pre, live_pre)
            and np.array_equal(mask_post, live_post)
        )
        return _ConsumerGateContractAudit(
            valid=bool(structural_valid and gate_valid and not np.any(write_violations)),
            write_violation_bits=write_violations,
        )
    if np.any(evidence & ~live_pre) or (steps > 0 and np.any(mask_pre[0])):
        structural_valid = False

    int32_max = np.iinfo(np.int32).max
    current_streak = np.zeros((12,), dtype=np.int32)
    current_idle = np.zeros((12,), dtype=np.int32)
    current_mask = np.zeros((12,), dtype=np.bool_)
    expected_write = np.zeros(expected_shape, dtype=np.bool_)
    expected_idle_pre = np.zeros(expected_shape, dtype=np.int32)
    expected_idle_post = np.zeros(expected_shape, dtype=np.int32)
    expected_mask_pre = np.zeros(expected_shape, dtype=np.bool_)
    expected_mask_post = np.zeros(expected_shape, dtype=np.bool_)
    for step in range(steps):
        expected_mask_pre[step] = current_mask
        expected_idle_pre[step] = current_idle
        incremented_streak = np.minimum(
            np.maximum(current_streak, 0),
            int32_max - 1,
        ) + 1
        updated_streak = np.where(
            live_pre[step] & evidence[step],
            incremented_streak,
            0,
        ).astype(np.int32)
        confirmed_write = (
            live_pre[step]
            & evidence[step]
            & (
                updated_streak
                >= config.consumer_evidence_confirmation_steps
            )
        )
        read_acquire = (
            live_pre[step]
            & evidence[step]
            & (
                updated_streak
                >= config.consumer_read_confirmation_steps
            )
        )
        expected_write[step] = confirmed_write
        incremented_idle = np.minimum(
            np.maximum(current_idle, 0),
            int32_max - 1,
        ) + 1
        updated_idle = np.where(
            live_pre[step],
            np.where(evidence[step], 0, incremented_idle),
            0,
        ).astype(np.int32)

        next_streak = np.zeros((12,), dtype=np.int32)
        next_idle = np.zeros((12,), dtype=np.int32)
        next_mask = np.zeros((12,), dtype=np.bool_)
        for post_slot, descriptor in enumerate(deployed_post[step]):
            if not live_post[step, post_slot]:
                continue
            matches = np.flatnonzero(
                np.all(deployed_pre[step] == descriptor, axis=1)
            )
            if matches.size != 1:
                continue
            source = int(matches[0])
            next_streak[post_slot] = updated_streak[source]
            next_idle[post_slot] = updated_idle[source]
            next_mask[post_slot] = bool(
                (current_mask[source] or read_acquire[source])
                and next_idle[post_slot] <= config.consumer_read_lease_steps
            )
        expected_mask_post[step] = next_mask
        expected_idle_post[step] = next_idle
        current_streak = next_streak
        current_idle = next_idle
        current_mask = next_mask

    gate_valid = bool(
        np.array_equal(write_gate, expected_write)
        and np.array_equal(read_idle_pre, expected_idle_pre)
        and np.array_equal(read_idle_post, expected_idle_post)
        and np.array_equal(mask_pre, expected_mask_pre)
        and np.array_equal(mask_post, expected_mask_post)
    )
    return _ConsumerGateContractAudit(
        valid=bool(structural_valid and gate_valid and not np.any(write_violations)),
        write_violation_bits=write_violations,
    )


def _consumer_gate_contract_valid(
    deployed_pre: np.ndarray,
    deployed_post: np.ndarray,
    evidence: np.ndarray,
    write_gate: np.ndarray,
    read_idle_pre: np.ndarray,
    read_idle_post: np.ndarray,
    mask_pre: np.ndarray,
    mask_post: np.ndarray,
    representations: np.ndarray,
    behavior_weights_pre: np.ndarray,
    behavior_weights_post: np.ndarray,
    control_q_weights_pre: np.ndarray,
    control_q_weights_post: np.ndarray,
    control_q_trace_pre: np.ndarray,
    control_q_trace_post: np.ndarray,
    config: IntegratedHiddenPartnerConfig,
) -> bool:
    """Return the fail-closed consumer read/write contract predicate."""
    return _consumer_gate_contract_audit(
        deployed_pre,
        deployed_post,
        evidence,
        write_gate,
        read_idle_pre,
        read_idle_post,
        mask_pre,
        mask_post,
        representations,
        behavior_weights_pre,
        behavior_weights_post,
        control_q_weights_pre,
        control_q_weights_post,
        control_q_trace_pre,
        control_q_trace_post,
        config,
    ).valid


@dataclasses.dataclass(frozen=True)
class _FeatureMemoryContractAudit:
    """Exact causal audit plus compact per-slot violation primitives."""

    valid: bool
    identity_routed_head_changed: np.ndarray
    violation_bits: np.ndarray


def _invalid_feature_memory_audit(steps: int) -> _FeatureMemoryContractAudit:
    safe_steps = max(steps, 0)
    return _FeatureMemoryContractAudit(
        valid=False,
        identity_routed_head_changed=np.zeros(
            (safe_steps, 12),
            dtype=np.bool_,
        ),
        violation_bits=np.ones(
            (safe_steps, 12),
            dtype=np.bool_,
        ),
    )


def _duplicate_descriptor_mask(
    descriptors: np.ndarray,
    live: np.ndarray,
) -> np.ndarray:
    codes = descriptors[..., 0] * 12 + descriptors[..., 1]
    matches = codes[:, :, None] == codes[:, None, :]
    duplicate_counts = np.sum(matches & live[:, None, :], axis=2)
    return cast(np.ndarray, live & (duplicate_counts != 1))


def _float32_bits(values: np.ndarray) -> np.ndarray:
    contiguous = np.ascontiguousarray(values, dtype=np.float32)
    return cast(np.ndarray, contiguous.view(np.uint32))


def _feature_memory_contract_audit(
    deployed_pre: np.ndarray,
    deployed_post: np.ndarray,
    shadow_pre: np.ndarray,
    shadow_post: np.ndarray,
    raw_evidence: np.ndarray,
    confirmed_evidence: np.ndarray,
    output_weights_pre: np.ndarray,
    output_weights_post: np.ndarray,
    streak_pre: np.ndarray,
    streak_post: np.ndarray,
    committed_pre: np.ndarray,
    committed_post: np.ndarray,
    config: IntegratedHiddenPartnerConfig,
) -> _FeatureMemoryContractAudit:
    """Reconstruct confirmed feature memory without trusting its state trace.

    Evidence and confirmation are indexed by the pre-curation shadow identity.
    Streak and commitment state then follow a surviving descriptor into its
    post-curation slot.  A new, replaced, promoted, or retired identity has no
    source and therefore starts with zero streak and an uncommitted head.
    """
    steps = raw_evidence.shape[0] if raw_evidence.ndim >= 1 else 0
    descriptor_shape = (steps, 12, 2)
    state_shape = (steps, 12)
    if any(
        values.shape != descriptor_shape
        for values in (
            deployed_pre,
            deployed_post,
            shadow_pre,
            shadow_post,
        )
    ):
        return _invalid_feature_memory_audit(steps)
    if any(
        values.shape != state_shape
        for values in (
            raw_evidence,
            confirmed_evidence,
            streak_pre,
            streak_post,
            committed_pre,
            committed_post,
        )
    ):
        return _invalid_feature_memory_audit(steps)
    if (
        output_weights_pre.ndim != 3
        or output_weights_pre.shape[0] != steps
        or output_weights_pre.shape[2] != 12
        or output_weights_pre.shape != output_weights_post.shape
        or output_weights_pre.shape[1] <= 0
    ):
        return _invalid_feature_memory_audit(steps)

    live_deployed_pre = _descriptor_live_mask(deployed_pre)
    live_deployed_post = _descriptor_live_mask(deployed_post)
    live_shadow_pre = _descriptor_live_mask(shadow_pre)
    live_shadow_post = _descriptor_live_mask(shadow_post)
    descriptor_valid = (
        (live_deployed_pre | np.all(deployed_pre == -1, axis=2))
        & (live_deployed_post | np.all(deployed_post == -1, axis=2))
        & (live_shadow_pre | np.all(shadow_pre == -1, axis=2))
        & (live_shadow_post | np.all(shadow_post == -1, axis=2))
    )
    descriptor_valid &= ~_duplicate_descriptor_mask(
        deployed_pre,
        live_deployed_pre,
    )
    descriptor_valid &= ~_duplicate_descriptor_mask(
        deployed_post,
        live_deployed_post,
    )
    descriptor_valid &= ~_duplicate_descriptor_mask(
        shadow_pre,
        live_shadow_pre,
    )
    descriptor_valid &= ~_duplicate_descriptor_mask(
        shadow_post,
        live_shadow_post,
    )

    violation_bits = ~descriptor_valid
    violation_bits |= np.any(deployed_pre != shadow_pre, axis=2)
    violation_bits |= np.any(deployed_post != shadow_post, axis=2)
    if steps > 1:
        violation_bits[1:] |= np.any(
            deployed_pre[1:] != deployed_post[:-1],
            axis=2,
        )
        violation_bits[1:] |= np.any(
            shadow_pre[1:] != shadow_post[:-1],
            axis=2,
        )

    pre_codes = shadow_pre[..., 0] * 12 + shadow_pre[..., 1]
    post_codes = shadow_post[..., 0] * 12 + shadow_post[..., 1]
    identity_matches = (
        (post_codes[:, :, None] == pre_codes[:, None, :])
        & live_shadow_post[:, :, None]
        & live_shadow_pre[:, None, :]
    )
    source_for_post = np.argmax(identity_matches, axis=2)
    post_has_source = np.any(identity_matches, axis=2)
    destination_for_pre = np.argmax(identity_matches, axis=1)
    pre_has_destination = np.any(identity_matches, axis=1)

    expected_streak_pre = np.zeros(state_shape, dtype=np.int32)
    expected_streak_post = np.zeros(state_shape, dtype=np.int32)
    expected_confirmed = np.zeros(state_shape, dtype=np.bool_)
    expected_committed_pre = np.zeros(state_shape, dtype=np.bool_)
    expected_committed_post = np.zeros(state_shape, dtype=np.bool_)
    current_streak = np.zeros((12,), dtype=np.int32)
    current_committed = np.zeros((12,), dtype=np.bool_)
    int32_max = np.iinfo(np.int32).max
    for step in range(steps):
        expected_streak_pre[step] = current_streak
        expected_committed_pre[step] = current_committed
        if config.evidence_gated_feature_memory:
            incremented = np.minimum(
                np.maximum(current_streak, 0),
                int32_max - 1,
            ) + 1
            updated_streak = np.where(
                live_shadow_pre[step] & raw_evidence[step],
                incremented,
                0,
            ).astype(np.int32)
            confirmed = (
                live_shadow_pre[step]
                & raw_evidence[step]
                & (
                    updated_streak
                    >= config.feature_evidence_confirmation_steps
                )
            )
            updated_committed = live_shadow_pre[step] & (
                current_committed | confirmed
            )
        else:
            updated_streak = np.zeros((12,), dtype=np.int32)
            confirmed = live_shadow_pre[step] & raw_evidence[step]
            updated_committed = np.zeros((12,), dtype=np.bool_)
        expected_confirmed[step] = confirmed

        source = source_for_post[step]
        next_streak = np.where(
            live_shadow_post[step] & post_has_source[step],
            updated_streak[source],
            0,
        ).astype(np.int32)
        next_committed = (
            live_shadow_post[step]
            & post_has_source[step]
            & updated_committed[source]
        )
        expected_streak_post[step] = next_streak
        expected_committed_post[step] = next_committed
        current_streak = next_streak
        current_committed = next_committed

    violation_bits |= raw_evidence & ~live_shadow_pre
    violation_bits |= confirmed_evidence != expected_confirmed
    violation_bits |= streak_pre != expected_streak_pre
    violation_bits |= streak_post != expected_streak_post
    violation_bits |= committed_pre != expected_committed_pre
    violation_bits |= committed_post != expected_committed_post

    pre_weight_bits = _float32_bits(output_weights_pre)
    post_weight_bits = _float32_bits(output_weights_post)
    routed_post_bits = np.take_along_axis(
        post_weight_bits,
        destination_for_pre[:, None, :],
        axis=2,
    )
    identity_routed_head_changed = (
        live_shadow_pre
        & pre_has_destination
        & np.any(pre_weight_bits != routed_post_bits, axis=1)
    )
    if steps > 1:
        violation_bits[1:] |= np.any(
            pre_weight_bits[1:] != post_weight_bits[:-1],
            axis=1,
        )
    nonfinite_weights = (
        np.any(~np.isfinite(output_weights_pre), axis=1)
        | np.any(~np.isfinite(output_weights_post), axis=1)
    )
    violation_bits |= nonfinite_weights
    if config.evidence_gated_feature_memory:
        violation_bits |= (
            expected_committed_pre
            & ~expected_confirmed
            & identity_routed_head_changed
        )

    return _FeatureMemoryContractAudit(
        valid=bool(not np.any(violation_bits)),
        identity_routed_head_changed=identity_routed_head_changed,
        violation_bits=violation_bits,
    )


def _canonical_lifecycle_rle(
    deployed_slots: np.ndarray,
    shadow_slots: np.ndarray,
    candidate_slots: np.ndarray,
) -> tuple[CriticalPairLifecycleInterval, ...]:
    if not (
        deployed_slots.shape == shadow_slots.shape == candidate_slots.shape
        and deployed_slots.ndim == 1
        and deployed_slots.size > 0
    ):
        raise ValueError("lifecycle slot arrays must be equal non-empty vectors")
    rows = np.stack((deployed_slots, shadow_slots, candidate_slots), axis=1)
    starts = np.concatenate(
        (
            np.asarray([0], dtype=np.int64),
            np.flatnonzero(np.any(rows[1:] != rows[:-1], axis=1)) + 1,
        )
    )
    ends = np.concatenate((starts[1:], np.asarray([rows.shape[0]], dtype=np.int64)))
    return tuple(
        CriticalPairLifecycleInterval(
            start=int(start),
            end_exclusive=int(end),
            deployed_slot=int(rows[start, 0]),
            shadow_slot=int(rows[start, 1]),
            candidate_slot=int(rows[start, 2]),
        )
        for start, end in zip(starts, ends, strict=True)
    )


def _packed_bool_payload(values: np.ndarray) -> dict[str, object]:
    array = np.asarray(values, dtype=np.bool_)
    packed = np.packbits(array.reshape(-1), bitorder="little")
    return {
        "shape": list(array.shape),
        "bitorder": "little",
        "data_base64": base64.b64encode(packed.tobytes()).decode("ascii"),
    }


def _float32_state_sequence_payload(
    values_pre: np.ndarray,
    values_post: np.ndarray,
) -> dict[str, object]:
    """Encode an exact continuous T+1 float32 state sequence canonically."""
    pre = np.ascontiguousarray(values_pre, dtype="<f4")
    post = np.ascontiguousarray(values_post, dtype="<f4")
    if pre.shape != post.shape or pre.ndim < 1 or pre.shape[0] < 1:
        raise ValueError("float32 pre/post traces must have equal non-empty shapes")
    pre_bits = pre.view("<u4")
    post_bits = post.view("<u4")
    if not np.array_equal(pre_bits[1:], post_bits[:-1]):
        raise ValueError("float32 pre/post traces are not bitwise continuous")
    states = np.concatenate((pre[:1], post), axis=0)
    state_bits = np.ascontiguousarray(states, dtype="<f4").view("<u4")
    deltas = np.empty_like(state_bits)
    deltas[0] = state_bits[0]
    deltas[1:] = state_bits[1:] ^ state_bits[:-1]
    compressed = zlib.compress(deltas.tobytes(order="C"), level=9)
    return {
        "shape": list(states.shape),
        "dtype": "float32",
        "byteorder": "little",
        "delta": "uint32-xor",
        "codec": "zlib",
        "data_base64": base64.b64encode(compressed).decode("ascii"),
    }


def _canonical_candidate_descriptors() -> np.ndarray:
    return np.asarray(
        tuple(
            (left, right)
            for left in range(12)
            for right in range(left + 1, 12)
        ),
        dtype=np.int32,
    )


def _candidate_archive_contract_valid(
    candidate_pre: np.ndarray,
    candidate_post: np.ndarray,
) -> bool:
    steps = candidate_pre.shape[0] if candidate_pre.ndim >= 1 else 0
    if (
        candidate_pre.shape != (steps, 66, 2)
        or candidate_post.shape != candidate_pre.shape
        or steps < 1
    ):
        return False
    if not np.array_equal(candidate_pre[1:], candidate_post[:-1]):
        return False
    states = np.concatenate((candidate_pre[:1], candidate_post), axis=0)
    canonical = _canonical_candidate_descriptors()
    return bool(np.all(states == canonical[None, :, :]))


def _canonical_candidate_bank_state_rle(
    candidate_states: np.ndarray,
) -> list[dict[str, object]]:
    states = np.asarray(candidate_states, dtype=np.int32)
    if (
        states.ndim != 3
        or states.shape[1:] != (66, 2)
        or states.shape[0] < 2
    ):
        raise ValueError("candidate-bank state trace must have shape (T+1, 66, 2)")
    starts = np.concatenate(
        (
            np.asarray([0], dtype=np.int64),
            np.flatnonzero(np.any(states[1:] != states[:-1], axis=(1, 2))) + 1,
        )
    )
    ends = np.concatenate(
        (starts[1:], np.asarray([states.shape[0]], dtype=np.int64))
    )
    return [
        {
            "start": int(start),
            "end_exclusive": int(end),
            "candidate_descriptors": states[start].tolist(),
        }
        for start, end in zip(starts, ends, strict=True)
    ]


def _canonical_bank_state_rle(
    deployed_states: np.ndarray,
    shadow_states: np.ndarray,
) -> list[dict[str, object]]:
    if (
        deployed_states.shape != shadow_states.shape
        or deployed_states.ndim != 3
        or deployed_states.shape[1:] != (12, 2)
        or deployed_states.shape[0] < 2
    ):
        raise ValueError("full-bank state traces must have shape (T+1, 12, 2)")
    flattened = np.concatenate(
        (
            deployed_states.reshape((deployed_states.shape[0], -1)),
            shadow_states.reshape((shadow_states.shape[0], -1)),
        ),
        axis=1,
    )
    starts = np.concatenate(
        (
            np.asarray([0], dtype=np.int64),
            np.flatnonzero(np.any(flattened[1:] != flattened[:-1], axis=1)) + 1,
        )
    )
    ends = np.concatenate(
        (
            starts[1:],
            np.asarray([deployed_states.shape[0]], dtype=np.int64),
        )
    )
    return [
        {
            "start": int(start),
            "end_exclusive": int(end),
            "deployed_descriptors": deployed_states[start].tolist(),
            "shadow_descriptors": shadow_states[start].tolist(),
        }
        for start, end in zip(starts, ends, strict=True)
    ]


def _critical_window_primitives(
    *,
    behavior_logits: np.ndarray,
    behavior_weights: np.ndarray,
    representations: np.ndarray,
    descriptors: np.ndarray,
    intended_actions: np.ndarray,
    pair: tuple[int, int],
    entry_step: int,
    window_start: int,
    window_end_exclusive: int,
) -> dict[str, object]:
    target = np.asarray(pair, dtype=np.int32)
    entry_matches = np.all(descriptors[entry_step] == target, axis=1)
    if np.sum(entry_matches) > 1:
        raise ValueError("critical pair is duplicated at target entry")
    entry_margin = 0.0
    if np.any(entry_matches):
        entry_slot = int(np.argmax(entry_matches))
        entry_weights = behavior_weights[entry_step, :, entry_slot]
        entry_margin = float(entry_weights[1] - entry_weights[0])
    rows: list[dict[str, object]] = []
    for step in range(window_start, window_end_exclusive):
        matches = np.all(descriptors[step] == target, axis=1)
        if np.sum(matches) > 1:
            raise ValueError("critical pair is duplicated in an evidence window")
        activation = 0.0
        current_margin = 0.0
        if np.any(matches):
            slot = int(np.argmax(matches))
            activation = float(representations[step, slot])
            weights = behavior_weights[step, :, slot]
            current_margin = float(weights[1] - weights[0])
        logits = behavior_logits[step]
        rows.append(
            {
                "step": step,
                "intended_action": int(intended_actions[step]),
                "online_logit_margin": float(logits[1] - logits[0]),
                "critical_activation": activation,
                "current_critical_weight_margin": current_margin,
            }
        )
    return {
        "pair": list(pair),
        "entry_step": entry_step,
        "window_start": window_start,
        "window_end_exclusive": window_end_exclusive,
        "entry_critical_weight_margin": entry_margin,
        "rows": rows,
    }


def critical_run_primitives(
    result: HiddenPartnerRunResult,
) -> dict[str, object]:
    """Extract compact fixed-window and event primitives for independent audit."""
    trace = result.trace
    cycle_steps = result.summary.cycle_steps
    deployed_pre = np.asarray(
        trace.active_descriptors,
        dtype=np.int32,
    )[:cycle_steps]
    deployed_post = np.asarray(
        trace.deployed_descriptors_post,
        dtype=np.int32,
    )[:cycle_steps]
    shadow_pre = np.asarray(
        trace.shadow_descriptors_pre,
        dtype=np.int32,
    )[:cycle_steps]
    shadow_post = np.asarray(
        trace.shadow_descriptors_post,
        dtype=np.int32,
    )[:cycle_steps]
    candidate_pre = np.asarray(
        trace.candidate_descriptors,
        dtype=np.int32,
    )[:cycle_steps]
    candidate_post = np.asarray(
        trace.candidate_descriptors_post,
        dtype=np.int32,
    )[:cycle_steps]
    deployed_states = np.concatenate((deployed_pre, deployed_post[-1:]))
    shadow_states = np.concatenate((shadow_pre, shadow_post[-1:]))
    if (
        candidate_pre.shape != (cycle_steps, 66, 2)
        or candidate_post.shape != candidate_pre.shape
        or not np.array_equal(candidate_pre[1:], candidate_post[:-1])
    ):
        raise ValueError("candidate descriptor trace is not exactly continuous")
    candidate_states = np.concatenate((candidate_pre[:1], candidate_post), axis=0)
    link_violations = np.any(deployed_pre != shadow_pre, axis=(1, 2))
    link_violations |= np.any(deployed_post != shadow_post, axis=(1, 2))
    if cycle_steps > 1:
        link_violations[1:] |= np.any(
            deployed_pre[1:] != deployed_post[:-1],
            axis=(1, 2),
        )
        link_violations[1:] |= np.any(
            shadow_pre[1:] != shadow_post[:-1],
            axis=(1, 2),
        )

    rewards = np.asarray(trace.reward, dtype=np.float64)[:cycle_steps]
    if (
        rewards.shape != (cycle_steps,)
        or not np.all(np.isfinite(rewards))
        or np.any((rewards != 0.0) & (rewards != 1.0))
    ):
        raise ValueError("hidden-partner rewards must be finite binary values")
    evidence = np.asarray(
        trace.interaction_evidence_refreshed,
        dtype=np.bool_,
    )[:cycle_steps]
    confirmed_evidence = np.asarray(
        trace.interaction_retention_evidence_refreshed,
        dtype=np.bool_,
    )[:cycle_steps]
    interaction_output_weights_pre = np.asarray(
        trace.interaction_output_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    interaction_output_weights_post = np.asarray(
        trace.interaction_output_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    feature_streak_pre = np.asarray(
        trace.interaction_utility_evidence_streak_pre,
        dtype=np.int32,
    )[:cycle_steps]
    feature_streak_post = np.asarray(
        trace.interaction_utility_evidence_streak_post,
        dtype=np.int32,
    )[:cycle_steps]
    feature_committed_pre = np.asarray(
        trace.interaction_active_output_memory_committed_pre,
        dtype=np.bool_,
    )[:cycle_steps]
    feature_committed_post = np.asarray(
        trace.interaction_active_output_memory_committed_post,
        dtype=np.bool_,
    )[:cycle_steps]
    consumer_write_gate = np.asarray(
        trace.consumer_write_gate_pre,
        dtype=np.bool_,
    )[:cycle_steps]
    consumer_read_idle_pre = np.asarray(
        trace.consumer_read_idle_steps_pre,
        dtype=np.int32,
    )[:cycle_steps]
    consumer_read_idle_post = np.asarray(
        trace.consumer_read_idle_steps_post,
        dtype=np.int32,
    )[:cycle_steps]
    consumer_mask_pre = np.asarray(
        trace.consumer_active_mask_pre,
        dtype=np.bool_,
    )[:cycle_steps]
    consumer_mask_post = np.asarray(
        trace.consumer_active_mask_post,
        dtype=np.bool_,
    )[:cycle_steps]
    behavior_weights_pre = np.asarray(
        trace.behavior_pair_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    behavior_weights_post = np.asarray(
        trace.behavior_pair_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_weights_pre = np.asarray(
        trace.control_pair_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_weights_post = np.asarray(
        trace.control_pair_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_trace_pre = np.asarray(
        trace.control_pair_trace_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_trace_post = np.asarray(
        trace.control_pair_trace_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    if any(
        values.shape != (cycle_steps, 12)
        for values in (
            evidence,
            confirmed_evidence,
            feature_streak_pre,
            feature_streak_post,
            feature_committed_pre,
            feature_committed_post,
            consumer_write_gate,
            consumer_read_idle_pre,
            consumer_read_idle_post,
            consumer_mask_pre,
            consumer_mask_post,
        )
    ):
        raise ValueError("evidence/consumer gate trace has the wrong shape")
    feature_memory_audit = _feature_memory_contract_audit(
        deployed_pre,
        deployed_post,
        shadow_pre,
        shadow_post,
        evidence,
        confirmed_evidence,
        interaction_output_weights_pre,
        interaction_output_weights_post,
        feature_streak_pre,
        feature_streak_post,
        feature_committed_pre,
        feature_committed_post,
        result.condition.config,
    )
    representations = np.asarray(
        trace.deployed_pair_features,
        dtype=np.float32,
    )[:cycle_steps]
    consumer_gate_audit = _consumer_gate_contract_audit(
        deployed_pre,
        deployed_post,
        evidence,
        consumer_write_gate,
        consumer_read_idle_pre,
        consumer_read_idle_post,
        consumer_mask_pre,
        consumer_mask_post,
        representations,
        behavior_weights_pre,
        behavior_weights_post,
        control_q_weights_pre,
        control_q_weights_post,
        control_q_trace_pre,
        control_q_trace_post,
        result.condition.config,
    )

    behavior_logits = np.asarray(
        trace.behavior_logits_preupdate,
        dtype=np.float64,
    )[:cycle_steps]
    behavior_weights = behavior_weights_pre.astype(np.float64)
    representations_for_windows = representations.astype(np.float64)
    intended_actions = np.asarray(
        trace.partner_intended_action,
        dtype=np.int64,
    )[:cycle_steps]
    if (
        behavior_logits.shape != (cycle_steps, 2)
        or behavior_weights.shape != (cycle_steps, 2, 12)
        or representations_for_windows.shape != (cycle_steps, 12)
        or intended_actions.shape != (cycle_steps,)
        or not np.all(np.isfinite(behavior_logits))
        or not np.all(np.isfinite(behavior_weights))
        or not np.all(np.isfinite(representations_for_windows))
        or np.any((intended_actions < 0) | (intended_actions >= 2))
    ):
        raise ValueError("critical behavior primitive trace is invalid")
    closed_read_violations = ~consumer_mask_pre & (representations != 0.0)
    counter_violations = ~(
        (np.asarray(trace.state_builder_step_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.state_builder_learning_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.behavior_step_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.interaction_step_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.world_step_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.control_step_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.router_route_delta)[:cycle_steps] == 1)
        & (np.asarray(trace.integrated_step_delta)[:cycle_steps] == 1)
    )
    causal_violations = ~(
        np.asarray(trace.route_valid, dtype=np.bool_)[:cycle_steps]
        & np.asarray(
            trace.causal_transition_valid,
            dtype=np.bool_,
        )[:cycle_steps]
    )
    finite_violations = ~np.asarray(
        trace.all_finite,
        dtype=np.bool_,
    )[:cycle_steps]

    ends = np.cumsum(
        (0, *result.summary.segment_lengths),
        dtype=np.int64,
    )
    d_start, d_end = int(ends[3]), int(ends[4])
    c_start, c_end = int(ends[5]), int(ends[6])
    recurrent_c_start = int(ends[8])
    recurrent_c_end = recurrent_c_start + RECURRENT_ENTRY_WINDOW
    return {
        "schema_version": CRITICAL_RUN_PRIMITIVES_SCHEMA,
        "cycle_steps": cycle_steps,
        "reward_one_bits": _packed_bool_payload(rewards == 1.0),
        "evidence_refresh_bits": _packed_bool_payload(evidence),
        "retention_evidence_refresh_bits": _packed_bool_payload(
            confirmed_evidence,
        ),
        "feature_memory_committed_pre_bits": _packed_bool_payload(
            feature_committed_pre,
        ),
        "feature_memory_committed_post_bits": _packed_bool_payload(
            feature_committed_post,
        ),
        "identity_routed_head_changed_bits": _packed_bool_payload(
            feature_memory_audit.identity_routed_head_changed,
        ),
        "feature_memory_contract_violation_bits": _packed_bool_payload(
            feature_memory_audit.violation_bits,
        ),
        "feature_memory_enabled": result.condition.config.evidence_gated_feature_memory,
        "consumer_write_gate_bits": _packed_bool_payload(consumer_write_gate),
        "consumer_write_contract_violation_bits": _packed_bool_payload(
            consumer_gate_audit.write_violation_bits,
        ),
        "consumer_active_mask_pre_bits": _packed_bool_payload(consumer_mask_pre),
        "consumer_active_mask_post_bits": _packed_bool_payload(consumer_mask_post),
        "closed_consumer_read_violation_bits": _packed_bool_payload(closed_read_violations),
        "representation_link_violation_bits": _packed_bool_payload(link_violations),
        "counter_contract_violation_bits": _packed_bool_payload(counter_violations),
        "causal_contract_violation_bits": _packed_bool_payload(causal_violations),
        "finite_violation_bits": _packed_bool_payload(finite_violations),
        "bank_state_rle": _canonical_bank_state_rle(
            deployed_states,
            shadow_states,
        ),
        "candidate_bank_state_rle": _canonical_candidate_bank_state_rle(
            candidate_states,
        ),
        "feature_head_state_xor": _float32_state_sequence_payload(
            interaction_output_weights_pre,
            interaction_output_weights_post,
        ),
        "behavior_pair_weight_state_xor": _float32_state_sequence_payload(
            behavior_weights_pre,
            behavior_weights_post,
        ),
        "control_q_pair_weight_state_xor": _float32_state_sequence_payload(
            control_q_weights_pre,
            control_q_weights_post,
        ),
        "control_q_trace_state_xor": _float32_state_sequence_payload(
            control_q_trace_pre,
            control_q_trace_post,
        ),
        "critical_windows": {
            "c_first_late": _critical_window_primitives(
                behavior_logits=behavior_logits,
                behavior_weights=behavior_weights,
                representations=representations_for_windows,
                descriptors=deployed_pre,
                intended_actions=intended_actions,
                pair=_C_PAIR,
                entry_step=c_start,
                window_start=c_end - FEATURE_LEARNING_WINDOW,
                window_end_exclusive=c_end,
            ),
            "d_late": _critical_window_primitives(
                behavior_logits=behavior_logits,
                behavior_weights=behavior_weights,
                representations=representations_for_windows,
                descriptors=deployed_pre,
                intended_actions=intended_actions,
                pair=_D_PAIR,
                entry_step=d_start,
                window_start=d_end - FEATURE_LEARNING_WINDOW,
                window_end_exclusive=d_end,
            ),
            "c_recurrent_early": _critical_window_primitives(
                behavior_logits=behavior_logits,
                behavior_weights=behavior_weights,
                representations=representations_for_windows,
                descriptors=deployed_pre,
                intended_actions=intended_actions,
                pair=_C_PAIR,
                entry_step=c_start,
                window_start=recurrent_c_start,
                window_end_exclusive=recurrent_c_end,
            ),
        },
    }


def _first_sustained(
    values: np.ndarray,
    start: int,
    end_exclusive: int,
    window: int,
) -> int | None:
    selected = np.asarray(values[start:end_exclusive], dtype=np.int8)
    if selected.size < window:
        return None
    totals = np.convolve(
        selected,
        np.ones(window, dtype=np.int32),
        mode="valid",
    )
    hits = np.flatnonzero(totals == window)
    return None if hits.size == 0 else int(start + hits[0])


def _transition_count(values: np.ndarray, *, rising: bool) -> int:
    previous = np.asarray(values[:-1], dtype=np.bool_)
    current = np.asarray(values[1:], dtype=np.bool_)
    selected = (~previous & current) if rising else (previous & ~current)
    return int(np.sum(selected))


def _promotion_steps_from_presence(
    present_states: np.ndarray,
) -> tuple[int, ...]:
    """Return transition indices whose post-state first contains the pair."""
    present = np.asarray(present_states, dtype=np.bool_)
    if present.ndim != 1 or present.size < 2:
        raise ValueError("pair presence must contain at least two decision states")
    return tuple(int(step) for step in np.flatnonzero(~present[:-1] & present[1:]))


def _target_attributed_acquisition(
    evidence_refresh_steps: tuple[int, ...],
    present_states: np.ndarray,
    start: int,
    end_exclusive: int,
) -> int | None:
    for event_step in evidence_refresh_steps:
        effective_step = event_step + 1
        confirmation_end = effective_step + FEATURE_LEARNING_WINDOW
        if (
            start <= event_step < end_exclusive
            and confirmation_end <= end_exclusive
            and bool(present_states[event_step])
            and bool(np.all(present_states[event_step:confirmation_end]))
        ):
            return effective_step
    return None


def _target_evidence_refresh_steps(
    descriptor_slots: np.ndarray,
    evidence_refreshed: np.ndarray,
    start: int,
    end_exclusive: int,
) -> tuple[int, ...]:
    if evidence_refreshed.ndim != 2 or evidence_refreshed.shape[1] != 12:
        raise ValueError("evidence refresh trace must have shape (steps, 12)")
    steps: list[int] = []
    for step in range(start, end_exclusive):
        slot = int(descriptor_slots[step])
        if slot >= 0 and bool(evidence_refreshed[step, slot]):
            steps.append(step)
    return tuple(steps)


@dataclasses.dataclass(frozen=True)
class _CriticalColumnWindowMetrics:
    online_nll: float
    entry_frozen_nll: float
    learning_nll_gain: float
    learning_positive_fraction: float
    entry_frozen_accuracy: float
    learning_accuracy_gain: float
    masked_nll_increase: float
    masked_nll_positive_fraction: float


def _softmax_nll_and_prediction(
    logits: np.ndarray,
    intended_action: int,
) -> tuple[float, int]:
    centered = np.asarray(logits, dtype=np.float64) - float(np.max(logits))
    log_normalizer = math.log(float(np.sum(np.exp(centered))))
    return (
        float(-centered[intended_action] + log_normalizer),
        int(np.argmax(centered)),
    )


def _critical_column_window_metrics(
    behavior_logits: np.ndarray,
    behavior_weights: np.ndarray,
    representations: np.ndarray,
    descriptors: np.ndarray,
    intended_actions: np.ndarray,
    pair: tuple[int, int],
    *,
    entry_step: int,
    window_start: int,
    window_end_exclusive: int,
    temperature: float = 1.0,
) -> _CriticalColumnWindowMetrics:
    if not math.isfinite(temperature) or temperature <= 0.0:
        raise ValueError("behavior temperature must be finite and positive")
    target = np.asarray(pair, dtype=np.int32)
    entry_matches = np.all(descriptors[entry_step] == target, axis=1)
    if np.sum(entry_matches) > 1:
        raise ValueError("critical pair is duplicated at target entry")
    entry_weights = (
        np.zeros((2,), dtype=np.float64)
        if not np.any(entry_matches)
        else behavior_weights[
            entry_step,
            :,
            int(np.argmax(entry_matches)),
        ]
    )
    online_nll: list[float] = []
    counterfactual_nll: list[float] = []
    zero_column_nll: list[float] = []
    online_correct: list[float] = []
    counterfactual_correct: list[float] = []
    for step in range(window_start, window_end_exclusive):
        matches = np.all(descriptors[step] == target, axis=1)
        if np.sum(matches) > 1:
            raise ValueError("critical pair is duplicated in an evaluation window")
        if np.any(matches):
            slot = int(np.argmax(matches))
            current_weights = behavior_weights[step, :, slot]
            feature_value = representations[step, slot]
        else:
            current_weights = np.zeros((2,), dtype=np.float64)
            feature_value = 0.0
        online_logits = behavior_logits[step] / temperature
        counterfactual_logits = (
            behavior_logits[step] + (entry_weights - current_weights) * feature_value
        ) / temperature
        zero_logits = (behavior_logits[step] - current_weights * feature_value) / temperature
        intended = int(intended_actions[step])
        online_loss, online_prediction = _softmax_nll_and_prediction(
            online_logits,
            intended,
        )
        counterfactual_loss, counterfactual_prediction = _softmax_nll_and_prediction(
            counterfactual_logits,
            intended,
        )
        zero_loss, _ = _softmax_nll_and_prediction(
            zero_logits,
            intended,
        )
        online_nll.append(online_loss)
        counterfactual_nll.append(counterfactual_loss)
        zero_column_nll.append(zero_loss)
        online_correct.append(float(online_prediction == intended))
        counterfactual_correct.append(float(counterfactual_prediction == intended))
    online_mean = float(np.mean(online_nll))
    counterfactual_mean = float(np.mean(counterfactual_nll))
    per_step_gain = np.asarray(counterfactual_nll) - np.asarray(online_nll)
    per_step_masked_increase = np.asarray(zero_column_nll) - np.asarray(online_nll)
    online_accuracy = float(np.mean(online_correct))
    counterfactual_accuracy = float(np.mean(counterfactual_correct))
    return _CriticalColumnWindowMetrics(
        online_nll=online_mean,
        entry_frozen_nll=counterfactual_mean,
        learning_nll_gain=counterfactual_mean - online_mean,
        learning_positive_fraction=float(np.mean(per_step_gain > 0.0)),
        entry_frozen_accuracy=counterfactual_accuracy,
        learning_accuracy_gain=(online_accuracy - counterfactual_accuracy),
        masked_nll_increase=float(np.mean(per_step_masked_increase)),
        masked_nll_positive_fraction=float(np.mean(per_step_masked_increase > 0.0)),
    )


def _window_mean(values: np.ndarray, start: int, end_exclusive: int) -> float:
    selected = np.asarray(values[start:end_exclusive], dtype=np.float64)
    if selected.size == 0 or not np.all(np.isfinite(selected)):
        raise ValueError("lifecycle performance window is empty or non-finite")
    return float(np.mean(selected))


def summarize_critical_lifecycle_v2(
    result: HiddenPartnerRunResult,
) -> CriticalLifecycleV2Summary:
    """Reconstruct continuous lifecycle facts from one primitive decision trace."""
    summary = result.summary
    trace = result.trace
    cycle_steps = summary.cycle_steps
    deployed_pre = np.asarray(
        trace.active_descriptors,
        dtype=np.int32,
    )[:cycle_steps]
    deployed_post = np.asarray(
        trace.deployed_descriptors_post,
        dtype=np.int32,
    )[:cycle_steps]
    shadow_pre = np.asarray(
        trace.shadow_descriptors_pre,
        dtype=np.int32,
    )[:cycle_steps]
    shadow_post = np.asarray(
        trace.shadow_descriptors_post,
        dtype=np.int32,
    )[:cycle_steps]
    candidates = np.asarray(trace.candidate_descriptors, dtype=np.int32)[:cycle_steps]
    candidates_post = np.asarray(
        trace.candidate_descriptors_post,
        dtype=np.int32,
    )[:cycle_steps]
    candidate_utilities_post = np.asarray(
        trace.candidate_utilities_post,
        dtype=np.float64,
    )[:cycle_steps]
    candidate_output_weights_post = np.asarray(
        trace.candidate_output_weights_post,
        dtype=np.float64,
    )[:cycle_steps]
    candidate_ages_post = np.asarray(
        trace.candidate_ages_post,
        dtype=np.int64,
    )[:cycle_steps]
    rewards = np.asarray(trace.reward, dtype=np.float64)[:cycle_steps]
    intended_correct = np.asarray(
        trace.behavior_intended_correct,
        dtype=np.bool_,
    )[:cycle_steps]
    intended_actions = np.asarray(
        trace.partner_intended_action,
        dtype=np.int64,
    )[:cycle_steps]
    behavior_logits = np.asarray(
        trace.behavior_logits_preupdate,
        dtype=np.float64,
    )[:cycle_steps]
    behavior_weights = np.asarray(
        trace.behavior_pair_weights_pre,
        dtype=np.float64,
    )[:cycle_steps]
    behavior_weights_post = np.asarray(
        trace.behavior_pair_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_weights_pre = np.asarray(
        trace.control_pair_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_weights_post = np.asarray(
        trace.control_pair_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_trace_pre = np.asarray(
        trace.control_pair_trace_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    control_q_trace_post = np.asarray(
        trace.control_pair_trace_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    representations = np.asarray(
        trace.deployed_pair_features,
        dtype=np.float64,
    )[:cycle_steps]
    evidence_refreshed = np.asarray(
        trace.interaction_evidence_refreshed,
        dtype=np.bool_,
    )[:cycle_steps]
    retention_evidence_refreshed = np.asarray(
        trace.interaction_retention_evidence_refreshed,
        dtype=np.bool_,
    )[:cycle_steps]
    interaction_output_weights_pre = np.asarray(
        trace.interaction_output_weights_pre,
        dtype=np.float32,
    )[:cycle_steps]
    interaction_output_weights_post = np.asarray(
        trace.interaction_output_weights_post,
        dtype=np.float32,
    )[:cycle_steps]
    feature_streak_pre = np.asarray(
        trace.interaction_utility_evidence_streak_pre,
        dtype=np.int32,
    )[:cycle_steps]
    feature_streak_post = np.asarray(
        trace.interaction_utility_evidence_streak_post,
        dtype=np.int32,
    )[:cycle_steps]
    feature_committed_pre = np.asarray(
        trace.interaction_active_output_memory_committed_pre,
        dtype=np.bool_,
    )[:cycle_steps]
    feature_committed_post = np.asarray(
        trace.interaction_active_output_memory_committed_post,
        dtype=np.bool_,
    )[:cycle_steps]
    consumer_write_gate = np.asarray(
        trace.consumer_write_gate_pre,
        dtype=np.bool_,
    )[:cycle_steps]
    consumer_read_idle_pre = np.asarray(
        trace.consumer_read_idle_steps_pre,
        dtype=np.int32,
    )[:cycle_steps]
    consumer_read_idle_post = np.asarray(
        trace.consumer_read_idle_steps_post,
        dtype=np.int32,
    )[:cycle_steps]
    consumer_mask_pre = np.asarray(
        trace.consumer_active_mask_pre,
        dtype=np.bool_,
    )[:cycle_steps]
    consumer_mask_post = np.asarray(
        trace.consumer_active_mask_post,
        dtype=np.bool_,
    )[:cycle_steps]
    expected_descriptor_shape = (cycle_steps, 12, 2)
    for name, values in (
        ("deployed_pre", deployed_pre),
        ("deployed_post", deployed_post),
        ("shadow_pre", shadow_pre),
        ("shadow_post", shadow_post),
    ):
        if values.shape != expected_descriptor_shape:
            raise ValueError(f"{name} descriptor trace has the wrong shape")
    if cycle_steps <= 0:
        raise ValueError("cycle must contain at least one decision")
    deployed_states = np.concatenate(
        (deployed_pre, deployed_post[-1:]),
        axis=0,
    )
    shadow_states = np.concatenate(
        (shadow_pre, shadow_post[-1:]),
        axis=0,
    )
    decision_state_count = cycle_steps + 1
    reset_mask = np.asarray(
        trace.interaction_matching_candidate_reset_mask,
        dtype=np.bool_,
    )[:cycle_steps]
    reset_count = np.asarray(
        trace.interaction_matching_candidate_reset_count,
        dtype=np.int64,
    )[:cycle_steps]
    representation_link_contract = bool(
        np.array_equal(deployed_pre[1:], deployed_post[:-1])
        and np.array_equal(shadow_pre[1:], shadow_post[:-1])
        and np.array_equal(deployed_pre, shadow_pre)
        and np.array_equal(deployed_post, shadow_post)
        and reset_mask.shape == (cycle_steps, 66)
        and np.array_equal(
            reset_count,
            np.sum(reset_mask, axis=1, dtype=np.int64),
        )
    )
    consumer_gate_contract = _consumer_gate_contract_valid(
        deployed_pre,
        deployed_post,
        evidence_refreshed,
        consumer_write_gate,
        consumer_read_idle_pre,
        consumer_read_idle_post,
        consumer_mask_pre,
        consumer_mask_post,
        representations,
        behavior_weights.astype(np.float32),
        behavior_weights_post,
        control_q_weights_pre,
        control_q_weights_post,
        control_q_trace_pre,
        control_q_trace_post,
        result.condition.config,
    )
    feature_memory_enabled = result.condition.config.evidence_gated_feature_memory
    feature_memory_contract = _feature_memory_contract_audit(
        deployed_pre,
        deployed_post,
        shadow_pre,
        shadow_post,
        evidence_refreshed,
        retention_evidence_refreshed,
        interaction_output_weights_pre,
        interaction_output_weights_post,
        feature_streak_pre,
        feature_streak_post,
        feature_committed_pre,
        feature_committed_post,
        result.condition.config,
    ).valid

    c_deployed_slots = _descriptor_slots(
        deployed_states,
        _C_PAIR,
        require_exactly_one=False,
    )
    d_deployed_slots = _descriptor_slots(
        deployed_states,
        _D_PAIR,
        require_exactly_one=False,
    )
    c_shadow_slots = _descriptor_slots(
        shadow_states,
        _C_PAIR,
        require_exactly_one=False,
    )
    d_shadow_slots = _descriptor_slots(
        shadow_states,
        _D_PAIR,
        require_exactly_one=False,
    )
    candidate_archive_contract = _candidate_archive_contract_valid(
        candidates,
        candidates_post,
    )
    c_candidate_slots = _descriptor_slots(
        candidates,
        _C_PAIR,
        require_exactly_one=False,
    )
    d_candidate_slots = _descriptor_slots(
        candidates,
        _D_PAIR,
        require_exactly_one=False,
    )
    canonical_candidates = _canonical_candidate_descriptors()
    c_canonical_slot = int(
        np.flatnonzero(
            np.all(canonical_candidates == np.asarray(_C_PAIR), axis=1)
        )[0]
    )
    d_canonical_slot = int(
        np.flatnonzero(
            np.all(canonical_candidates == np.asarray(_D_PAIR), axis=1)
        )[0]
    )
    c_candidate_slots = np.where(
        c_candidate_slots >= 0,
        c_candidate_slots,
        c_canonical_slot,
    ).astype(np.int32)
    d_candidate_slots = np.where(
        d_candidate_slots >= 0,
        d_candidate_slots,
        d_canonical_slot,
    ).astype(np.int32)
    c_candidate_state_slots = np.concatenate(
        (c_candidate_slots, c_candidate_slots[-1:]),
    )
    d_candidate_state_slots = np.concatenate(
        (d_candidate_slots, d_candidate_slots[-1:]),
    )
    c_present = c_deployed_slots >= 0
    d_present = d_deployed_slots >= 0
    c_mismatch_steps = int(np.sum(c_deployed_slots != c_shadow_slots))
    d_mismatch_steps = int(np.sum(d_deployed_slots != d_shadow_slots))

    ends = np.cumsum((0, *summary.segment_lengths), dtype=np.int64)
    d_start, d_end = int(ends[3]), int(ends[4])
    first_c_start, first_c_end = int(ends[5]), int(ends[6])
    recurrent_c_start = int(ends[8])

    # Promotion is a representation state transition, not a trusted event
    # label.  Deriving it from the T+1 decision-state sequence prevents an
    # omitted repromotion diagnostic from manufacturing stable retirement.
    c_promotion_steps = _promotion_steps_from_presence(c_present)
    d_promotion_steps = _promotion_steps_from_presence(d_present)
    c_target_refresh_steps = _target_evidence_refresh_steps(
        c_deployed_slots,
        evidence_refreshed,
        first_c_start,
        first_c_end,
    )
    d_target_refresh_steps = _target_evidence_refresh_steps(
        d_deployed_slots,
        evidence_refreshed,
        d_start,
        d_end,
    )
    c_acquisition = _target_attributed_acquisition(
        c_target_refresh_steps,
        c_present,
        first_c_start,
        first_c_end,
    )
    c_first_late_start = first_c_end - FEATURE_LEARNING_WINDOW
    c_first_late_reward = _window_mean(
        rewards,
        c_first_late_start,
        first_c_end,
    )
    c_first_late_accuracy = _window_mean(
        intended_correct,
        c_first_late_start,
        first_c_end,
    )
    c_first_window = _critical_column_window_metrics(
        behavior_logits,
        behavior_weights,
        representations,
        deployed_pre,
        intended_actions,
        _C_PAIR,
        entry_step=first_c_start,
        window_start=c_first_late_start,
        window_end_exclusive=first_c_end,
    )
    c_target_created_share = c_first_window.learning_nll_gain / max(
        c_first_window.masked_nll_increase,
        1e-12,
    )
    c_task_learned = (
        representation_link_contract
        and c_mismatch_steps == 0
        and c_acquisition is not None
        and c_first_late_reward >= INITIAL_LATE_REWARD_THRESHOLD
        and c_first_late_accuracy >= CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD
        and c_first_window.learning_nll_gain >= CRITICAL_COLUMN_LEARNING_NLL_GAIN_THRESHOLD
        and c_first_window.learning_positive_fraction
        >= CRITICAL_COLUMN_LEARNING_POSITIVE_FRACTION_THRESHOLD
        and c_target_created_share >= CRITICAL_COLUMN_TARGET_CREATED_SHARE_THRESHOLD
        and c_first_window.masked_nll_increase >= CRITICAL_MASKED_NLL_INCREASE_THRESHOLD
        and c_first_window.masked_nll_positive_fraction
        >= CRITICAL_MASKED_NLL_POSITIVE_FRACTION_THRESHOLD
    )
    c_survival_end = min(
        cycle_steps,
        recurrent_c_start + RECURRENT_ENTRY_WINDOW,
    )
    if c_acquisition is None:
        c_gap_steps = None
        c_first_gap = None
        c_evictions = 0
        c_repromotions = 0
        c_continuous = False
    else:
        c_interval = c_present[c_acquisition:c_survival_end]
        missing = np.flatnonzero(~c_interval)
        c_gap_steps = int(missing.size)
        c_first_gap = None if missing.size == 0 else int(c_acquisition + missing[0])
        c_evictions = _transition_count(c_interval, rising=False)
        c_repromotions = sum(
            c_acquisition < event_step + 1 < c_survival_end for event_step in c_promotion_steps
        )
        c_continuous = c_gap_steps == 0

    recurrent_c_end = min(
        cycle_steps,
        recurrent_c_start + RECURRENT_ENTRY_WINDOW,
    )
    c_early_reward = _window_mean(
        rewards,
        recurrent_c_start,
        recurrent_c_end,
    )
    c_retention_ratio = (c_early_reward - CHANCE_REWARD) / max(
        c_first_late_reward - CHANCE_REWARD,
        1e-7,
    )
    c_early_accuracy = _window_mean(
        intended_correct,
        recurrent_c_start,
        recurrent_c_end,
    )
    c_recurrent_window = _critical_column_window_metrics(
        behavior_logits,
        behavior_weights,
        representations,
        deployed_pre,
        intended_actions,
        _C_PAIR,
        entry_step=first_c_start,
        window_start=recurrent_c_start,
        window_end_exclusive=recurrent_c_end,
    )
    c_retained_and_used = (
        c_task_learned
        and c_continuous
        and c_early_reward >= RECURRENT_EARLY_REWARD_THRESHOLD
        and c_retention_ratio >= RETENTION_RATIO_THRESHOLD
        and c_early_accuracy >= CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD
        and c_recurrent_window.masked_nll_increase >= CRITICAL_MASKED_NLL_INCREASE_THRESHOLD
        and c_recurrent_window.masked_nll_positive_fraction
        >= CRITICAL_MASKED_NLL_POSITIVE_FRACTION_THRESHOLD
    )

    d_acquisition = _target_attributed_acquisition(
        d_target_refresh_steps,
        d_present,
        d_start,
        d_end,
    )
    d_through_exit = bool(np.all(d_present[d_end - FEATURE_LEARNING_WINDOW : d_end]))
    d_late_start = d_end - FEATURE_LEARNING_WINDOW
    d_late_reward = _window_mean(rewards, d_late_start, d_end)
    d_late_accuracy = _window_mean(
        intended_correct,
        d_late_start,
        d_end,
    )
    d_late_window = _critical_column_window_metrics(
        behavior_logits,
        behavior_weights,
        representations,
        deployed_pre,
        intended_actions,
        _D_PAIR,
        entry_step=d_start,
        window_start=d_late_start,
        window_end_exclusive=d_end,
    )
    d_target_created_share = d_late_window.learning_nll_gain / max(
        d_late_window.masked_nll_increase,
        1e-12,
    )
    d_task_learned = (
        representation_link_contract
        and d_mismatch_steps == 0
        and d_acquisition is not None
        and d_through_exit
        and d_late_reward >= INITIAL_LATE_REWARD_THRESHOLD
        and d_late_accuracy >= CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD
        and d_late_window.learning_nll_gain >= CRITICAL_COLUMN_LEARNING_NLL_GAIN_THRESHOLD
        and d_late_window.learning_positive_fraction
        >= CRITICAL_COLUMN_LEARNING_POSITIVE_FRACTION_THRESHOLD
        and d_target_created_share >= CRITICAL_COLUMN_TARGET_CREATED_SHARE_THRESHOLD
        and d_late_window.masked_nll_increase >= CRITICAL_MASKED_NLL_INCREASE_THRESHOLD
        and d_late_window.masked_nll_positive_fraction
        >= CRITICAL_MASKED_NLL_POSITIVE_FRACTION_THRESHOLD
    )
    d_post_exit = d_present[d_end:cycle_steps]
    d_post_exit_steps = int(np.sum(d_post_exit))
    d_post_exit_promotions = sum(event_step >= d_end for event_step in d_promotion_steps)
    d_final_absent = bool(np.all(~d_present[-(FINAL_ABSENCE_WINDOW + 1) :]))

    retired_left = np.asarray(trace.interaction_retired_left, dtype=np.int32)[:cycle_steps]
    retired_right = np.asarray(trace.interaction_retired_right, dtype=np.int32)[:cycle_steps]
    d_retired_events = (retired_left == _D_PAIR[0]) & (retired_right == _D_PAIR[1])
    d_event_steps = tuple(int(step) for step in np.flatnonzero(d_retired_events))
    d_event_reset_counts: list[int] = []
    d_event_candidate_utilities: list[float] = []
    d_event_candidate_head_linf: list[float] = []
    d_event_candidate_ages: list[int] = []
    for event_step in d_event_steps:
        candidate_index = int(d_candidate_slots[event_step])
        d_event_reset_counts.append(int(reset_mask[event_step, candidate_index]))
        d_event_candidate_utilities.append(
            float(candidate_utilities_post[event_step, candidate_index])
        )
        d_event_candidate_head_linf.append(
            float(
                np.max(
                    np.abs(
                        candidate_output_weights_post[
                            event_step,
                            :,
                            candidate_index,
                        ]
                    )
                )
            )
        )
        d_event_candidate_ages.append(int(candidate_ages_post[event_step, candidate_index]))

    d_retirement_event_step: int | None = None
    d_retirement: int | None = None
    d_event_latency: int | None = None
    d_latency: int | None = None
    d_linked_reset: int | None = None
    d_linked_utility: float | None = None
    d_linked_head_linf: float | None = None
    d_linked_age: int | None = None
    for event_index, event_step in enumerate(d_event_steps):
        effective_step = event_step + 1
        confirmation_end = effective_step + RETIREMENT_CONFIRMATION_WINDOW
        aligned = (
            event_step >= d_end
            and confirmation_end <= decision_state_count
            and bool(d_present[event_step])
            and not bool(d_present[effective_step])
            and bool(np.all(~d_present[effective_step:confirmation_end]))
            and d_event_reset_counts[event_index] == 1
            and d_event_candidate_utilities[event_index] == 0.0
            and d_event_candidate_head_linf[event_index] == 0.0
            and d_event_candidate_ages[event_index] == 0
            and event_step not in d_promotion_steps
        )
        if aligned:
            d_retirement_event_step = event_step
            d_retirement = effective_step
            d_event_latency = event_step - d_end
            d_latency = effective_step - d_end
            d_linked_reset = d_event_reset_counts[event_index]
            d_linked_utility = d_event_candidate_utilities[event_index]
            d_linked_head_linf = d_event_candidate_head_linf[event_index]
            d_linked_age = d_event_candidate_ages[event_index]
            break
    d_repromotions = (
        0
        if d_retirement_event_step is None
        else sum(event_step > d_retirement_event_step for event_step in d_promotion_steps)
    )
    d_retirement_event_count = len(d_event_steps)
    d_candidate_reset_count = int(sum(d_event_reset_counts))
    d_event_aligned = d_retirement_event_step is not None
    d_stably_retired = d_task_learned and d_event_aligned and d_final_absent and d_repromotions == 0

    c_candidate_index = int(c_candidate_slots[-1])
    d_candidate_index = int(d_candidate_slots[-1])
    joint_memory_management_success = bool(
        representation_link_contract
        and consumer_gate_contract
        and feature_memory_enabled
        and feature_memory_contract
        and candidate_archive_contract
        and c_retained_and_used
        and d_stably_retired
    )
    return CriticalLifecycleV2Summary(
        cycle_steps=cycle_steps,
        decision_state_count=decision_state_count,
        representation_link_contract_valid=representation_link_contract,
        consumer_gate_contract_valid=consumer_gate_contract,
        feature_memory_enabled=feature_memory_enabled,
        feature_memory_contract_valid=feature_memory_contract,
        c_shadow_deployed_mismatch_steps=c_mismatch_steps,
        d_shadow_deployed_mismatch_steps=d_mismatch_steps,
        c_promotion_event_steps=c_promotion_steps,
        c_target_evidence_refresh_steps=c_target_refresh_steps,
        c_acquisition_step=c_acquisition,
        c_first_late_reward=c_first_late_reward,
        c_first_late_intended_accuracy=c_first_late_accuracy,
        c_first_late_online_nll=c_first_window.online_nll,
        c_first_late_entry_frozen_critical_nll=(c_first_window.entry_frozen_nll),
        c_critical_column_learning_nll_gain=(c_first_window.learning_nll_gain),
        c_critical_column_learning_positive_fraction=(c_first_window.learning_positive_fraction),
        c_critical_column_target_created_share=c_target_created_share,
        c_first_late_entry_frozen_critical_accuracy=(c_first_window.entry_frozen_accuracy),
        c_critical_column_learning_accuracy_gain=(c_first_window.learning_accuracy_gain),
        c_first_late_masked_nll_increase=(c_first_window.masked_nll_increase),
        c_first_late_masked_nll_positive_fraction=(c_first_window.masked_nll_positive_fraction),
        c_task_learned=c_task_learned,
        c_survival_end_exclusive=c_survival_end,
        c_survival_gap_steps=c_gap_steps,
        c_first_survival_gap_step=c_first_gap,
        c_evictions_after_acquisition=c_evictions,
        c_repromotions_after_acquisition=c_repromotions,
        c_continuously_survived=c_continuous,
        c_recurrent_early_reward=c_early_reward,
        c_recurrent_early_excess_reward_retention=c_retention_ratio,
        c_recurrent_early_intended_accuracy=c_early_accuracy,
        c_recurrent_early_masked_nll_increase=(c_recurrent_window.masked_nll_increase),
        c_recurrent_early_masked_nll_positive_fraction=(
            c_recurrent_window.masked_nll_positive_fraction
        ),
        c_retained_and_used=c_retained_and_used,
        d_promotion_event_steps=d_promotion_steps,
        d_target_evidence_refresh_steps=d_target_refresh_steps,
        d_acquisition_step=d_acquisition,
        d_deployed_through_exit=d_through_exit,
        d_late_reward=d_late_reward,
        d_late_intended_accuracy=d_late_accuracy,
        d_late_online_nll=d_late_window.online_nll,
        d_late_entry_frozen_critical_nll=(d_late_window.entry_frozen_nll),
        d_critical_column_learning_nll_gain=(d_late_window.learning_nll_gain),
        d_critical_column_learning_positive_fraction=(d_late_window.learning_positive_fraction),
        d_critical_column_target_created_share=d_target_created_share,
        d_late_entry_frozen_critical_accuracy=(d_late_window.entry_frozen_accuracy),
        d_critical_column_learning_accuracy_gain=(d_late_window.learning_accuracy_gain),
        d_late_masked_nll_increase=d_late_window.masked_nll_increase,
        d_late_masked_nll_positive_fraction=(d_late_window.masked_nll_positive_fraction),
        d_task_learned=d_task_learned,
        d_retirement_event_step=d_retirement_event_step,
        d_retirement_step=d_retirement,
        d_retirement_event_latency_steps=d_event_latency,
        d_retirement_latency_steps=d_latency,
        d_post_exit_live_slot_steps=d_post_exit_steps,
        d_post_exit_live_fraction=d_post_exit_steps / max(cycle_steps - d_end, 1),
        d_post_exit_promotion_count=d_post_exit_promotions,
        d_repromotions_after_retirement=d_repromotions,
        d_absent_entire_final_window=d_final_absent,
        d_retirement_event_steps=d_event_steps,
        d_retirement_event_reset_counts=tuple(d_event_reset_counts),
        d_retirement_event_candidate_utility_post=tuple(d_event_candidate_utilities),
        d_retirement_event_candidate_head_linf_post=tuple(d_event_candidate_head_linf),
        d_retirement_event_candidate_age_post=tuple(d_event_candidate_ages),
        d_retirement_event_count=d_retirement_event_count,
        d_matching_candidate_reset_count=d_candidate_reset_count,
        d_linked_matching_candidate_reset_count=d_linked_reset,
        d_linked_candidate_utility_post=d_linked_utility,
        d_linked_candidate_head_linf_post=d_linked_head_linf,
        d_linked_candidate_age_post=d_linked_age,
        d_retirement_event_aligned=d_event_aligned,
        d_learned_then_stably_retired=d_stably_retired,
        joint_memory_management_success=joint_memory_management_success,
        candidate_archive_contract_valid=candidate_archive_contract,
        c_candidate_utility_at_life_end=float(candidate_utilities_post[-1, c_candidate_index]),
        d_candidate_utility_at_life_end=float(candidate_utilities_post[-1, d_candidate_index]),
        c_lifecycle_rle=_canonical_lifecycle_rle(
            c_deployed_slots,
            c_shadow_slots,
            c_candidate_state_slots,
        ),
        d_lifecycle_rle=_canonical_lifecycle_rle(
            d_deployed_slots,
            d_shadow_slots,
            d_candidate_state_slots,
        ),
    )


def _cell_digest(cell: EvidenceLeaseTuningCell) -> str:
    serialized = json.dumps(
        cell.to_dict(),
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(serialized).hexdigest()


def _all_run_contracts_valid(
    summary: HiddenPartnerRunSummary,
    lifecycle: CriticalLifecycleV2Summary,
) -> bool:
    """Return the fail-closed contract predicate used by grid feasibility."""
    return bool(
        summary.all_finite
        and summary.counter_contract_valid
        and summary.causal_contract_valid
        and summary.resource_shape_matched
        and lifecycle.representation_link_contract_valid
        and lifecycle.consumer_gate_contract_valid
        and lifecycle.feature_memory_enabled
        and lifecycle.feature_memory_contract_valid
        and lifecycle.candidate_archive_contract_valid
    )


def run_evidence_lease_tuning_grid(
    *,
    seed_pairs: Sequence[HiddenPartnerSeedPair] | None = None,
    protocol: HiddenPartnerDevelopmentProtocol | None = None,
) -> dict[str, object]:
    """Execute the reserved v4 development grid and select only feasible cells."""
    resolved_seeds = (
        derive_hidden_partner_seed_pairs(
            LEASE_TUNING_NAMESPACE,
            LEASE_TUNING_SEED_COUNT,
        )
        if seed_pairs is None
        else tuple(seed_pairs)
    )
    expected_seeds = derive_hidden_partner_seed_pairs(
        LEASE_TUNING_NAMESPACE,
        LEASE_TUNING_SEED_COUNT,
    )
    if resolved_seeds != expected_seeds:
        raise ValueError("tuning seeds must be the exact derived eight-pair v4 grid")
    resolved_protocol = HiddenPartnerDevelopmentProtocol() if protocol is None else protocol
    if resolved_protocol.to_config() != HiddenPartnerDevelopmentProtocol().to_config():
        raise ValueError("lease tuning requires the exact default hidden-partner protocol")
    run_records: list[dict[str, object]] = []
    aggregates: list[dict[str, object]] = []
    required_successes = math.ceil(MINIMUM_JOINT_SUCCESS_FRACTION * len(resolved_seeds))
    for cell in LEASE_TUNING_GRID:
        condition = HiddenPartnerCondition(
            name="full",
            config=cell.agent_config(),
            isolated_question=f"evidence-lease tuning cell {cell.index}",
        )
        runner = HiddenPartnerDevelopmentRunner(condition, resolved_protocol)
        cell_digest = _cell_digest(cell)
        condition_config = condition.to_config()
        cell_records: list[tuple[HiddenPartnerRunResult, CriticalLifecycleV2Summary]] = []
        for seed_pair in resolved_seeds:
            result = runner.run(seed_pair)
            lifecycle = summarize_critical_lifecycle_v2(result)
            run_primitives = critical_run_primitives(result)
            cell_records.append((result, lifecycle))
            run_records.append(
                {
                    "cell_index": cell.index,
                    "cell_digest": cell_digest,
                    "condition_config": condition_config,
                    "seed_pair": seed_pair.to_dict(),
                    "run_summary": result.summary.to_dict(),
                    "critical_lifecycle": lifecycle.to_dict(),
                    "critical_run_primitives": run_primitives,
                }
            )
        summaries = [item[0].summary for item in cell_records]
        lifecycles = [item[1] for item in cell_records]
        rewards = np.asarray(
            [summary.mean_reward for summary in summaries],
            dtype=np.float64,
        )
        joint_count = sum(lifecycle.joint_memory_management_success for lifecycle in lifecycles)
        c_count = sum(lifecycle.c_retained_and_used for lifecycle in lifecycles)
        d_count = sum(lifecycle.d_learned_then_stably_retired for lifecycle in lifecycles)
        latencies = [
            lifecycle.d_retirement_latency_steps
            for lifecycle in lifecycles
            if lifecycle.d_retirement_latency_steps is not None
        ]
        contracts_valid = all(
            _all_run_contracts_valid(summary, lifecycle)
            for summary, lifecycle in zip(
                summaries,
                lifecycles,
                strict=True,
            )
        )
        feasible = (
            contracts_valid
            and float(np.mean(rewards)) >= 0.85
            and float(np.min(rewards)) >= 0.80
            and joint_count >= required_successes
            and c_count >= required_successes
            and d_count >= required_successes
        )
        aggregates.append(
            {
                "cell_index": cell.index,
                "cell_digest": cell_digest,
                "seed_count": len(resolved_seeds),
                "required_success_count": required_successes,
                "finite_contract_valid": contracts_valid,
                "mean_reward": float(np.mean(rewards)),
                "minimum_seed_reward": float(np.min(rewards)),
                "joint_success_count": joint_count,
                "c_retained_and_used_count": c_count,
                "d_learned_then_stably_retired_count": d_count,
                "total_d_repromotions": int(
                    sum(lifecycle.d_repromotions_after_retirement for lifecycle in lifecycles)
                ),
                "median_d_retirement_latency_steps": (
                    None if not latencies else float(np.median(latencies))
                ),
                "feasible": feasible,
            }
        )

    feasible_cells = [record for record in aggregates if record["feasible"]]
    selected: dict[str, object] | None = None
    if feasible_cells:
        selected = max(
            feasible_cells,
            key=lambda record: (
                cast(int, record["joint_success_count"]),
                cast(float, record["minimum_seed_reward"]),
                cast(float, record["mean_reward"]),
                -cast(int, record["total_d_repromotions"]),
                -cast(
                    float,
                    record["median_d_retirement_latency_steps"],
                ),
                -cast(int, record["cell_index"]),
            ),
        )
    return {
        "schema_version": HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA,
        "development_only": True,
        "scientific_promotion_allowed": False,
        "protocol": resolved_protocol.to_config(),
        "seed_namespace": LEASE_TUNING_NAMESPACE,
        "seed_pairs": [pair.to_dict() for pair in resolved_seeds],
        "grid": [cell.to_dict() for cell in LEASE_TUNING_GRID],
        "selection_rule": TUNING_SELECTION_RULE,
        "aggregates": aggregates,
        "selected_cell": selected,
        "runs": run_records,
        "scope_limits": list(LEASE_TUNING_SCOPE_LIMITS),
    }


__all__ = [
    "CRITICAL_LATE_PREDICTION_ACCURACY_THRESHOLD",
    "CRITICAL_RUN_PRIMITIVES_SCHEMA",
    "CriticalLifecycleV2Summary",
    "CriticalPairLifecycleInterval",
    "EvidenceLeaseTuningCell",
    "FEATURE_LEARNING_WINDOW",
    "FINAL_ABSENCE_WINDOW",
    "HIDDEN_PARTNER_LIFECYCLE_V2_SCHEMA",
    "LEASE_TUNING_GRID",
    "LEASE_TUNING_NAMESPACE",
    "LEASE_TUNING_SEED_COUNT",
    "MINIMUM_JOINT_SUCCESS_FRACTION",
    "RECURRENT_EARLY_REWARD_THRESHOLD",
    "RECURRENT_ENTRY_WINDOW",
    "RETENTION_RATIO_THRESHOLD",
    "RETIREMENT_CONFIRMATION_WINDOW",
    "TUNING_SELECTION_RULE",
    "critical_run_primitives",
    "run_evidence_lease_tuning_grid",
    "summarize_critical_lifecycle_v2",
]
