# mypy: disable-error-code="call-arg"
"""Development-only evaluation for the hidden-regime Lewis lifecycle.

The evaluator runs a helper and beneficiary through one uninterrupted hidden
regime life.  Both roles receive only their ordinary local input, their local
action, and the common scalar reward.  Segment identity, schedule position,
target permutations, and replacement provenance remain evaluator-only facts.

This module deliberately defines no acceptance threshold, artifact writer,
CLI, held-out protocol, or promotion path.  Its default schedule is long
enough for development inspection (every non-transient segment is sixteen
times the substrate default while D remains sixteen steps), but the reserved
seed namespace below is intentionally unexecuted.  Callers must supply seed
pairs explicitly.

The primitive trace records both role value banks as raw float32 bits before
and after every transition.  Consequently durable immutability is an exact
same-generation property: a selective durable table may change only at an
atomically reported retirement/commit transition that changes its generation.
This is a bounded three-slot mechanism test, not evidence that finite memory
can retain an unbounded number of arbitrary conventions.
"""

from __future__ import annotations

import dataclasses
import functools
import hashlib
from collections.abc import Mapping, Sequence
from typing import Any, Literal, cast

import jax
import jax.numpy as jnp
import jax.random as jr
import numpy as np
from jax import Array

from alberta_framework.core.slot_signaling_agent import (
    N_SLOTS,
    SLOT_DURABLE,
    SLOT_VACANT,
    SlotSignalingAgent,
    SlotSignalingConfig,
    SlotSignalingState,
    slot_signaling_keys,
    slot_signaling_resource_budget,
)
from alberta_framework.streams.hidden_regime_signaling import (
    CONSTANT_ZERO_TERNARY_CHANNEL,
    DEFAULT_REGIME_PERMUTATIONS,
    DEFAULT_SEGMENT_LENGTHS,
    DEFAULT_SEGMENT_REGIMES,
    DIRECT_TERNARY_CHANNEL,
    SHUFFLED_TERNARY_CHANNEL,
    HiddenRegimeChannel,
    HiddenRegimeSignalingWorld,
    HiddenRegimeWorldConfig,
    HiddenRegimeWorldState,
    hidden_regime_world_keys,
)

HIDDEN_REGIME_DEVELOPMENT_SCHEMA = "alberta.hidden-regime-signaling.development.v1"
HIDDEN_REGIME_TRACE_SCHEMA = "alberta.hidden-regime-signaling.primitive-trace.v1"
DEVELOPMENT_ONLY = True
SCIENTIFIC_PROMOTION_ALLOWED = False
ACCEPTANCE_STATUS = "descriptive_only_no_acceptance_gate"

# This namespace is a reservation, not an invitation to run it.  Tests use
# explicit manual seed pairs under unrelated names and never derive this set.
RESERVED_DEVELOPMENT_SEED_NAMESPACE = (
    "hidden-regime-signaling-v0-reserved-development-a-v1"
)
RESERVED_DEVELOPMENT_SEED_NAMESPACE_EXECUTED = False

CONSTANT_CHANNEL_SYMBOL = 0
EXPECTED_DYAD_STATE_BYTES = 552
DEVELOPMENT_CANDIDATE_PROVENANCE = (
    "lease_length=16, confirmation_steps=8, and candidate_confirmation_leases=4 "
    "were selected after descriptive runs on consumed manual development seeds; "
    "they are unfrozen, nonpromoting, and require a new preregistered protocol "
    "before any held-out scientific claim"
)

# Preserve the deliberately short D exposure while making every other default
# segment a useful development-length inspection window.
DEFAULT_DEVELOPMENT_SEGMENT_LENGTHS: tuple[int, ...] = tuple(
    length if regime == 4 else length * 16
    for length, regime in zip(
        DEFAULT_SEGMENT_LENGTHS,
        DEFAULT_SEGMENT_REGIMES,
        strict=True,
    )
)

SELECTIVE_FULL: Literal["selective_full"] = "selective_full"
WRITABLE_LRU: Literal["writable_lru"] = "writable_lru"
HELPER_FROZEN: Literal["helper_frozen"] = "helper_frozen"
BENEFICIARY_FROZEN: Literal["beneficiary_frozen"] = "beneficiary_frozen"
CONSTANT_CHANNEL: Literal["constant_channel_0"] = "constant_channel_0"
SHUFFLED_CHANNEL: Literal["shuffled_channel"] = "shuffled_channel"

type HiddenRegimeDevelopmentCondition = Literal[
    "selective_full",
    "writable_lru",
    "helper_frozen",
    "beneficiary_frozen",
    "constant_channel_0",
    "shuffled_channel",
]

MATCHED_CONDITIONS: tuple[HiddenRegimeDevelopmentCondition, ...] = (
    SELECTIVE_FULL,
    WRITABLE_LRU,
    HELPER_FROZEN,
    BENEFICIARY_FROZEN,
    CONSTANT_CHANNEL,
    SHUFFLED_CHANNEL,
)

_CHANNEL_DIRECT = 0
_CHANNEL_CONSTANT_ZERO = 1
_CHANNEL_SHUFFLED = 2


def _default_development_world() -> HiddenRegimeWorldConfig:
    return HiddenRegimeWorldConfig(
        segment_lengths=DEFAULT_DEVELOPMENT_SEGMENT_LENGTHS,
        segment_regimes=DEFAULT_SEGMENT_REGIMES,
        regime_permutations=DEFAULT_REGIME_PERMUTATIONS,
        repeat_schedule=False,
    )


def _default_development_learner() -> SlotSignalingConfig:
    """Return the explicitly calibrated, still-unfrozen development candidate."""

    return SlotSignalingConfig(
        lease_length=16,
        confirmation_steps=8,
        candidate_confirmation_leases=4,
    )


@dataclasses.dataclass(frozen=True)
class HiddenRegimeDevelopmentConfig:
    """Exact nonpromoting world, learner, and descriptive metric window."""

    world: HiddenRegimeWorldConfig = dataclasses.field(default_factory=_default_development_world)
    learner: SlotSignalingConfig = dataclasses.field(
        default_factory=_default_development_learner
    )
    metric_window: int = 128

    def __post_init__(self) -> None:
        if not isinstance(self.world, HiddenRegimeWorldConfig):
            raise TypeError("world must be a HiddenRegimeWorldConfig")
        if self.world.repeat_schedule:
            raise ValueError("development evaluation requires one finite nonrepeating schedule")
        if not isinstance(self.learner, SlotSignalingConfig):
            raise TypeError("learner must be a SlotSignalingConfig")
        if type(self.metric_window) is not int or self.metric_window < 1:
            raise ValueError("metric_window must be a positive integer")

    @property
    def num_steps(self) -> int:
        """Number of transitions in the uninterrupted finite development life."""

        return self.world.total_schedule_steps

    def to_dict(self) -> dict[str, object]:
        """Return a strict JSON-compatible nonpromotion record."""

        return {
            "schema_version": HIDDEN_REGIME_DEVELOPMENT_SCHEMA,
            "development_only": True,
            "scientific_promotion_allowed": False,
            "acceptance_status": ACCEPTANCE_STATUS,
            "claim_thresholds_frozen": False,
            "world": self.world.to_dict(),
            "learner": self.learner.to_dict(),
            "metric_window": self.metric_window,
            "num_steps": self.num_steps,
            "default_schedule_semantics": (
                "non-D substrate segments scaled by 16; D-transient fixed at 16 steps"
            ),
            "development_candidate_provenance": DEVELOPMENT_CANDIDATE_PROVENANCE,
            "retention_scope": (
                "three durable modules plus scratch; bounded hidden-regime development only"
            ),
        }


@dataclasses.dataclass(frozen=True)
class HiddenRegimeSeedPair:
    """Separated deterministic world and learner seeds."""

    namespace: str
    index: int
    world_seed: int
    learner_seed: int

    def __post_init__(self) -> None:
        if not isinstance(self.namespace, str) or not self.namespace:
            raise ValueError("namespace must be a non-empty string")
        if type(self.index) is not int or self.index < 0:
            raise ValueError("index must be a non-negative integer")
        for name in ("world_seed", "learner_seed"):
            value = getattr(self, name)
            if type(value) is not int or not 0 <= value <= 0xFFFFFFFF:
                raise ValueError(f"{name} must be a uint32 integer")

    def to_dict(self) -> dict[str, int | str]:
        return dataclasses.asdict(self)


def derive_hidden_regime_seed_pairs(
    namespace: str,
    count: int,
) -> tuple[HiddenRegimeSeedPair, ...]:
    """Derive stable SHA-256-separated world/learner uint32 seed pairs.

    Merely calling this function does not execute a protocol.  The reserved
    namespace remains unexecuted by this module and its tests.
    """

    if not isinstance(namespace, str) or not namespace:
        raise ValueError("namespace must be a non-empty string")
    if type(count) is not int or count < 1:
        raise ValueError("count must be a positive integer")
    pairs: list[HiddenRegimeSeedPair] = []
    for index in range(count):
        seeds: list[int] = []
        for owner in ("world", "learner"):
            material = (
                f"{HIDDEN_REGIME_DEVELOPMENT_SCHEMA}|{namespace}|{index}|{owner}"
            ).encode()
            seeds.append(int.from_bytes(hashlib.sha256(material).digest()[:4], "big"))
        pairs.append(HiddenRegimeSeedPair(namespace, index, seeds[0], seeds[1]))
    return tuple(pairs)


@dataclasses.dataclass(frozen=True)
class HiddenRegimeConditionSpec:
    """Exact fixed-resource intervention for one matched condition."""

    channel: HiddenRegimeChannel
    helper_write: bool
    beneficiary_write: bool
    writable_lru_ablation: bool


def condition_spec(condition: HiddenRegimeDevelopmentCondition) -> HiddenRegimeConditionSpec:
    """Return one condition without adding learner-visible oracle inputs."""

    if condition == SELECTIVE_FULL:
        return HiddenRegimeConditionSpec(DIRECT_TERNARY_CHANNEL, True, True, False)
    if condition == WRITABLE_LRU:
        return HiddenRegimeConditionSpec(DIRECT_TERNARY_CHANNEL, True, True, True)
    if condition == HELPER_FROZEN:
        return HiddenRegimeConditionSpec(DIRECT_TERNARY_CHANNEL, False, True, False)
    if condition == BENEFICIARY_FROZEN:
        return HiddenRegimeConditionSpec(DIRECT_TERNARY_CHANNEL, True, False, False)
    if condition == CONSTANT_CHANNEL:
        return HiddenRegimeConditionSpec(
            CONSTANT_ZERO_TERNARY_CHANNEL,
            True,
            True,
            False,
        )
    if condition == SHUFFLED_CHANNEL:
        return HiddenRegimeConditionSpec(SHUFFLED_TERNARY_CHANNEL, True, True, False)
    raise ValueError(f"unknown hidden-regime development condition: {condition!r}")


def _channel_code(channel: HiddenRegimeChannel) -> int:
    if channel == DIRECT_TERNARY_CHANNEL:
        return _CHANNEL_DIRECT
    if channel == CONSTANT_ZERO_TERNARY_CHANNEL:
        return _CHANNEL_CONSTANT_ZERO
    if channel == SHUFFLED_TERNARY_CHANNEL:
        return _CHANNEL_SHUFFLED
    raise ValueError(f"unsupported development channel: {channel!r}")


@dataclasses.dataclass(frozen=True)
class HiddenRegimePrimitiveTrace:
    """Fixed-shape primitives sufficient for independent summary reconstruction."""

    step_index: Array
    segment_index: Array
    segment_step: Array
    regime_id: Array
    helper_cue: Array
    oracle_target: Array
    helper_message: Array
    delivered_message: Array
    beneficiary_action: Array
    reward: Array
    helper_write_enabled: Array
    beneficiary_write_enabled: Array
    helper_active_slot_pre: Array
    helper_active_slot_post: Array
    beneficiary_active_slot_pre: Array
    beneficiary_active_slot_post: Array
    helper_status_pre: Array
    helper_status_post: Array
    beneficiary_status_pre: Array
    beneficiary_status_post: Array
    helper_generation_pre: Array
    helper_generation_post: Array
    beneficiary_generation_pre: Array
    beneficiary_generation_post: Array
    helper_candidate_confirmations_pre: Array
    helper_candidate_confirmations_post: Array
    beneficiary_candidate_confirmations_pre: Array
    beneficiary_candidate_confirmations_post: Array
    helper_value_write: Array
    beneficiary_value_write: Array
    helper_value_pre: Array
    helper_candidate_value: Array
    helper_value_post: Array
    beneficiary_value_pre: Array
    beneficiary_candidate_value: Array
    beneficiary_value_post: Array
    helper_lease_boundary: Array
    beneficiary_lease_boundary: Array
    helper_candidate_lease_success: Array
    beneficiary_candidate_lease_success: Array
    helper_committed_slot: Array
    helper_committed_generation: Array
    helper_retired_slot: Array
    helper_retired_generation: Array
    beneficiary_committed_slot: Array
    beneficiary_committed_generation: Array
    beneficiary_retired_slot: Array
    beneficiary_retired_generation: Array
    lifecycle_synchronized: Array
    helper_value_bits_pre: Array
    helper_value_bits_post: Array
    beneficiary_value_bits_pre: Array
    beneficiary_value_bits_post: Array
    helper_selective_mutation_violation: Array
    beneficiary_selective_mutation_violation: Array

    def to_dict(self) -> dict[str, object]:
        """Serialize raw primitives without an evaluator replay."""

        return {
            "schema_version": HIDDEN_REGIME_TRACE_SCHEMA,
            **{
                field.name: np.asarray(getattr(self, field.name)).tolist()
                for field in dataclasses.fields(self)
            },
        }


@dataclasses.dataclass(frozen=True)
class SegmentRewardSummary:
    """Descriptive prequential reward and recurrence metrics for one segment."""

    segment_index: int
    regime_id: int
    regime_label: str
    occurrence_index: int
    steps: int
    mean_reward: float
    early_reward: float
    late_reward: float
    is_recurrence: bool
    previous_occurrence_late_reward: float | None
    recurrence_entry_change: float | None
    within_segment_recovery: float

    def to_dict(self) -> dict[str, object]:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class RegimeRecurrenceSummary:
    """Aggregate recurrence-entry and within-segment recovery by regime."""

    regime_id: int
    regime_label: str
    occurrences: int
    recurrence_count: int
    recurrence_entry_reward_mean: float | None
    previous_late_reward_mean: float | None
    recurrence_entry_change_mean: float | None
    recurrence_recovery_mean: float | None

    def to_dict(self) -> dict[str, object]:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class HiddenRegimeResourceReport:
    """Exact initial/final dyad budget for a fixed-resource condition."""

    initial_state_scalars: int
    final_state_scalars: int
    initial_state_bytes: int
    final_state_bytes: int
    expected_state_bytes: int
    resource_constant: bool
    resource_matched: bool

    def to_dict(self) -> dict[str, object]:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class HiddenRegimeRunSummary:
    """Reconstructed descriptive outcomes for one uninterrupted life."""

    num_steps: int
    mean_prequential_reward: float
    recurrence_entry_reward_mean: float | None
    recurrence_recovery_mean: float | None
    segment_rewards: tuple[SegmentRewardSummary, ...]
    recurrence_by_regime: tuple[RegimeRecurrenceSummary, ...]
    helper_value_write_count: int
    beneficiary_value_write_count: int
    both_roles_learned: bool
    helper_commit_count: int
    beneficiary_commit_count: int
    helper_replacement_count: int
    beneficiary_replacement_count: int
    candidate_confirmation_events: int
    c_old_to_c_new_replacement_count: int
    c_old_to_c_new_target_slots: tuple[int, ...]
    c_old_to_c_new_generation_pairs: tuple[tuple[int, int], ...]
    c_old_to_c_new_exactly_one_target: bool
    d_short_checked: bool
    d_short_non_displacement: bool
    selective_immutability_applicable: bool
    helper_selective_mutation_violations: int
    beneficiary_selective_mutation_violations: int
    selective_durable_bit_immutable_until_atomic_replacement: bool
    lifecycle_synchronized_every_step: bool

    def to_dict(self) -> dict[str, object]:
        payload = dataclasses.asdict(self)
        payload["segment_rewards"] = [item.to_dict() for item in self.segment_rewards]
        payload["recurrence_by_regime"] = [
            item.to_dict() for item in self.recurrence_by_regime
        ]
        payload["c_old_to_c_new_target_slots"] = list(self.c_old_to_c_new_target_slots)
        payload["c_old_to_c_new_generation_pairs"] = [
            list(pair) for pair in self.c_old_to_c_new_generation_pairs
        ]
        return payload


@dataclasses.dataclass(frozen=True)
class HiddenRegimeRunResult:
    """One matched development condition with trace and reconstructed summary."""

    condition: HiddenRegimeDevelopmentCondition
    seed_pair: HiddenRegimeSeedPair
    config: HiddenRegimeDevelopmentConfig
    trace: HiddenRegimePrimitiveTrace
    summary: HiddenRegimeRunSummary
    resource: HiddenRegimeResourceReport
    final_state: SlotSignalingState

    def to_dict(self, *, include_trace: bool = True) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema_version": HIDDEN_REGIME_DEVELOPMENT_SCHEMA,
            "development_only": True,
            "scientific_promotion_allowed": False,
            "acceptance_status": ACCEPTANCE_STATUS,
            "claim_thresholds_frozen": False,
            "artifact_written": False,
            "reserved_namespace_executed": False,
            "oracle_upper_bound_included": False,
            "condition": self.condition,
            "seed_pair": self.seed_pair.to_dict(),
            "config": self.config.to_dict(),
            "resource": self.resource.to_dict(),
            "summary": self.summary.to_dict(),
            "trace_included": include_trace,
        }
        if include_trace:
            payload["trace"] = self.trace.to_dict()
        return payload


@dataclasses.dataclass(frozen=True)
class PairedControlMetric:
    """One same-seed, same-world descriptive comparison to selective full."""

    condition: str
    mean_prequential_reward: float
    delta_vs_selective_full: float
    recurrence_entry_reward_mean: float | None
    recurrence_entry_delta_vs_selective_full: float | None
    helper_value_write_count: int
    beneficiary_value_write_count: int
    resource_bytes: int

    def to_dict(self) -> dict[str, object]:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class HiddenRegimeDevelopmentReport:
    """All fixed-resource controls for one explicitly supplied seed pair."""

    seed_pair: HiddenRegimeSeedPair
    config: HiddenRegimeDevelopmentConfig
    runs: tuple[HiddenRegimeRunResult, ...]
    paired_controls: tuple[PairedControlMetric, ...]

    def to_dict(self, *, include_traces: bool = True) -> dict[str, object]:
        return {
            "schema_version": HIDDEN_REGIME_DEVELOPMENT_SCHEMA,
            "development_only": True,
            "scientific_promotion_allowed": False,
            "acceptance_status": ACCEPTANCE_STATUS,
            "claim_thresholds_frozen": False,
            "artifact_written": False,
            "reserved_seed_namespace": RESERVED_DEVELOPMENT_SEED_NAMESPACE,
            "reserved_namespace_executed": False,
            "oracle_upper_bound_included": False,
            "seed_pair": self.seed_pair.to_dict(),
            "config": self.config.to_dict(),
            "condition_order": [run.condition for run in self.runs],
            "runs": [run.to_dict(include_trace=include_traces) for run in self.runs],
            "paired_controls": [item.to_dict() for item in self.paired_controls],
        }


def _role_selective_mutation_violation(
    status_pre: Array,
    status_post: Array,
    generation_pre: Array,
    generation_post: Array,
    values_pre: Array,
    values_post: Array,
    committed_slot: Array,
    committed_generation: Array,
    retired_slot: Array,
    retired_generation: Array,
    writable_lru: bool,
) -> Array:
    """Flag any durable bit mutation not explained by one atomic replacement."""

    slot_ids = jnp.arange(N_SLOTS, dtype=jnp.int32)
    changed = jnp.any(values_pre != values_post, axis=(1, 2))
    was_durable = status_pre == SLOT_DURABLE
    atomic_replacement = jnp.logical_and(
        retired_slot == slot_ids,
        jnp.logical_and(
            committed_slot == slot_ids,
            jnp.logical_and(
                retired_generation == generation_pre,
                jnp.logical_and(
                    committed_generation == generation_post,
                    jnp.logical_and(
                        generation_pre != generation_post,
                        status_post == SLOT_DURABLE,
                    ),
                ),
            ),
        ),
    )
    violation = jnp.logical_and(was_durable, jnp.logical_and(changed, ~atomic_replacement))
    return jnp.where(jnp.asarray(writable_lru), jnp.zeros_like(violation), violation)


@functools.lru_cache(maxsize=16)
def _scan_runner(config: HiddenRegimeDevelopmentConfig, writable_lru: bool) -> Any:
    """Compile a single uninterrupted, fixed-shape development life."""

    world = HiddenRegimeSignalingWorld(config.world)
    learner_config = dataclasses.replace(
        config.learner,
        writable_lru_ablation=writable_lru,
    )
    learner = SlotSignalingAgent(learner_config)

    def run(
        world_state: HiddenRegimeWorldState,
        learner_state: SlotSignalingState,
        channel_code: Array,
        helper_write: Array,
        beneficiary_write: Array,
    ) -> Any:
        def step(
            carry: tuple[HiddenRegimeWorldState, SlotSignalingState],
            _: Array,
        ) -> tuple[
            tuple[HiddenRegimeWorldState, SlotSignalingState],
            tuple[Array, ...],
        ]:
            old_world, old_learner = carry
            observation = world.observe(old_world)
            # The helper sees only its private cue.
            helper = learner.select_helper(old_learner.helper, observation.helper_cue)
            shuffled_draw_key, _ = jr.split(old_world.channel_key)
            shuffled = jr.randint(shuffled_draw_key, (), 0, 3, dtype=jnp.int32)
            delivered = jnp.select(
                (
                    channel_code == _CHANNEL_DIRECT,
                    channel_code == _CHANNEL_CONSTANT_ZERO,
                ),
                (helper.action, jnp.asarray(CONSTANT_CHANNEL_SYMBOL, dtype=jnp.int32)),
                default=shuffled,
            ).astype(jnp.int32)
            # The beneficiary sees only the delivered ternary symbol.
            beneficiary = learner.select_beneficiary(old_learner.beneficiary, delivered)
            # Evaluator-only target/regime fields are created after both decisions.
            transition, next_world = world.step_with_delivery(
                old_world,
                helper.action,
                delivered,
                beneficiary.action,
            )
            update = learner.update(
                old_learner,
                helper,
                beneficiary,
                transition.reward,
                helper_write=helper_write,
                beneficiary_write=beneficiary_write,
            )
            old_helper_bits = jax.lax.bitcast_convert_type(
                old_learner.helper.values,
                jnp.uint32,
            )
            new_helper_bits = jax.lax.bitcast_convert_type(
                update.state.helper.values,
                jnp.uint32,
            )
            old_beneficiary_bits = jax.lax.bitcast_convert_type(
                old_learner.beneficiary.values,
                jnp.uint32,
            )
            new_beneficiary_bits = jax.lax.bitcast_convert_type(
                update.state.beneficiary.values,
                jnp.uint32,
            )
            helper_violation = _role_selective_mutation_violation(
                old_learner.helper.status,
                update.state.helper.status,
                old_learner.helper.generation,
                update.state.helper.generation,
                old_helper_bits,
                new_helper_bits,
                update.helper.committed_slot,
                update.helper.committed_generation,
                update.helper.retired_slot,
                update.helper.retired_generation,
                writable_lru,
            )
            beneficiary_violation = _role_selective_mutation_violation(
                old_learner.beneficiary.status,
                update.state.beneficiary.status,
                old_learner.beneficiary.generation,
                update.state.beneficiary.generation,
                old_beneficiary_bits,
                new_beneficiary_bits,
                update.beneficiary.committed_slot,
                update.beneficiary.committed_generation,
                update.beneficiary.retired_slot,
                update.beneficiary.retired_generation,
                writable_lru,
            )
            output = (
                transition.oracle.step_count,
                transition.oracle.segment_index,
                transition.oracle.segment_step,
                transition.oracle.regime_id,
                transition.observation.helper_cue,
                transition.oracle.target,
                transition.helper_message,
                transition.delivered_message,
                transition.beneficiary_action,
                transition.reward,
                helper_write,
                beneficiary_write,
                old_learner.helper.active_slot,
                update.state.helper.active_slot,
                old_learner.beneficiary.active_slot,
                update.state.beneficiary.active_slot,
                old_learner.helper.status,
                update.state.helper.status,
                old_learner.beneficiary.status,
                update.state.beneficiary.status,
                old_learner.helper.generation,
                update.state.helper.generation,
                old_learner.beneficiary.generation,
                update.state.beneficiary.generation,
                old_learner.helper.candidate_successful_leases,
                update.state.helper.candidate_successful_leases,
                old_learner.beneficiary.candidate_successful_leases,
                update.state.beneficiary.candidate_successful_leases,
                update.helper.value_write,
                update.beneficiary.value_write,
                update.helper.value_pre,
                update.helper.candidate_value,
                update.helper.value_post,
                update.beneficiary.value_pre,
                update.beneficiary.candidate_value,
                update.beneficiary.value_post,
                update.helper.lease_boundary,
                update.beneficiary.lease_boundary,
                update.helper.candidate_lease_success,
                update.beneficiary.candidate_lease_success,
                update.helper.committed_slot,
                update.helper.committed_generation,
                update.helper.retired_slot,
                update.helper.retired_generation,
                update.beneficiary.committed_slot,
                update.beneficiary.committed_generation,
                update.beneficiary.retired_slot,
                update.beneficiary.retired_generation,
                update.lifecycle_synchronized,
                old_helper_bits,
                new_helper_bits,
                old_beneficiary_bits,
                new_beneficiary_bits,
                helper_violation,
                beneficiary_violation,
            )
            return (next_world, update.state), output

        return jax.lax.scan(
            step,
            (world_state, learner_state),
            jnp.arange(config.num_steps, dtype=jnp.int32),
        )

    return jax.jit(run)


def _make_trace(outputs: tuple[Array, ...]) -> HiddenRegimePrimitiveTrace:
    values = list(outputs)
    int32_fields = {
        "step_index",
        "segment_index",
        "segment_step",
        "helper_generation_pre",
        "helper_generation_post",
        "beneficiary_generation_pre",
        "beneficiary_generation_post",
        "helper_candidate_confirmations_pre",
        "helper_candidate_confirmations_post",
        "beneficiary_candidate_confirmations_pre",
        "beneficiary_candidate_confirmations_post",
        "helper_committed_slot",
        "helper_committed_generation",
        "helper_retired_slot",
        "helper_retired_generation",
        "beneficiary_committed_slot",
        "beneficiary_committed_generation",
        "beneficiary_retired_slot",
        "beneficiary_retired_generation",
    }
    int8_fields = {
        "regime_id",
        "helper_cue",
        "oracle_target",
        "helper_message",
        "delivered_message",
        "beneficiary_action",
        "helper_active_slot_pre",
        "helper_active_slot_post",
        "beneficiary_active_slot_pre",
        "beneficiary_active_slot_post",
        "helper_status_pre",
        "helper_status_post",
        "beneficiary_status_pre",
        "beneficiary_status_post",
    }
    bool_fields = {
        "helper_write_enabled",
        "beneficiary_write_enabled",
        "helper_value_write",
        "beneficiary_value_write",
        "helper_lease_boundary",
        "beneficiary_lease_boundary",
        "helper_candidate_lease_success",
        "beneficiary_candidate_lease_success",
        "lifecycle_synchronized",
        "helper_selective_mutation_violation",
        "beneficiary_selective_mutation_violation",
    }
    uint_fields = {
        "helper_value_bits_pre",
        "helper_value_bits_post",
        "beneficiary_value_bits_pre",
        "beneficiary_value_bits_post",
    }
    converted: dict[str, Array] = {}
    for field, value in zip(dataclasses.fields(HiddenRegimePrimitiveTrace), values, strict=True):
        if field.name in int32_fields:
            converted[field.name] = value.astype(jnp.int32)
        elif field.name in int8_fields:
            converted[field.name] = value.astype(jnp.int8)
        elif field.name in bool_fields:
            converted[field.name] = value.astype(jnp.bool_)
        elif field.name in uint_fields:
            converted[field.name] = value.astype(jnp.uint32)
        else:
            converted[field.name] = value.astype(jnp.float32)
    return HiddenRegimePrimitiveTrace(**converted)


_REGIME_LABELS = {
    0: "A",
    1: "B",
    2: "C-old",
    3: "C-new",
    4: "D-short",
}


def _label(regime: int) -> str:
    return _REGIME_LABELS.get(regime, f"regime-{regime}")


def _segment_summaries(
    trace: HiddenRegimePrimitiveTrace,
    config: HiddenRegimeDevelopmentConfig,
) -> tuple[tuple[SegmentRewardSummary, ...], tuple[RegimeRecurrenceSummary, ...]]:
    rewards = np.asarray(trace.reward, dtype=np.float32)
    segments = np.asarray(trace.segment_index, dtype=np.int32)
    regimes = np.asarray(trace.regime_id, dtype=np.int32)
    occurrences: dict[int, int] = {}
    previous_late: dict[int, float] = {}
    summaries: list[SegmentRewardSummary] = []
    for segment_index, expected_regime in enumerate(config.world.segment_regimes):
        indices = np.flatnonzero(segments == segment_index)
        if indices.size == 0:
            continue
        regime = int(regimes[indices[0]])
        if regime != expected_regime:
            raise ValueError("trace regime does not match evaluator schedule")
        window = min(config.metric_window, int(indices.size))
        values = rewards[indices]
        early = float(np.mean(values[:window], dtype=np.float64))
        late = float(np.mean(values[-window:], dtype=np.float64))
        occurrence = occurrences.get(regime, 0)
        prior = previous_late.get(regime)
        summaries.append(
            SegmentRewardSummary(
                segment_index=segment_index,
                regime_id=regime,
                regime_label=_label(regime),
                occurrence_index=occurrence,
                steps=int(indices.size),
                mean_reward=float(np.mean(values, dtype=np.float64)),
                early_reward=early,
                late_reward=late,
                is_recurrence=occurrence > 0,
                previous_occurrence_late_reward=prior,
                recurrence_entry_change=None if prior is None else early - prior,
                within_segment_recovery=late - early,
            )
        )
        occurrences[regime] = occurrence + 1
        previous_late[regime] = late

    recurrence: list[RegimeRecurrenceSummary] = []
    for regime in sorted(occurrences):
        items = [item for item in summaries if item.regime_id == regime]
        recurrent = [item for item in items if item.is_recurrence]
        recurrence.append(
            RegimeRecurrenceSummary(
                regime_id=regime,
                regime_label=_label(regime),
                occurrences=len(items),
                recurrence_count=len(recurrent),
                recurrence_entry_reward_mean=(
                    None
                    if not recurrent
                    else float(np.mean([item.early_reward for item in recurrent]))
                ),
                previous_late_reward_mean=(
                    None
                    if not recurrent
                    else float(
                        np.mean(
                            [
                                cast(float, item.previous_occurrence_late_reward)
                                for item in recurrent
                            ]
                        )
                    )
                ),
                recurrence_entry_change_mean=(
                    None
                    if not recurrent
                    else float(
                        np.mean([cast(float, item.recurrence_entry_change) for item in recurrent])
                    )
                ),
                recurrence_recovery_mean=(
                    None
                    if not recurrent
                    else float(np.mean([item.within_segment_recovery for item in recurrent]))
                ),
            )
        )
    return tuple(summaries), tuple(recurrence)


def _replacement_provenance(
    trace: HiddenRegimePrimitiveTrace,
) -> tuple[tuple[int, ...], tuple[tuple[int, int], ...]]:
    committed_slots = np.asarray(trace.helper_committed_slot, dtype=np.int32)
    committed_generations = np.asarray(trace.helper_committed_generation, dtype=np.int32)
    retired_generations = np.asarray(trace.helper_retired_generation, dtype=np.int32)
    regimes = np.asarray(trace.regime_id, dtype=np.int32)
    generation_regime: dict[int, int] = {}
    targets: list[int] = []
    generation_pairs: list[tuple[int, int]] = []
    for step in np.flatnonzero(committed_slots >= 0):
        new_generation = int(committed_generations[step])
        retired_generation = int(retired_generations[step])
        regime = int(regimes[step])
        if (
            retired_generation >= 0
            and generation_regime.get(retired_generation) == 2
            and regime == 3
        ):
            targets.append(int(committed_slots[step]))
            generation_pairs.append((retired_generation, new_generation))
        generation_regime[new_generation] = regime
    return tuple(targets), tuple(generation_pairs)


def _d_short_non_displacement(
    trace: HiddenRegimePrimitiveTrace,
) -> tuple[bool, bool]:
    segments = np.asarray(trace.segment_index, dtype=np.int32)
    regimes = np.asarray(trace.regime_id, dtype=np.int32)
    d_segments = sorted(set(int(x) for x in segments[regimes == 4]))
    if not d_segments:
        return False, False
    for segment in d_segments:
        indices = np.flatnonzero(segments == segment)
        first = int(indices[0])
        last = int(indices[-1])
        for role in ("helper", "beneficiary"):
            status_pre = np.asarray(getattr(trace, f"{role}_status_pre"))[first]
            status_post = np.asarray(getattr(trace, f"{role}_status_post"))[last]
            generation_pre = np.asarray(getattr(trace, f"{role}_generation_pre"))[first]
            generation_post = np.asarray(getattr(trace, f"{role}_generation_post"))[last]
            if not np.array_equal(status_pre, status_post):
                return True, False
            if not np.array_equal(generation_pre, generation_post):
                return True, False
    return True, True


def reconstruct_hidden_regime_summary(
    trace: HiddenRegimePrimitiveTrace,
    config: HiddenRegimeDevelopmentConfig,
    condition: HiddenRegimeDevelopmentCondition,
) -> HiddenRegimeRunSummary:
    """Recompute all descriptive metrics from fixed-shape primitives."""

    segments, recurrence = _segment_summaries(trace, config)
    helper_writes = int(np.count_nonzero(np.asarray(trace.helper_value_write)))
    beneficiary_writes = int(np.count_nonzero(np.asarray(trace.beneficiary_value_write)))
    helper_commits = int(np.count_nonzero(np.asarray(trace.helper_committed_slot) >= 0))
    beneficiary_commits = int(
        np.count_nonzero(np.asarray(trace.beneficiary_committed_slot) >= 0)
    )
    helper_replacements = int(np.count_nonzero(np.asarray(trace.helper_retired_slot) >= 0))
    beneficiary_replacements = int(
        np.count_nonzero(np.asarray(trace.beneficiary_retired_slot) >= 0)
    )
    confirmation_events = int(
        np.count_nonzero(
            np.logical_and(
                np.asarray(trace.helper_candidate_lease_success),
                np.asarray(trace.helper_candidate_confirmations_post) == 0,
            )
        )
    )
    targets, generations = _replacement_provenance(trace)
    d_checked, d_non_displacement = _d_short_non_displacement(trace)
    spec = condition_spec(condition)
    helper_violations = int(
        np.count_nonzero(np.asarray(trace.helper_selective_mutation_violation))
    )
    beneficiary_violations = int(
        np.count_nonzero(np.asarray(trace.beneficiary_selective_mutation_violation))
    )
    immutability_applicable = not spec.writable_lru_ablation
    recurrent_segments = [
        segment
        for segment in segments
        if segment.is_recurrence and segment.regime_id in (0, 1, 2, 3)
    ]
    recurrence_entry_mean = (
        None
        if not recurrent_segments
        else float(np.mean([segment.early_reward for segment in recurrent_segments]))
    )
    recurrence_recovery_mean = (
        None
        if not recurrent_segments
        else float(np.mean([segment.within_segment_recovery for segment in recurrent_segments]))
    )
    return HiddenRegimeRunSummary(
        num_steps=int(np.asarray(trace.reward).size),
        mean_prequential_reward=float(
            np.mean(np.asarray(trace.reward, dtype=np.float32), dtype=np.float64)
        ),
        recurrence_entry_reward_mean=recurrence_entry_mean,
        recurrence_recovery_mean=recurrence_recovery_mean,
        segment_rewards=segments,
        recurrence_by_regime=recurrence,
        helper_value_write_count=helper_writes,
        beneficiary_value_write_count=beneficiary_writes,
        both_roles_learned=helper_writes > 0 and beneficiary_writes > 0,
        helper_commit_count=helper_commits,
        beneficiary_commit_count=beneficiary_commits,
        helper_replacement_count=helper_replacements,
        beneficiary_replacement_count=beneficiary_replacements,
        candidate_confirmation_events=confirmation_events,
        c_old_to_c_new_replacement_count=len(targets),
        c_old_to_c_new_target_slots=targets,
        c_old_to_c_new_generation_pairs=generations,
        c_old_to_c_new_exactly_one_target=len(targets) == 1,
        d_short_checked=d_checked,
        d_short_non_displacement=d_non_displacement,
        selective_immutability_applicable=immutability_applicable,
        helper_selective_mutation_violations=helper_violations,
        beneficiary_selective_mutation_violations=beneficiary_violations,
        selective_durable_bit_immutable_until_atomic_replacement=(
            immutability_applicable and helper_violations == 0 and beneficiary_violations == 0
        ),
        lifecycle_synchronized_every_step=bool(
            np.all(np.asarray(trace.lifecycle_synchronized))
        ),
    )


def _resource_report(
    initial_state: SlotSignalingState,
    final_state: SlotSignalingState,
) -> HiddenRegimeResourceReport:
    initial = slot_signaling_resource_budget(initial_state)
    final = slot_signaling_resource_budget(final_state)
    constant = (
        initial.state_scalars == final.state_scalars
        and initial.state_bytes == final.state_bytes
        and initial.state_bytes == EXPECTED_DYAD_STATE_BYTES
    )
    return HiddenRegimeResourceReport(
        initial_state_scalars=initial.state_scalars,
        final_state_scalars=final.state_scalars,
        initial_state_bytes=initial.state_bytes,
        final_state_bytes=final.state_bytes,
        expected_state_bytes=EXPECTED_DYAD_STATE_BYTES,
        resource_constant=constant,
        resource_matched=True,
    )


def run_hidden_regime_condition(
    condition: HiddenRegimeDevelopmentCondition,
    *,
    seed_pair: HiddenRegimeSeedPair,
    config: HiddenRegimeDevelopmentConfig | None = None,
) -> HiddenRegimeRunResult:
    """Run one explicitly seeded, fixed-resource condition in one JIT scan."""

    if not isinstance(seed_pair, HiddenRegimeSeedPair):
        raise TypeError("seed_pair must be a HiddenRegimeSeedPair")
    if seed_pair.namespace == RESERVED_DEVELOPMENT_SEED_NAMESPACE:
        raise ValueError("the reserved development namespace is intentionally unexecuted")
    config = config or HiddenRegimeDevelopmentConfig()
    spec = condition_spec(condition)
    world = HiddenRegimeSignalingWorld(config.world)
    learner = SlotSignalingAgent(
        dataclasses.replace(
            config.learner,
            writable_lru_ablation=spec.writable_lru_ablation,
        )
    )
    world_state = world.init(hidden_regime_world_keys(jr.key(seed_pair.world_seed)))
    learner_state = learner.init(slot_signaling_keys(jr.key(seed_pair.learner_seed)))
    (_, final_state), outputs = _scan_runner(config, spec.writable_lru_ablation)(
        world_state,
        learner_state,
        jnp.asarray(_channel_code(spec.channel), dtype=jnp.int32),
        jnp.asarray(spec.helper_write),
        jnp.asarray(spec.beneficiary_write),
    )
    trace = _make_trace(outputs)
    summary = reconstruct_hidden_regime_summary(trace, config, condition)
    resource = _resource_report(learner_state, final_state)
    return HiddenRegimeRunResult(
        condition=condition,
        seed_pair=seed_pair,
        config=config,
        trace=trace,
        summary=summary,
        resource=resource,
        final_state=final_state,
    )


def run_hidden_regime_development(
    *,
    seed_pair: HiddenRegimeSeedPair,
    config: HiddenRegimeDevelopmentConfig | None = None,
    conditions: Sequence[HiddenRegimeDevelopmentCondition] = MATCHED_CONDITIONS,
) -> HiddenRegimeDevelopmentReport:
    """Run explicitly requested matched controls without promotion or persistence."""

    config = config or HiddenRegimeDevelopmentConfig()
    condition_order = tuple(conditions)
    if not condition_order or SELECTIVE_FULL not in condition_order:
        raise ValueError("conditions must include selective_full")
    if len(set(condition_order)) != len(condition_order):
        raise ValueError("conditions must be unique")
    runs = tuple(
        run_hidden_regime_condition(condition, seed_pair=seed_pair, config=config)
        for condition in condition_order
    )
    selective = next(run for run in runs if run.condition == SELECTIVE_FULL)
    controls = tuple(
        PairedControlMetric(
            condition=run.condition,
            mean_prequential_reward=run.summary.mean_prequential_reward,
            delta_vs_selective_full=(
                run.summary.mean_prequential_reward
                - selective.summary.mean_prequential_reward
            ),
            recurrence_entry_reward_mean=run.summary.recurrence_entry_reward_mean,
            recurrence_entry_delta_vs_selective_full=(
                None
                if run.summary.recurrence_entry_reward_mean is None
                or selective.summary.recurrence_entry_reward_mean is None
                else run.summary.recurrence_entry_reward_mean
                - selective.summary.recurrence_entry_reward_mean
            ),
            helper_value_write_count=run.summary.helper_value_write_count,
            beneficiary_value_write_count=run.summary.beneficiary_value_write_count,
            resource_bytes=run.resource.final_state_bytes,
        )
        for run in runs
        if run.condition != SELECTIVE_FULL
    )
    return HiddenRegimeDevelopmentReport(seed_pair, config, runs, controls)


def _expected_trace_shapes(num_steps: int) -> dict[str, tuple[int, ...]]:
    vector_fields = {
        "helper_status_pre",
        "helper_status_post",
        "beneficiary_status_pre",
        "beneficiary_status_post",
        "helper_generation_pre",
        "helper_generation_post",
        "beneficiary_generation_pre",
        "beneficiary_generation_post",
        "helper_selective_mutation_violation",
        "beneficiary_selective_mutation_violation",
    }
    bank_fields = {
        "helper_value_bits_pre",
        "helper_value_bits_post",
        "beneficiary_value_bits_pre",
        "beneficiary_value_bits_post",
    }
    return {
        field.name: (
            (num_steps, N_SLOTS, 3, 3)
            if field.name in bank_fields
            else (num_steps, N_SLOTS)
            if field.name in vector_fields
            else (num_steps,)
        )
        for field in dataclasses.fields(HiddenRegimePrimitiveTrace)
    }


def _array_equal(left: Array, right: Array) -> bool:
    return bool(np.array_equal(np.asarray(left), np.asarray(right)))


def validate_hidden_regime_run_result(run: HiddenRegimeRunResult) -> tuple[str, ...]:
    """Fail closed on trace, resource, intervention, and summary inconsistency."""

    errors: list[str] = []
    if not isinstance(run, HiddenRegimeRunResult):
        return ("run must be a HiddenRegimeRunResult",)
    spec = condition_spec(run.condition)
    trace = run.trace
    expected_shapes = _expected_trace_shapes(run.config.num_steps)
    for field in dataclasses.fields(trace):
        value = np.asarray(getattr(trace, field.name))
        if value.shape != expected_shapes[field.name]:
            errors.append(f"trace.{field.name} shape mismatch")
        if value.dtype.kind == "f" and not np.all(np.isfinite(value)):
            errors.append(f"trace.{field.name} contains non-finite values")
    if errors:
        return tuple(errors)

    steps = np.asarray(trace.step_index, dtype=np.int32)
    if not np.array_equal(steps, np.arange(run.config.num_steps, dtype=np.int32)):
        errors.append("step_index is not the uninterrupted zero-based life")
    expected_segments = np.repeat(
        np.arange(len(run.config.world.segment_lengths), dtype=np.int32),
        run.config.world.segment_lengths,
    )
    expected_segment_steps = np.concatenate(
        [np.arange(length, dtype=np.int32) for length in run.config.world.segment_lengths]
    )
    expected_regimes = np.repeat(
        np.asarray(run.config.world.segment_regimes, dtype=np.int32),
        run.config.world.segment_lengths,
    )
    if not np.array_equal(trace.segment_index, expected_segments):
        errors.append("segment_index does not reconstruct the configured schedule")
    if not np.array_equal(trace.segment_step, expected_segment_steps):
        errors.append("segment_step does not reconstruct configured boundaries")
    if not np.array_equal(trace.regime_id, expected_regimes):
        errors.append("regime_id does not reconstruct the configured schedule")
    cues = np.asarray(trace.helper_cue, dtype=np.int32)
    targets = np.asarray(trace.oracle_target, dtype=np.int32)
    permutations = np.asarray(run.config.world.regime_permutations, dtype=np.int32)
    expected_targets = permutations[expected_regimes, cues]
    if not np.array_equal(targets, expected_targets):
        errors.append("oracle_target does not match evaluator-only permutation")
    expected_reward = (
        np.asarray(trace.beneficiary_action, dtype=np.int32) == expected_targets
    ).astype(np.float32)
    if not np.array_equal(np.asarray(trace.reward, dtype=np.float32), expected_reward):
        errors.append("reward is not the exact prequential action-target equality")

    if spec.channel == DIRECT_TERNARY_CHANNEL:
        if not _array_equal(trace.delivered_message, trace.helper_message):
            errors.append("direct channel changed the helper message")
    elif spec.channel == CONSTANT_ZERO_TERNARY_CHANNEL:
        if not np.array_equal(
            np.asarray(trace.delivered_message),
            np.full((run.config.num_steps,), CONSTANT_CHANNEL_SYMBOL, dtype=np.int8),
        ):
            errors.append("constant channel is not exact symbol 0")
    elif spec.channel == SHUFFLED_TERNARY_CHANNEL:
        world = HiddenRegimeSignalingWorld(run.config.world)
        state = world.init(hidden_regime_world_keys(jr.key(run.seed_pair.world_seed)))
        delivered: list[int] = []
        for message in np.asarray(trace.helper_message, dtype=np.int32):
            delivered.append(int(world.deliver(state, message, SHUFFLED_TERNARY_CHANNEL)))
            _, state = world.step_with_delivery(state, message, delivered[-1], 0)
        if not np.array_equal(trace.delivered_message, np.asarray(delivered, dtype=np.int8)):
            errors.append("shuffled channel does not match its isolated world RNG stream")

    for role, enabled in (
        ("helper", spec.helper_write),
        ("beneficiary", spec.beneficiary_write),
    ):
        if not np.array_equal(
            np.asarray(getattr(trace, f"{role}_write_enabled")),
            np.full((run.config.num_steps,), enabled, dtype=np.bool_),
        ):
            errors.append(f"{role} write intervention changed during the life")
        if not enabled and np.any(np.asarray(getattr(trace, f"{role}_value_write"))):
            errors.append(f"{role} frozen control contains an ordinary value write")
        for suffix in ("active_slot", "status", "generation", "value_bits"):
            pre = np.asarray(getattr(trace, f"{role}_{suffix}_pre"))
            post = np.asarray(getattr(trace, f"{role}_{suffix}_post"))
            if run.config.num_steps > 1 and not np.array_equal(pre[1:], post[:-1]):
                errors.append(f"{role} {suffix} trace continuity failed")
        pre_bits = np.asarray(getattr(trace, f"{role}_value_bits_pre"), dtype=np.uint32)
        post_bits = np.asarray(getattr(trace, f"{role}_value_bits_post"), dtype=np.uint32)
        pre_status = np.asarray(getattr(trace, f"{role}_status_pre"), dtype=np.int32)
        post_status = np.asarray(getattr(trace, f"{role}_status_post"), dtype=np.int32)
        pre_generation = np.asarray(
            getattr(trace, f"{role}_generation_pre"),
            dtype=np.int32,
        )
        post_generation = np.asarray(
            getattr(trace, f"{role}_generation_post"),
            dtype=np.int32,
        )
        committed_slot = np.asarray(getattr(trace, f"{role}_committed_slot"), dtype=np.int32)
        committed_generation = np.asarray(
            getattr(trace, f"{role}_committed_generation"),
            dtype=np.int32,
        )
        retired_slot = np.asarray(getattr(trace, f"{role}_retired_slot"), dtype=np.int32)
        retired_generation = np.asarray(
            getattr(trace, f"{role}_retired_generation"),
            dtype=np.int32,
        )
        recomputed = np.asarray(
            jax.vmap(
                lambda *args: _role_selective_mutation_violation(
                    *args,
                    spec.writable_lru_ablation,
                )
            )(
                jnp.asarray(pre_status),
                jnp.asarray(post_status),
                jnp.asarray(pre_generation),
                jnp.asarray(post_generation),
                jnp.asarray(pre_bits),
                jnp.asarray(post_bits),
                jnp.asarray(committed_slot),
                jnp.asarray(committed_generation),
                jnp.asarray(retired_slot),
                jnp.asarray(retired_generation),
            )
        )
        recorded = np.asarray(getattr(trace, f"{role}_selective_mutation_violation"))
        if not np.array_equal(recorded, recomputed):
            errors.append(f"{role} selective durable mutation audit mismatch")
        if not spec.writable_lru_ablation and np.any(recomputed):
            errors.append(f"{role} selective durable bits changed without atomic replacement")

        for step in np.flatnonzero(committed_slot >= 0):
            slot = int(committed_slot[step])
            if slot not in (1, 2, 3):
                errors.append(f"{role} commit target is not durable")
                continue
            if post_status[step, slot] != SLOT_DURABLE:
                errors.append(f"{role} committed slot is not durable post-state")
            if post_generation[step, slot] != committed_generation[step]:
                errors.append(f"{role} committed generation does not match post-state")
            replacement = retired_slot[step] >= 0
            if replacement:
                if retired_slot[step] != slot:
                    errors.append(f"{role} retirement and commit are not atomic in one slot")
                if pre_status[step, slot] != SLOT_DURABLE:
                    errors.append(f"{role} replacement did not retire a durable slot")
                if pre_generation[step, slot] != retired_generation[step]:
                    errors.append(f"{role} retired generation does not match pre-state")
                if pre_generation[step, slot] == post_generation[step, slot]:
                    errors.append(f"{role} replacement reused the same generation")
            elif pre_status[step, slot] != SLOT_VACANT:
                errors.append(f"{role} vacancy commit did not target a vacant slot")

    if not spec.helper_write or not spec.beneficiary_write:
        for role in ("helper", "beneficiary"):
            if np.any(np.asarray(getattr(trace, f"{role}_committed_slot")) >= 0):
                errors.append("freeze control bypassed the joint lifecycle commit gate")
            if np.any(np.asarray(getattr(trace, f"{role}_retired_slot")) >= 0):
                errors.append("freeze control bypassed the joint lifecycle replacement gate")
    if not np.all(np.asarray(trace.lifecycle_synchronized)):
        errors.append("role lifecycle states were not synchronized")
    for name in (
        "active_slot_pre",
        "active_slot_post",
        "status_pre",
        "status_post",
        "generation_pre",
        "generation_post",
        "candidate_confirmations_pre",
        "candidate_confirmations_post",
        "committed_slot",
        "committed_generation",
        "retired_slot",
        "retired_generation",
    ):
        if not _array_equal(
            getattr(trace, f"helper_{name}"),
            getattr(trace, f"beneficiary_{name}"),
        ):
            errors.append(f"synchronized lifecycle field {name} differs by role")

    recomputed_summary = reconstruct_hidden_regime_summary(trace, run.config, run.condition)
    if recomputed_summary.to_dict() != run.summary.to_dict():
        errors.append("summary does not reconstruct exactly from primitive trace")
    expected_resource = _resource_report(
        SlotSignalingAgent(
            dataclasses.replace(
                run.config.learner,
                writable_lru_ablation=spec.writable_lru_ablation,
            )
        ).init(slot_signaling_keys(jr.key(run.seed_pair.learner_seed))),
        run.final_state,
    )
    if expected_resource != run.resource:
        errors.append("resource report does not match initial/final persistent state")
    if not run.resource.resource_constant or run.resource.final_state_bytes != 552:
        errors.append("condition is not the exact constant 552-byte dyad")
    return tuple(errors)


def validate_hidden_regime_development_payload(payload: Mapping[str, object]) -> tuple[str, ...]:
    """Validate the strict report envelope; trace validation uses in-memory runs.

    This payload validator intentionally does not turn the development report
    into an evidence artifact.  It fail-closes the version/scope/resource and
    paired-comparison envelope, while :func:`validate_hidden_regime_run_result`
    performs exact primitive reconstruction before serialization.
    """

    errors: list[str] = []
    expected = {
        "schema_version",
        "development_only",
        "scientific_promotion_allowed",
        "acceptance_status",
        "claim_thresholds_frozen",
        "artifact_written",
        "reserved_seed_namespace",
        "reserved_namespace_executed",
        "oracle_upper_bound_included",
        "seed_pair",
        "config",
        "condition_order",
        "runs",
        "paired_controls",
    }
    if set(payload) != expected:
        errors.append("report fields do not match the strict v1 schema")
    if payload.get("schema_version") != HIDDEN_REGIME_DEVELOPMENT_SCHEMA:
        errors.append("schema_version mismatch")
    if payload.get("development_only") is not True:
        errors.append("report must remain development-only")
    if payload.get("scientific_promotion_allowed") is not False:
        errors.append("scientific promotion must remain disabled")
    if payload.get("acceptance_status") != ACCEPTANCE_STATUS:
        errors.append("acceptance_status must remain descriptive-only")
    if payload.get("claim_thresholds_frozen") is not False:
        errors.append("development report cannot claim frozen thresholds")
    if payload.get("artifact_written") is not False:
        errors.append("development evaluator cannot write an artifact")
    if payload.get("reserved_seed_namespace") != RESERVED_DEVELOPMENT_SEED_NAMESPACE:
        errors.append("reserved seed namespace mismatch")
    if payload.get("reserved_namespace_executed") is not False:
        errors.append("reserved seed namespace must remain unexecuted")
    if payload.get("oracle_upper_bound_included") is not False:
        errors.append("oracle upper bound is not a learner condition in v1")
    condition_order = payload.get("condition_order")
    runs = payload.get("runs")
    controls = payload.get("paired_controls")
    if not isinstance(condition_order, list) or not condition_order:
        errors.append("condition_order must be a nonempty list")
        condition_order = []
    if not isinstance(runs, list) or len(runs) != len(condition_order):
        errors.append("runs must align exactly with condition_order")
        runs = []
    if isinstance(condition_order, list) and condition_order:
        if condition_order[0] != SELECTIVE_FULL:
            errors.append("selective_full must be the paired reference")
        if len(set(cast(list[str], condition_order))) != len(condition_order):
            errors.append("condition_order contains duplicates")
    if isinstance(runs, list):
        for index, run in enumerate(runs):
            if not isinstance(run, Mapping):
                errors.append(f"run {index} is not a mapping")
                continue
            if index < len(condition_order) and run.get("condition") != condition_order[index]:
                errors.append(f"run {index} condition order mismatch")
            resource = run.get("resource")
            if not isinstance(resource, Mapping):
                errors.append(f"run {index} resource missing")
            elif (
                resource.get("initial_state_bytes") != EXPECTED_DYAD_STATE_BYTES
                or resource.get("final_state_bytes") != EXPECTED_DYAD_STATE_BYTES
                or resource.get("resource_constant") is not True
                or resource.get("resource_matched") is not True
            ):
                errors.append(f"run {index} is not a matched constant 552-byte dyad")
    expected_control_count = max(0, len(condition_order) - 1)
    if not isinstance(controls, list) or len(controls) != expected_control_count:
        errors.append("paired_controls must contain every non-reference condition")
    elif isinstance(condition_order, list):
        expected_names = condition_order[1:]
        actual_names = [
            item.get("condition") if isinstance(item, Mapping) else None for item in controls
        ]
        if actual_names != expected_names:
            errors.append("paired control order does not match condition_order")
        if any(
            not isinstance(item, Mapping)
            or item.get("resource_bytes") != EXPECTED_DYAD_STATE_BYTES
            for item in controls
        ):
            errors.append("paired control resource disclosure mismatch")
    return tuple(errors)


__all__ = [
    "ACCEPTANCE_STATUS",
    "BENEFICIARY_FROZEN",
    "CONSTANT_CHANNEL",
    "CONSTANT_CHANNEL_SYMBOL",
    "DEFAULT_DEVELOPMENT_SEGMENT_LENGTHS",
    "DEVELOPMENT_CANDIDATE_PROVENANCE",
    "DEVELOPMENT_ONLY",
    "EXPECTED_DYAD_STATE_BYTES",
    "HELPER_FROZEN",
    "HIDDEN_REGIME_DEVELOPMENT_SCHEMA",
    "HIDDEN_REGIME_TRACE_SCHEMA",
    "HiddenRegimeDevelopmentConfig",
    "HiddenRegimeDevelopmentReport",
    "HiddenRegimePrimitiveTrace",
    "HiddenRegimeRunResult",
    "HiddenRegimeRunSummary",
    "HiddenRegimeSeedPair",
    "MATCHED_CONDITIONS",
    "RESERVED_DEVELOPMENT_SEED_NAMESPACE",
    "RESERVED_DEVELOPMENT_SEED_NAMESPACE_EXECUTED",
    "SCIENTIFIC_PROMOTION_ALLOWED",
    "SELECTIVE_FULL",
    "SHUFFLED_CHANNEL",
    "WRITABLE_LRU",
    "condition_spec",
    "derive_hidden_regime_seed_pairs",
    "reconstruct_hidden_regime_summary",
    "run_hidden_regime_condition",
    "run_hidden_regime_development",
    "validate_hidden_regime_development_payload",
    "validate_hidden_regime_run_result",
]
