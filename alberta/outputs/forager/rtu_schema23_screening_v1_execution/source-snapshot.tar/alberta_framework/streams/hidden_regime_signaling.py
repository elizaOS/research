# mypy: disable-error-code="call-arg"
"""Continuing ternary hidden-regime signaling world for L1 development.

A helper privately observes one uniform ternary cue and sends one ternary
message.  A beneficiary observes only the delivered message and chooses one
ternary action.  An evaluator-only hidden regime selects a target permutation;
both learners receive only their local input, local action, and common binary
reward.  Regime, target, segment index, and schedule never enter ordinary
observations.

The finite evaluator schedule either repeats or holds its last regime forever,
so the world never terminates or resets.  A bounded schedule cursor continues
after the diagnostic global int32 step counter saturates.  Cue and channel
randomness use named independent streams.  This is a development substrate with no acceptance
threshold, artifact, seed namespace, or performance claim.  Its three-symbol
channel carries only log2(3) bits per step, and a learner with three durable
modules cannot retain an unbounded sequence of incompatible permutations.
"""

from __future__ import annotations

import dataclasses
from typing import Any, Literal

import chex
import jax.numpy as jnp
import jax.random as jr
import numpy as np
from jax import Array
from jaxtyping import Bool, Float, Int, PRNGKeyArray

N_HIDDEN_REGIME_SYMBOLS = 3

DIRECT_TERNARY_CHANNEL: Literal["direct"] = "direct"
CONSTANT_ZERO_TERNARY_CHANNEL: Literal["constant_0"] = "constant_0"
CONSTANT_ONE_TERNARY_CHANNEL: Literal["constant_1"] = "constant_1"
CONSTANT_TWO_TERNARY_CHANNEL: Literal["constant_2"] = "constant_2"
SHUFFLED_TERNARY_CHANNEL: Literal["shuffled"] = "shuffled"

type HiddenRegimeChannel = Literal[
    "direct",
    "constant_0",
    "constant_1",
    "constant_2",
    "shuffled",
]

HIDDEN_REGIME_CHANNELS: tuple[HiddenRegimeChannel, ...] = (
    DIRECT_TERNARY_CHANNEL,
    CONSTANT_ZERO_TERNARY_CHANNEL,
    CONSTANT_ONE_TERNARY_CHANNEL,
    CONSTANT_TWO_TERNARY_CHANNEL,
    SHUFFLED_TERNARY_CHANNEL,
)

# Stable named tags are part of the world contract.  New random consumers must
# receive a new tag rather than positionally splitting either existing stream.
_CUE_RNG_TAG = 0x48524355  # ASCII "HRCU"
_CHANNEL_RNG_TAG = 0x48524348  # ASCII "HRCH"

DEFAULT_REGIME_PERMUTATIONS: tuple[tuple[int, int, int], ...] = (
    (0, 1, 2),  # A
    (1, 2, 0),  # B
    (1, 0, 2),  # C-old
    (2, 1, 0),  # C-new
    (0, 2, 1),  # D-transient
)
DEFAULT_SEGMENT_REGIMES: tuple[int, ...] = (
    0,
    1,
    0,
    2,
    1,
    0,
    2,
    0,
    1,
    3,
    0,
    1,
    3,
    4,
    0,
    1,
    3,
)
DEFAULT_SEGMENT_LENGTHS: tuple[int, ...] = (
    64,
    72,
    56,
    64,
    72,
    64,
    56,
    72,
    64,
    64,
    56,
    72,
    64,
    16,
    72,
    56,
    64,
)


@dataclasses.dataclass(frozen=True)
class HiddenRegimeWorldConfig:
    """Evaluator-owned schedule and target permutations.

    Segment identities and boundaries are never emitted by :meth:`observe`.
    ``repeat_schedule=False`` makes the final regime persist indefinitely;
    ``True`` repeats the complete evaluator schedule without resetting state.
    """

    segment_lengths: tuple[int, ...] = DEFAULT_SEGMENT_LENGTHS
    segment_regimes: tuple[int, ...] = DEFAULT_SEGMENT_REGIMES
    regime_permutations: tuple[tuple[int, int, int], ...] = DEFAULT_REGIME_PERMUTATIONS
    repeat_schedule: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.segment_lengths, tuple) or not self.segment_lengths:
            raise ValueError("segment_lengths must be a nonempty tuple")
        if any(type(length) is not int or length < 1 for length in self.segment_lengths):
            raise ValueError("segment_lengths must contain positive integers")
        if sum(self.segment_lengths) > np.iinfo(np.int32).max:
            raise ValueError("total schedule length must fit int32")
        if not isinstance(self.segment_regimes, tuple) or len(self.segment_regimes) != len(
            self.segment_lengths
        ):
            raise ValueError("segment_regimes must match segment_lengths")
        if not isinstance(self.regime_permutations, tuple) or not self.regime_permutations:
            raise ValueError("regime_permutations must be a nonempty tuple")
        for permutation in self.regime_permutations:
            if (
                not isinstance(permutation, tuple)
                or len(permutation) != N_HIDDEN_REGIME_SYMBOLS
                or tuple(sorted(permutation)) != tuple(range(N_HIDDEN_REGIME_SYMBOLS))
            ):
                raise ValueError("every regime permutation must contain exactly 0, 1, 2")
        if any(
            type(regime) is not int or regime < 0 or regime >= len(self.regime_permutations)
            for regime in self.segment_regimes
        ):
            raise ValueError("segment_regimes contains an invalid regime index")
        if type(self.repeat_schedule) is not bool:
            raise ValueError("repeat_schedule must be boolean")

    @property
    def total_schedule_steps(self) -> int:
        """Return the finite evaluator schedule length before repeat/hold."""

        return sum(self.segment_lengths)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-compatible development-only world definition."""

        return {
            "segment_lengths": list(self.segment_lengths),
            "segment_regimes": list(self.segment_regimes),
            "regime_permutations": [list(row) for row in self.regime_permutations],
            "repeat_schedule": self.repeat_schedule,
            "total_schedule_steps": self.total_schedule_steps,
            "development_only": True,
            "scientific_promotion_allowed": False,
        }


@chex.dataclass(frozen=True)
class HiddenRegimeWorldKeys:
    """Named independent random streams owned only by the world."""

    cue: PRNGKeyArray
    channel: PRNGKeyArray


def hidden_regime_world_keys(root_key: Array) -> HiddenRegimeWorldKeys:
    """Derive stable cue/channel streams without positional coupling."""

    return HiddenRegimeWorldKeys(
        cue=jr.fold_in(root_key, _CUE_RNG_TAG),
        channel=jr.fold_in(root_key, _CHANNEL_RNG_TAG),
    )


@chex.dataclass(frozen=True)
class HiddenRegimeObservation:
    """The helper's sole ordinary pre-message observation."""

    helper_cue: Int[Array, ""]


@chex.dataclass(frozen=True)
class HiddenRegimeWorldState:
    """Fixed-shape continuing state with a bounded evaluator schedule cursor."""

    cue_key: PRNGKeyArray
    channel_key: PRNGKeyArray
    cue: Int[Array, ""]
    step_count: Int[Array, ""]
    schedule_position: Int[Array, ""]


@chex.dataclass(frozen=True)
class HiddenRegimeOracle:
    """Evaluator-only facts forbidden from either learner policy."""

    step_count: Int[Array, ""]
    segment_index: Int[Array, ""]
    segment_step: Int[Array, ""]
    regime_id: Int[Array, ""]
    target: Int[Array, ""]


@chex.dataclass(frozen=True)
class HiddenRegimeTransition:
    """One continuing ternary signaling transition."""

    observation: HiddenRegimeObservation
    helper_message: Int[Array, ""]
    delivered_message: Int[Array, ""]
    beneficiary_action: Int[Array, ""]
    reward: Float[Array, ""]
    next_observation: HiddenRegimeObservation
    terminated: Bool[Array, ""]
    discount: Float[Array, ""]
    oracle: HiddenRegimeOracle


class HiddenRegimeSignalingWorld:
    """Pure-JAX continuing world with aliased hidden regimes."""

    def __init__(self, config: HiddenRegimeWorldConfig | None = None) -> None:
        self._config = config or HiddenRegimeWorldConfig()
        self._segment_ends = jnp.asarray(
            np.cumsum(self._config.segment_lengths),
            dtype=jnp.int32,
        )
        self._segment_regimes = jnp.asarray(
            self._config.segment_regimes,
            dtype=jnp.int32,
        )
        self._permutations = jnp.asarray(
            self._config.regime_permutations,
            dtype=jnp.int32,
        )

    @property
    def config(self) -> HiddenRegimeWorldConfig:
        """Return the evaluator-only static world configuration."""

        return self._config

    def schedule_position_of(self, step_count: Array) -> Array:
        """Map a global step into the finite schedule without exposing it."""

        step = jnp.asarray(step_count, dtype=jnp.int32)
        if self._config.repeat_schedule:
            return step % self._config.total_schedule_steps
        return jnp.minimum(
            step,
            jnp.asarray(self._config.total_schedule_steps - 1, dtype=jnp.int32),
        )

    def segment_index_of(self, step_count: Array) -> Array:
        """Return evaluator-only segment index for a global step."""

        position = self.schedule_position_of(step_count)
        return self._segment_index_at(position)

    def _segment_index_at(self, schedule_position: Array) -> Array:
        """Return the segment index for an already bounded world cursor."""

        position = jnp.asarray(schedule_position, dtype=jnp.int32)
        return jnp.sum(position >= self._segment_ends).astype(jnp.int32)

    def segment_step_of(self, step_count: Array) -> Array:
        """Return evaluator-only offset within the current finite segment."""

        position = self.schedule_position_of(step_count)
        return self._segment_step_at(position)

    def _segment_step_at(self, schedule_position: Array) -> Array:
        """Return the within-segment offset for an already bounded cursor."""

        position = jnp.asarray(schedule_position, dtype=jnp.int32)
        segment = self._segment_index_at(position)
        previous_end = jnp.where(
            segment == 0,
            jnp.asarray(0, dtype=jnp.int32),
            self._segment_ends[jnp.maximum(segment - 1, 0)],
        )
        return (position - previous_end).astype(jnp.int32)

    def regime_of(self, step_count: Array) -> Array:
        """Return evaluator-only hidden regime index."""

        return self._regime_at(self.schedule_position_of(step_count))

    def _regime_at(self, schedule_position: Array) -> Array:
        """Return the hidden regime for an already bounded world cursor."""

        return self._segment_regimes[self._segment_index_at(schedule_position)]

    def target_of(self, step_count: Array, cue: Array) -> Array:
        """Return evaluator-only target action for one hidden regime and cue."""

        return self._target_at(self.schedule_position_of(step_count), cue)

    def _target_at(self, schedule_position: Array, cue: Array) -> Array:
        """Return the target for an already bounded world cursor."""

        return self._permutations[
            self._regime_at(schedule_position),
            jnp.asarray(cue, dtype=jnp.int32),
        ]

    def _next_schedule_position(self, schedule_position: Array) -> Array:
        """Advance the bounded cursor without integer overflow."""

        position = jnp.asarray(schedule_position, dtype=jnp.int32)
        final_position = jnp.asarray(
            self._config.total_schedule_steps - 1,
            dtype=jnp.int32,
        )
        if self._config.repeat_schedule:
            return jnp.where(
                position == final_position,
                jnp.asarray(0, dtype=jnp.int32),
                position + jnp.asarray(1, dtype=jnp.int32),
            )
        return jnp.where(
            position < final_position,
            position + jnp.asarray(1, dtype=jnp.int32),
            position,
        )

    @staticmethod
    def _next_step_count(step_count: Array) -> Array:
        """Saturate the diagnostic global counter at the int32 maximum."""

        step = jnp.asarray(step_count, dtype=jnp.int32)
        maximum = jnp.asarray(np.iinfo(np.int32).max, dtype=jnp.int32)
        return jnp.where(
            step < maximum,
            step + jnp.asarray(1, dtype=jnp.int32),
            step,
        )

    def init(self, keys: HiddenRegimeWorldKeys) -> HiddenRegimeWorldState:
        """Sample the first cue and initialize a continuing global step."""

        cue_draw_key, next_cue_key = jr.split(keys.cue)
        cue = jr.randint(
            cue_draw_key,
            (),
            0,
            N_HIDDEN_REGIME_SYMBOLS,
            dtype=jnp.int32,
        )
        return HiddenRegimeWorldState(
            cue_key=next_cue_key,
            channel_key=keys.channel,
            cue=cue,
            step_count=jnp.asarray(0, dtype=jnp.int32),
            schedule_position=jnp.asarray(0, dtype=jnp.int32),
        )

    def observe(self, state: HiddenRegimeWorldState) -> HiddenRegimeObservation:
        """Return the ordinary observation, containing only the private cue."""

        return HiddenRegimeObservation(helper_cue=state.cue)

    def deliver(
        self,
        state: HiddenRegimeWorldState,
        helper_message: Array,
        channel: HiddenRegimeChannel,
    ) -> Array:
        """Resolve a ternary channel without advancing any world stream."""

        if channel == DIRECT_TERNARY_CHANNEL:
            return jnp.asarray(helper_message, dtype=jnp.int32)
        if channel == CONSTANT_ZERO_TERNARY_CHANNEL:
            return jnp.asarray(0, dtype=jnp.int32)
        if channel == CONSTANT_ONE_TERNARY_CHANNEL:
            return jnp.asarray(1, dtype=jnp.int32)
        if channel == CONSTANT_TWO_TERNARY_CHANNEL:
            return jnp.asarray(2, dtype=jnp.int32)
        if channel == SHUFFLED_TERNARY_CHANNEL:
            draw_key, _ = jr.split(state.channel_key)
            return jr.randint(
                draw_key,
                (),
                0,
                N_HIDDEN_REGIME_SYMBOLS,
                dtype=jnp.int32,
            )
        raise ValueError(f"unknown hidden-regime channel: {channel!r}")

    def step(
        self,
        state: HiddenRegimeWorldState,
        helper_message: Array,
        beneficiary_action: Array,
        channel: HiddenRegimeChannel = DIRECT_TERNARY_CHANNEL,
    ) -> tuple[HiddenRegimeTransition, HiddenRegimeWorldState]:
        """Apply a message/action pair and advance without termination."""

        delivered = self.deliver(state, helper_message, channel)
        return self.step_with_delivery(
            state,
            helper_message,
            delivered,
            beneficiary_action,
        )

    def step_with_delivery(
        self,
        state: HiddenRegimeWorldState,
        helper_message: Array,
        delivered_message: Array,
        beneficiary_action: Array,
    ) -> tuple[HiddenRegimeTransition, HiddenRegimeWorldState]:
        """Advance using an already resolved evaluator-declared channel output."""

        observation = self.observe(state)
        delivered = jnp.asarray(delivered_message, dtype=jnp.int32)
        action = jnp.asarray(beneficiary_action, dtype=jnp.int32)
        segment = self._segment_index_at(state.schedule_position)
        regime = self._regime_at(state.schedule_position)
        target = self._target_at(state.schedule_position, observation.helper_cue)
        reward = (action == target).astype(jnp.float32)

        cue_draw_key, next_cue_key = jr.split(state.cue_key)
        next_cue = jr.randint(
            cue_draw_key,
            (),
            0,
            N_HIDDEN_REGIME_SYMBOLS,
            dtype=jnp.int32,
        )
        _, next_channel_key = jr.split(state.channel_key)
        next_state = HiddenRegimeWorldState(
            cue_key=next_cue_key,
            channel_key=next_channel_key,
            cue=next_cue,
            step_count=self._next_step_count(state.step_count),
            schedule_position=self._next_schedule_position(state.schedule_position),
        )
        transition = HiddenRegimeTransition(
            observation=observation,
            helper_message=jnp.asarray(helper_message, dtype=jnp.int32),
            delivered_message=delivered,
            beneficiary_action=action,
            reward=reward,
            next_observation=self.observe(next_state),
            terminated=jnp.asarray(False),
            discount=jnp.asarray(1.0, dtype=jnp.float32),
            oracle=HiddenRegimeOracle(
                step_count=state.step_count,
                segment_index=segment,
                segment_step=self._segment_step_at(state.schedule_position),
                regime_id=regime,
                target=target,
            ),
        )
        return transition, next_state
